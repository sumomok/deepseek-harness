# @haoran/dsh-screenshot

[English](README.md) | 中文

DeepSeek Harness 的 `screenshot` 工具:用无头浏览器渲染一个页面,把像素作为 image 块返回,于是 agent 可以直接看页面,而不是靠源码推断它。需要登录才能看到的页面,在本人于桌面外壳打开的窗口里登录一次之后照常截图。

## 一个 agent 为什么需要它

写 HTML、CSS 或组件的 agent 是盲的。它可以把自己写下的每一个字节都读回来,仍然不知道两个元素叠在了一起、某个颜色在它的背景上根本看不清、或者布局在它被要求的宽度下垮掉了。源码不是外观,把源码再读多少遍也不会把一个变成另一个。

同样的盲区也适用于不是 agent 写的系统。给一个正在运行的应用写文档、检查某个部署实际显示成什么样、给手册配图——都需要页面的像素,而这类页面多半在登录之后。一次拍回来是登录墙的截图,会变成向本人提的一个问题:本人在桌面外壳打开的窗口里登录一次,登录状态留在他自己的机器上,这次截图随后用它重拍。`cookieJar` 是另一条路,给的是有人手工导出的会话:cookie 值放在本部署的配置里,模型自始至终只念得出 jar 的名字。`headers` 携带 bearer token,`outputPath` 把 PNG 按 agent 起的名字落到磁盘上,于是这张截图可以进文档,而不只是进对话。

`screenshot` 把这个回路闭上:渲染页面、看它、用它。工具描述就是用模型读到的原话这么写的,插件还向系统提示词贡献一行——`Use the screenshot tool to look at any page as pixels …`——因为模型想不到去调的工具等于不存在,而没人重读的 schema 里的参数不算一种能力。

当前模型必须接受图像输入。在纯文本路由上工具会拒绝,而不是返回图像:工具结果会进入持久会话历史,之后该会话的每一次请求都要带着它。

## 安装

```sh
pnpm run build
cd packages/screenshot && pnpm pack --pack-destination ../../dist
dsh plugin --profile <name> add ../../dist/haoran-dsh-screenshot-0.5.0.tgz
```

manifest 声明了 `dsh.bundle.patch`,所以安装会把这个包追加进 profile 的 `dsh.profile.bundles`,由它的 patch 层挂载插件。除非要改某个默认值,profile 自己的 `cordis.patch.yml` 里不需要加任何东西。

只有在挂载了附件存储时工具才注册——每个已发布的应用 bundle 都挂了一个——因为它返回的 image 块必须引用已持久提交的字节。

## 工具

```
screenshot(url, width?, height?, fullPage?, delayMs?, headers?, cookieJar?, outputPath?, timeoutMs?, onTimeout?, blockHosts?)
```

| 参数 | 默认值 | 含义 |
| --- | --- | --- |
| `url` | 必填 | `http(s)://` URL、`file://` URL,或一个 `.html` 文件的绝对路径。 |
| `width` | `defaultWidth` | 视口宽度(px)。返回的图像正好是这个宽度。 |
| `height` | `defaultHeight` | 视口高度(px)。 |
| `fullPage` | `false` | 拍整个可滚动页面,而不是视口。 |
| `delayMs` | `defaultDelayMs` | 加载完成后的额外等待,给动画或脚本用。 |
| `headers` | 无 | 页面请求的额外 HTTP 头,写成名到字符串值的映射。`Cookie:` 头会被拒绝并指向 `cookieJar`。 |
| `cookieJar` | 无 | `cookieJars` 下配置的某个 jar 的名字。模型点名 jar,cookie 永远不出现在参数里。 |
| `outputPath` | 无 | 同时把 PNG 写到这里,绝对路径或相对于会话工作区的路径,且必须留在工作区内。 |
| `timeoutMs` | `timeoutMs` | 这次渲染最长可以花多久,从 1000 起。桌面渲染服务对超过 120000 的值直接拒绝,而不是替你缩短。 |
| `onTimeout` | `onTimeout` | `capture` 返回截止时刻已经画出来的东西,并标记为局部截图;`fail` 返回错误。 |
| `blockHosts` | `blockHosts` | 本次渲染要取消其请求的主机,每项是一个精确主机或 `*.suffix`。页面自己的主机不能被屏蔽。 |

没有登录相关的参数,也不会加。一次截图能不能用本机持有的登录身份,是从页面自己的 URL 推出来、由本人回答的,永远不由调用点名。

结果在图像旁边带一个 `render` 字段:渲染器产出的报告;后端不产报告时为 `null`;报告头这个客户端读不懂时为 `"unreadable"`。`partial` 说明这些像素是不是一个尚未加载完的页面,`loginNote` 说明登录流程对这次截图做了什么,什么都没做时该字段不存在。本人在登录卡片上取消掉的截图,返回的是 `{ url, cancelled: true, note }`,没有图像,也没有任何描述这个页面的东西。

绝对路径会变成 `file://` URL。相对路径会被拒绝:浏览器会拿它相对自己的工作目录去解析,而不是相对 agent 的,于是渲染出来的会是另一个文件,或者什么都没有。除 `http`、`https`、`file` 之外的每一种 scheme 都会被指名拒绝。

超出范围的 `width`、`height` 或 `delayMs` 是参数错误,而不是被夹回范围内的值。模型要求看的是一个具体的视口;悄悄渲染另一个,会让它对一个它从没见过的页面下结论。

结果是两块内容:一个信封,写明 URL、图像尺寸、字节数和画它的引擎,后面跟着图像本身。

```
<url>file:///tmp/page.html</url>
<type>image</type>
<content>
image/png image, 1024x768 px, 24631 bytes (renderer: chrome)
</content>
```

之所以点名引擎,是因为下面两个后端画出来的像素并不完全一致,而拿同一个页面的两张截图做比较的模型,需要知道自己是不是同时在比较两个渲染器。

## 这次渲染做了什么

桌面渲染服务会报告它执行的每一次渲染,工具把这份报告变成图像旁边至多两行。跑完的页面一行就说完了:

```
image/png image, 1440x900 px, 61233 bytes (renderer: desktop)
render: complete in 1.8s · main document 200 · 31 requests, 0 failed
```

超时的页面会说它在等什么,以及下次该带什么参数再调。标记放在最前面,因为把局部截图当成完成的页面来读,得出的是「这个页面渲染错了」,比完全没有截图更糟:

```
render: TIMED OUT after 25s — this image is what had painted, not the finished page. main document 200 ("Issues - Redmine"), load event not fired. 63 requests: 41 done, 0 failed, 22 pending for 21s, all on www.gravatar.com. If that host is not needed, call again with blockHosts: ["www.gravatar.com"]; or raise timeoutMs (ceiling 120s).
image/png image, 1440x900 px, 61233 bytes (renderer: desktop)
console: 1 error, 1 warning — "Failed to load resource: net::ERR_CONNECTION_TIMED_OUT"
```

被服务拒绝的渲染说的和工具错误是同一件事,只是没有图像:

```
the desktop renderer refused to render https://intranet.example.test/board (HTTP 500) — render: FAILED after 0.1s. no main document, load event not fired. 1 request: 0 done, 1 failed. main frame did not load: ERR_NAME_NOT_RESOLVED (-105).
```

每一个子句都是有界的,而顺序本身就是要点:先结果,再页面做了什么,再该换什么参数调,最后单独一行放 console 采样——唯一一个内容由页面自己写的子句。图像旁边的摘要在所有子句齐全、每个值都超过上限时至多 647 个字符;失败形式还会打印落地 URL 和会话重试建议,至多 718。这个界由主机名定:渲染服务按 96 个字符报告一个主机,它被打印两次——作为事实时裁到 48,放进 `blockHosts` 模式时保持完整,因为那个模式会被抄进下一次调用,裁过的主机什么都匹配不到。页面变大,它一点都不会变大。这个顺序也是外壳自己的超时行文遵守的规则:把无界子句打印在建议之后,会把建议一起带走,而且恰好发生在最需要建议的那几次渲染上。

渲染服务自己不得不裁掉的主机,只作为事实点名,永不作为模式给出:裁过的主机抄进下一次调用什么也屏蔽不了,所以那种渲染给出的是 `Raise timeoutMs (ceiling 120s).`。

只有桌面渲染服务会产出报告。系统浏览器拍的截图带 `render: null`,没有摘要行,因为一次性的 `--screenshot` 命令行没有承载它的通道。

## 登录之后才能看到的页面

一次拍回来是登录墙的截图,最多变成一个问题,再最多变成一次截图。模型做的是对一个 URL 调 `screenshot`;此后的一切都属于本人。已经产出像素的渲染绝不会因为登录而失败——登录墙是关于这个页面的事实,被告知自己在看什么的模型可以据此行动,而一个错误关于这个站点什么都没说。

**登录墙是从渲染已经报告过的内容里读出来的**,所以正常加载的页面不花任何代价,遇到墙也不多花一次请求。三个信号,任意一个成立即为登录墙:

- 主框架停在了另一个可注册域上。把匿名访问者送去自己身份提供方的页面,是最常见的情形。
- 主框架停在同一站点、路径命中 `loginPathPatterns`。这一条只针对渲染并未要求过的落地位置去读:一次要求 `/login` 的调用就是要看登录页,为它弹一张卡片是在和调用方抬杠。
- 主文档回了 `401` 或 `403`。拒绝而不重定向的站点,以及自身文档就被拒的 API 驱动页面,都落在这里。

登录被归档到哪个站点,取决于**被要求的**那个页面的可注册域,永远不是落地位置的,所以经由另一个域上的身份提供方兜一圈,登录状态仍然记在把渲染送过去的那个站点名下。

**两张卡片,各有一个表示「是」的标签。** 本机尚未持有登录的站点,问的是「截取 <url> 需要先登录 <domain>。」,给出三个选择:【去登录】、【截当前】、【取消】。【去登录】 带着这张卡片唯一的承诺——「登录状态只保存在这台电脑上,仅用于截图」——另外两个不带任何说明,因为它们都不保存任何东西。本机已经持有登录的站点给出 【允许】 与 【取消】。两张卡片都带标题「截图登录」,并把裸域名作为 detail,于是自己渲染这类卡片的 UI 可以把站点单独占一行显示,而句子点的是完整 URL。

【取消】 在两张卡片上是两回事,靠问题 id 而不是靠这个词来区分。在复用卡片上它是拒绝:已经拍到的未登录截图照样返回,并附一句话说明。在登录卡片上它是取消:这次截图被丢掉,结果只有一句话,没有任何图像。

这个包的浏览器端就是这样一个 UI:它在标准问答流程之前注册一个输入框条目,只认领这两个问题、把它们画成自己的卡片,其余问题原地不动。没有加载这一端的地方——终端、自动化客户端、没装它的 Web 界面——标准流程会用同样的标签问同样的问题,两种情况下答案的编码完全一致。

除了精确按下那个授权标签一次以外,任何回答都是「否」:跳过问题、打字写的自由文本、另一个标签、多一个尾随空格的标签、选了不止一项、以及回答的是这张卡片没问的问题。`ctx.userQuestions.ask()` 的通用问答流程总会在调用方给出的选项旁边附上「跳过」和一个自由文本框,所以空回答和写出来的回答都是人能产生的东西——而它们都不是「本人按下了交出自己会话的那个按钮」。这类回答一律落在 【截当前】 上,保留已经拍到的那张截图;把那张截图丢掉,只有 【取消】 这个标签自己能做出这个决定。

**这个问题问的是人,永远不问模型。** user-questions 缝只有单一在册 provider,前面没有瀑布,所以任何自动批准工具调用的东西都答不了这类卡片;而且 `ask()` 会拒绝不是注册表中那个确切存活运行时根的调用方。于是子代理拿到的是未登录的截图,外加一句话,告诉它把登录墙写进自己的结果、让拥有这场对话的 agent 去截。完全没有问答通道的部署、背后没有对话的调用、以及已经不再存活的运行时,各自有各自的一句话,因为补救办法不同,而读它的是一个正在决定下一步的模型。

**分区键在这一侧算出,并且永远不是工具参数。** 一份已保存的登录存在 `persist:dsh-render-login-<可注册域>` 里,域名由 `tldts` 从页面自己的 URL 上答出。能点名分区的模型,就能要求用某人在一个与本次调用毫不相干的站点上的会话来截图,而那个人回答的卡片说的是另一个站点。域名是公共后缀问题,不是字符串后缀问题:`example.co.uk` 和 `other.co.uk` 是两个站点,取末尾两段的规则会把所有 `co.uk` 的登录塞进同一个共享存储。

**窗口是外壳的,而且只在授权之后才打开。** 对尚无登录的站点,插件向外壳申请一个只对该页面和该分区有效的一次性 nonce,用它打开一个可见窗口,等本人关闭它;然后在那个分区里重新渲染该页面。对本机已经持有登录的站点,什么都不会打开——复用卡片就是全部的问题,第二次渲染紧随其后。两条路上插件都只送出一个 URL、一个分区和一个 nonce,读回一个落地位置;这条线上两个方向都不经过任何 cookie。

**四种情况让整套流程完全不介入**,都在问任何人之前就已判定:

- 部署把 `loginConsent` 设成了 `false`。
- 截图来自系统浏览器,它既不报告落地位置也不报告主文档回了什么,没有可以据以判断登录墙的材料。
- 调用自带了 `cookieJar`。调用方已经提供了会话,此时的墙意味着那个 jar 过期了,该由调用方去修。
- 页面没有可注册域——`file:` URL、IP 字面量、开发用主机——没有可以归档登录的站点。

**结果里写什么。** `loginNote` 带一句话,信封把它打印在尺寸行之前、也在局部截图标记之前:等读到后面才知道自己看的是登录页的读者,早就已经对这个站点下了结论。

| 路径 | `loginNote` 说什么 |
| --- | --- |
| 已登录,窗口打开过 | 本人在外壳打开的窗口里登录了该站点,这次截图用的是那个会话,之后对该站点的截图会先问再复用。 |
| 复用已保存的登录 | 本人允许这次截图使用本机保存的登录。 |
| 拒绝——登录卡片上的 截当前、复用卡片上的 取消,或任何不是这张卡片标签的回答 | 本人拒绝了,后面跟着点明登录墙的那句话。 |
| 没有人可问 | 为什么这个问题问不出去,后面跟着点明登录墙的那句话。 |
| 登录窗口没能走完 | 外壳拒绝了什么,后面跟着点明登录墙的那句话。 |
| 登录了但仍然是墙 | 两句话:授权了什么,以及窗口是在未完成登录的情况下被关掉的、或者登录的这个账号看不到这个页面。 |
| 没有墙,或命中上面四种情况之一 | 什么都不写,该字段不存在。 |

点明登录墙的那句话,正是阻止把像素当成页面来读的那一句:`This image is a sign-in wall, not the page that was asked for … No stored login was used, so do not read the pixels as the requested page.`

**被取消的截图没有 `loginNote`,因为它没有可以附注的结果。** 按下 【取消】 会在图像被保存或写到任何地方之前就返回:工具答的是 `{ url, cancelled: true, note }`,模型只看到那一句话——`The user cancelled this capture; no image was taken.`——没有任何东西描述这个页面。尺寸、落地位置或渲染报告,每一个都会招来同一次调用只改一个参数再来一遍,而这正是取消要终结的重试循环。声明出去的输出 schema 就是这两种结果的联合,它们之间除了 `url` 没有共同字段。

## 管理已保存的登录

两个入口,**都不是工具**。它们能做的是读出哪些站点有登录,以及抹掉一个;而后者是本人对自己会话的决定。

**设置页。** 这个包的浏览器端注册一个设置分节,列出已保存的站点并可登出其中一个。它经由本包自己的 Typert Remote 到达宿主,该 Remote 由 harness 的 typert loader 从 `exports["./typert"]` 发现——插件以自己的包名出现在 Loader 条目里,就是全部的注册手续——并且分节只在该 Remote 挂载成功之后才注册,因为一个没有东西可读的页面比没有这个页面更糟。Remote 只投影两个动词,没有第三个:`list` 给出已保存的站点、它们的两个时间戳,以及是否有外壳可供登出;`forget` 抹掉一个。没有任何一个动词会返回 cookie,而且从这一侧也加不出来——值在 Chromium 自己的存储里。

**`/screenshot-logout <domain>`。** 斜杠命令之所以是第二个入口,是因为它可证明是人:命令从不进入工具目录,它的 run 与 done 记录只进日志、不是模型可见面,而 `/` 平面是从人的输入框进入的。它接受 `github.com`、`www.github.com` 或一整个 URL,三者都经由构建分区键所用的同一份公共后缀答案来读,于是它抹掉的正是设置页列出的那一项。不带参数时,它说出本机持有哪些。只有在挂载了命令注册表的地方它才注册。

登出先问外壳、再改索引,于是抹除失败时条目仍然可见,而不是把一份还在的登录藏起来。本机从未记录过的域名同样会送给外壳——索引是这个插件自己的记事本,分区才是真相,知道这个站点的人无论如何都应该能清掉它。在没有配置渲染服务的部署上,登出会被指名拒绝,因为登录存在外壳里。

## 一次登录留下了什么

**cookie 值只存在于一个地方**:桌面外壳 userData 目录里、Chromium 自己的加密 profile 存储。渲染服务的任何一条路由都不返回它,三条登录路由的任何一个字段都不把它带回来,这个插件里也没有任何东西有办法去要它——服务没有、它的 Typert Remote 没有、工具也没有。

**这个插件自己的索引里只有一个域名和两个时间戳。** 它位于 `$DSH_HOME/dsh-screenshot/logins.json`,以 `0600` 写入、目录以 `0700` 创建,条目就是站点、创建它的登录窗口关闭的时刻、以及最近一次截图用到它的时刻。这里不写任何 cookie、token、请求头或 URL。它刻意不是真相来源——外壳的分区才是——所以这份构建读不懂的文件从空列表开始,代价是一次登录窗口,而不是一次失败的截图;落不下去的写入报到宿主日志,而不是报给模型。

**除了域名之外,登录的任何信息都不会进入会话日志、工具结果或模型请求。** `loginNote` 点明站点和决定;分区在 harness 进程内算出,只出现在发往外壳的请求体里,别处没有。

**宿主重启会丢掉一张打开着的卡片。** 一张同意卡片就是一次被阻塞的工具调用。客户端重新加载会重放待答的问题,所以关掉标签页再打开,卡片会回到本人面前。卡片开着时宿主进程重启则不然:这次工具调用会以一个通用的「被中断的工具结果」收场,那张卡片再也不会出现,这次截图就这么没了。模型可以再调一次 `screenshot`,流程从头开始。

**多人连着同一个部署时,这个功能不是多用户安全的。** 卡片会广播给每一个已连接的客户端,先答的赢——谁先回答,谁就决定要不要在持有外壳的那台机器上打开登录窗口、以及要不要用那里已经保存的会话去截图。给每个人各自一份 harness,或者在多人观看的部署上把 `loginConsent` 设成 `false`。完全没有渲染服务的部署根本走不到卡片这一步,因为这套流程需要桌面后端。

## 手工导出的会话

`cookieJar` 是给「不会有人去交互式登录」的会话准备的入口:从浏览器导出来的那种,或者部署为某个服务账号持有的那种。

**cookie 是配置出来的,不是传进来的。** cookie 值是一份持有即用的凭据,而模型作为工具参数写下的任何东西,都会写进会话日志、写进该会话之后的每一次模型请求、以及此后读这份记录的一切。所以这些值放在 `cordis.yml` 的 `cookieJars` 下,每个 jar 一个名字,工具取的是 `cookieJar: "<name>"`。插件在持有配置的那个进程里解析这个名字,通过 loopback 把 cookie 送给渲染器;任何 cookie 值都不会出现在结果里、不会写进日志、也不会被引进错误信息——关于 cookie 的拒绝只点名它的 jar 和它的位置,绝不说里面是什么。

```yaml
- id: screenshot
  name: '@haoran/dsh-screenshot'
  config:
    cookieJars:
      redmine:
        cookies:
          - name: _redmine_session
            value: '…'
            domain: redmine.internal.test
            path: /
            httpOnly: true
      grafana:
        cookies:
          - { name: grafana_session, value: '…', domain: grafana.internal.test, secure: true }
```

| 成员 | 默认值 | 含义 |
| --- | --- | --- |
| `name` | 必填 | cookie 的名字,一个 HTTP token。 |
| `value` | 必填 | 凭据本身。它只到渲染器,不到别处。 |
| `domain` | 必填 | 它所属的主机,带不带前导点都可以;它覆盖该主机的子域。 |
| `path` | `/` | 它会被发送的路径前缀。 |
| `secure` | `false` | 只在 https 上发送。 |
| `httpOnly` | `false` | 不让页面自己的脚本读到它。 |
| `expirationDate` | 无 | 自纪元起的秒数。不写就是会话 cookie,而那正是渲染想要的。 |

jar 的名字由字母、数字、点、短横或下划线组成,并且它是模型能看到的 jar 的唯一部分:工具的 `cookieJar` 描述列出已配置的名字好让模型够得着,除此之外什么都不列。不认识的名字会被拒绝——`cookieJar "x" is not configured; add it under cookieJars in the plugin config`——而不是渲染成未登录的样子;这条拒绝也不会列出本机确实有哪些 jar,因为它同样会进会话日志。每个 jar 都在加载时按渲染服务强制的同一套语法校验,于是拼错的域名在部署启动时就报错,而不是在某人急需的那次截图上。

`domain` 是每个 cookie 各自的作用域,所以一个 jar 装得下页面会访问的每一个主机的 cookie——应用主机加它的 API 主机是最常见的情形。`path` 默认为 `/`,而不是 RFC 6265 的 default-path(即 cookie 被存下时所在的目录):留在 `/app/issues/` 的 cookie 到不了页面发出的任何 `/api/…` 请求,而一个数据全部 401 的已登录页面,不是任何人想看的那个页面。

`headers` 仍然只做请求头该做的事——bearer token、主机覆盖——并且只跟着主框架导航。`Cookie:` 头会被指名拒绝并指向 `cookieJar`,因为写在那里的 cookie 就是写进会话日志的 cookie,而这正是 jar 存在的全部理由。

**每次渲染各有自己的 cookie 存储。** 桌面外壳在一个窗口里渲染,其会话分区为这次请求创建、只存在于内存、随窗口销毁。一次渲染的 cookie 读不到下一次渲染那里,也没有任何东西写到磁盘上。唯一的例外是获得授权的登录之后的第二次渲染,它跑在该站点的登录分区里;带分区的请求不带 `cookies`,所以 jar 永远不会被写进一个比它自己的请求活得更久的存储。

**只有桌面后端能携带它们。** 用 `--headless=new --screenshot` 启动的系统浏览器没有办法设置 cookie 或请求头,所以在那里带着 `cookieJar` 或 `headers` 的调用会被拒绝、并说明该后端做不到什么,而不是把页面渲染成未登录、再把登录界面当成请求的页面返回。

同一条拒绝还覆盖该后端同样无法兑现的两个参数:`blockHosts`,因为命令行取消不了页面发出的请求;以及 `onTimeout: "capture"`,因为那个浏览器只在页面跑完之后才写 PNG。两者都是拒绝而不是忽略。被悄悄丢掉的补救措施会以原样再失败一次,而答复里没有任何东西说明这个补救根本没运行——调用方就是这样一遍又一遍地重复施用它的。`onTimeout` 的拒绝只对自己点名了 `capture` 的调用触发;部署默认值不是某次调用要求的东西,所以它永远不会让系统浏览器的截图失败。该后端同样拒绝带已保存登录的渲染——只有当外壳的渲染服务在「发现登录墙的那次截图」与「本人批准的那次截图」之间消失时才会走到这里:在有人刚刚批准了一次登录截图之后拿回一张未登录的截图,正是同意机制要防的那种混淆。

**渲染跑到别处去了会说出来。** 当桌面外壳报告主框架停在了请求之外的 URL 上时,信封多一行:

```
image/png image, 1440x900 px, 61233 bytes (renderer: desktop)
The main frame ended at http://10.0.0.4:30010/login?back_url=/issues, not the requested URL: the site redirected the render, so pass cookieJar or headers to capture it with a session.
```

没有这一行,登录页的截图就是一张对错误页面的正确渲染,而像素本身说不出它是两者中的哪一个。当落地位置是一堵登录墙、并且上面那套流程跑过时,这一行位于 `loginNote` 之下:那一句说的是关于登录做了什么决定,这一行说的是框架去了哪里。

## 把截图写成文件

`outputPath` 在返回 image 块之外,把同一张 PNG 写到磁盘上,结果里会写明它写到了哪个路径。截图要变成文档里的插图,靠的就是它:image 块背后的附件按内容寻址、没有路径,所以重复截同一个页面并不会产生任何可供查找的新文件。

相对路径相对调用方会话的工作区解析,和 harness 里每一个写文件的工具一样,并且解析后的路径必须留在工作区内:`outputPath must stay inside the workspace (…); use a relative path like shots/page.png`。会话之外的调用根本不能要求写文件,因为没有工作区可以安放它。工作区内缺失的父目录会被创建;已存在的文件会被替换,并且结果里会说出来,而不是悄悄替换。

包含性检查做了两遍,因为其中一遍并不是它看起来的那条边界。解析路径解决 `..`;解析其中已存在的最深部分的符号链接解决其余部分,因为工作区内的目录可以是指向工作区外的链接,于是一个读起来像是被包含的路径会被写到外面去。两遍都在创建任何东西之前跑,所以一次拒绝也不会留下目录。

写入用的是普通的 `node:fs` 写,而不是 `ctx.fs`:文件系统缝没有字节写,只有 UTF-8 文本,所以 PNG 走不了它。上面那条工作区边界是这个插件能够诚实执行的,并且它比部署自己的沙箱策略更窄,而不是更宽。

## 两个后端

`backend` 决定由哪一个渲染。默认的 `auto` 按以下顺序尝试:

**1. 桌面外壳自己的渲染服务**,只要 `DSH_DESKTOP_RENDER_ENDPOINT` 和 `DSH_DESKTOP_RENDER_TOKEN` 都出现在 harness 进程环境里。宣告了这个服务的外壳,已经跑着一个浏览器引擎,而且知道自己的窗口长什么样。它的协议在下面写明。

**2. 无头模式的系统浏览器。** Chrome、Edge、Chromium 和 Brave 都接受同一条 `--headless=new --screenshot` 命令行,而运行桌面应用的机器上几乎总会装着其中一个,所以这个插件去探测,而不是给一个截图工具加上一百兆的浏览器下载。任何时候都不下载任何东西。

探测顺序是配置里的 `browserPath`,然后环境里的 `CHROME_PATH`,然后平台的安装位置:

| 平台 | 依次探测 |
| --- | --- |
| macOS | `/Applications/Google Chrome.app`、`~/Applications/Google Chrome.app`、`/Applications/Microsoft Edge.app`、`/Applications/Chromium.app`、`/Applications/Brave Browser.app`(各取 `…/Contents/MacOS/<binary>`) |
| Windows | `%ProgramFiles%`、`%ProgramFiles(x86)%`、`%LocalAppData%` 下的 `\Google\Chrome\Application\chrome.exe`,然后 `%ProgramFiles(x86)%` 与 `%ProgramFiles%` 下的 `\Microsoft\Edge\Application\msedge.exe` |
| Linux 及其他 | `PATH` 上的 `google-chrome`、`google-chrome-stable`、`chromium`、`chromium-browser`、`microsoft-edge` |

找到的第一个可执行文件在插件的生命周期内被记住。`browserPath` 和 `CHROME_PATH` 是仅有的两处显式设置,而一个不是可执行文件的路径会被报出来,而不是跳过去继续探测:有人写下来又写错了的路径,是应该被告知的错误,不是换一个浏览器渲染的理由。哪里都没装时,工具的答复是:

```
no headless-capable browser found; install Google Chrome/Edge or set screenshot.browserPath in cordis.patch.yml
```

**外壳的失败不会改用系统浏览器重试。** 一旦配置了渲染服务,它就是渲染器;回退会在已经出问题的时候悄悄换掉引擎,让一张截图的来源变得无从知晓。

知道自己要哪个引擎的部署直接说出来,而不是依赖那个顺序。`backend: shell` 只经外壳渲染,没有外壳时指名失败——`backend is set to "shell" and this harness was given no render service … Start the desktop shell, or set backend to "auto" or "browser" in the plugin config`——这正是页面全都需要会话的部署想要的,因为那里的回退只可能产出登录界面。`backend: browser` 即使在外壳正在运行时也用机器自己的 Chrome 渲染,给那些必须来自用户实际拥有的浏览器的截图。

## 配置

```yaml
- id: screenshot
  name: '@haoran/dsh-screenshot'
  config:
    defaultWidth: 1024
    defaultHeight: 768
    defaultDelayMs: 0
    maxDelayMs: 10000
    timeoutMs: 30000
    onTimeout: capture
    blockHosts: []
    maxWidth: 4096
    maxHeight: 4096
    backend: auto
    loginConsent: true
    loginPathPatterns:
      - /login
      - /signin
      - /sign-in
      - /sign_in
      - /auth
      - /oauth
      - /sso
      - /session/new
      - /users/sign_in
      - /account/login
```

| 字段 | 默认值 | 含义 |
| --- | --- | --- |
| `defaultWidth` | `1024` | 未点名尺寸的调用所用的视口宽度。 |
| `defaultHeight` | `768` | 未点名尺寸的调用所用的视口高度。 |
| `defaultDelayMs` | `0` | 未点名等待的调用所用的加载后等待。 |
| `maxDelayMs` | `10000` | 一次调用可以要求的最长等待。 |
| `timeoutMs` | `30000` | 未点名预算的调用所用的渲染预算(ms)。它是渲染器运行时所遵守的截止时间;HTTP abort 位于它之上 5000 ms。 |
| `onTimeout` | `capture` | 什么都没点名的调用在截止时刻做什么。 |
| `blockHosts` | `[]` | 本部署每次渲染都取消其请求的主机,与调用点名的合并。 |
| `maxWidth` | `4096` | 一次调用可以要求的最大视口宽度。 |
| `maxHeight` | `4096` | 一次调用可以要求的最大视口高度。 |
| `browserPath` | 未设置 | 浏览器二进制的绝对路径;不设置表示探测。 |
| `cookieJars` | `{}` | 截图可以使用的会话,按名字组织。**凭据就住在这里**——在这台机器的这个文件里,永远不在工具参数里,也永远不在会话日志里。 |
| `userAgent` | 本平台的稳定版 Chrome | 每次渲染自称是什么。空字符串表示用后端自己的,那会说出 Electron 或本机浏览器。 |
| `backend` | `auto` | `auto` 优先用外壳的渲染服务,`shell` 要求它,`browser` 总是用本机的 Chrome。 |
| `loginConsent` | `true` | 拍回来是登录墙的截图要不要就登录一事问本人。对从来不会撞上登录墙的部署,它不花任何代价,因为这个判断是从渲染已经报告过的内容里读出来的。在没有人看着对话的地方关掉它——定时任务、自动化服务器——于是撞上墙的截图直接给出那堵墙,而不是卡在一个没人会看到的问题上。 |
| `loginPathPatterns` | 上面那十条前缀 | 读起来像登录页的路径前缀,不区分大小写地匹配渲染并未要求过的落地位置。每一条都必须以 `/` 开头,而且是前缀而非精确路径,因为真实的登录路由会带上返回 URL、租户或步骤。为在别处登录的站点扩充它;在 `/auth` 是普通页面的部署上缩短它。 |

这些默认值会到达模型:它们就是工具自己参数 schema 上的 `default` 注解,于是按 1440 宽渲染的部署会把这件事告诉模型,而不是留给它猜。

profile 的 `cordis.patch.yml` 里针对该 id 的 patch **会整块替换 `config`**,所以要保留的键必须逐条重写。默认值高于它自己的上限会在加载时被拒绝,因为它会弄坏的那次调用,恰恰是完全没点名尺寸的那一次。

## 桌面渲染器协议

这是一个桌面外壳要实现的契约。插件是客户端;这个包里没有任何东西提供该服务。

**发现。** 外壳把两个变量放进它启动的 harness 进程的环境里。两者缺一不可:没有 token 的 endpoint 每次调用都会被拒,没有 endpoint 的 token 什么都指不到。

| 变量 | 值 |
| --- | --- |
| `DSH_DESKTOP_RENDER_ENDPOINT` | 服务的 origin,例如 `http://127.0.0.1:53412`。末尾的斜杠会被忽略。 |
| `DSH_DESKTOP_RENDER_TOKEN` | 外壳为这个 harness 进程铸的 bearer token。 |

它们在每次调用时读取,而不是在加载时,所以在 harness 起来之后才启动渲染服务的外壳,从下一次截图起就会被用上。

**请求。**

```http
POST {endpoint}/render
authorization: Bearer {token}
content-type: application/json
accept: image/png

{"url":"https://example.com","width":1024,"height":768,"fullPage":false,"delayMs":0,"timeoutMs":30000,"onTimeout":"capture","userAgent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"}
```

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `url` | string | 一个 `http:`、`https:` 或 `file:` URL。已经规范化过:插件绝不会送出裸路径或别的 scheme。 |
| `width` | integer | 视口宽度(px),至少为 1。无论外壳显示器的缩放系数是多少,返回的图像必须正好是这个宽度。 |
| `height` | integer | 视口高度(px),至少为 1。 |
| `fullPage` | boolean | 拍整个可滚动页面而不是视口。能测量文档的外壳应当精确兑现这一点;这正是它比命令行后端做得更好的主要一项。 |
| `delayMs` | integer | 加载完成后、截图之前的等待(ms),至少为 0。 |
| `headers` | object | 除非调用带了,否则不出现。请求头名到字符串值的映射,施加于页面请求。 |
| `cookies` | array | 除非调用点名了 jar,否则不出现。每个 cookie 为 `{ name, value, domain, path, secure, httpOnly, expirationDate? }`,除最后一项外每个属性都已定好,在加载前设置到本次渲染自己的会话上,于是它们到达页面发出的每一个请求,而不只是它自己目录下的那些。按每个 cookie 自己的 `domain` 和 `path` 定作用域,而不是按页面的:一个 jar 装着页面会访问的每一个主机的 cookie。 |
| `userAgent` | string | 部署用后端自己的 UA 渲染时不出现。把它同样施加于文档及其子资源。 |
| `timeoutMs` | integer | 本次渲染的截止时间,从服务接受请求的那一刻起算。总是发送。无法兑现某个预算的服务必须指名拒绝,而不是按另一个预算去渲染。 |
| `onTimeout` | string | `fail` 用失败回答已过的截止时间;`capture` 回 `200`,带上已经画出来的东西,并在报告里给出 `outcome: "timeout"`。总是发送。 |
| `blockHosts` | array | 没有则不出现。主机模式——精确主机或 `*.suffix`,已转小写——其请求在发出之前被取消。主文档自己的主机不得被屏蔽。 |
| `partition` | string | 除了本人授权的登录之后的第二次渲染之外都不出现。`persist:dsh-render-login-<可注册域>`,小写,在 harness 进程内从页面自己的 URL 算出,绝不来自模型写下的任何东西。在那个持久会话里渲染。带它的请求不带 `cookies`;外壳拒绝语法之外的分区、`file:` URL 上的分区,以及与 `cookies` 并存的分区。 |

无法兑现 `headers` 或 `cookies` 的外壳必须拒绝请求,而不是不带它们去渲染:把登录页当成一次成功的截图返回,正是这两个字段要终结的失败。这两者的数量和大小由外壳自己设界;插件在加载时按这里的语法校验每一个 cookie,所以它接受的 jar 就是合规外壳会接受的 jar。

**每个请求在自己的 cookie 存储里渲染,并且不留下任何值。** 一个请求的 cookie 不得被下一个读到,不得进入用户自己的浏览会话,也不得写到磁盘上。桌面外壳的做法是每次渲染创建一个会话分区,并随窗口销毁。外壳还必须把 cookie 值排除在它写下的一切之外——日志、拒绝信息、`x-dsh-render-report`——因为这些都会回到某份记录里。带 `partition` 的请求改为在那个持久存储里渲染,那是唯一一个写到磁盘上的渲染会话;它不带 `cookies`,所以不会有调用方提供的东西被代为持久化。

**成功。** `200`,`content-type: image/png`,body 是 PNG 字节。content type 不是 `image/png` 的 `200` 会被客户端拒绝,并在消息里写出收到的类型——否则就是几步之后才因为魔数校验失败的一堆字节,而且报错说的是附件。

**它停在了哪里。** `200` 可以带 `x-dsh-render-landed-url`,并且只要主框架停在了请求之外的 URL 上就应该带——最常见的是重定向到登录页。把可打印 ASCII 之外的一切**以及 `%` 字节本身**做百分号编码,否则页面写下的百分号序列回来时会变成它所代表的那个字符;客户端会解码这个头,解不开就保留原值,并把它变成上面引用的那一句话。渲染停在原地时不要发这个头。

**失败。** 任何非 `200`。body 按文本读取,前 500 个字符会被引进模型看到的工具错误里,所以那里要写一句话,而不是一个代码:

```
the desktop renderer refused to render https://example.com (HTTP 422): no window is available to render into
```

**这次渲染做了什么。** 每一个渲染真正到达过的答复——`200`、拒绝一次失败渲染的 `500`,以及超时失败——都带 `x-dsh-render-report`:整份渲染报告的 JSON,像落地位置头一样做百分号编码——可打印 ASCII 之外的一切,以及 `%` 本身。没有启动任何渲染的拒绝不带它,比这套协议更老的外壳发的也是这样,两种情况下客户端都退回到 body 那一行。客户端只读 `version: 1`,对别的版本一概忽略,而不是去读那些它恰好认识名字的成员;读不懂的头不会让这次截图付出任何代价,只会被报成一句话。

报告说明渲染怎么结束的(`complete`、`timeout`、`failed`)、走到了哪一步、主文档回了什么、load 事件有没有触发、窗口有没有绘制、多少请求上了线、多少还在飞、哪些主机拿着它们、页面记了什么日志、主框架为什么失败,以及渲染进程最后怎么样了。schema 归外壳所有,并且它给每个列表和字符串设界,于是这个头不会随页面一起变大。

**超时。** 请求自带截止时间,客户端的 HTTP abort 位于它之上 5000 ms,于是外壳的答复——包括 `onTimeout: "capture"` 在截止时刻产出的局部截图——能够到达,而不是被截断。无法在给定预算内渲染完的外壳应当用一次失败作答,而不是把连接一直挂着。

**认证。** 插件送出它拿到的 token,除此之外什么都不做;比对是外壳的事。把服务绑在 loopback 上:它会为任何拿着 token 能够到它的人渲染任意 URL,包括 `file:` URL。

**三条登录路由。** 它们带与 `/render` 相同的 `authorization: Bearer {token}` 和 `content-type: application/json`,各自收一个、答一个 JSON 对象:

```
POST {endpoint}/login-grant        {"url":"https://app.example.com/board","partition":"persist:dsh-render-login-example.com"}   →  {"nonce":"<single-use value>"}
POST {endpoint}/login              {"nonce":"<single-use value>"}                                                              →  {"landedUrl":"…","sameSite":true}
DELETE {endpoint}/login-sessions   {"partition":"persist:dsh-render-login-example.com"}                                        →  {"cleared":true}
```

插件从授权答复里读 `nonce`,三条路由里别的什么都不读:`/login` 的答复只要是 JSON 就行,因为随后那次截图才是「登录有没有成功」的回答;而登出在外壳说完之后就算做完了。任何非 `2xx` 都是一次拒绝,它的 body——和这套协议里其他地方一样,一行文本——会被引进工具结果携带的那句话里,或者引进命令的错误里。只提供 `/render` 而不提供这三条的外壳会对三者都回 `404`,那里撞上登录墙的截图就以它本来的未登录截图收场。

授权把页面和分区一起定死,所以 `/login` 两者都不选,窗口也就不可能为本人刚刚同意之外的站点打开。插件对授权或登出在 10 秒后放弃,对 `/login` 在 20 分钟后放弃——高于外壳自己给「一扇立在用户屏幕上的窗口」定的截止时间,于是外壳的答复能够到达而不是在这一侧被截断,这与渲染的 `timeoutMs + 5000` 是同一种关系。读表单、找密码、过第二因子,就是这个数字对着量的事情。

## 与 `@haoran/dsh-llm-permission-gateway` 搭配

`screenshot` 会像任何其他有副作用的调用一样被闸门审查,而且理应如此。**不要把它加进 `readOnlyTools`。** 它会向模型选定的任意 URL 发起网络请求,点名 jar 的调用会把本机的凭据送到那个主机,`outputPath` 点名时它会写文件,而对 `file:` URL 它是通过浏览器而不是 `ctx.fs` 读本地文件的——所以文件系统沙箱管不到它能渲染什么。这些都值得审查模型看一眼。

审查的代价是每张截图一次判定,而截图本身已经要花上几秒。

**闸门的判定不是同意。** 闸门决定这次调用跑不跑;它能不能带着本人自己保存的会话跑,是另一个问题,那个问题通过 user-questions 缝问一个人,而闸门既不在它前面、也答不了它。即便部署自动批准每一次工具调用,每一堵登录墙仍然会有一张卡片摆到人的面前。

## 这个工具不做的事

**`fullPage` 是近似的。** 无头 `--screenshot` 拍的是窗口而不是文档,所以整页截图渲染在一个 4000px 高的窗口里。更长的页面被切掉,更短的页面用它的背景色补齐。`maxHeight` 限制一次调用可以要求什么,并且刻意不限制这个内部高度。能测量文档的桌面外壳应当把 `fullPage` 实现对;这正是第一个后端存在的主要理由。

**没有交互。** 没有点击、滚动、输入或悬停。只在点击之后才出现的控件永远不会出现,任何登录表单也不会由 agent 去填:cookie jar 和 `headers` 携带的是部署已经拥有的会话,而登录窗口是本人自己去填的,窗口归外壳所有、工具伸不进去。除了获得授权的登录之后的第二次渲染以外,每一次截图都从一个全新的内存 profile 开始,所以两次截图之间什么都不留,也不与用户自己的浏览会话共享任何东西。驱动页面是另一个工具、另一种风险,不是这一个。

**登录流程需要桌面后端。** 系统浏览器拍的截图既不报告落地位置也不报告主文档回了什么,所以那里判定不出登录墙:拿到的就是未登录的那张截图,没有备注,也不报错。页面全都在登录之后的部署,出于同样的理由应当用 `backend: shell`。

**同一时刻只有一扇登录窗口。** 外壳只开一扇,已经有一扇开着时的第二个请求会被拒绝;提出请求的那次截图带着「登录窗口没能走完」的那句话回来,等第一扇处理完,模型可以再调一次 `screenshot`。

**已保存的登录永远不会被过期。** 外壳一直保留这个分区,直到有人把它登出——设置页、`/screenshot-logout`,或者应用的 userData 被删掉。索引里的两个时间戳说明它何时创建、何时被截图最后一次用到;没有任何东西依据它们行动。站点自己让会话过期,代价是多一张卡片,因为下一次截图会再次撞上那堵墙。

**截图不是免费的。** 浏览器写完 PNG 之后,在 macOS 上会继续运行,所以一次截图以「文件出现并且不再变大」为结束——两次 200ms 轮询——而不是以进程退出为结束。无论如何进程组都会被终止。用命令行后端时,每张截图大约两到三秒。

**Chrome 不加 `--no-sandbox` 就不会以 root 运行**,而这个插件不传、也不会传这个参数:它会为 agent 渲染的每一个页面关掉浏览器自己的沙箱。在以 root 运行的容器里,把 `browserPath` 指向一个加上该参数的包装脚本,并且清楚你关掉了什么。

**每次渲染都自称是 Chrome。** `userAgent` 默认取插件所在平台的普通稳定版 Chrome 字符串,因为两个后端否则都会自报家门:桌面外壳的 Chromium 发的是 `… Chrome/150.0.7871.224 Electron/43.4.0 Safari/537.36`,这等于告诉 agent 看的每一个页面「正在看你的是一个 Electron 应用」,有些站点会为此回一个不同的页面。设 `userAgent: ''` 表示用后端自己发的那个。它在两个后端上都到达文档及其子资源——渲染服务把它设在本次渲染的会话和 web contents 上,系统浏览器拿到的是 `--user-agent`。

**图像就是浏览器看到的东西。** 加载失败的页面会渲染成浏览器自己的错误页,模型随后正确地把它读成「这个没加载出来」。这是预期行为,不是缺口。

**局部截图不是跑完的页面。** `onTimeout: "capture"` 返回截止时刻已经画出来的像素,那是一个加载到一半的页面:图片缺失、晚到的脚本没跑、`fullPage` 测量中折叠线以下的一切都不在。它在结果里和 `partial` 字段里都有标记,它之所以存在,是因为拿着像素和一份报告的调用方可以决定下一步,而只拿到一行超时的调用方不能。

## 开发

构建、基于 tarball 的 profile 安装,以及为什么不能用 `link:` 依赖,见工作区 README。

测试套件不需要浏览器即可运行。有一个可选启用的 spec 会真的起一个:

```sh
pnpm vitest run --dir packages/screenshot                    # 不启动浏览器
SCREENSHOT_E2E=1 pnpm vitest run --dir packages/screenshot   # 在已安装的浏览器里渲染一个本地页面
```
