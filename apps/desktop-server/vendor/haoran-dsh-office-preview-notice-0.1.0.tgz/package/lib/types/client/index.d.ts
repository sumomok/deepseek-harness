/**
 * Browser half of @haoran/dsh-office-preview-notice.
 *
 * Registers one implementation with the document preview's
 * `documentPreviews` registry for Word and PowerPoint suffixes, in the
 * `extension` priority band that automatic selection ranks above the builtin
 * Office renderer, and its body under the same id in the keyed
 * `sidebar.right.tab.document` slot.
 *
 * @module @haoran/dsh-office-preview-notice/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type OfficePreviewNoticeKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The notice line and its viewer-menu label. */
        'office-preview-notice': OfficePreviewNoticeKey;
    }
}
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * Register the dictionary, the preview implementation, and its body.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map