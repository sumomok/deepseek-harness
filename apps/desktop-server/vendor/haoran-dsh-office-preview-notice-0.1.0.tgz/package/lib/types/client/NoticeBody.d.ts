/**
 * Document body for a Word or PowerPoint file: one centered line of copy.
 *
 * The document preview hands a `renderer`-mode body a load request per
 * content revision. This body reads no bytes, so it ends each revision with
 * `failed()`, which only clears the pending load; `loaded()` would record a
 * file version and arm the preview's "file changed" bar for a body that never
 * shows the file.
 *
 * @module @haoran/dsh-office-preview-notice/client/NoticeBody
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { DocumentContent } from '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/client';
import type { NS } from './locales.ts';
/** Props this body reads: the preview's content request and its dictionary. */
export type NoticeBodyProps = {
    readonly content: DocumentContent;
} & PropsLocale<typeof NS>;
/**
 * Settle the current load request and show the notice.
 * @param props - content request and localized copy.
 * @returns the notice line.
 */
export declare function NoticeBody(props: NoticeBodyProps): ReactNode;
//# sourceMappingURL=NoticeBody.d.ts.map