/**
 * Copy for the notice body and its entry in the document viewer menu. Both
 * strings reach end users, so they name the file kinds and the apps a user
 * already knows and nothing about how the preview is produced.
 *
 * @module @haoran/dsh-office-preview-notice/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "office-preview-notice";
/** Every key this plugin's own copy uses. */
export type OfficePreviewNoticeKey = 'title' | 'notice';
/** Chinese copy. */
export declare const zh: Record<OfficePreviewNoticeKey, string>;
/** English copy. */
export declare const en: Record<OfficePreviewNoticeKey, string>;
//# sourceMappingURL=locales.d.ts.map