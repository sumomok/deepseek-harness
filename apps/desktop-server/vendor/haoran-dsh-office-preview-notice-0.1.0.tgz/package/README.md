# @haoran/dsh-office-preview-notice

English | [中文](README.zh.md)

Show a plain notice in the DeepSeek Harness right sidebar when a Word or PowerPoint file is opened there, on a desktop build that ships no document converter.

## What it does

The document preview (`@deepseek-ai/dsh-client-ui-sidebar-documentpreview`) always registers its builtin Office renderer for `doc`, `docx`, `ppt`, and `pptx`. Without the `office-to-pdf` converter that renderer fails with a message about enabling a preview service on the machine that runs the app, which means nothing to an end user.

This plugin registers its own implementation for the same four suffixes in the `extension` priority band, which the preview's automatic selection ranks above the builtin band. Opening such a file therefore shows this plugin's line instead:

- 中文：这里暂时无法预览 Word 和 PPT 文件，请用电脑上的 Office 或 WPS 打开。
- English: Word and PowerPoint files can't be previewed here yet. Open them with Office or WPS on your computer.

The body reads no file content. Every suffix is declared binary, so the viewer menu offers no plain-text view of the file. Spreadsheets (`xls`, `xlsx`) are left alone: the preview renders them in the browser without a converter.

## Known limitation

The document toolbar's viewer menu still lists the builtin renderer as "Office document". A user who picks it by hand sees the builtin message again. The plugin cannot hide or relabel that entry: the builtin renderer registers unconditionally, and its copy lives in the preview package's own locale namespace.

## Later work

The notice is the first half of on-demand converter download. The download control is meant to go into the same body, or into the keyed `sidebar.right.tab.document.action` toolbar seat under this plugin's implementation id, which is where the builtin renderer puts its own controls. This version has no download control, store, or configuration.

## Install

Desktop-internal; not published to npm. Pack a tarball (`pnpm pack`) and install it into a profile the same way any local plugin is vendored. Requires DSH `>=0.1.7-rc.1 <0.2.0`.
