# @haoran/dsh-office-preview-notice

[English](README.md) | 中文

在不带文档转换器的桌面版里，从 DeepSeek Harness 右栏打开 Word 或 PowerPoint 文件时，显示一句普通用户看得懂的提示。

## 它做什么

文档预览（`@deepseek-ai/dsh-client-ui-sidebar-documentpreview`）总会为 `doc`、`docx`、`ppt`、`pptx` 注册内置的 Office 渲染器。没有 `office-to-pdf` 转换器时，这个渲染器报出的是「请在运行应用的主机上启用预览服务」一类的话，终端用户看不懂。

本插件为同样四个后缀注册自己的实现，优先级落在 `extension` 档；预览的自动选择把这一档排在内置档前面。所以打开这类文件时显示的是本插件的提示：

- 中文：这里暂时无法预览 Word 和 PPT 文件，请用电脑上的 Office 或 WPS 打开。
- English: Word and PowerPoint files can't be previewed here yet. Open them with Office or WPS on your computer.

提示正文不读取文件内容。四个后缀都声明为二进制，所以查看方式菜单里不会多出纯文本查看。表格（`xls`、`xlsx`）不受影响：预览在浏览器里直接渲染它们，不需要转换器。

## 已知限制

文档工具栏的查看方式菜单里仍然列着内置渲染器「Office 文档」。用户手动选它，会重新看到内置的那句旧提示。本插件无法隐藏或改名这一项：内置渲染器无条件注册，它的文案属于预览包自己的 locale 命名空间。

## 后续

这句提示是「按需下载转换器」的前半段。下载按钮将来放在同一个正文里，或者放进以本插件实现 id 为键的 `sidebar.right.tab.document.action` 工具栏槽位——内置渲染器也是把自己的控件放在那里。这一版没有下载按钮、状态存储或配置项。

## 安装

仅限桌面内部使用，未发布到 npm。打包成 tarball（`pnpm pack`）后按本地插件的常规方式装进某个 profile。要求 DSH `>=0.1.7-rc.1 <0.2.0`。
