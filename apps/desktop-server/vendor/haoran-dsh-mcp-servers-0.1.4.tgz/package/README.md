# @haoran/dsh-mcp-servers

English | [中文](README.zh.md)

Desktop-internal, not published. Connect external MCP tool servers from the Settings page.

The harness already ships an MCP client, `@deepseek-ai/dsh-mcp-client`: one composition entry per server, edited in a YAML file, applied at the next restart, and every tool the server lists goes straight onto `ctx.tools`. On a desktop that is unusable twice over — someone who does not open a terminal cannot add a server at all, and an unreviewed tool would enter every model request the moment a server offered it.

This plugin drives that same client from a settings document, and puts a few decisions in front of it.

## The decisions

**Storing a server is the consent to connect it.** Filling the form in and saving it is the decision; there is no second click. The server connects, and the set of tools it turns out to offer is recorded as the set that was trusted — a fingerprint nobody could have typed, because it is only knowable once the server has answered.

**A set the server changes afterwards was not consented to.** The protocol lets a server rewrite its tool list at any moment. The moment what it offers stops matching what was recorded — a tool added, dropped, or reworded — the row asks again, and the tools it is asking about cannot be ticked until it is answered. Those are the changed and newly added ones, and they were already out of the model's reach, because a tick is pinned to one exact wording. A ticked tool the server did not touch keeps working: it is the same tool that was read.

**Editing the destination retires the confirmation.** A stored server carries the fingerprint of the destination that was confirmed — command, arguments, working directory, environment, or URL and headers. Change any of them and the server stops and the page asks again, because the record no longer describes the place that was agreed to. Confirming it also clears the recorded tool set: what a different destination offers is unknown until it has been connected.

**A tool reaches the model only after someone ticked that exact wording.** The tick stores a fingerprint of the tool's name, description, and input schema, so a tool whose description or arguments changed since it was ticked is a tool nobody has read. It returns to the waiting list. A tool that was never ticked is never registered at all, which is what keeps it out of the model's schema list rather than merely refusing the call.

With no server stored, the plugin registers no tool, starts no process, and adds nothing to any request.

## Adding a server

The Settings page has an **External tools** section.

**A program on this computer.** Fill in the full path of a program that speaks MCP over its standard input and output, plus any start-up arguments, a working directory, and environment entries. The path has to be a full one: a bare name would be resolved against whatever directory the app happened to start in, which is not something a person can predict, so it is refused with a reason instead.

**A web address.** Fill in an `http://` or `https://` URL of a Streamable HTTP endpoint, plus any request headers.

Saving connects it: the row reads **Connecting** and then **Connected**, and lists every tool the server offers. Tick the ones the model may use. Ticking one does not restart the server — the tool moves into the registry against the connection that is already open — and neither does un-ticking one.

A row reads **Waiting for you** only when something stopped matching what was agreed to: the destination was edited, or the server changed the tools it offers. It says which, spells the destination out, and its one control confirms what the page is showing.

**Removing a server asks first.** The row's **Remove** puts the question on the card, naming the server, and only the control inside that question drops the record — together with every tool approval ticked for it, which nothing on this page puts back.

## Credentials

Both places a connection carries a secret take it the same two ways: an HTTP header's value, and an environment entry handed to a local program. Either can be typed into the form, or can name a saved credential.

Choosing **Use a saved credential** stores only the reference name. The secret stays wherever the credential seam keeps it, is read once per connection, and **never enters the settings document** — that holds for a header and for an environment entry alike. Rotating the secret behind the same name reconnects that one server and is not treated as a change of destination: the name is what was confirmed, not the value.

A reference nothing is stored under leaves the server unconnected and says which name was missing.

A web address itself may not carry a user name and password (`https://user:pw@host/…`). That form is refused rather than accepted, because unlike a credential reference there would be nowhere for it to live except the settings document, in a field this page prints on screen. Use a request header instead. A `#fragment` is refused too — the client never sends it, so it can mean nothing to the server.

A URL's query string is the other common place for a key, and the page never prints one. Where a destination is shown, a URL that carries a query reads as `https://example.test/mcp (with query parameters)` — enough that two servers differing only in their query do not look like the same one, without the value on screen.

## What this cannot do

- **A server named as a package (`npx …`, `uvx …`) will not start.** The desktop ships Node and pnpm for its own installer and nothing else on `PATH`; there is no `npx`, no `uv`, and no package manager reachable from a server command. Install the program first, then name its full path. This is why most configurations copied from a third-party guide need one change before they work here.
- **HTTP+SSE endpoints are not supported.** The upstream client speaks stdio and Streamable HTTP; an older SSE-only endpoint has no transport here.
- **A stdio server runs outside the sandbox.** The MCP SDK starts the process itself, so no sandbox mode the app offers applies to it. It runs with the account and permissions of whoever is using the computer. Saving one is agreeing to that, which is why the form says the full path of the program it is about to start.
- **Every ticked tool's description enters every request.** Tool definitions are not loaded on demand, so ticking thirty tools costs those thirty descriptions in each turn. Tick what is actually used.
- **A tool the server changes goes back to the waiting list, and the row asks again.** A tool whose description or arguments were rewritten is a tool nobody has read; one the server just added is one nobody asked for. Neither reaches the model, and neither can be ticked until the row's confirmation is given. Tools that were ticked and that the server did not touch keep working throughout — they are the same tools that were read. A server that rewrites its list often will ask often.
- **Only the FIRST connection is final.** If it fails, or if the server accepts the connection and then says nothing until this plugin's own budget runs out, the server is reported as unusable and stays that way; switching it off and on again from the page is the retry. Once a server has connected, a later drop is the upstream client's business: it reconnects on its own with the policy that client documents — ten consecutive attempts per outage, backing off from 0.5s to 30s, with the budget resetting after a connection that stays up. Exhausting that budget unregisters the server's tools.
- **A drop is invisible until something calls the server.** The upstream client publishes no connection state and leaves a dropped server's tools registered while it retries, so this page cannot show "reconnecting". What it can show is **Not answering**, with the message, the moment an error comes back in place of a result; the row clears itself as soon as another call reaches one. A call that reaches nothing at all before this plugin's own `toolCallTimeoutMs` runs out is a different row: **No answer in time**, naming that budget rather than a message. What fired there was the deadline this side armed, and nothing came back to say why — a server still working on the call and a request the transport lost silently both look exactly like that, so the row claims neither. Three things deliberately leave the row alone: a tool answering with its own failure, an error the server sent back about an unknown tool or bad arguments, and a call somebody cancelled — all three are the server answering, or nobody's fault at all.
- **An edit saved at the wrong moment can be lost, and the page will not say so.** The confirmation this plugin writes and the edits the Settings page saves rewrite the same stored list, and both state the revision they read it at, so whichever lands second is refused rather than overwriting the other. This plugin rebuilds on the newer document and writes again. The page does not: `@deepseek-ai/dsh-client-ui-settings` reloads Host state and reports nothing, so the control you just changed reads as saved, shows no error, and goes back to its previous value when that reload arrives. The window is one moment per server — while it records what it offers for the first time — and the code that swallows the refusal is not this package's, but the side that loses is the page's edit. Make it again.
- **The tool descriptions come from the server verbatim.** Nothing rewrites or screens them, so a server can put instructions in front of the model through a description. Read what a tool says before ticking it.

## Installing

The host half imports `@deepseek-ai/dsh-mcp-client`, which is a peer dependency like every other `@deepseek-ai/*` import in this workspace: it must be reachable in the running installation's own dependency closure, not installed beside the plugin. For the desktop that means `apps/desktop-server/package.json` lists it; the profile's module fallback then links it like any other installation package. Without it the plugin fails to load, loudly, rather than pretending to work.

## Configuration

```yaml
- id: mcp-servers
  name: '@haoran/dsh-mcp-servers'
  config:
    enabled: true
    confirm: settings
    toolCallTimeoutMs: 60000
```

| Field | Default | Meaning |
| --- | --- | --- |
| `enabled` | `true` | `false` leaves the composition without this capability entirely: no service, no settings section, no connections. |
| `confirm` | `settings` | Which channel answers whether a server may connect. `settings` takes the stored confirmation as the answer. `approval` asks through the harness approval channel — see below. |
| `toolCallTimeoutMs` | `60000` | Per-tool-call timeout handed to every server connection. |
| `connectTimeoutMs` | `15000` | How long one server's FIRST connection may take before this plugin gives up on it. The MCP SDK's own `initialize` deadline is a minute and the upstream client offers no way to shorten it, so without this a server that accepts a connection and then says nothing would hold this plugin for that long. Raise it for a slow machine, or for a server that indexes something before it answers. |

Both timeouts must be a finite number of milliseconds from 1 to 2147483647, judged at load. A larger number is past what `setTimeout` keeps and would fire at once, and `NaN` is what a numeric schema's `min`/`max` cannot catch — either would silently make every first connection time out immediately, so both fail the plugin instead.

The server list is deliberately not configuration. Servers are added and removed while the app runs, which a composition entry cannot express.

### The confirmation channel

The question this channel answers is never "may this server connect" — storing it answered that. It is "this server now offers a different set of tools than the one it was trusted at; may it keep serving them".

`confirm: settings` is the working default: the answer lives in the settings document, where the row's confirmation control writes it, so until it does the answer is no and the server's tools stay withheld. **No model-facing tool writes that document**, and the only write this plugin makes into it is the one fingerprint a person cannot produce — the set a server turned out to offer, recorded the first time it connects. The document is not out of reach in principle: the harness's own settings Remote takes any namespace (`SettingsController.update` / `replace` / `mutate`, `packages/api/settings-controller/src/index.ts:144`, `:161`, `:180`), so anything already admitted to `/api` can write this namespace exactly as it can write every other one. The confirmation is a gate against a server changing what it offers unasked, not against a caller who already holds the settings API.

`confirm: approval` sends the same question through `ctx.approval` as well. That channel is agent-bound and turn-bound — it can only reach someone while exactly one conversation is open and mid-turn — which is, in fact, when a server most often rewrites its tool list, since a tool call is what makes it do so. Outside that window it refuses and the Settings page asks instead; nothing is served in the meantime either way. It is here because the seam is the same one a desktop shell will answer with a native window that the web UI cannot forge; a plugin in the same process installs that answer with `ctx.mcpServers.useConfirmer(...)`, which is not part of the Remote face and so is unreachable over the wire.

## The settings document

Namespace `mcp-servers`, one key:

```yaml
mcp-servers:
  servers:
    - id: my-tools            # [a-z0-9][a-z0-9_-]{0,31}; also the tool-name namespace
      label: My tools
      enabled: true
      transport: stdio        # or: http
      command: /usr/local/bin/some-mcp-server
      args: ['--serve']
      cwd: ''
      env:
        - { name: SOME_SETTING, value: a literal }
        - { name: SOME_TOKEN, credential: SOME_SAVED_NAME }
      confirmedEndpoint: '<destination fingerprint>'
      confirmedTools: '<tool-set fingerprint>'
      approvedTools:
        - name: mcp__my-tools__echo
          fingerprint: '<wording fingerprint>'
    - id: remote
      label: Remote tools
      enabled: true
      transport: http
      url: https://example.test/mcp
      headers:
        - { name: Authorization, credential: SOME_TOKEN }
      confirmedEndpoint: ''
      confirmedTools: ''
      approvedTools: []
```

`env` and `headers` have the same form: a list of entries, each with a `name` and exactly one of `value` and `credential`. A stdio server stored by a dev snapshot from before 0.1.0, when `env` was an object of name/value pairs, is skipped with a warning and has to be added again — this package is pre-release and carries no migration.

The namespace schema accepts any array of records, and each record is then judged on its own: one hand-edited row that cannot be read is skipped with a warning while every other server keeps running. The three fingerprints are the plugin's own; hand-writing one is possible and is exactly equivalent to clicking the confirmation, which is the point of storing them rather than a bare `true`.

`confirmedTools` is the one field the host writes as well as reads: only a connected server can say what it offers, so the first connection stores it — through the same settings seam the page writes through, on the record's own row, leaving every other entry byte for byte. The write states the revision it read the document at, so an edit the page made in between refuses it instead of overwriting it; it then rebuilds on the newer document and writes again, a bounded number of times. A write that is refused for any other reason (a read-only provider) is logged once; the connection still stands for that session, and nothing durable claims a confirmation that was not stored.

Registered tool names follow the upstream client's rule: `mcp__<id>__<the server's own name>`.

## Why the tool registry is substituted rather than filtered

The upstream client registers what its server lists, and has no filter of its own. The registry's own `tools.restrict()` cannot help either: it requires an agent-scoped context and rejects a name it does not already know, so it cannot pre-deny a tool from a server that has not connected yet. A guard would deny the call but leave the tool in the request.

So each server is mounted in its own child fiber whose context carries an own `tools` property. Only cordis's root context is a proxy; every context below it is a plain object created from its parent, so a name defined on one of them is found by ordinary prototype-chain lookup and the service resolution behind that proxy is never reached for it. The upstream client's `ctx.tools.register` therefore lands on this plugin's per-server gate while every other service it reads stays the real one. The gate keeps every definition the server offered, forwards only the approved ones to the real registry, and re-forwards on a tick without touching the connection. Nothing in the upstream package is modified.

That rests on one invariant: **the upstream client reaches the registry through the `ctx.tools` property.** Only a property read is shadowed, not `ctx.get('tools')`, which resolves through the service store and would hand back the real registry — an upstream version that switched to it would register straight past this gate. `tests/tool-service-substitution.spec.ts` pins the invariant against the real upstream plugin and a real server: it fails if any registration reaches the real registry instead of the gate.

Servers are brought up in parallel, and each server's own work is serialized against its own earlier work, so a server that never answers holds up only itself.

A first connection that outlives `connectTimeoutMs` is let go of rather than waited for. A cordis fiber cannot be unloaded while its startup is still running — disposing it waits out that startup, which is exactly the minute the budget exists to escape — so the same own-property substitution is used a second time: the child context also carries its own `effect`, which registers the upstream plugin's effects on its own fiber as usual and hands this plugin their disposers. Running those closes the client, so `initialize` rejects and the fiber finishes on its own, the child process is reaped in the moment rather than a minute later, and the server name the upstream client reserves is released — so the next attempt at the same server is not refused as a duplicate.
