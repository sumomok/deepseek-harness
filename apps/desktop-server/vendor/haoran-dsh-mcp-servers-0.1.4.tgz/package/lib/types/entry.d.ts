/**
 * Reading one stored entry's id — the one thing the host half and the browser
 * half both do to a raw `servers` entry, since both rewrite one record while
 * carrying every other entry through byte for byte.
 *
 * It lives in a module of its own, and not beside the rest of the document's
 * judgement in `settings-document.ts`, because the browser bundle imports it:
 * that module pulls in zod and schemastery, and neither may ride into a page
 * load for one field read.
 *
 * @module @haoran/dsh-mcp-servers/entry
 */
/**
 * @param value - one entry of the stored `servers` array.
 * @returns its id, when it has a usable one.
 */
export declare function idOf(value: unknown): string | undefined;
//# sourceMappingURL=entry.d.ts.map