/**
 * Reading and writing the stored server records from the browser.
 *
 * Two promises, and they differ per entry. An entry with no usable `id` is
 * carried through byte for byte on every write, because the page cannot
 * address it and must not lose it. An entry WITH an id is rewritten to this
 * plugin's own schema whenever the page saves it: every field is re-read
 * loosely, missing ones take their default, and a field this version does not
 * know is dropped — the same fields the host's own parse keeps, so what the
 * page saves is what the host will read back.
 *
 * @module @haoran/dsh-mcp-servers/client/records
 */
import type { ServerRecord } from '../types.ts';
/**
 * Read one stored record into a complete draft the form can edit.
 * @param value - the stored record.
 * @returns the draft, or undefined when the entry has no usable id.
 */
export declare function readServerRecord(value: unknown): ServerRecord | undefined;
/**
 * A new, empty record.
 * @param id - the id minted for it.
 * @returns the draft.
 */
export declare function blankRecord(id: string): ServerRecord;
/**
 * Mint an id no stored record uses.
 *
 * The id is the tool-name namespace, so it is reduced to the characters that
 * grammar accepts and made unique by a counter rather than by anything the
 * person typed, which they may repeat.
 * @param label - the name the person gave the server.
 * @param taken - ids already in the document.
 * @returns the new id.
 */
export declare function mintServerId(label: string, taken: readonly string[]): string;
/**
 * Replace one record in the stored array, keeping every other entry byte for
 * byte, including one this page could not read.
 * @param stored - the array as the document holds it.
 * @param next - the record to store.
 * @returns the array to write back.
 */
export declare function withRecord(stored: readonly unknown[], next: ServerRecord): unknown[];
/**
 * Drop one record from the stored array.
 * @param stored - the array as the document holds it.
 * @param id - the record to drop.
 * @returns the array to write back.
 */
export declare function withoutRecord(stored: readonly unknown[], id: string): unknown[];
/**
 * Parse the arguments textarea, one argument per line.
 * @param text - the field's raw text.
 * @returns the arguments, empty lines dropped.
 */
export declare function parseArgsText(text: string): string[];
//# sourceMappingURL=records.d.ts.map