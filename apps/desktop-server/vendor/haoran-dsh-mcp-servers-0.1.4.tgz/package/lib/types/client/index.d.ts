/**
 * Browser half: one settings page.
 *
 * The only host path is the Remote this package's host half exports — one
 * read, no mutator. Everything the page changes it writes to the settings
 * document through the scope every settings row writes through, so this plugin
 * adds no way to start a process or admit a tool that does not go through the
 * settings seam.
 *
 * @module @haoran/dsh-mcp-servers/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type McpServersKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-mcp-servers` copy. */
        mcpServers: McpServersKey;
    }
}
export { idOf } from '../entry.ts';
export { CONTRIBUTION, parseServerViews } from './contribution.ts';
export { badgeTone, confirmCopy, McpSection, reasonText, statusKey } from './McpSection.tsx';
export type { ConfirmCopy, McpSectionInjected, McpSectionProps } from './McpSection.tsx';
export { blankRecord, mintServerId, parseArgsText, readServerRecord, withoutRecord, withRecord, } from './records.ts';
export { ServerForm } from './ServerForm.tsx';
export type { ServerFormProps } from './ServerForm.tsx';
export { insertStyles, STYLE_TAG } from './styles.ts';
/** Required browser services. */
export declare const inject: string[];
/**
 * How often the open settings page re-reads the host.
 *
 * A page-local interval rather than a config field: it runs only while someone
 * is looking at this page, and it is what makes a server that changed its own
 * tool list show up without the person reloading anything.
 */
export declare const POLL_MS = 3000;
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 */
export declare function apply(ctx: Context): Promise<void>;
//# sourceMappingURL=index.d.ts.map