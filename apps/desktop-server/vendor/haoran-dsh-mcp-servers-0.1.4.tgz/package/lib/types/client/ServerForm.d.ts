/**
 * The add/change form for one server.
 *
 * Two kinds, and only two: a program already installed on this computer,
 * named by its full path, and a web address. Neither is a package name this
 * app could fetch, because it ships no package manager for one.
 *
 * @module @haoran/dsh-mcp-servers/client/ServerForm
 */
import { type ReactNode } from 'react';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { ServerRecord } from '../types.ts';
/** Props the form reads. */
export interface ServerFormProps {
    /** The record being edited; a blank one when adding. */
    initial: ServerRecord;
    /** Whether this is a new record, which changes the heading only. */
    adding: boolean;
    /** Store the edited record. */
    onSave: (next: ServerRecord) => void;
    /** Leave the form without storing. */
    onCancel: () => void;
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'mcpServers'>;
}
/**
 * The add/change form.
 * @param props - the record being edited and the two exits.
 * @returns the form.
 */
export declare function ServerForm({ initial, adding, onSave, onCancel, t }: ServerFormProps): ReactNode;
//# sourceMappingURL=ServerForm.d.ts.map