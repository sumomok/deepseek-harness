/**
 * The browser half's Typert contribution: the consumer-side mirror of
 * `../typert.ts`.
 *
 * The descriptor must match the host manifest's invocation exactly — same id,
 * namespace, method, and parameter wire names — because the gateway matches
 * arguments by field name. The codec is a hand-written narrowing rather than a
 * schema library: this file is bundled into the browser, and a validator's
 * bytes would ride into every page load for one small read.
 *
 * @module @haoran/dsh-mcp-servers/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { McpServerView } from '../types.ts';
/**
 * Narrow the server list.
 * @param value - the wire value.
 * @returns the views.
 */
export declare function parseServerViews(value: unknown): McpServerView[];
/** The contribution `ctx.remote.$mount()` installs, mirroring `../typert.ts`. */
export declare const CONTRIBUTION: TypertRemoteContribution;
//# sourceMappingURL=contribution.d.ts.map