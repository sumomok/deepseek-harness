/**
 * The per-server gate between the upstream MCP client plugin and the harness
 * tool registry.
 *
 * The upstream plugin registers every tool its server lists, straight onto
 * `ctx.tools`. This gate stands in for that service inside the one context the
 * upstream plugin runs in, so a tool the person has not approved is never
 * registered at all, rather than blocked at call time. An unregistered tool is
 * absent from the model's schema list, which is the only way to keep an
 * unreviewed tool out of the request entirely.
 *
 * **Invariant this rests on: the upstream plugin reaches the registry only
 * through the `ctx.tools` PROPERTY.** A context's own property shadows a
 * property read, not `ctx.get('tools')`, which resolves through the service
 * store and would return the real registry — so an upstream version that
 * switched to `ctx.get('tools')`, or that took a registry reference from
 * anywhere else, would register straight past this gate and every unapproved
 * tool would reach the model. `tests/tool-service-substitution.spec.ts` pins
 * the invariant against the real upstream plugin: it fails if a registration
 * ever arrives at the real registry instead of here.
 *
 * Approval is pinned to wording, not to a name: the fingerprint covers the
 * tool's name, description, and input schema, so a server that rewrites any of
 * them offers something the person has not seen, and it returns to pending
 * until they approve it again.
 *
 * The gate also holds the SET a server was trusted at, and reports when what it
 * offers stops matching — a tool added, dropped, or rewritten, announced or
 * not. That report is what puts the server's row in front of a person. It does
 * NOT take the server's other tools down: a tool that was ticked and whose
 * wording the server did not touch is the same tool the person read, and the
 * per-tool approval above already withholds exactly the ones this change is
 * about, because a new or reworded tool matches no stored approval.
 *
 * @module @haoran/dsh-mcp-servers/tool-gate
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { ApprovedTool, McpToolView, ServerReason } from './types.ts';
/** Why the last tool call this server ran did not reach a result. */
export interface CallFailure {
    /** Which of the two ways a call can fail to come back this was. */
    reason: Extract<ServerReason, 'call-failed' | 'call-slow'>;
    /** The connection error, or the budget in seconds a slow call outlived. */
    detail: string;
}
/** The one `ctx.tools` member the upstream MCP client plugin uses. */
export interface ToolRegistrar {
    /**
     * Register one tool and return its unregister disposer.
     * @param definition - the complete tool definition.
     * @returns the disposer that unregisters it.
     */
    register(definition: ToolDefinition): () => void;
}
/**
 * Render a budget for the row that reports it: one decimal below ten seconds,
 * whole seconds at or above it, so a sub-second budget keeps a digit and a
 * minute does not read as `60.0`.
 * @param ms - a number of milliseconds.
 * @returns the budget in seconds.
 */
export declare function secondsOf(ms: number): string;
/**
 * One server's gate. It is both the stand-in tool service handed to the
 * upstream plugin and the read model the settings page renders.
 */
export declare class ToolGate implements ToolRegistrar {
    private readonly target;
    private readonly onError;
    private readonly onToolsChanged;
    private readonly toolCallTimeoutMs;
    private readonly entries;
    private approved;
    private expected;
    private lastCallFailure;
    private disposed;
    /** Set while a coalesced settlement is queued behind the current task. */
    private queued;
    /**
     * @param target - the real tool registry an approved tool reaches.
     * @param approved - the tools the person has admitted.
     * @param expected - the tool-set fingerprint this server was trusted at;
     *   the empty string while none was ever recorded, which reports no change.
     * @param onError - receives a registration failure raised outside the
     *   upstream plugin's own transaction, which is the case when an approval is
     *   switched on against an already open connection.
     * @param onToolsChanged - receives the news that this server's tool set
     *   changed while it was connected, once the whole change has landed.
     * @param toolCallTimeoutMs - the per-call budget this server's connection
     *   was built with, which is what tells the deadline this side armed apart
     *   from an error that arrived on its own.
     */
    constructor(target: ToolRegistrar, approved: readonly ApprovedTool[], expected: string, onError: (error: unknown) => void, onToolsChanged: () => void, toolCallTimeoutMs: number);
    /**
     * Fingerprint of the set this server offers right now.
     * @returns the fingerprint, over every tool the gate currently holds.
     */
    toolset(): string;
    /**
     * Whether the set on offer is not the one this server was trusted at, which
     * is what a person is asked to confirm.
     * @returns true while the recorded set and the offered set disagree; false
     *   while nothing was ever recorded, which is a server just stored.
     */
    toolsetChanged(): boolean;
    /**
     * The tool-set fingerprint this server is trusted at right now.
     * @returns the fingerprint, or the empty string while none was recorded.
     */
    trusted(): string;
    /**
     * Adopt the tool-set fingerprint this server is trusted at.
     *
     * Nothing is registered or unregistered by it: which tools are live follows
     * the per-tool approvals alone, and confirming a changed set is what lets a
     * person tick the tools that changed — it does not tick them.
     * @param expected - the fingerprint now recorded, or the empty string for none.
     */
    expect(expected: string): void;
    /**
     * Take one tool from the upstream plugin, forwarding it to the real registry
     * only while it is approved.
     *
     * A throw here reaches the upstream plugin's own rollback, which is what
     * keeps a partially registered generation from ever becoming visible.
     *
     * After {@link ToolGate.dispose} it accepts nothing: a connection this
     * plugin has let go of can still be mid-sync, and a late registration would
     * put a tool back in front of the model for a server that is gone.
     * @param definition - the tool definition the upstream plugin built.
     * @returns the disposer the upstream plugin owns for this tool; a no-op once
     *   this gate is disposed.
     */
    register(definition: ToolDefinition): () => void;
    /**
     * Adopt a new approval set, registering and unregistering to match it.
     *
     * This is why approving a tool does not restart its server: ticking it in the
     * settings page moves it into the registry against the connection that is
     * already open.
     * @param approved - the tools the person has admitted.
     */
    setApproved(approved: readonly ApprovedTool[]): void;
    /**
     * Why the last tool call this server ran never reached a result, or nothing
     * when it did — including when the result it reached was the server's own
     * failure.
     *
     * The upstream client publishes no connection state and keeps a dropped
     * server's tools registered, so a call that never comes back is the only
     * evidence this plugin has that a server stopped answering.
     * @returns the failure, or undefined.
     */
    callFailure(): CallFailure | undefined;
    /**
     * Every tool this server currently offers, live and waiting alike.
     * @returns the tools, ordered by registered name.
     */
    tools(): McpToolView[];
    /** Unregister everything this gate put in the registry, and accept no more. */
    dispose(): void;
    /**
     * Whether one tool belongs in the registry: the person ticked this exact
     * wording. A server's tool set changing does not enter into it — the tools
     * that changed are the ones no approval matches any more.
     */
    private wants;
    /**
     * Bring the registry in line with the approvals.
     *
     * A registration that fails here is outside the upstream plugin's
     * transaction, so it is reported on that tool's own row instead of failing
     * anything else.
     */
    private reconcile;
    /**
     * Report the change once the whole of it has landed, rather than at each
     * step of it.
     *
     * The upstream plugin swaps a generation by disposing every previous
     * registration and then registering the next one, synchronously; announced
     * step by step, every intermediate set would be reported as a change of its
     * own, and in `confirm: approval` each would be a question put to a person.
     * One coalesced report behind the current task sees only the finished set.
     */
    private announceLater;
    /**
     * Wrap one definition so this gate learns whether its calls come back.
     * Everything else about the definition is passed through by reference, so
     * the registry sees the upstream contract unchanged.
     */
    private observed;
    /**
     * Read one failed call as this side's deadline, as the connection, or as the
     * server answering.
     *
     * What the elapsed time separates is narrow, and it is not "slow server" versus
     * "dropped connection": a `RequestTimeout` that measures the whole budget is
     * the timer armed with THIS call firing, and nothing came back to say why.
     * A server still working on the call and a request the transport lost
     * silently both surface exactly that way, at exactly that time, so the row
     * it produces must claim neither. What it does rule out is an error that
     * arrived on its own — a closed connection, a transport failure, a
     * `RequestTimeout` from anywhere else — because those arrive when they
     * arrive, not on this budget.
     *
     * A failed RESULT records nothing, just as a successful one clears the
     * record: the server answered, which is the fact this record is about.
     */
    private classify;
}
//# sourceMappingURL=tool-gate.d.ts.map