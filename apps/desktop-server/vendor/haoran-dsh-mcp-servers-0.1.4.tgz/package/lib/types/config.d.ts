/**
 * Plugin configuration. Every field is changeable from `cordis.yml` and
 * validated at load.
 *
 * The server list is deliberately NOT here. Servers are added and removed from
 * the settings page while the app runs; a composition entry would need a
 * restart, and a person who cannot open a terminal cannot edit one.
 *
 * The settings namespace name is not here either, for a reason the other
 * fields do not share: the browser half binds the same namespace and has no
 * config channel of its own, so a name only the host could see would leave the
 * two halves reading different documents. It is a shared constant instead
 * (`settings-namespace.ts`), as in `@sumomok/dsh-balance`.
 *
 * @module @haoran/dsh-mcp-servers/config
 */
import s from '@deepseek-ai/schemastery';
/** Which channel asks whether a server may be connected. */
export type ConfirmChannel = 'settings' | 'approval';
/** Plugin configuration. */
export interface Config {
    /** Whether the plugin acts at all; false leaves the composition without MCP servers. */
    enabled?: boolean;
    /**
     * Which channel asks whether a server may be connected.
     *
     * `settings` takes the stored confirmation in the settings document as the
     * answer. `approval` asks through the harness approval channel, which can
     * only reach someone while exactly one conversation is open and mid-turn,
     * and refuses otherwise.
     */
    confirm?: ConfirmChannel;
    /**
     * Per-tool-call timeout handed to every server connection, in milliseconds.
     * A finite number from 1 to {@link MAX_TIMEOUT_MS}.
     */
    toolCallTimeoutMs?: number;
    /**
     * How long one server's FIRST connection may take before this plugin gives
     * up on it, in milliseconds.
     *
     * The upstream client hands the MCP SDK its own default request timeout for
     * `initialize` and offers no way to shorten it, so a server that accepts a
     * connection and then says nothing would otherwise hold this plugin for a
     * minute. Servers connect in parallel, so this bounds one server rather than
     * the whole pass; a slow machine, or a server that indexes something before
     * it answers, is what this is raised for. A finite number from 1 to
     * {@link MAX_TIMEOUT_MS}.
     */
    connectTimeoutMs?: number;
}
/**
 * The longest delay `setTimeout` keeps. Past it a timer fires immediately, so
 * a larger budget would mean no budget at all.
 */
export declare const MAX_TIMEOUT_MS = 2147483647;
export declare const Config: s<Config>;
/** The two timeouts, after the one explicit resolve step. */
export interface ResolvedTimeouts {
    /** Per-tool-call timeout handed to every server connection. */
    toolCallTimeoutMs: number;
    /** Budget for one server's first connection. */
    connectTimeoutMs: number;
}
/**
 * The one explicit resolve step from raw config to the timeouts this plugin
 * runs on, so a value the schema cannot judge fails the plugin at load rather
 * than silently becoming a one-millisecond budget.
 * @param config - the plugin config.
 * @returns the resolved timeouts.
 * @throws {Error} when either timeout is not a usable number of milliseconds.
 */
export declare function resolveTimeouts(config: Config): ResolvedTimeouts;
//# sourceMappingURL=config.d.ts.map