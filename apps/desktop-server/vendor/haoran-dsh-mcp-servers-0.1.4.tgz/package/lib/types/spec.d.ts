/**
 * Turn one stored record into the config the upstream MCP client plugin
 * takes, rejecting everything that plugin would otherwise be handed blind.
 *
 * The checks mirror the harness's own programmatic mount (`dsh-acp`'s
 * `mountAcpMcpServers`): an absolute program path, an `http(s)` URL, header
 * names and values the HTTP layer accepts, environment names without `=` or
 * NUL, and null-prototype records so an entry literally named `__proto__`
 * stays data. Two checks go beyond it. A URL carrying a user name or password
 * in front of the host is refused, because that is a secret written into a
 * field this plugin shows on screen and stores in plain settings. A URL
 * carrying a fragment is refused as well: the fragment never leaves the
 * client, so it cannot mean anything to the server, and keeping it would put
 * a part of the destination in the record that nothing ever sends.
 *
 * @module @haoran/dsh-mcp-servers/spec
 */
import type * as McpClient from '@deepseek-ai/dsh-mcp-client';
import type { ServerReason, ServerRecord } from './types.ts';
/** One resolved name/value pair, after any credential reference was read. */
export type ResolvedEntry = readonly [name: string, value: string];
/** A record this plugin refuses to start, with the settings page's own reason. */
export declare class ServerSpecError extends Error {
    /** The closed reason code the settings page renders. */
    readonly reason: ServerReason;
    /** Free text accompanying the reason — a name, or a message. */
    readonly detail: string;
    /**
     * @param reason - the closed reason code.
     * @param detail - free text accompanying it; empty when there is none.
     */
    constructor(reason: ServerReason, detail: string);
}
/**
 * Build the upstream MCP client config for one record.
 *
 * Reconnection is left at the upstream defaults: a server that drops is
 * retried without this plugin restating a policy it has no better answer for.
 * @param record - the parsed server record.
 * @param resolved - the record's already-resolved headers and environment entries.
 * @param toolCallTimeoutMs - per-tool-call timeout from this plugin's config.
 * @returns the config to hand `ctx.plugin(McpClient, ...)`.
 * @throws {ServerSpecError} when the record names a destination this plugin will not start.
 */
export declare function buildClientConfig(record: ServerRecord, resolved: {
    headers: readonly ResolvedEntry[];
    env: readonly ResolvedEntry[];
}, toolCallTimeoutMs: number): McpClient.Config;
/**
 * One line naming where a server connects, for the settings page, the
 * confirmation channel, and the Remote view — the same string in all three, so
 * what someone confirms is what they were shown.
 *
 * A URL is reduced to its origin and path. The query string is dropped because
 * it is a common place for an API key, and this string is rendered on screen,
 * handed to whatever answers a confirmation, and returned over the wire —
 * {@link endpointHasQuery} reports that one was dropped, so a display can say
 * so without showing it, and two records differing only in their query do not
 * read as the same destination.
 * @param record - the parsed server record.
 * @returns the command line, or the URL without its query.
 */
export declare function describeEndpoint(record: ServerRecord): string;
/**
 * Whether this record's destination carries a query string that
 * {@link describeEndpoint} left out.
 * @param record - the parsed server record.
 * @returns true when an http record's URL has a query.
 */
export declare function endpointHasQuery(record: ServerRecord): boolean;
//# sourceMappingURL=spec.d.ts.map