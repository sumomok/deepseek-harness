/**
 * Stable digests over the three things a stored confirmation is pinned to:
 * where a server connects, the exact wording of one tool, and the whole set of
 * tools a server offered when it was trusted. Each is compared against a stored
 * value, so each must be order-independent and representation-independent — the
 * same facts written in a different key order are the same facts.
 *
 * @module @haoran/dsh-mcp-servers/fingerprint
 */
import type { ServerRecord } from './types.ts';
/**
 * Serialize a JSON value with every object's keys in sorted order.
 * @param value - the value to serialize; `undefined` members are omitted.
 * @returns the canonical JSON text.
 */
export declare function canonicalJson(value: unknown): string;
/**
 * Digest one tool's model-facing wording. Description and input schema are
 * included because those are what a person read when they approved it: a
 * server that rewrites either is offering a different tool.
 * @param name - the registered, model-facing tool name.
 * @param description - the server's own description, verbatim.
 * @param parameters - the server's own input schema, verbatim.
 * @returns the fingerprint stored beside an approval.
 */
export declare function toolFingerprint(name: string, description: string, parameters: unknown): string;
/**
 * Digest the whole set of tools one server offers, from the wording
 * fingerprints of its members. This is what a server is trusted at: a server
 * that adds a tool, drops one, or rewrites one offers a set nobody has seen,
 * and returns to waiting until a person confirms it.
 *
 * Discovery order carries no meaning — the protocol's list is whatever the
 * server sends — so the members are sorted before they are digested. An empty
 * set still digests to a value, which is what separates "this server offers
 * nothing" from "nothing was ever recorded", the empty string.
 * @param tools - the tools currently offered, each with its own wording fingerprint.
 * @returns the fingerprint stored as a record's `confirmedTools`.
 */
export declare function toolsetFingerprint(tools: readonly {
    name: string;
    fingerprint: string;
}[]): string;
/**
 * Digest where a server connects and under what identity. A change here
 * retires the person's confirmation: the record still carries their old
 * fingerprint, which no longer matches.
 *
 * Literal header and environment VALUES are included, so replacing a token
 * typed into the form is a change the person confirms again. An entry naming a
 * credential contributes only that name — the secret is never in the settings
 * document, and rotating it behind the same name is not a change of
 * destination.
 * @param record - the parsed server record.
 * @returns the fingerprint compared against `record.confirmedEndpoint`.
 */
export declare function endpointFingerprint(record: ServerRecord): string;
/**
 * Where one record stands against the destination confirmation stored on it.
 */
export type RecordTrust = 
/**
 * Nothing was ever confirmed. Storing the record IS the consent — a person
 * filled the form in and saved it — so the server connects and the tool set
 * it turns out to offer is recorded as the one that was trusted.
 */
'first'
/** The stored confirmation still describes this record's destination. */
 | 'confirmed'
/**
 * The destination was edited after it was confirmed, so the record no longer
 * describes the place that was agreed to and the server stays unconnected.
 */
 | 'endpoint-changed';
/**
 * Read one record's destination confirmation.
 * @param record - the parsed server record.
 * @returns where it stands.
 */
export declare function recordTrust(record: ServerRecord): RecordTrust;
//# sourceMappingURL=fingerprint.d.ts.map