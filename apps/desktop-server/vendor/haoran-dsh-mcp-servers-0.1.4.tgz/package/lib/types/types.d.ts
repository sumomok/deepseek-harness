/**
 * Values shared by the host half, the browser half, and the settings
 * document: one stored server record, and the read-only view the settings
 * page renders.
 *
 * @module @haoran/dsh-mcp-servers/types
 */
/** Which transport a server record describes. */
export type ServerTransport = 'stdio' | 'http';
/**
 * One named value a connection carries: an HTTP header, or an environment
 * entry for a local program. Both take their value the same two ways, so both
 * can name a saved credential instead of storing the secret.
 */
export interface NamedValue {
    /** Header name, or environment variable name. */
    name: string;
    /** Literal value. Exactly one of `value` and `credential` is set. */
    value?: string;
    /**
     * Name of a credential reference resolved through `ctx.credentials` at mount
     * time. The value itself never enters the settings document.
     */
    credential?: string;
}
/** One tool the person admitted, pinned to the exact wording they saw. */
export interface ApprovedTool {
    /** Model-facing registered name (`mcp__<server>__<raw>`). */
    name: string;
    /** Fingerprint of the name, description, and input schema that were approved. */
    fingerprint: string;
}
/**
 * One stored server, after parsing. Every field is present: the parser fills
 * the defaults so no consumer repeats them.
 */
export interface ServerRecord {
    /** Stable id, also the tool-name namespace (`mcp__<id>__<raw>`). */
    id: string;
    /** Name shown in the settings page. */
    label: string;
    /** Whether the person wants this server running at all. */
    enabled: boolean;
    /** Which transport the remaining fields describe. */
    transport: ServerTransport;
    /** stdio: absolute path of the program to start. */
    command: string;
    /** stdio: arguments passed without shell interpolation. */
    args: string[];
    /** stdio: working directory; empty inherits the host's. */
    cwd: string;
    /** stdio: extra environment entries merged over the scrubbed ambient env. */
    env: NamedValue[];
    /** http: the endpoint URL. */
    url: string;
    /** http: headers sent with every request. */
    headers: NamedValue[];
    /**
     * Endpoint fingerprint that was confirmed. Empty while nothing was ever
     * confirmed, which is the first-trust state; a stored value that no longer
     * matches the record's own connection facts means they were edited since,
     * and the server stays unmounted until someone confirms again.
     */
    confirmedEndpoint: string;
    /**
     * Fingerprint of the tool set this server was trusted at. Empty until the
     * first connection observed one, which is when it is recorded without asking.
     * A server that later offers a different set puts its row back in front of a
     * person; the tools that CHANGED are the ones out of the model's reach, since
     * no approval matches their wording, while a ticked tool the server did not
     * touch keeps working.
     */
    confirmedTools: string;
    /** Tools the person admitted, by the exact wording they approved. */
    approvedTools: ApprovedTool[];
}
/** The parsed settings document. */
export interface McpServersDocument {
    /** Every stored server, in the order the document lists them. */
    servers: ServerRecord[];
}
/** Why a server is not currently serving tools; empty when nothing is wrong. */
export type ServerReason = ''
/** stdio without a program to start. */
 | 'command-missing'
/** stdio whose program is not an absolute path. */
 | 'command-relative'
/** stdio whose environment entries are unusable. */
 | 'env-invalid'
/** http without a usable `http(s)` URL. */
 | 'url-invalid'
/** http whose URL carries a user name or password in front of the host. */
 | 'url-userinfo'
/** http whose URL carries a `#` part, which never reaches the server. */
 | 'url-fragment'
/** http whose headers are unusable. */
 | 'header-invalid'
/** A header or environment entry names a saved credential that is not stored, or storage is absent. */
 | 'credential-missing'
/** The destination was edited after it was confirmed. */
 | 'endpoint-changed'
/** The server now offers a different set of tools than the one it was trusted at. */
 | 'tools-changed'
/** The server was reached but the connection or its tool list failed. */
 | 'connect-failed'
/** The first connection did not settle inside this plugin's own budget. */
 | 'connect-timeout'
/** An earlier attempt at this server has not finished shutting down. */
 | 'previous-attempt-still-closing'
/** The last tool call this server ran never reached a result. */
 | 'call-failed'
/**
 * Nothing came back from the last tool call before this plugin's own
 * per-call budget ran out, so what fired was the deadline this side armed.
 * Whether the server is still working on it or the request was lost on the
 * way is not knowable from that, and neither is claimed. `detail` carries
 * the budget in seconds.
 */
 | 'call-slow';
/** What the settings page shows for one server. */
export type ServerStatus = 
/** Switched off by the person. */
'disabled'
/**
 * Waiting for a person: either the destination was edited after it was
 * confirmed, or the server changed the tools it offers. A newly stored
 * server is NOT here — storing it is the consent, and it goes straight to
 * `connecting`.
 */
 | 'needs-confirm'
/** A connection attempt is in flight; any earlier reason is still on the view. */
 | 'connecting'
/** Confirmed and enabled, but unusable for the reason on the view. */
 | 'blocked'
/** Connected; its tools are the ones listed. */
 | 'connected'
/**
 * Connected, but the last tool call did not come back — the connection
 * dropped or broke the protocol, or the call outlived this plugin's own
 * per-call budget, which `reason` tells apart. A tool answering with a
 * failed RESULT does not put a server here: that is the server answering.
 * The upstream client exposes no connection state, so a call that never
 * comes back is the only evidence this plugin has that a server stopped
 * answering.
 */
 | 'degraded';
/** One tool a connected server offers. */
export interface McpToolView {
    /** Model-facing registered name (`mcp__<server>__<raw>`). */
    name: string;
    /** The server's own description, verbatim. */
    description: string;
    /** Fingerprint of this exact name, description, and input schema. */
    fingerprint: string;
    /**
     * Whether this exact wording is in the model's tool list right now. False for
     * a tool nobody ticked, for one the server added, and for one whose wording
     * changed since it was ticked. A server waiting for its tool set to be
     * confirmed does not change this for any other tool it offers.
     */
    approved: boolean;
    /**
     * Why this tool is not in the registry although it is approved — a
     * registration that failed after the connection was already open. Empty
     * when there is nothing to report.
     */
    error: string;
}
/** One server as the settings page renders it. */
export interface McpServerView {
    /** The record's stable id. */
    id: string;
    /** Name shown in the settings page. */
    label: string;
    /** Which transport this server uses. */
    transport: ServerTransport;
    /** Whether the person switched it on. */
    enabled: boolean;
    /** What the settings page shows. */
    status: ServerStatus;
    /** Why it is not serving tools; empty when nothing is wrong. */
    reason: ServerReason;
    /**
     * Free text accompanying `reason` — a credential name, a connection error,
     * or the per-call budget in seconds that a slow call outlived.
     */
    detail: string;
    /**
     * Display-only summary of where it connects: the command line, or the URL
     * without its query.
     */
    endpoint: string;
    /**
     * Whether `endpoint` left out a query string. The query itself is never
     * shown — it is a common place for a key — but a display that hides its
     * presence too would make two different destinations read as one.
     */
    endpointHasQuery: boolean;
    /**
     * Fingerprint of this record's current connection facts. Storing it as the
     * record's `confirmedEndpoint` is what confirms this exact destination; the
     * settings page takes it from here rather than computing it, so the two
     * halves cannot disagree about what was agreed to.
     */
    endpointFingerprint: string;
    /**
     * Fingerprint of the tool set this server is offering right now, empty while
     * it is not connected. Storing it as the record's `confirmedTools` is what
     * confirms this exact set; storing the empty string retires whatever was
     * recorded, so the next connection records what it finds.
     */
    toolsetFingerprint: string;
    /** Tools this server currently offers, approved and pending alike. */
    tools: McpToolView[];
    /** How many of `tools` are waiting for approval. */
    pendingCount: number;
}
//# sourceMappingURL=types.d.ts.map