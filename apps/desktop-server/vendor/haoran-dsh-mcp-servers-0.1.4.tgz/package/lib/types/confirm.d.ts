/**
 * The channel that asks a person whether one server may keep offering its
 * tools after it changed which ones it offers.
 *
 * Nothing is asked when a server is first stored: filling the form in and
 * saving it IS the consent, and the set of tools that server turns out to
 * offer is recorded without a second question. What the person cannot consent
 * to in advance is a change the SERVER makes afterwards — a tool added,
 * dropped, or reworded, which the protocol lets it do at any moment — and that
 * is the one thing this channel is reached for.
 *
 * It is a seam so the desktop shell can later answer with a native window the
 * web UI cannot forge, without anything else in this plugin changing.
 *
 * @module @haoran/dsh-mcp-servers/confirm
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ServerTransport } from './types.ts';
/** The server a person is being asked about. */
export interface ServerTrustRequest {
    /** The record's stable id, also its tool-name namespace. */
    id: string;
    /** The name the person gave this server. */
    label: string;
    /** Which transport it uses. */
    transport: ServerTransport;
    /** Where it connects: the command line, or the URL without its query. */
    endpoint: string;
    /** Whether `endpoint` left out a query string. */
    endpointHasQuery: boolean;
}
/** Answers whether one server may keep serving the tools it now offers. */
export interface ServerConfirmer {
    /**
     * Ask about one server.
     * @param request - which server is being asked about.
     * @returns true to trust the set of tools it now offers.
     */
    confirm(request: ServerTrustRequest): Promise<boolean>;
}
/**
 * The answer the settings page itself carries.
 *
 * The answer to this question lives in the settings document: a person confirms
 * a server's new tool set by clicking on its row, which stores the fingerprint
 * of that set. Reaching this channel at all means the document does not hold
 * the set on offer yet, so the answer is no — and the row shows the button
 * that changes it.
 */
export declare const settingsConfirmer: ServerConfirmer;
/**
 * Ask through the harness's approval channel, which reaches whatever surface
 * currently answers approvals.
 *
 * The channel is agent-bound and turn-bound: it can only ask while exactly one
 * conversation is open and mid-turn — which is, in fact, when a server most
 * often changes its tool list, because a tool call is what makes it. Outside
 * that window there is nobody to ask, and this confirmer refuses, leaving the
 * settings page to ask instead.
 * @param ctx - the plugin context.
 * @returns the confirmer.
 */
export declare function approvalConfirmer(ctx: Context): ServerConfirmer;
/**
 * Pick the configured channel.
 * @param ctx - the plugin context.
 * @param mode - the configured channel name.
 * @returns the confirmer for that mode.
 */
export declare function resolveConfirmer(ctx: Context, mode: 'settings' | 'approval'): ServerConfirmer;
//# sourceMappingURL=confirm.d.ts.map