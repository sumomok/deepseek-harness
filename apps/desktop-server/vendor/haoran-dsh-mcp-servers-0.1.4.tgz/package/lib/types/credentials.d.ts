/**
 * Resolve the named values one record's connection carries: HTTP headers for a
 * web address, environment entries for a local program.
 *
 * A value is either literal or a reference to a saved credential. The
 * reference is resolved through `ctx.credentials` at each mount, so rotating
 * the secret behind a name reaches the next connection without editing the
 * settings document — and the secret itself never enters that document,
 * whether it belongs to a header or to an environment entry.
 *
 * @module @haoran/dsh-mcp-servers/credentials
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ResolvedEntry } from './spec.ts';
import type { NamedValue, ServerRecord } from './types.ts';
/**
 * Resolve one list of named values to literal ones.
 * @param ctx - the plugin context; its `credentials` service is optional.
 * @param entries - the stored entries.
 * @returns ordered name/value pairs.
 * @throws {ServerSpecError} `credential-missing` when a referenced credential
 *   cannot be read, naming the reference.
 */
export declare function resolveNamedValues(ctx: Context, entries: readonly NamedValue[]): Promise<ResolvedEntry[]>;
/**
 * Resolve everything one record's connection needs from the credential seam.
 * @param ctx - the plugin context.
 * @param record - the parsed server record.
 * @returns the resolved headers and environment entries.
 * @throws {ServerSpecError} `credential-missing`, as {@link resolveNamedValues} does.
 */
export declare function resolveConnection(ctx: Context, record: ServerRecord): Promise<{
    headers: ResolvedEntry[];
    env: ResolvedEntry[];
}>;
/**
 * Every credential reference one record names, across both lists. The single
 * definition of "which credentials does this server depend on", so deciding
 * whether a credential change affects a server cannot drift from what mounting
 * it actually reads.
 * @param record - the parsed server record.
 * @returns the reference names, without duplicates.
 */
export declare function credentialNames(record: ServerRecord): string[];
//# sourceMappingURL=credentials.d.ts.map