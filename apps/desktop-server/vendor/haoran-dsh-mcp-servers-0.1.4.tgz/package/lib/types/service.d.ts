/**
 * The `mcpServers` Service Definition and its Typert Remote face.
 *
 * One read, no mutator. Everything a person changes — adding a server,
 * confirming it, ticking a tool — is a write to the settings document through
 * the settings seam the whole GUI already writes through, so this plugin adds
 * no wire path that could start a process or admit a tool.
 *
 * @module @haoran/dsh-mcp-servers/service
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { ServerConfirmer } from './confirm.ts';
import type { McpServerView } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Connected MCP servers and the tools they offer (provided by `@haoran/dsh-mcp-servers`). */
        mcpServers: McpServersService;
    }
}
/** Read-only view of this installation's MCP servers. */
export declare abstract class McpServersService extends TypertRemoteService {
    /**
     * @param ctx - owning plugin context.
     */
    constructor(ctx: Context);
    /**
     * Every stored server: what it connects to, whether it is running, and the
     * tools it currently offers with their approval state.
     * @returns one view per stored server, in document order.
     */
    abstract list(): Promise<McpServerView[]>;
    /**
     * Replace the channel that answers whether a server may be connected. Not
     * part of the Remote face: only a plugin in this process can install one,
     * which is what lets a desktop shell answer with a window the web UI cannot
     * forge.
     * @param confirmer - the replacement channel.
     * @returns the disposer restoring the previous channel.
     */
    abstract useConfirmer(confirmer: ServerConfirmer): () => void;
    /**
     * Remote face of {@link McpServersService.list}; the decorator cannot mark
     * the abstract member, so this concrete adapter carries the identical contract.
     * @returns one view per stored server, in document order.
     */
    remoteExportList(): Promise<McpServerView[]>;
}
export default McpServersService;
//# sourceMappingURL=service.d.ts.map