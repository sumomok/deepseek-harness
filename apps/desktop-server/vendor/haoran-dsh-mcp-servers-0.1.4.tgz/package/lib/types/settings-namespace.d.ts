/**
 * This plugin's settings namespace name, shared between the host half (which
 * hands it to `SettingsProvider.installSection`) and the browser half (which
 * binds a scope over the same raw string through `ctx.settingsScope.bind`).
 * Both seams take a plain string, so neither half imports the branded
 * `SettingsNamespace` type.
 *
 * @module @haoran/dsh-mcp-servers/settings-namespace
 */
/** The namespace name, matching this plugin's own cordis short name. */
export declare const MCP_SERVERS_SETTINGS_NAMESPACE_NAME = "mcp-servers";
//# sourceMappingURL=settings-namespace.d.ts.map