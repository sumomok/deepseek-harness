/**
 * Connect external MCP tool servers from the Settings page.
 *
 * The harness already ships a client for one MCP server per composition entry
 * (`@deepseek-ai/dsh-mcp-client`), which requires editing a YAML file and
 * restarting. This plugin drives that client from a settings document instead,
 * so servers are added, switched off, and removed while the app runs, and adds
 * the decisions a desktop needs on top of it:
 *
 * - Storing a server is the consent to connect it. It connects at once and the
 *   set of tools it turns out to offer is recorded as the trusted one, without
 *   a second click for a fingerprint nobody could compute by hand.
 * - A server that later offers a DIFFERENT set — a tool added, dropped, or
 *   reworded — is a change the server made, not the person, so its row asks
 *   again, and the tools it is asking about cannot be ticked until it is
 *   answered. A ticked tool the server did not touch keeps working.
 * - Editing the destination retires the confirmation, because the record no
 *   longer describes the place that was agreed to.
 * - A tool reaches the model only after someone ticked that exact wording,
 *   pinned to a fingerprint of the name, description, and input schema.
 *
 * With no server stored the plugin registers no tool, starts no process, and
 * costs nothing in any request.
 *
 * What it touches: the settings document under its own namespace — read for
 * everything, written for the one field a person cannot compute — the
 * credential seam (once per connection, for an HTTP header that names a saved
 * credential), and the tool registry through a per-server gate. It appends no
 * session event and registers no HTTP route.
 *
 * @module @haoran/dsh-mcp-servers
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.ts';
export { Config, MAX_TIMEOUT_MS, resolveTimeouts } from './config.ts';
export type { ConfirmChannel, ResolvedTimeouts } from './config.ts';
export { approvalConfirmer, resolveConfirmer, settingsConfirmer } from './confirm.ts';
export type { ServerConfirmer, ServerTrustRequest } from './confirm.ts';
export { credentialNames, resolveConnection, resolveNamedValues } from './credentials.ts';
export { idOf } from './entry.ts';
export { canonicalJson, endpointFingerprint, recordTrust, toolFingerprint, toolsetFingerprint } from './fingerprint.ts';
export type { RecordTrust } from './fingerprint.ts';
export { McpServersService } from './service.ts';
export { EMPTY_SECTION, parseDocument, SERVER_ID_PATTERN, settingsConfirmationWriter, Settings, } from './settings-document.ts';
export type { ConfirmationWriter, McpServersSection } from './settings-document.ts';
export { MCP_SERVERS_SETTINGS_NAMESPACE_NAME } from './settings-namespace.ts';
export { buildClientConfig, describeEndpoint, endpointHasQuery, ServerSpecError } from './spec.ts';
export type { ResolvedEntry } from './spec.ts';
export { McpSupervisor } from './supervisor.ts';
export { ToolGate } from './tool-gate.ts';
export type { ToolRegistrar } from './tool-gate.ts';
export type { ApprovedTool, McpServersDocument, McpServerView, McpToolView, NamedValue, ServerReason, ServerRecord, ServerStatus, ServerTransport, } from './types.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "mcp-servers";
/** Required host services. */
export declare const inject: string[];
/**
 * Mount the MCP server capability.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map