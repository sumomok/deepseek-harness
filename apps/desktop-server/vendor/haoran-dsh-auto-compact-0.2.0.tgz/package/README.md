# @haoran/dsh-auto-compact

English | [中文](README.zh.md)

Compact the conversation before it runs out of room, at a point you choose. A card appears in Settings under **Plugins** with a switch and a slider: turn it on, drag it to the share of the context window you want, and whenever a reply finishes with the conversation that full, it is condensed before you send the next one.

## What you set, and what it does

| Control | Range | What it means |
| --- | --- | --- |
| The switch | on / off | Whether the conversation is condensed on its own at all |
| The slider | 20%–95%, in steps of 5 | The share of the context window that, once a turn ends above it, condenses the conversation |

The percentage is read the same way as the usage ring beside the message box. That ring is the one figure you have already watched climb, and the slider is where you say how far you are willing to let it climb.

One value, for everything. There is no per-conversation override and no per-model one: it is a preference about how you like to work, not a property of any one conversation.

**Turning the switch off does not turn off compaction.** It turns off compacting *early*. When a conversation will not fit at all, the harness still recovers on its own — that is its floor, and this plugin can neither raise nor lower it. What the switch decides is whether anything happens before that point.

## When it happens

At the end of a turn, and never inside one.

The harness's own automatic compaction runs between the steps of a turn, and this plugin switches that off. Two things are wrong with the earlier moment. A reply you are watching stops while its history is summarised. And a summarisation that fails there is simply logged, with the very next step trying again — nothing is carried between the attempts — so a summarising model that is down produces one failed attempt per step for as long as the turn runs.

The end of a turn has neither problem. Nothing is in flight, so nothing is interrupted; and there is exactly one attempt, because the next reading is not taken until the next turn ends. A run that fails, or that leaves the conversation still above your share, waits for the next turn rather than trying again immediately.

## What it condenses

Everything it safely can. The end-of-turn compaction is the same operation the `/compact` command performs, and that operation keeps no verbatim tail: the conversation up to the last balanced boundary becomes one summary. The harness's between-steps compaction did keep a tail, sized by the compaction backend's own `retainRatio` and `retainTokens`, because it was making room for a request that was about to go out. This one is not, so it takes the whole reduction at once and the next turn starts from the summary.

## What it is not

It does not measure the context window and it does not write the summary. The reading comes from the projection the usage ring reads, and the compaction is the harness's own, performed through its published seam. What this plugin owns is the switch, the percentage, and the moment.

It does not report a compaction that went wrong, either: a failed compaction is shown by the failure card in the chat (host builds from rc.33 on), because the harness records the failure itself and the conversation view already renders it.

## Where it works, and where it does nothing

The card takes the keyed seat the Settings **Plugins** page dispatches once per settings namespace it serves — the same seat the harness's own configurable-plugin cards take. A build whose settings page has no such seat never declares the key, and then this plugin registers no interface at all. Nothing is version-checked: the declaration is the detection.

The host half registers its namespace and publishes its policy wherever it is composed; without a settings provider it simply answers the profile's own values and nothing can change them. The end-of-turn compaction additionally needs the compaction seam and the projection registry, and installs itself only where both are composed — a composition with no compaction has nothing for it to trigger.

## The service it publishes

Under the Cordis service key `compactionPolicy`:

| Method | Answer |
| --- | --- |
| `isEnabled()` | `false`, always — this is how the harness's own between-steps compaction is switched off |
| `thresholdRatio()` | The share of the context window, 0–1, this plugin triggers at, read live from the settings document |

The switch in Settings is *not* what `isEnabled()` returns. It decides whether the end-of-turn compaction runs, and it is read there. No shipped backend reads `thresholdRatio()` while `isEnabled()` answers false — the one path that consulted it is the one being switched off — and it stays because it is half of a published key another backend may read.

## Settings namespace

`auto-compact`, with two fields:

| Field | Type | Default |
| --- | --- | --- |
| `enabled` | boolean | `true` |
| `thresholdPercent` | whole number, 20–95 | `60` |

A section outside those bounds is refused, at the write that produced it.

## Configuration

Both fields of `cordis.patch.yml` are the composition layer — what someone who has never opened Settings gets. Moving the switch or the slider writes a user layer over them.

```yaml
- insert:
    - id: auto-compact
      name: '@haoran/dsh-auto-compact'
      config:
        enabled: true
        thresholdPercent: 60
```

## Install

```sh
dsh plugin --profile <name> add <path-or-tarball>
```
