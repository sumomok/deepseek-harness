/**
 * The `compactionPolicy` service: the two answers the agent loop asks for
 * before it starts a step.
 *
 * **`isEnabled()` answers false, always.** The seat is how this plugin turns
 * the harness's own between-steps compaction off, and that is the whole of
 * what it is used for here: compacting in the middle of a turn interrupts work
 * the user is watching, and the loop retries a failed attempt at every
 * following step with nothing held between the attempts. This plugin triggers
 * its own compaction once, after the turn ends (`./idle-compaction.ts`). The
 * switch a person sets is read there, not here.
 *
 * `thresholdRatio()` still reads through to the settings source on every call,
 * so it answers the share in force right now rather than the one stored at
 * mount. The engine no longer asks — a false `isEnabled()` closes the only
 * path that reads it — and it stays because it is half of a published service
 * key any backend may read.
 *
 * @module @haoran/dsh-auto-compact/policy
 */
import type { AutoCompactSettings } from './section.ts';
/** Live automatic-compaction policy a host-plane plugin provides from user settings. */
export interface CompactionPolicy {
    /**
     * Whether pressure-triggered compaction runs at all; overflow recovery is unaffected.
     * @returns false, always: this plugin compacts after the turn ends instead.
     */
    isEnabled(): boolean;
    /**
     * Share of the model's context window (0–1) at which the next step compacts first.
     * @returns the live threshold ratio; a value outside (0, 1], or one the retained tail
     *   would not clear, is refused and the configured ratio governs instead.
     */
    thresholdRatio(): number;
}
/**
 * The service key, declared here because this package is the only one that
 * can: the agent loop that reads it at runtime lives in the harness checkout,
 * and this plugin builds against the published packages, which do not carry
 * the declaration. Retire this block if a published `@deepseek-ai/dsh-*` ever
 * declares the key itself — two augmentations of one interface member must
 * agree exactly, and the other one would then be the authority.
 */
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Automatic-compaction policy, provided by `@haoran/dsh-auto-compact`. */
        compactionPolicy: CompactionPolicy;
    }
}
/**
 * Build the policy over a settings source.
 * @param source - thunk returning the section in force right now; the settings
 * scope while one is attached, the composition entry otherwise.
 * @returns the policy to provide under `compactionPolicy`.
 */
export declare function createCompactionPolicy(source: () => AutoCompactSettings): CompactionPolicy;
//# sourceMappingURL=policy.d.ts.map