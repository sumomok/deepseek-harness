/**
 * When the compaction actually happens: at the end of a turn, never inside one.
 *
 * The harness's own automatic path runs `agent/pre-step`, so a conversation
 * over the threshold compacts between the steps of a turn the user is watching
 * — and a compaction that fails there is only warned about and retried at the
 * very next step, with nothing carried across steps to slow it down. A
 * summarizer that is down therefore produces one failed attempt per step for
 * as long as the turn runs.
 *
 * This module moves the decision to the one moment neither problem exists: the
 * agent has just gone from running to idle. The conversation is settled, the
 * turn is closed, the user is not waiting on a step, and there is exactly one
 * attempt per turn — the next reading happens after the next turn ends, so a
 * failure waits for new work instead of repeating immediately.
 *
 * The reading is the usage ring's: `projectedTokens` over the routed
 * `contextWindow`, both taken from the `contextPressure` projection the ring
 * itself divides, falling back to `pressureTokens` exactly as the ring does
 * before the first surface movement is folded.
 *
 * @module @haoran/dsh-auto-compact/idle-compaction
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ContextPressureProjection } from '@deepseek-ai/dsh-token-meter/client';
import type { AutoCompactSettings } from './section.ts';
/**
 * The share of the window the next request would occupy, read the way the
 * usage ring beside the message box reads it.
 *
 * `projectedTokens` is the provider's last prompt-side sample carried forward
 * by the surface's movement since; `pressureTokens` is that sample alone, and
 * is what the projection publishes before any movement has been folded. A
 * session with no sample or no known route capacity has no reading at all —
 * the ring draws nothing there, and neither does this.
 * @param pressure - the session's published `contextPressure` value.
 * @returns the occupied share of the window, or null while it is unknown.
 */
export declare function occupiedShare(pressure: ContextPressureProjection | undefined): number | null;
/**
 * Compact once, at the end of a turn, when the conversation is full enough.
 *
 * Only the running-to-idle transition acts. The previous status is tracked
 * rather than inferred from the event, because "the conversation just ended"
 * is this plugin's own rule: an agent observed idle without having been seen
 * running — a session opened, a listener installed mid-life — has produced
 * nothing new to compact and must not be compacted for merely existing.
 *
 * One attempt per transition, one attempt at a time per agent. A run that
 * leaves the conversation still above the share does not try again here: the
 * next turn's end is the next decision point. Failures are logged and dropped;
 * the harness's own compaction records already carry them into the
 * conversation.
 *
 * @param ctx - a context with `compaction` and `sessionProjections` composed; its unload removes the listener.
 * @param section - thunk returning the switch and the share in force right now.
 */
export declare function installIdleCompaction(ctx: Context, section: () => AutoCompactSettings): void;
//# sourceMappingURL=idle-compaction.d.ts.map