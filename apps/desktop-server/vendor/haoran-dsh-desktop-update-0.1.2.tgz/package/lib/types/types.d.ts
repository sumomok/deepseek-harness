/**
 * The value types both halves and the Typert manifests share.
 *
 * @module @haoran/dsh-desktop-update/types
 */
/**
 * Where the application's own update stands.
 *
 * `unsupported` is this plugin's own answer, not the shell's: the shell only
 * ever reports the first five. It means the deployment lends no update service
 * at all — a `dsh web` on a server, or a desktop build that did not start one.
 */
export type UpdatePhase = 'idle' | 'checking' | 'downloading' | 'ready' | 'failed' | 'unsupported';
/** How often the browser half re-reads the state. */
export interface PollCadence {
    /** Interval used while the settings section is open or a transfer is running. */
    activeMs: number;
    /** Interval used the rest of the time, which is what keeps the ready button honest. */
    idleMs: number;
}
/**
 * The shell's `/state` body, verbatim.
 *
 * Every field past `phase` and `currentVersion` is present only when the shell
 * has something to put in it, so a caller reads them as optional in every
 * phase.
 */
export interface UpdateState {
    /** Where the update stands. */
    phase: UpdatePhase;
    /** The version running right now. */
    currentVersion: string;
    /** The version the last check found, when one was found. */
    latestVersion?: string;
    /** What the publisher wrote about {@link UpdateState.latestVersion}. */
    releaseNotes?: string;
    /** Download progress, 0–100. */
    percent?: number;
    /** Bytes transferred so far. */
    transferredBytes?: number;
    /** Bytes the download totals, when the server declared a length. */
    totalBytes?: number;
    /** The shell's own plain sentence for a `failed` or `unsupported` phase. */
    reason?: string;
    /** When the last check ran, as the shell spelled it (ISO 8601). */
    checkedAt?: string;
}
/**
 * What the browser half reads: the shell's state plus the two facts the shell
 * knows nothing about — whether this deployment offers updates at all, and how
 * often to ask again.
 */
export interface UpdateView extends UpdateState {
    /**
     * False exactly where the deployment lends no update service. The browser
     * half registers nothing at all in that case, so nothing about updating
     * appears in a deployment that cannot update.
     */
    available: boolean;
    /** The polling intervals, resolved from this plugin's config. */
    poll: PollCadence;
}
/**
 * How one of the three commands ended.
 *
 * `error` carries the shell's own sentence when it refused; this plugin adds
 * its own only for the two cases the shell never sees — no update service, and
 * a service that did not answer.
 */
export interface CommandOutcome {
    /** Whether the shell accepted the command. */
    ok: boolean;
    /** Why it did not, when it did not. */
    error?: string;
}
//# sourceMappingURL=types.d.ts.map