/**
 * The one thing this plugin shows outside its Settings page: a compact
 * 「更新到最新」 button, and only once a version is on disk.
 *
 * Every other phase renders `null`. Checking is nothing to look at, and a
 * download in flight is deliberately invisible here — someone who did not go
 * looking for an update should not be told about one being fetched, and there
 * is nothing they could do about it if they were. `ready` is the first moment
 * with an action behind it.
 *
 * Pressing it opens the Settings page rather than installing. Installing
 * restarts the application, and the sidebar is not where a person expects to
 * lose their place; the page states what changed and what the button will do.
 *
 * @module @haoran/dsh-desktop-update/client/UpdateReadyAction
 */
import type { ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type UpdateStoreState } from './store.ts';
/** Registration-side dependencies of {@link UpdateReadyAction}. */
export interface UpdateReadyActionInjected {
    hooks: {
        /** The browser half's own store. */
        update: HostObservable<UpdateStoreState>;
    };
    /** This plugin's `settings.section` id, for a shell that hands down an opener. */
    sectionId: string;
    /** This plugin's settings nav label in the active locale, for the shell that does not. */
    navLabel: () => string;
    /** Runs the nav selection after the settings panel has rendered. */
    schedule: (run: () => void) => void;
}
/**
 * Full component props.
 *
 * Typed against the patched seat, whose owner share is the sidebar-foot seat's
 * plus an optional opener — so one component satisfies both registrations.
 */
export type UpdateReadyActionProps = PropsRuntime<'settings.trigger.action'> & PropsLocale<'desktopUpdate'> & InjectFace<UpdateReadyActionInjected>;
/**
 * The registered ready button.
 * @param props - the sidebar column state plus this plugin's store and opener.
 * @returns the button, or null in every phase but `ready`.
 */
export declare function UpdateReadyAction(props: UpdateReadyActionProps): ReactNode;
//# sourceMappingURL=UpdateReadyAction.d.ts.map