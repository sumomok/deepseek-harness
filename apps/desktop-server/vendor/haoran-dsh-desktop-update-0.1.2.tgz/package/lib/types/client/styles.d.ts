/**
 * The browser half's stylesheet, injected once as a tagged `<style>`.
 *
 * Every colour is a harness theme variable rather than a literal, so the page
 * and the button follow the light and dark schemes the shell already switches
 * between. The button is an ordinary flex item wherever it lands: no absolute
 * positioning, and no assumption that it owns either edge of its row, because
 * both seats it can take are shared with other plugins.
 *
 * @module @haoran/dsh-desktop-update/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-desktop-update";
/**
 * Put the stylesheet in the document, once.
 * @returns a disposer removing the tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map