/**
 * How often the browser half asks the host where the update stands.
 *
 * There is no push channel for this: the shell owns the download and reports
 * progress on a route, so the page finds out by asking. Asking is one loopback
 * request that touches no network, but asking every three seconds forever for a
 * fact nobody is looking at is still waste, so the cadence follows what is on
 * screen — the fast interval while the page is open or a transfer is running,
 * the slow one the rest of the time.
 *
 * Both intervals are `cordis.yml` fields, resolved on the host and carried in
 * every view; nothing here decides a number.
 *
 * @module @haoran/dsh-desktop-update/client/poll
 */
import type { PollCadence, UpdatePhase } from '../types.ts';
/**
 * The interval to wait before the next read.
 * @param phase - the phase the last read reported.
 * @param sectionOpen - whether the settings page is on screen.
 * @param cadence - the two intervals the host resolved from config.
 * @returns the interval in milliseconds.
 */
export declare function pollIntervalMs(phase: UpdatePhase, sectionOpen: boolean, cadence: PollCadence): number;
/** The timer face a poller drives, injected so a test needs no clock. */
export interface PollTimers {
    /**
     * Schedule one callback.
     * @param callback - what to run.
     * @param ms - how long to wait.
     * @returns a handle {@link PollTimers.clear} accepts.
     */
    set: (callback: () => void, ms: number) => unknown;
    /**
     * Cancel a scheduled callback.
     * @param handle - what {@link PollTimers.set} returned.
     */
    clear: (handle: unknown) => void;
}
/** What a poller needs. */
export interface PollerOptions {
    /** Perform one read; its rejection is the caller's to contain. */
    read: () => Promise<void>;
    /** The interval to wait after the read that just finished. */
    nextMs: () => number;
    /** The timers to drive; `window` in the browser. */
    timers: PollTimers;
}
/** A running poll loop. */
export interface Poller {
    /**
     * Read now and restart the loop from this moment.
     *
     * Called when something changed what the cadence should be — the page
     * opening, a command the person pressed — so the next read is not waiting out
     * an interval chosen for the old state.
     */
    restart: () => void;
    /** Stop the loop; a read already in flight still settles, and schedules nothing. */
    stop: () => void;
}
/**
 * Read on a cadence that is re-decided after every read.
 *
 * One read is ever in flight: the next interval is scheduled when the previous
 * read settles, never on a fixed tick, so a slow answer cannot stack requests
 * behind it.
 * @param options - the read, the cadence, and the timers.
 * @returns the running loop.
 */
export declare function createPoller(options: PollerOptions): Poller;
//# sourceMappingURL=poll.d.ts.map