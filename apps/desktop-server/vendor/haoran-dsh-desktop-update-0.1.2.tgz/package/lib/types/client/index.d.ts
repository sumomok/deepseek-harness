/**
 * Browser half: the application-update page in Settings, and the one button
 * outside it.
 *
 * The only host path is the Typert Remote this package's host half exports,
 * mounted here through `ctx.remote.$mount()`. This plugin fetches nothing
 * itself and knows no token, no endpoint, and no path.
 *
 * **Nothing is registered at all where updating is impossible.** A `dsh web` on
 * a server lends no update service, and a Settings page that opens onto an
 * explanation of why a feature does not work is worse than no page: the person
 * did not ask for it, cannot act on it, and now has one more thing in Settings.
 * So the first thing this does is read the host once, and an `available: false`
 * answer ends the registration before it starts.
 *
 * @module @haoran/dsh-desktop-update/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type DesktopUpdateKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-desktop-update` copy. */
        desktopUpdate: DesktopUpdateKey;
    }
}
export { CONTRIBUTION, parseCommandOutcome, parseUpdateView } from './contribution.ts';
export { formatCheckedAt, formatMegabytes, progressPercent } from './format.ts';
export { en, fill, NS, zh } from './locales.ts';
export type { DesktopUpdateKey } from './locales.ts';
export { DIALOG_TRIGGER_SELECTOR, findSettingsTrigger, openSettingsSection, PANEL_NAV_SELECTOR, selectPanelSection, TRIGGER_SEARCH_DEPTH, } from './open-settings.ts';
export { createPoller, pollIntervalMs } from './poll.ts';
export type { Poller, PollerOptions, PollTimers } from './poll.ts';
export { FOOTER_ACTION_SLOT, installSeatAction, TRIGGER_ACTION_SLOT } from './seat.ts';
export type { SeatKey, SeatSlots, SettingsTriggerActionOwnerProps } from './seat.ts';
export { createUpdateStore, readyVersion } from './store.ts';
export type { Busy, UpdateApi, UpdateStore, UpdateStoreState } from './store.ts';
export { insertStyles, STYLE_TAG } from './styles.ts';
export { UpdateReadyAction } from './UpdateReadyAction.tsx';
export type { UpdateReadyActionInjected, UpdateReadyActionProps } from './UpdateReadyAction.tsx';
export { UpdateSettingsSection } from './UpdateSettingsSection.tsx';
export type { UpdateSettingsSectionInjected, UpdateSettingsSectionProps } from './UpdateSettingsSection.tsx';
/** Required browser services. */
export declare const inject: string[];
/** This plugin's settings page id, which is also what an opener is given. */
export declare const SECTION_ID = "desktop-update";
/** The list id both seats use for the ready button. */
export declare const ACTION_ID = "desktop-update";
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 */
export declare function apply(ctx: Context): Promise<void>;
//# sourceMappingURL=index.d.ts.map