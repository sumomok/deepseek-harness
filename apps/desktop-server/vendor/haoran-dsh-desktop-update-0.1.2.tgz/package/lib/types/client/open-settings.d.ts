/**
 * Opening the Settings panel on this plugin's own page, from a button outside
 * it.
 *
 * **The settings shell publishes no way to do this.** Checked against the
 * harness at `0.1.5-rc.1`: `ui-settings` declares the slot types and
 * `ctx.settingsScope`, and nothing else; the shell that renders the panel
 * (`ui-settings-general`'s `SettingsRoot`) keeps both `open` and the active
 * section id in component-local `useState`, and the one opener it hands out —
 * `openSection(id)` — reaches exactly one audience, the occupants of the
 * `settings.onboarding` slot, which is a coordinator for first-run steps and
 * not a seat a plugin may take to open a page. There is no cordis service, no
 * command, and no event.
 *
 * So this module does what a person does: it presses the shell's own controls.
 * Two presses — the sidebar-foot trigger that opens the panel, then the nav row
 * that selects the page — found by walking out from the button that was
 * clicked rather than by searching the document, because
 * `button[aria-haspopup="dialog"][aria-expanded]` also matches the chat's stat
 * pills and there is no marked-up identity to tell them apart. The action this
 * plugin registers always sits in the sidebar foot, beside or inside the
 * settings trigger row, so the trigger is a few parents away and nothing else
 * is.
 *
 * Every failure here is silent and harmless: nothing found means nothing
 * pressed, and the person opens Settings the way they always could.
 *
 * @module @haoran/dsh-desktop-update/client/open-settings
 */
/** The settings trigger as the shell marks it up, shared with the chat's stat pills. */
export declare const DIALOG_TRIGGER_SELECTOR = "button[aria-haspopup=\"dialog\"][aria-expanded]";
/** The nav rows inside the open settings panel. */
export declare const PANEL_NAV_SELECTOR = "[role=\"dialog\"][aria-modal=\"true\"] button";
/**
 * How far up from the action's own node the settings trigger is looked for.
 *
 * The trigger row and the footer-action row are siblings under the sidebar
 * foot, so two levels reach it from either seat; the rest is slack for a shell
 * that wraps its rows differently.
 */
export declare const TRIGGER_SEARCH_DEPTH = 6;
/**
 * Find the settings trigger nearest the node an action was clicked in.
 * @param from - the action's own node.
 * @returns the trigger, or undefined when no ancestor within
 * {@link TRIGGER_SEARCH_DEPTH} levels contains one.
 */
export declare function findSettingsTrigger(from: HTMLElement): HTMLElement | undefined;
/**
 * Select one page in the open settings panel by its nav label.
 * @param root - the document the panel is in.
 * @param label - the nav label this plugin registered, in the active locale.
 * @returns whether a row was found and pressed.
 */
export declare function selectPanelSection(root: Document, label: string): boolean;
/**
 * Open Settings on this plugin's page.
 *
 * The nav row only exists once the panel has rendered, which is a React commit
 * away from the trigger's click, so selecting the page is scheduled rather than
 * done inline.
 * @param from - the node of the button the person pressed.
 * @param label - this plugin's nav label, in the active locale.
 * @param schedule - runs the second press after the panel has rendered.
 * @returns whether a trigger was found to press.
 */
export declare function openSettingsSection(from: HTMLElement, label: string, schedule: (run: () => void) => void): boolean;
//# sourceMappingURL=open-settings.d.ts.map