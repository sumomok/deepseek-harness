/**
 * Where the ready button sits, and how that is decided at runtime.
 *
 * Two seats can hold it, and which one exists depends on the build:
 *
 * - `settings.trigger.action` — a list seat on the settings row itself,
 *   right-aligned beside the trigger. It is added by a core patch, so it exists
 *   in the fork's desktop builds and in nothing else.
 * - `sidebar.footer.action` — the stock sidebar's own foot seat, declared by
 *   `@deepseek-ai/dsh-client-ui-sidebar`, which every composition with a
 *   sidebar has. This is where the button goes when the patch is not there.
 *
 * **The choice is made from the live declaration ledger, not from a version
 * check.** `ctx.slots.inject(key, …)` runs its callback once per declaration
 * lifetime of `key` and never runs it at all while the key is undeclared, so
 * injecting on the patched key IS the detection: the callback firing means the
 * seat exists. The fallback injection registers only while that has not
 * happened, and stands down the moment it does — which also covers the order
 * the two declarations arrive in, since the sidebar declares its foot before
 * the settings shell it contains can declare anything.
 *
 * A collapse of the patched declaration does not put the fallback back. Losing
 * it means the settings shell itself was unregistered, and a button whose whole
 * job is to open the settings panel has nothing to open.
 *
 * @module @haoran/dsh-desktop-update/client/seat
 */
/**
 * The patched seat's type, declared here because this package is the only one
 * that can: the core patch that declares it at runtime lives in the harness
 * checkout, and this plugin builds against the published packages, which do not
 * carry it. Retire this block if a published `@deepseek-ai/dsh-client-ui-*`
 * ever declares the key itself — two augmentations of one interface member must
 * agree exactly, and the other one would then be the authority.
 */
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /**
         * Actions right-aligned on the settings trigger row, beside the trigger
         * itself. Added by a core patch; absent from the stock shell.
         */
        'settings.trigger.action': {
            kind: 'list';
            scope: 'root';
            owner: SettingsTriggerActionOwnerProps;
        };
    }
}
/**
 * Owner share of an action on the settings trigger row.
 *
 * `wide` mirrors every other sidebar-foot seat. `openSection` is optional
 * because the patch that declares this seat may or may not hand one down: the
 * settings shell has an `openSection` of its own right there, but nothing
 * obliges the patch to pass it, and an occupant that assumed it would break on
 * the build where it does not.
 */
export interface SettingsTriggerActionOwnerProps {
    /** Whether the sidebar renders wide content (false = 56px rail). */
    wide: boolean;
    /** Open the settings panel on one registered section, when the shell supplies it. */
    openSection?: (id: string) => void;
}
/** The seat a core patch adds on the settings row. */
export declare const TRIGGER_ACTION_SLOT = "settings.trigger.action";
/** The seat the stock sidebar declares at its foot. */
export declare const FOOTER_ACTION_SLOT = "sidebar.footer.action";
/** The two seats this plugin can take. */
export type SeatKey = typeof TRIGGER_ACTION_SLOT | typeof FOOTER_ACTION_SLOT;
/** The one slot-service method this coordinator uses. */
export interface SeatSlots {
    /**
     * Install an effect for each declaration lifetime of a slot.
     * @param key - the seat to depend on.
     * @param callback - creates the disposer for one declaration lifetime.
     * @returns idempotent disposer for the wait and the active effect.
     */
    inject: (key: SeatKey, callback: () => () => void) => () => void;
}
/**
 * Register the action in whichever seat this build declares.
 * @param slots - the slot service.
 * @param register - registers the action in one seat and returns its disposer.
 * @returns a disposer removing both injections.
 */
export declare function installSeatAction(slots: SeatSlots, register: (key: SeatKey) => () => void): () => void;
//# sourceMappingURL=seat.d.ts.map