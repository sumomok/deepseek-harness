/**
 * Copy for the browser half, in the two locales the harness ships.
 *
 * The Chinese is the original and the English is its translation, which is the
 * order this product is written in. Neither says "feed", "channel",
 * "artifact", or "blockmap": the person reading it opened an application and
 * wants a newer one, and every one of those words would be asking them to
 * learn how the thing is delivered before they can press a button.
 *
 * `currentVersion` is the only line that carries a version number, and it is
 * the reader's own. No line names the version being offered: a person deciding
 * whether to update is choosing between what they have and something newer,
 * and a release string is not what makes that choice for them.
 *
 * @module @haoran/dsh-desktop-update/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "desktopUpdate";
/** Chinese copy (the dictionary that defines the key domain). */
export declare const zh: {
    nav: string;
    title: string;
    currentVersion: string;
    latestVersion: string;
    upToDate: string;
    checking: string;
    checkedAt: string;
    neverChecked: string;
    check: string;
    download: string;
    downloading: string;
    progress: string;
    progressUnknownTotal: string;
    releaseNotesTitle: string;
    ready: string;
    install: string;
    installing: string;
    failed: string;
    failedPlain: string;
    action: string;
    actionAria: string;
};
/** English copy. */
export declare const en: Record<DesktopUpdateKey, string>;
/** Dictionary key domain. */
export type DesktopUpdateKey = keyof typeof zh;
/**
 * Substitute `{name}` placeholders in one line of copy.
 * @param text - the dictionary line.
 * @param values - the values to put in, by placeholder name.
 * @returns the filled line; a placeholder with no value is left as written.
 */
export declare function fill(text: string, values: Record<string, string>): string;
//# sourceMappingURL=locales.d.ts.map