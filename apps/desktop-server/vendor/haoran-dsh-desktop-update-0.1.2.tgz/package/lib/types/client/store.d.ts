/**
 * The browser half's one piece of state: the last view the host answered, what
 * the person is waiting on, and the last thing that went wrong.
 *
 * Both surfaces read this same store — the settings page and the compact ready
 * button — so they can never disagree about the phase, and one read serves
 * both.
 *
 * @module @haoran/dsh-desktop-update/client/store
 */
import type { CommandOutcome, UpdateView } from '../types.ts';
/** The four calls this store makes, bound to the mounted Remote. */
export interface UpdateApi {
    /** Read where the update stands. */
    state: () => Promise<UpdateView>;
    /** Ask the application to look for a newer version. */
    check: () => Promise<CommandOutcome>;
    /** Ask the application to fetch the version its last check found. */
    download: () => Promise<CommandOutcome>;
    /** Ask the application to restart into the downloaded version. */
    install: () => Promise<CommandOutcome>;
}
/** Which command the person is waiting on, when they are waiting on one. */
export type Busy = 'check' | 'download' | 'install' | undefined;
/** What both surfaces render from. */
export interface UpdateStoreState {
    /** The last view the host answered. */
    view: UpdateView;
    /** The command in flight. */
    busy: Busy;
    /** The last refusal or failure, as a sentence; cleared when the next command starts. */
    error: string | undefined;
}
/** The store both surfaces read and the poller drives. */
export interface UpdateStore {
    /** Current state; a stable reference between changes, so it pairs with `useSyncExternalStore`. */
    getSnapshot: () => UpdateStoreState;
    /**
     * Observe changes.
     * @param listener - called after every change.
     * @returns unsubscribe.
     */
    subscribe: (listener: () => void) => () => void;
    /** Read the host once and publish the answer. */
    refresh: () => Promise<void>;
    /** Ask the application to look for a newer version, then re-read. */
    check: () => Promise<void>;
    /** Ask the application to fetch what the last check found, then re-read. */
    download: () => Promise<void>;
    /** Ask the application to restart into the downloaded version, then re-read. */
    install: () => Promise<void>;
    /**
     * Report whether the settings page is on screen, which is what the fast
     * polling cadence follows.
     * @param open - whether one more page is open (true) or one closed (false).
     */
    setSectionOpen: (open: boolean) => void;
    /** Whether the settings page is on screen. */
    isSectionOpen: () => boolean;
}
/**
 * Create the store, seeded with the view `apply` already read.
 * @param api - the bound Remote calls.
 * @param first - the view the first read answered.
 * @param onCadenceChange - called when the cadence a poller should use may have
 * changed (the phase moved, or the page opened or closed).
 * @returns the store.
 */
export declare function createUpdateStore(api: UpdateApi, first: UpdateView, onCadenceChange: () => void): UpdateStore;
/**
 * The version on disk, when one is ready to install.
 *
 * `ready` is the only phase with something to act on: a version is on disk and
 * restarting installs it. Every other phase — including a download in flight —
 * has nothing for anyone outside the settings page to press, which is why the
 * ready button reads this as its gate rather than for anything it prints.
 * @param view - the current view.
 * @returns the version, or undefined when nothing is ready.
 */
export declare function readyVersion(view: UpdateView): string | undefined;
//# sourceMappingURL=store.d.ts.map