/**
 * The two things this page has to turn into text: a byte count and a
 * timestamp.
 *
 * `MB` is a unit symbol, not copy — it is the same in both dictionaries and in
 * every other one — so it stays here rather than in `locales.ts`. Everything
 * around it is a dictionary line.
 *
 * @module @haoran/dsh-desktop-update/client/format
 */
/**
 * A byte count as megabytes.
 * @param bytes - the count.
 * @returns the size, one decimal place, with its unit symbol.
 */
export declare function formatMegabytes(bytes: number): string;
/**
 * A check timestamp in the reader's own locale and time zone.
 * @param iso - the timestamp the shell wrote.
 * @returns the local rendering, or the raw text when it is not a date.
 */
export declare function formatCheckedAt(iso: string): string;
/**
 * Download progress as a whole percentage.
 * @param percent - the shell's own figure, when it gave one.
 * @param transferred - bytes transferred so far.
 * @param total - bytes the download totals, when the server declared a length.
 * @returns the percentage 0–100, or undefined when neither source can give one.
 */
export declare function progressPercent(percent: number | undefined, transferred: number | undefined, total: number | undefined): number | undefined;
//# sourceMappingURL=format.d.ts.map