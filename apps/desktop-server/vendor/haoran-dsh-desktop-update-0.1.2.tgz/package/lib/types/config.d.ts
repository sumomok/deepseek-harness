/**
 * Plugin configuration. Every field is changeable from `cordis.yml` and
 * validated at load; nothing here is a constant compiled into the code.
 *
 * The protocol is not configuration and is not here: the environment variable
 * names, the four route paths, and the bearer scheme are fixed facts of the
 * shell this plugin talks to, and a deployment that changed them would be
 * talking to nothing.
 *
 * @module @haoran/dsh-desktop-update/config
 */
import z from '@deepseek-ai/schemastery';
/** Plugin configuration. */
export interface Config {
    /**
     * How often the browser half re-reads the state while the settings page is
     * open or a transfer is running.
     *
     * This is the interval a progress bar advances on, so it is short; the read
     * is one loopback request that touches no network.
     */
    activePollMs?: number;
    /**
     * How often the browser half re-reads the state the rest of the time.
     *
     * The only thing that depends on it is how long after a download finishes
     * the ready button appears for someone who never opened Settings, so it is
     * long.
     */
    idlePollMs?: number;
    /**
     * How long the host half waits for one answer from the shell.
     *
     * The shell owns the real deadline for whatever it starts; this budget only
     * has to sit above the time it takes to accept a request and answer it.
     */
    requestTimeoutMs?: number;
}
export declare const Config: z<Config>;
/** Configuration after defaults, with nothing left optional. */
export interface ResolvedConfig {
    activePollMs: number;
    idlePollMs: number;
    requestTimeoutMs: number;
}
/**
 * Settle defaults.
 * @param config - the schema-validated plugin config.
 * @returns the resolved configuration.
 */
export declare function resolveDesktopUpdateConfig(config: Config): ResolvedConfig;
//# sourceMappingURL=config.d.ts.map