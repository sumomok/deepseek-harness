/**
 * Update the desktop application itself, from inside it.
 *
 * The application that has to be replaced is the one doing the replacing, so
 * none of the work is here: the shell owns the feed, the signature check, the
 * partial file, and the restart. This plugin is the part of that story a person
 * can see — one Settings page saying which version is running, which one is
 * published, what changed in it, and how far the download has got, plus one
 * button that restarts into the new version once it is on disk.
 *
 * Where the affordance lives is the whole product decision:
 *
 * - **Settings, not the chat.** An update is not part of the work someone came
 *   here to do. It waits where the other application-wide choices are.
 * - **Nothing prominent while it downloads.** Progress belongs to whoever went
 *   looking for it, so it renders on the Settings page and nowhere else.
 * - **One visible affordance, and only when it is actionable.** The compact
 *   「更新到 X」 button appears at `phase === 'ready'` and never before —
 *   there is nothing to act on until a version is on disk.
 * - **The click is the consent.** Pressing restart-and-install restarts the
 *   application. Nothing asks a second time.
 *
 * What this plugin touches: the shell's update service on the loopback
 * address, and nothing else. It registers no HTTP route, reads no file, and
 * knows no URL — the browser half reaches it only through the harness's `/api`
 * Typert gateway, and the endpoint and token stay on this side of it.
 *
 * A deployment that is not the desktop application — every `dsh web` on a
 * server — lends no such service, and then `state()` answers `unsupported` and
 * the browser half registers no slots at all.
 *
 * @module @haoran/dsh-desktop-update
 */
import type { Context } from '@deepseek-ai/cordis';
import { type Config } from './config.ts';
export { Config, resolveDesktopUpdateConfig } from './config.ts';
export type { ResolvedConfig } from './config.ts';
export { DesktopUpdateService } from './service.ts';
export { CHECK_PATH, DOWNLOAD_PATH, ENDPOINT_ENV, INSTALL_PATH, parseOutcome, parseState, readState, requestCheck, requestDownload, requestInstall, shellRouteFromEnv, STATE_PATH, TOKEN_ENV, } from './shell.ts';
export type { ShellRoute } from './shell.ts';
export { DesktopUpdate, SHELL_CALLS } from './updates.ts';
export type { DesktopUpdateOptions, ShellCalls } from './updates.ts';
export type { CommandOutcome, PollCadence, UpdatePhase, UpdateState, UpdateView } from './types.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "desktop-update";
/**
 * Mount the desktop-update capability.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map