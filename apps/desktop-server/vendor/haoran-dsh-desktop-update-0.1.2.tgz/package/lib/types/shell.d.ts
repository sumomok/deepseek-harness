/**
 * The desktop shell's update service, used when it offers one.
 *
 * The desktop application is the only thing that can replace the desktop
 * application, so everything about updating it lives in the shell: the feed it
 * reads, the signature it checks, the partial file it resumes, and the restart
 * that swaps the running copy. The shell advertises that service by putting
 * `DSH_DESKTOP_UPDATE_ENDPOINT` and `DSH_DESKTOP_UPDATE_TOKEN` into the harness
 * process environment; a deployment that offers none — every `dsh web` on a
 * server — sets neither, and this plugin then reports the capability
 * unavailable and puts up no user interface at all.
 *
 * This module composes four requests against a loopback origin and reads their
 * answers. It downloads nothing, verifies nothing, and restarts nothing.
 *
 * `POST /install` restarts the application into the new version immediately.
 * The person's click is the consent for that, so nothing here — and nothing in
 * the browser half — asks a second time.
 *
 * @module @haoran/dsh-desktop-update/shell
 */
import type { CommandOutcome, UpdateState } from './types.ts';
/** Environment variable naming the update service's origin. */
export declare const ENDPOINT_ENV = "DSH_DESKTOP_UPDATE_ENDPOINT";
/** Environment variable carrying the bearer token that service requires. */
export declare const TOKEN_ENV = "DSH_DESKTOP_UPDATE_TOKEN";
/** Route reporting where the update stands. */
export declare const STATE_PATH = "/state";
/** Route asking the shell to look for a newer version. */
export declare const CHECK_PATH = "/check";
/** Route asking the shell to fetch the version its last check found. */
export declare const DOWNLOAD_PATH = "/download";
/** Route that restarts the application into the downloaded version. */
export declare const INSTALL_PATH = "/install";
/** Where the shell's update service lives and how to authenticate to it. */
export interface ShellRoute {
    /** Origin of the service, without a trailing slash. */
    readonly endpoint: string;
    /** Bearer token the shell minted for this harness process. */
    readonly token: string;
}
/**
 * Read the update route out of the environment.
 *
 * Both variables are required together: an endpoint without a token would be
 * refused by the shell on every call, and a token without an endpoint names
 * nothing.
 * @param env - the environment to read.
 * @returns the route, or undefined when this deployment offers no such service.
 */
export declare function shellRouteFromEnv(env: NodeJS.ProcessEnv): ShellRoute | undefined;
/**
 * Narrow one `/state` body.
 *
 * This is a process boundary — the body arrives from another program over a
 * socket — so every field is checked rather than trusted, and a field the shell
 * spelled with a type this build does not expect is dropped instead of
 * poisoning the view. A body without a readable `phase` is a refusal, because
 * the whole page is a projection of that one field.
 * @param body - the parsed JSON body.
 * @returns the state.
 * @throws when the body carries no readable phase or version.
 */
export declare function parseState(body: unknown): UpdateState;
/**
 * Narrow one command answer.
 * @param body - the parsed JSON body.
 * @returns the outcome; a body without a readable `ok` is read as a refusal.
 */
export declare function parseOutcome(body: unknown): CommandOutcome;
/**
 * Ask where the update stands.
 * @param route - the shell's endpoint and token.
 * @param abortMs - how long to wait for the answer.
 * @returns the shell's state.
 * @throws when the shell refuses or does not answer in time.
 */
export declare function readState(route: ShellRoute, abortMs: number): Promise<UpdateState>;
/**
 * Ask the shell to look for a newer version.
 * @param route - the shell's endpoint and token.
 * @param abortMs - how long to wait for the answer.
 * @returns whether the shell accepted the command.
 * @throws when the shell refuses or does not answer in time.
 */
export declare function requestCheck(route: ShellRoute, abortMs: number): Promise<CommandOutcome>;
/**
 * Ask the shell to fetch the version its last check found.
 * @param route - the shell's endpoint and token.
 * @param abortMs - how long to wait for the answer.
 * @returns whether the shell accepted the command.
 * @throws when the shell refuses or does not answer in time.
 */
export declare function requestDownload(route: ShellRoute, abortMs: number): Promise<CommandOutcome>;
/**
 * Ask the shell to restart into the downloaded version, right now.
 *
 * The application goes away while this call is in flight, so an answer is not
 * guaranteed and a transport failure here is the expected ending rather than a
 * fault.
 * @param route - the shell's endpoint and token.
 * @param abortMs - how long to wait for the answer.
 * @returns whether the shell accepted the command.
 * @throws when the shell refuses or does not answer in time.
 */
export declare function requestInstall(route: ShellRoute, abortMs: number): Promise<CommandOutcome>;
//# sourceMappingURL=shell.d.ts.map