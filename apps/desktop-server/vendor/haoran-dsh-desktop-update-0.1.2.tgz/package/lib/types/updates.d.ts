/**
 * What the four Remote methods actually do: read the shell's state, and pass
 * three commands through to it.
 *
 * One rule shapes the whole module: **nothing here throws at the caller.** It
 * is mounted by a plugin whose absence would be invisible, its whole surface is
 * one Settings page, and every failure it can meet — no shell, a shell that
 * stopped answering, a body it cannot read — becomes a sentence on that page
 * rather than an exception crossing the gateway. A failure that reaches the
 * person as 「检查失败」 is a working feature reporting a broken machine; one
 * that reaches them as a blank Settings page is not.
 *
 * @module @haoran/dsh-desktop-update/updates
 */
import { type ShellRoute } from './shell.ts';
import type { CommandOutcome, PollCadence, UpdateState, UpdateView } from './types.ts';
/** The shell calls this module makes, injected so the whole flow is testable without a shell. */
export interface ShellCalls {
    /** Ask where the update stands. */
    state: (route: ShellRoute, abortMs: number) => Promise<UpdateState>;
    /** Ask the shell to look for a newer version. */
    check: (route: ShellRoute, abortMs: number) => Promise<CommandOutcome>;
    /** Ask the shell to fetch the version its last check found. */
    download: (route: ShellRoute, abortMs: number) => Promise<CommandOutcome>;
    /** Ask the shell to restart into the downloaded version. */
    install: (route: ShellRoute, abortMs: number) => Promise<CommandOutcome>;
}
/** The real calls. */
export declare const SHELL_CALLS: ShellCalls;
/** What this module needs from the plugin around it. */
export interface DesktopUpdateOptions {
    /**
     * The shell's update route, or undefined where nothing lent this deployment
     * an update service.
     */
    route: ShellRoute | undefined;
    /** The polling intervals the browser half is told to use. */
    poll: PollCadence;
    /** How long to wait for one answer. */
    requestTimeoutMs: number;
    /** Receives one line about a failure; never a token and never a path. */
    log: (line: string) => void;
    /** The shell calls to make; {@link SHELL_CALLS} in production. */
    calls?: ShellCalls;
}
/** The four Remote methods, with the shell behind them. */
export declare class DesktopUpdate {
    private readonly route;
    private readonly poll;
    private readonly timeout;
    private readonly log;
    private readonly calls;
    /**
     * @param options - the shell route, the cadence to publish, and the injectable calls.
     */
    constructor(options: DesktopUpdateOptions);
    /**
     * Where the update stands.
     *
     * A deployment with no update service answers `unsupported` rather than
     * failing, and a shell that stops answering degrades to `failed` carrying its
     * own message — the page then says so instead of going blank.
     * @returns the view the browser half renders.
     */
    state(): Promise<UpdateView>;
    /**
     * Ask the shell to look for a newer version.
     * @returns whether the shell accepted it.
     */
    check(): Promise<CommandOutcome>;
    /**
     * Ask the shell to fetch the version its last check found.
     * @returns whether the shell accepted it.
     */
    download(): Promise<CommandOutcome>;
    /**
     * Ask the shell to restart into the downloaded version, right now.
     *
     * The person's click is the consent, so nothing here asks again. The
     * application goes away while the call is in flight, which is why a
     * transport failure on this one route is reported as the shell's own
     * message rather than treated as a fault.
     * @returns whether the shell accepted it.
     */
    install(): Promise<CommandOutcome>;
    /**
     * Pass one command to the shell.
     * @param name - which of the three commands to send.
     * @returns whether the shell accepted it.
     */
    private command;
}
//# sourceMappingURL=updates.d.ts.map