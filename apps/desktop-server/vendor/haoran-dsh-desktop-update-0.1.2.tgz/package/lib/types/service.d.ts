/**
 * The `desktopUpdate` Service Definition and its Typert Remote face.
 *
 * The browser reaches this service only through the harness's own `/api` Typert
 * gateway, which inherits the host's trust fence. This plugin registers no HTTP
 * route of its own, and **the browser never sees the shell's endpoint or its
 * token**: both are read once from the process environment on the host side and
 * never leave it.
 *
 * Three of these four methods change something, so where the authority sits
 * matters. It is not here. Every command forwards to the desktop shell, which
 * owns the feed it reads, the signature it checks, and the restart that swaps
 * the running copy. A caller admitted to `/api` behind a reverse proxy can ask
 * the application to check, download, or restart into the version the shell
 * itself found; it cannot name a version, a URL, or a file.
 *
 * @module @haoran/dsh-desktop-update/service
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { CommandOutcome, UpdateView } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The desktop application's own updates (provided by `@haoran/dsh-desktop-update`). */
        desktopUpdate: DesktopUpdateService;
    }
}
/** Updating the desktop application itself. */
export declare abstract class DesktopUpdateService extends TypertRemoteService {
    /**
     * @param ctx - owning plugin context.
     */
    constructor(ctx: Context);
    /**
     * Where the update stands, plus whether this deployment updates itself at
     * all and how often to ask again.
     * @returns the current view; `available: false` with phase `unsupported`
     * where nothing lent this deployment an update service.
     */
    abstract state(): Promise<UpdateView>;
    /**
     * Ask the application to look for a newer version.
     * @returns whether the application accepted the request.
     */
    abstract check(): Promise<CommandOutcome>;
    /**
     * Ask the application to fetch the version its last check found.
     * @returns whether the application accepted the request.
     */
    abstract download(): Promise<CommandOutcome>;
    /**
     * Ask the application to restart into the downloaded version, right now.
     *
     * There is no second confirmation anywhere in this seam: the person pressed
     * a button that says the application will restart, and it does.
     *
     * Named `installUpdate` rather than `install` because the gateway's Client
     * API refuses any method colliding with a `RemoteNamespaceService` prototype
     * member, and `install` is one; the refusal fails the whole Loader entry, so
     * every browser plugin fails to apply. `tests/client-api-names.spec.ts`
     * holds the four names against the real rule.
     * @returns whether the application accepted the request.
     */
    abstract installUpdate(): Promise<CommandOutcome>;
    /**
     * Remote face of {@link DesktopUpdateService.state}; the decorator cannot
     * mark the abstract member, so this concrete adapter carries the identical
     * contract.
     * @returns the current view.
     */
    remoteExportState(): Promise<UpdateView>;
    /**
     * Remote face of {@link DesktopUpdateService.check}.
     * @returns whether the application accepted the request.
     */
    remoteExportCheck(): Promise<CommandOutcome>;
    /**
     * Remote face of {@link DesktopUpdateService.download}.
     * @returns whether the application accepted the request.
     */
    remoteExportDownload(): Promise<CommandOutcome>;
    /**
     * Remote face of {@link DesktopUpdateService.installUpdate}.
     * @returns whether the application accepted the request.
     */
    remoteExportInstallUpdate(): Promise<CommandOutcome>;
}
export default DesktopUpdateService;
//# sourceMappingURL=service.d.ts.map