/**
 * The Updates tab: what you installed, what is newer, and one button per row.
 *
 * Two things are deliberately not on screen. **Which profile a package lives
 * in** is routing this tab does not explain — the person installed a plugin,
 * and where the package manager has to run for it is not a question they asked.
 * And **rows with nothing to do** are folded into one collapsed group, because
 * the whole point of opening this tab is the rows that have something to do.
 *
 * A row that has just been updated stops offering an update and offers a
 * restart instead: the new version is on disk and the running application is
 * still composed from the old one, and saying "updated" without saying that
 * would be a lie the next launch corrects.
 *
 * Below both, two more groups render only when they hold something: plugins
 * the shell disabled instead of booting, and plugins the person deliberately
 * turned off. Each row there speaks only in the plain-Chinese sentence its
 * `kind` maps to — never the marker file's own English `detail`, and never a
 * word like "profile" or "bundle" — and, once its own action finishes,
 * flips to the same "restart to finish" state a fresh update does.
 *
 * @module @haoran/dsh-plugin-updates/client/UpdatesSettingsTab
 */
import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { UpdatesStore } from './store.ts';
/** Registration-side business face for the tab. */
export interface UpdatesSettingsTabInjected {
    hooks: {
        /** The browser half's own store, bound by the renderer as `useUpdates`. */
        updates: UpdatesStore;
    };
    /** Run a check now. */
    check: () => void;
    /**
     * Update one plugin.
     * @param name - the package name.
     */
    update: (name: string) => void;
    /** Put the last update back. */
    rollback: () => void;
    /** Ask the person to restart. */
    relaunch: () => void;
    /**
     * Re-check one defective plugin.
     * @param name - the package name.
     */
    recheck: (name: string) => void;
    /**
     * Try to repair one defective plugin.
     * @param name - the package name.
     */
    repair: (name: string) => void;
    /**
     * Remove one defective or removed entry for good.
     * @param name - the package name.
     */
    forget: (name: string) => void;
    /**
     * Re-enable one removed plugin.
     * @param name - the package name.
     */
    enable: (name: string) => void;
}
/** Full component props assembled by the Settings slot renderer. */
export type UpdatesSettingsTabProps = PropsRuntime<'settings.plugins.tab'> & PropsLocale<'pluginUpdates'> & InjectFace<UpdatesSettingsTabInjected>;
/** Render the Updates tab. */
export declare function UpdatesSettingsTab({ t, useUpdates, check, update, rollback, relaunch, recheck, repair, forget, enable }: UpdatesSettingsTabProps): ReactNode;
//# sourceMappingURL=UpdatesSettingsTab.d.ts.map