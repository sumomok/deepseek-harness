/**
 * Update the plugins you installed, from inside the desktop application.
 *
 * The question this answers is the one a customer without a terminal cannot
 * answer at all: *a newer version of this plugin exists — how do I get it?* The
 * answer everywhere else is `dsh plugin --profile <name> add <package>@latest`,
 * which needs a shell, a package manager on PATH, and the name of a profile.
 * The desktop application has none of those in front of the person using it,
 * and its own installer is the only thing on the machine that ships a package
 * manager at all.
 *
 * So this plugin adds one Settings tab and borrows that package manager. It
 * lists what the person installed — never what the application ships, which is
 * not theirs to update — beside the newest published version, updates one row
 * at a time behind a confirmation the application itself draws, and keeps the
 * previous version's number so the last update can be put back.
 *
 * The same tab also shows two groups the shell disables rather than boots: a
 * plugin that did not compose cleanly, kept visible as defective instead of
 * silently dropped, and a plugin the person deliberately turned off. Both offer
 * a way back — recheck, repair, or forget the first; enable or forget the
 * second — behind the same shell and the same confirmations.
 *
 * What this plugin touches:
 *
 * - Two profile manifests and one migration marker under the harness home,
 *   read-only, to know what is installed and where.
 * - The desktop shell's plugin-admin service on the loopback address, for every
 *   registry read and every install. It never runs a package manager itself and
 *   never fetches a registry URL, so the machine's own npm configuration —
 *   mirror, proxy, credentials — is what every request goes through.
 * - Its own directory under the harness home, holding two version strings.
 *
 * It registers no HTTP route. The browser half reaches it only through the
 * harness's `/api` Typert gateway, and every method that changes anything ends
 * at a native dialog on the machine's own screen.
 *
 * A deployment that is not the desktop application — every `dsh web` on a
 * server — has no such service, and then every method here answers
 * "unavailable" and the browser half puts up no tab at all.
 *
 * TODO: browsing and installing community plugins is a separate tab, not an
 * extension of this one. Nothing here builds toward it: this tab's whole
 * subject is packages the profile already declares, and a catalogue is a
 * different list with a different fence.
 *
 * @module @haoran/dsh-plugin-updates
 */
import type { Context } from '@deepseek-ai/cordis';
import { type Config } from './config.ts';
export { Config, resolveUpdatesConfig } from './config.ts';
export type { ResolvedConfig } from './config.ts';
export { clearJournal, JOURNAL_DIR, JOURNAL_DIR_MODE, JOURNAL_FILE, JOURNAL_MODE, journalPath, readJournal, writeJournal, } from './journal.ts';
export type { JournalEntry } from './journal.ts';
export { HARNESS_SCOPE, mismatchDetail, mismatchWarning, peerMismatches } from './peers.ts';
export type { PeerMismatch } from './peers.ts';
export { declaredDependencies, DESKTOP_PROFILE, excludedNames, installedPlugins, installedVersion, MIGRATION_MARKER_FILENAME, migratedNames, PROFILES_DIR, repairMarker, runningVersion, WEB_PROFILE, } from './profiles.ts';
export type { DefectiveMarkerEntry, InstalledPlugin } from './profiles.ts';
export { REPAIR_CALLS, Repairs } from './repairs.ts';
export type { RepairCalls, RepairsOptions } from './repairs.ts';
export { PluginUpdatesService } from './service.ts';
export { ENABLE_PATH, ENDPOINT_ENV, FORGET_PATH, OUTDATED_PATH, PEERS_PATH, readOutdated, readPeers, RECHECK_PATH, RELAUNCH_PATH, REPAIR_PATH, requestEnable, requestForget, requestRecheck, requestRelaunch, requestRepair, requestUpdate, shellRouteFromEnv, TOKEN_ENV, UPDATE_PATH, } from './shell.ts';
export type { OutdatedAnswer, OutdatedEntry, PeersAnswer, RelaunchAnswer, RepairAnswer, RunEnding, ShellRoute, UpdateAnswer, } from './shell.ts';
export { installedNow, isNewer, SHELL_CALLS, Updates } from './updates.ts';
export type { ShellCalls, UpdatesOptions } from './updates.ts';
export type { DefectiveKind, DefectiveRow, OwningProfile, PluginRow, RelaunchOutcome, RemovedRow, RepairOutcome, RepairRowState, RepairsView, RollbackOffer, RowState, UnavailableReason, UpdateOutcome, UpdatesView, } from './types.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "plugin-updates";
/**
 * Mount the plugin-updates capability.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map