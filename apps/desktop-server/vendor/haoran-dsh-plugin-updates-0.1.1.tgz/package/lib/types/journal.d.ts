/**
 * The record of the last update, which is what makes a rollback possible.
 *
 * Rolling back means installing the version that was there before, and after a
 * successful update nothing on the machine still says what that was: pnpm has
 * replaced the package, the manifest carries the new specifier, and the
 * registry has no idea which of a package's versions this machine used to run.
 * So the version is written down at the moment it is still known.
 *
 * One entry, not a history. The offer this backs is "undo what just happened",
 * and a list of every update ever made would be a second feature — with its own
 * screen, its own retention, and its own question about what undoing the third
 * entry from the bottom means. Rolling back consumes the entry, so the offer
 * appears once per update and goes away when it is taken.
 *
 * The file holds two version strings and a package name, and is written
 * owner-only like every other record under the harness home.
 *
 * @module @haoran/dsh-plugin-updates/journal
 */
import type { OwningProfile, RollbackOffer } from './types.ts';
/** Directory under the harness home this plugin writes in. */
export declare const JOURNAL_DIR = "dsh-plugin-updates";
/** File name under {@link JOURNAL_DIR}. */
export declare const JOURNAL_FILE = "last-update.json";
/** Owner-only file mode; the record is one machine's own history. */
export declare const JOURNAL_MODE = 384;
/** Owner-only directory mode, matching every other harness-home directory. */
export declare const JOURNAL_DIR_MODE = 448;
/** The last update, as the file holds it. */
export interface JournalEntry extends RollbackOffer {
    /** The profile the update ran in, so the rollback runs in the same one. */
    profile: OwningProfile;
}
/**
 * Where the record lives.
 * @param root - this plugin's directory under the harness home.
 * @returns the absolute file path.
 */
export declare function journalPath(root: string): string;
/**
 * Read the last update.
 * @param path - the record's path.
 * @returns the entry, or undefined when there is none to offer.
 */
export declare function readJournal(path: string): Promise<JournalEntry | undefined>;
/**
 * Record one update, replacing whatever was recorded before.
 * @param path - the record's path.
 * @param entry - what was just installed and what it replaced.
 * @throws when the directory or the file cannot be written.
 */
export declare function writeJournal(path: string, entry: JournalEntry): Promise<void>;
/**
 * Take the offer away, which is what a completed rollback does.
 * @param path - the record's path.
 */
export declare function clearJournal(path: string): Promise<void>;
//# sourceMappingURL=journal.d.ts.map