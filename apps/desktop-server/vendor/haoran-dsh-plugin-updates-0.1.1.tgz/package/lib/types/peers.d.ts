/**
 * The compatibility preflight one update runs before it asks the user.
 *
 * A plugin is installed into a profile whose `pnpm-workspace.yaml` turns off
 * `autoInstallPeers` and does not set `strictPeerDependencies`, and its peers
 * are meant to resolve through the flat fallback directory into the running
 * installation. That arrangement is what keeps every plugin on one cordis
 * instance, and it is also why a mismatch is silent: pnpm installs the new
 * version without a word, and the plugin fails at the next launch, in a window
 * whose Settings page is what the person was just using.
 *
 * So the check happens before the install rather than after it. The published
 * version's peer ranges are read from the registry through the shell, each
 * `@deepseek-ai/*` range is compared against the version this process actually
 * resolves, and a range that is not satisfied becomes one plain sentence in the
 * confirmation dialog. It is a warning, never a refusal: a peer range is what a
 * plugin author declared, the person owns the machine, and nothing here can
 * prove that a range this build does not satisfy will actually break.
 *
 * Only `@deepseek-ai/*` peers are compared. Everything else a plugin declares —
 * `react`, `zod`, the packages it bundles — is either inlined into its own
 * bundle or resolved from its own install, so a range this process cannot
 * satisfy says nothing about whether the plugin will run.
 *
 * @module @haoran/dsh-plugin-updates/peers
 */
/** The scope whose peers a plugin shares with the running installation. */
export declare const HARNESS_SCOPE = "@deepseek-ai/";
/** One peer a published version declares and this installation does not satisfy. */
export interface PeerMismatch {
    /** The peer package name. */
    name: string;
    /** The range the published version declares. */
    range: string;
    /** The version this installation resolves, or undefined when it carries none. */
    running: string | undefined;
}
/**
 * Compare one published version's declared peers against this installation.
 *
 * A peer this installation does not carry is not a mismatch: the plugin brings
 * its own copy, or nothing composes it, and either way there is no version to
 * disagree with. A range this build's version does not satisfy is one, and
 * prerelease versions are why the check is `semver` rather than a comparison:
 * `0.1.1-rc.2` does not satisfy `^0.1.0-rc.7`, because a range's prerelease
 * comparator admits prereleases of its own `major.minor.patch` and no other,
 * and that is exactly the case a release-candidate line produces every week.
 * @param peers - the peer ranges the published version declares.
 * @param resolve - the version this installation resolves for one package name.
 * @returns every harness peer whose range this installation does not satisfy.
 */
export declare function peerMismatches(peers: Record<string, string>, resolve: (name: string) => string | undefined): PeerMismatch[];
/**
 * The one sentence a mismatch puts in the confirmation dialog.
 *
 * Chinese and jargon-free, because the shell's own dialogs are Chinese and the
 * person reading it installed a plugin, not a dependency graph. It names no
 * package and no range: which internal component disagrees is a support fact,
 * and it goes to the log rather than into a modal the person has to decide on.
 * @param mismatches - what the preflight found.
 * @returns the sentence, or undefined when there is nothing to warn about.
 */
export declare function mismatchWarning(mismatches: readonly PeerMismatch[]): string | undefined;
/**
 * The line the host log carries about one preflight, naming what the dialog
 * does not.
 * @param name - the plugin being updated.
 * @param version - the version being installed.
 * @param mismatches - what the preflight found.
 * @returns the log line.
 */
export declare function mismatchDetail(name: string, version: string, mismatches: readonly PeerMismatch[]): string;
//# sourceMappingURL=peers.d.ts.map