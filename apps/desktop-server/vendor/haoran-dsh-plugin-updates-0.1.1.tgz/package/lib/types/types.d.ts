/**
 * Wire types shared by the host half, the browser half, and the Typert
 * manifest. Nothing here carries a token, a path, or a package-manager
 * transcript: every value in this module is something the browser is allowed to
 * render, and the two that are not — which profile a package lives in, and the
 * text pnpm printed — are named as such where they appear.
 *
 * @module @haoran/dsh-plugin-updates/types
 */
/**
 * Which profile one package is installed in.
 *
 * Internal routing only. It decides which directory an update runs in and is
 * never rendered: "profile" is a word from the command line, and the person
 * this feature is for installed a plugin, not a profile.
 */
export type OwningProfile = 'desktop' | 'web';
/** Where one row stands. */
export type RowState = 
/** No check has reported on this row yet. */
'unknown'
/** Checked, and nothing newer is published. */
 | 'current'
/** Checked, and a newer version is published. */
 | 'outdated'
/** Updated in this session; the new version takes effect after a restart. */
 | 'updated';
/** One installed plugin, as the Updates tab renders it. */
export interface PluginRow {
    /** The package name, which is also the name shown. */
    name: string;
    /** The profile this package is installed in; routing only, never rendered. */
    profile: OwningProfile;
    /** The version running now. */
    installed: string;
    /** The newest published version, once a check has reported one. */
    latest?: string;
    /** Where this row stands. */
    state: RowState;
}
/** The one update that can still be undone. */
export interface RollbackOffer {
    /** The package that was updated. */
    name: string;
    /** The version it was on before, which rolling back returns it to. */
    from: string;
    /** The version it was updated to. */
    to: string;
    /** Epoch milliseconds of the update. */
    at: number;
}
/** Why the updater can do nothing at all here. */
export type UnavailableReason = 
/** This deployment is not the desktop application, so nothing lent it a package manager. */
'no-package-manager';
/**
 * Why one update, rollback, or restart did not happen.
 *
 * A code rather than a sentence, because the sentence belongs to whichever
 * language the person reads and this half serves both. The one message this
 * package does compose in Chinese is the compatibility warning, which goes into
 * a native dialog the application draws in Chinese whatever the browser is set
 * to.
 */
export type FailureCode = 
/** This deployment lends no package manager, so nothing can be installed. */
'unavailable'
/** The named plugin is not installed any more. */
 | 'not-installed'
/** Nothing newer than what is installed has been published. */
 | 'already-current'
/** There is no update to undo. */
 | 'nothing-to-undo'
/** The application did not answer the request. */
 | 'unreachable'
/** The install ran and did not finish. */
 | 'install-failed';
/** Everything the Updates tab renders from. */
export interface UpdatesView {
    /**
     * Whether updating is possible in this deployment at all. When false the tab
     * is not rendered, and every other field is empty.
     */
    available: boolean;
    /** Why, when it is not available. */
    reason?: UnavailableReason;
    /** The plugins the user installed, by name; never the ones the application ships. */
    rows: PluginRow[];
    /** Epoch milliseconds of the last completed check; null when none has completed. */
    checkedAt: number | null;
    /** Whether a check is running right now. */
    checking: boolean;
    /** Whether the last check could not reach the registry. */
    checkFailed: boolean;
    /** The one update that can still be undone. */
    rollback: RollbackOffer | null;
}
/** How one update or rollback ended. */
export interface UpdateOutcome {
    /** Whether the package now on disk is the one that was asked for. */
    ok: boolean;
    /** Whether the person confirmed the application's own dialog. */
    confirmed: boolean;
    /** The package that was acted on. */
    name: string;
    /** The version asked for. */
    version: string;
    /** Why it did not happen, when it did not. */
    failure?: FailureCode;
    /** Whether the dialog carried a compatibility warning about this version. */
    warned: boolean;
    /** Whether the application has to restart before this takes effect. */
    restartRequired: boolean;
}
/** How the restart request ended. */
export interface RelaunchOutcome {
    /** Whether the person chose to restart now. */
    confirmed: boolean;
    /** Why the request could not be made, when it could not. */
    failure?: FailureCode;
}
/**
 * Why one installed plugin was disabled instead of booted.
 *
 * A code rather than a sentence: the tab derives its own plain-Chinese line
 * from this, so the marker file's own English `detail` sentence never has to
 * cross into the browser at all.
 */
export type DefectiveKind = 
/** The installed package has no runnable file the Loader can start. */
'entry-missing'
/** The version on disk does not declare itself a plugin. */
 | 'not-a-bundle'
/** The plugin's own code failed while the application was composing it. */
 | 'load-failed';
/** Where one defective or removed row stands. */
export type RepairRowState = 
/** Still disabled; the row's own actions are offered. */
'active'
/** An action just finished; the fix takes effect at the next restart. */
 | 'pending-restart';
/** One installed plugin the shell disabled instead of booting, kept visible rather than silently dropped. */
export interface DefectiveRow {
    /** The package name. */
    name: string;
    /** Why it was disabled. */
    kind: DefectiveKind;
    /** Where this row stands. */
    state: RepairRowState;
    /** The version recorded for it in the profile it was installed from, when one is on record. */
    installed?: string;
}
/** One plugin the person deliberately turned off, and can turn back on. */
export interface RemovedRow {
    /** The package name. */
    name: string;
    /** Where this row stands. */
    state: RepairRowState;
    /** The version recorded for it in the profile it was installed from, when one is on record. */
    installed?: string;
}
/** What the defective and disabled groups under the Updates tab render from. */
export interface RepairsView {
    /**
     * Whether this deployment can act on either group at all. When false both
     * groups render nothing, the same rule {@link UpdatesView.available} follows.
     */
    available: boolean;
    /** Installed plugins the shell disabled because they did not compose cleanly. */
    defective: DefectiveRow[];
    /** Plugins the person deliberately turned off. */
    removed: RemovedRow[];
}
/** How one recheck, repair, forget, or enable ended. */
export interface RepairOutcome {
    /** Whether it succeeded. */
    ok: boolean;
    /** The plugin it was asked to act on. */
    name: string;
    /** Whether the application has to restart before this takes effect. */
    restartRequired: boolean;
    /** Why this package could not even ask the shell, when it could not. */
    failure?: FailureCode;
    /** The plain sentence the shell itself gave for refusing, when it refused. */
    reason?: string;
}
//# sourceMappingURL=types.d.ts.map