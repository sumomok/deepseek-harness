/**
 * Host-face Typert manifest, discovered by `@deepseek-ai/dsh-typert-loader`.
 *
 * The loader resolves `<package>/package.json` from the config tree, reads
 * `exports["./typert"]`, imports this module, and registers the `TYPERT`
 * export — so a third-party Remote needs no allowlist and no repository
 * change: the plugin appearing as a Loader entry under its own package name is
 * the whole registration. The manifest is hand-written here because the Typert
 * generator runs over the harness workspace, not over out-of-repo packages; it
 * is structurally what that generator emits, and every codec is a zod v4
 * schema, which the loader checks.
 *
 * Keep this file free of imports other than `zod`: the loader imports it
 * directly by file path, outside the plugin's own module graph.
 *
 * @module @haoran/dsh-plugin-updates/typert
 */
import { z } from 'zod';
import type { RelaunchOutcome, RepairOutcome, RepairsView, UpdateOutcome, UpdatesView } from './types.ts';
/** The contribution `dsh-typert-loader` registers for this package. */
export declare const TYPERT: {
    package: string;
    face: string;
    schemas: never[];
    invocations: ({
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodType<UpdatesView, unknown, z.core.$ZodTypeInternals<UpdatesView, unknown>>;
        };
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodString;
            };
        }[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodType<UpdateOutcome, unknown, z.core.$ZodTypeInternals<UpdateOutcome, unknown>>;
        };
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodType<RelaunchOutcome, unknown, z.core.$ZodTypeInternals<RelaunchOutcome, unknown>>;
        };
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodType<RepairsView, unknown, z.core.$ZodTypeInternals<RepairsView, unknown>>;
        };
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodString;
            };
        }[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodType<RepairOutcome, unknown, z.core.$ZodTypeInternals<RepairOutcome, unknown>>;
        };
    })[];
    model: {
        services: {
            description: string;
            summary: string;
            tags: never[];
            jsDoc: string;
            key: string;
            exportName: string;
            members: {
                kind: string;
                name: string;
                signature: string;
                summary: string;
                jsDoc: string;
            }[];
            types: never[];
        }[];
        events: never[];
        objects: never[];
    };
};
export default TYPERT;
//# sourceMappingURL=typert.d.ts.map