/**
 * Plugin configuration. Every field is changeable from `cordis.yml` and
 * validated at load; nothing here is a constant compiled into the code.
 *
 * The protocol is not configuration and is not here: the environment variable
 * names, the route paths, and the fence the shell enforces are fixed facts of
 * the shell this plugin talks to, and a deployment that changed them would be
 * talking to nothing.
 *
 * @module @haoran/dsh-plugin-updates/config
 */
import z from '@deepseek-ai/schemastery';
/** Plugin configuration. */
export interface Config {
    /**
     * Whether to look for newer versions once, shortly after startup.
     *
     * The check is a registry read and nothing else: it installs nothing, asks
     * nothing, and shows nothing until the person opens the Updates tab, where
     * its result is what puts a count on the tab. A deployment that does not want
     * a network read on every launch turns it off, and the tab's own button still
     * checks on demand.
     */
    checkOnStart?: boolean;
    /**
     * How long after startup that check runs.
     *
     * Late enough that it is not competing with the boot for the link, early
     * enough that the count is on the tab before anyone opens Settings.
     */
    checkDelayMs?: number;
    /**
     * Directory this plugin writes its rollback record into. Empty means
     * `$DSH_HOME/dsh-plugin-updates`.
     */
    root?: string;
}
export declare const Config: z<Config>;
/** Configuration after defaults, with nothing left optional. */
export interface ResolvedConfig {
    checkOnStart: boolean;
    checkDelayMs: number;
    /** The settled record directory; never empty. */
    root: string;
}
/**
 * Settle defaults.
 * @param config - the schema-validated plugin config.
 * @param homePath - resolves a path under the harness home, for the record's default directory.
 * @returns the resolved configuration.
 */
export declare function resolveUpdatesConfig(config: Config, homePath: (...segments: string[]) => string): ResolvedConfig;
//# sourceMappingURL=config.d.ts.map