/**
 * The two groups below the Updates list: plugins the shell disabled because
 * they did not compose cleanly, and plugins the person deliberately turned
 * off. Both stay visible instead of vanishing, and both offer a way back.
 *
 * The same rule as `updates.ts` governs this module: **nothing here throws at
 * the caller.** A row's own action answers `ok: false` with why, never an
 * exception crossing the gateway, because this feature's whole surface is a
 * few extra rows in a Settings tab.
 *
 * @module @haoran/dsh-plugin-updates/repairs
 */
import { type DefectiveMarkerEntry } from './profiles.ts';
import { type RepairAnswer, type ShellRoute } from './shell.ts';
import type { RepairOutcome, RepairsView } from './types.ts';
/** The four shell calls this module makes, injected so the whole flow is testable without a shell. */
export interface RepairCalls {
    /** Ask the shell to re-check one defective entry, free of charge. */
    recheck: (route: ShellRoute, name: string) => Promise<RepairAnswer>;
    /** Ask the shell to reinstall or rebuild one defective entry, behind its own confirmation. */
    repair: (route: ShellRoute, name: string) => Promise<RepairAnswer>;
    /** Ask the shell to remove one defective or removed entry for good. */
    forget: (route: ShellRoute, name: string) => Promise<RepairAnswer>;
    /** Ask the shell to re-enable one removed entry. */
    enable: (route: ShellRoute, name: string) => Promise<RepairAnswer>;
}
/** The real calls. */
export declare const REPAIR_CALLS: RepairCalls;
/** What this module needs from the plugin around it. */
export interface RepairsOptions {
    /** The harness home whose marker and web profile are read. */
    home: string;
    /**
     * The shell's plugin-admin route, or undefined where nothing lent this
     * deployment a package manager.
     */
    route: ShellRoute | undefined;
    /** Receives one line about a failed shell call; never a token and never a path. */
    log: (line: string) => void;
    /** The shell calls to make; {@link REPAIR_CALLS} in production. */
    calls?: RepairCalls;
    /** Reads the marker's defective and removed entries; injected so a test needs no profile on disk. */
    readMarker?: (home: string) => {
        defective: DefectiveMarkerEntry[];
        removed: string[];
    };
    /** Reads one package's recorded version in the `web` profile; injected the same way. */
    resolveWebVersion?: (home: string, name: string) => string | undefined;
}
/**
 * The whole feature, as one object the Service Provider forwards to.
 *
 * It holds one piece of state between calls: which names this session has
 * already fixed and is waiting to restart into effect. That state is lost on
 * restart, which is right — a restart is exactly what makes a repair or an
 * enable take effect, so a row that said "restart to finish" has nothing left
 * to say afterwards.
 */
export declare class Repairs {
    private readonly options;
    private readonly calls;
    /** Names whose last action succeeded and is waiting for a restart. */
    private readonly pendingRestart;
    /**
     * @param options - the home to read, the shell to call, and the log.
     */
    constructor(options: RepairsOptions);
    /** Whether this deployment can act on either group at all. */
    get available(): boolean;
    /**
     * What the marker holds for both groups, joined with the `web` profile's
     * own record of each package's version where one exists.
     * @returns the current view.
     */
    list(): Promise<RepairsView>;
    /**
     * Re-check one defective entry, free of charge.
     * @param name - the package name.
     * @returns how it ended.
     */
    recheck(name: string): Promise<RepairOutcome>;
    /**
     * Reinstall or rebuild one defective entry, behind the shell's own native
     * confirmation. May take a while; this call carries no assumption about how
     * long.
     * @param name - the package name.
     * @returns how it ended.
     */
    repair(name: string): Promise<RepairOutcome>;
    /**
     * Re-enable one removed entry.
     * @param name - the package name.
     * @returns how it ended, refused when the entry turns out defective.
     */
    enable(name: string): Promise<RepairOutcome>;
    /**
     * Remove one defective or removed entry for good.
     * @param name - the package name.
     * @returns how it ended.
     */
    forget(name: string): Promise<RepairOutcome>;
    /**
     * Run one shell call and turn its answer, or its failure, into an outcome.
     * @param which - the call to make.
     * @param name - the package name.
     * @returns how it ended.
     */
    private act;
}
//# sourceMappingURL=repairs.d.ts.map