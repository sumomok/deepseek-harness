/**
 * What the Updates tab actually does: build the list, run a check, run one
 * update behind its preflight, put the last one back, and ask for a restart.
 *
 * Everything here is arranged around one rule: **nothing this module does can
 * throw at the caller, and nothing it does can fail a launch.** It is mounted
 * by a plugin whose absence would be invisible, its whole surface is a Settings
 * tab, and every failure it can meet — no shell, no network, a registry that
 * refuses, a package that vanished — is a sentence in that tab rather than an
 * exception crossing the gateway. A failure that reaches the person as
 * "检查失败" is a working feature reporting a broken network; one that reaches
 * them as a blank Settings page is not.
 *
 * @module @haoran/dsh-plugin-updates/updates
 */
import { type InstalledPlugin } from './profiles.ts';
import { type OutdatedAnswer, type PeersAnswer, type RelaunchAnswer, type ShellRoute, type UpdateAnswer } from './shell.ts';
import type { OwningProfile, RelaunchOutcome, UpdateOutcome, UpdatesView } from './types.ts';
/** The shell calls this module makes, injected so the whole flow is testable without a shell. */
export interface ShellCalls {
    /** Ask which of one profile's packages have a newer version published. */
    outdated: (route: ShellRoute, profile: OwningProfile) => Promise<OutdatedAnswer>;
    /** Ask what one published version requires of the application around it. */
    peers: (route: ShellRoute, profile: OwningProfile, name: string, version: string) => Promise<PeersAnswer>;
    /** Ask the person to confirm, then install. */
    update: (route: ShellRoute, profile: OwningProfile, name: string, version: string, warning?: string) => Promise<UpdateAnswer>;
    /** Ask the person to confirm, then restart. */
    relaunch: (route: ShellRoute) => Promise<RelaunchAnswer>;
}
/** The real calls. */
export declare const SHELL_CALLS: ShellCalls;
/** What this module needs from the plugin around it. */
export interface UpdatesOptions {
    /** The harness home whose profiles are read. */
    home: string;
    /** This plugin's directory under the harness home, holding the rollback record. */
    root: string;
    /**
     * The shell's plugin-admin route, or undefined where nothing lent this
     * deployment a package manager.
     */
    route: ShellRoute | undefined;
    /** The wall clock, injected so a test can fix it. */
    now: () => number;
    /** Receives one line about a preflight or a failure; never a token and never a path. */
    log: (line: string) => void;
    /** The shell calls to make; {@link SHELL_CALLS} in production. */
    calls?: ShellCalls;
    /** Reads what version this installation resolves for one package; used by the preflight. */
    resolveRunning?: (name: string) => string | undefined;
    /** Reads what is installed; injected so a test needs no profile on disk. */
    readInstalled?: (home: string) => InstalledPlugin[];
    /**
     * Reads the names the marker holds as defective or removed, so this module
     * can leave them to the repairs groups; injected so a test needs no profile
     * on disk.
     */
    readExcluded?: (home: string) => Set<string>;
}
/**
 * Whether one install put the version that was asked for on disk.
 *
 * **The version on disk is the outcome, not the exit status.** `pnpm add` exits
 * 1 with `ERR_PNPM_IGNORED_BUILDS` while installing correctly, on every profile
 * that has not answered its build-approval question — which is every profile
 * the desktop shell seeds, for any plugin whose tree carries a package with an
 * install script. Reading the status as the outcome told the person their
 * update had failed while it had succeeded, and took the undo and the restart
 * prompt down with it.
 *
 * A shell that reports no version at all is read as a failure: an older shell
 * that predates this field cannot be distinguished from one whose install left
 * nothing, and refusing to claim success is the safe reading of both.
 * @param answer - the shell's answer to the install.
 * @param version - the version that was asked for.
 * @returns true when that exact version is what is installed now.
 */
export declare function installedNow(answer: Pick<UpdateAnswer, 'installedVersion'>, version: string): boolean;
/**
 * Whether a published version is newer than the one on disk.
 *
 * Both have to be real versions for the comparison to mean anything: a profile
 * whose package could not be read falls back to the declared specifier, which
 * is a range, and a range is never reported as an installed version to compare.
 * @param installed - what is on disk.
 * @param latest - what the registry published.
 * @returns true when an update exists.
 */
export declare function isNewer(installed: string, latest: string | undefined): boolean;
/**
 * The whole feature, as one object the Service Provider forwards to.
 *
 * It holds three pieces of state between calls: what the last check found, when
 * it finished, and which packages this session has already updated. All three
 * are lost on restart, which is right — a restart is exactly what makes an
 * update take effect, so a row that said "restart to finish" has nothing left
 * to say afterwards.
 */
export declare class Updates {
    private readonly options;
    private readonly calls;
    /** The newest published version per name, from the last check. */
    private latest;
    /** Epoch milliseconds of the last completed check. */
    private checkedAt;
    /** Whether a check is running now, so the tab can say so and a second one joins it. */
    private inflight;
    /** Whether the last check could not reach the registry. */
    private checkFailed;
    /** Names installed in this session, whose new version waits for a restart. */
    private readonly pendingRestart;
    /**
     * @param options - the home to read, the shell to call, and the clock.
     */
    constructor(options: UpdatesOptions);
    /** Whether this deployment can update anything at all. */
    get available(): boolean;
    /**
     * What is installed, and what the last check said about it.
     * @returns the current view.
     */
    list(): Promise<UpdatesView>;
    /**
     * Look for newer published versions, joining a check already running.
     * @returns the view including whatever the check found.
     */
    check(): Promise<UpdatesView>;
    /**
     * Install the newest published version of one installed plugin.
     * @param name - the package name.
     * @returns how it ended.
     */
    update(name: string): Promise<UpdateOutcome>;
    /**
     * Put the last update back.
     * @returns how it ended.
     */
    rollback(): Promise<UpdateOutcome>;
    /**
     * Ask the person to restart the application.
     * @returns what they answered.
     */
    relaunch(): Promise<RelaunchOutcome>;
    /**
     * What is installed right now, read from disk on every call, minus any name
     * the marker holds as defective or removed — that name's row lives in the
     * repairs groups instead, so it does not also appear here as if nothing
     * were wrong.
     */
    private installed;
    /** The rows the tab renders, folding in what the last check found. */
    private rows;
    /** Where one row stands, given what the last check reported for it. */
    private stateOf;
    /**
     * The rollback offer, dropped when the package it names is gone.
     * @param rows - the rows just built, so a record naming nothing is not offered.
     * @returns the offer, or null.
     */
    private offer;
    /** Write the rollback record, reporting rather than failing when it cannot be written. */
    private record;
    /**
     * Compose the compatibility sentence one update's dialog carries.
     *
     * A preflight that cannot run produces no sentence rather than a scary one:
     * not knowing whether a version fits is not the same statement as knowing it
     * does not.
     * @param route - the shell to ask.
     * @param row - the installed plugin being updated.
     * @param version - the version to be installed.
     * @returns the sentence, or undefined when there is nothing to warn about.
     */
    private preflight;
    /** One check across both profiles, folding pnpm's answers into the latest map. */
    private runCheck;
}
//# sourceMappingURL=updates.d.ts.map