/**
 * Copy for the two surfaces this plugin owns: the selection pill and the
 * `@message` picker rows, the chip label cached on each occurrence, and the
 * `header.*` vocabulary the blockquote the model reads is built from.
 *
 * The header words are read at submit time rather than at insert time, so a
 * chip inserted before a language switch still serializes in the language the
 * user is working in when they send.
 *
 * @module @sumomok/dsh-quote-message/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "quote-message";
/** Chinese copy (the dictionary that defines the key domain). */
export declare const zh: {
    'pill.quote': string;
    'pill.title': string;
    'section.messages': string;
    'candidate.description': string;
    'role.user': string;
    'role.assistant': string;
    'chip.label': string;
    'chip.labelUnknown': string;
    'header.quote': string;
    'header.user': string;
    'header.assistant': string;
};
/** English copy. */
export declare const en: Record<QuoteKey, string>;
/** Dictionary key domain. */
export type QuoteKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map