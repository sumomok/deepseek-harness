/**
 * The `shell.overlay` entry: a thin subscriber over {@link BannerStore},
 * rendering the shared `ConnectionBanner` atom while visible and nothing
 * otherwise — unmounting it entirely (not just hiding it) the instant the
 * connection recovers.
 *
 * `shell.overlay` (`@deepseek-ai/dsh-client-ui-layout`) is a root-scope list
 * slot the host frame renders unconditionally from first paint, above every
 * column and outside their scroll containers, documented for exactly "a
 * badge, a toast stack or a status pill" — connection state has no session
 * or conversation scope to anchor a narrower seat on, and this banner must
 * stay visible even before any session exists, so this is the seat rather
 * than a document.body mount of this plugin's own.
 *
 * `role="status"` on the wrapper (not on `ConnectionBanner` itself, which
 * this plugin does not own) makes the banner's appearance an ARIA live
 * announcement. The wrapper carries no layout of its own — `ConnectionBanner`'s
 * `position: fixed` strip is the only thing that occupies space, and it is a
 * plain `<div>` with no descendant capturing pointer events outside its own
 * bounding box — so mounting it can never intercept a click elsewhere on the
 * page.
 *
 * `useSyncExternalStore`'s third argument (`getServerSnapshot`) is the same
 * function as its second: this component has no actual server-rendered HTML
 * to hydrate against (it only ever runs inside the browser client bundle),
 * but React's server renderer throws on a missing third argument regardless,
 * including under `renderToStaticMarkup` in this package's own tests.
 *
 * @module @haoran/dsh-connection-banner/client/ConnectionBannerEntry
 */
import { type ReactNode } from 'react';
import type { BannerStore } from './banner-store.ts';
/** What the entry needs from the plugin install. */
export interface ConnectionBannerEntryDeps {
    /** The visibility store fed by the `connection/state` listener. */
    readonly store: BannerStore;
    /** Reads the current localized banner text (bound to the live locale). */
    readonly label: () => string;
}
/**
 * Build the `shell.overlay` entry component.
 * @param deps - the visibility store and localized label reader.
 * @returns the component to register at `shell.overlay`.
 */
export declare function createConnectionBannerEntry(deps: ConnectionBannerEntryDeps): () => ReactNode;
//# sourceMappingURL=ConnectionBannerEntry.d.ts.map