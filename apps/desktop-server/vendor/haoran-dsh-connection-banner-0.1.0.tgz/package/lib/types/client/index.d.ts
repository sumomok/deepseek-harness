/**
 * Browser half of @haoran/dsh-connection-banner.
 *
 * Listens for the core `connection/state` client event (not yet in a
 * `dsh-client-runtime` publish — see `dsh-render-unpublished-shims.d.ts`) and
 * feeds every transition into a {@link BannerStore}, whose debounced
 * visibility drives one `shell.overlay` list entry
 * ({@link createConnectionBannerEntry}).
 *
 * @module @haoran/dsh-connection-banner/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type ConnectionBannerKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The banner text this plugin adds. */
        'connection-banner': ConnectionBannerKey;
    }
}
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * Register this plugin's dictionary, wire the `connection/state` listener
 * into a visibility store, and register the `shell.overlay` entry.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map