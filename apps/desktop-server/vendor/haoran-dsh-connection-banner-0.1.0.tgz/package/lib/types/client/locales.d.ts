/**
 * Copy for this plugin's one piece of UI: the banner text shown while a
 * reconnect attempt is in progress.
 *
 * @module @haoran/dsh-connection-banner/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "connection-banner";
/** Every key this plugin's own copy uses. */
export type ConnectionBannerKey = 'reconnecting';
/** English copy. */
export declare const en: Record<ConnectionBannerKey, string>;
/** Chinese copy. */
export declare const zh: Record<ConnectionBannerKey, string>;
//# sourceMappingURL=locales.d.ts.map