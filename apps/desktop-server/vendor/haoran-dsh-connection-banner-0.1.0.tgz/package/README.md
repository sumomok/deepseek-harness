# @haoran/dsh-connection-banner

English | [中文](README.zh.md)

Show a top-of-page banner in the DeepSeek Harness web GUI when the connection to the server drops and the client is reconnecting.

## What it does

The client already retries a dropped connection on its own with exponential backoff — this plugin makes that state visible instead of leaving a stalled UI with no explanation. It listens for the core `connection/state` client event and, once `'reconnecting'` has persisted for more than 5 seconds (a brief drop the transport recovers from within a couple of attempts stays silent), shows a small fixed strip at the top of the page: "Connection lost, reconnecting…" (localized). The banner disappears the instant the connection recovers.

The strip has no buttons and never intercepts a click anywhere else on the page; it announces itself to assistive technology through `role="status"`.

## Why not sooner / status

`connection/state` does not exist in any published `@deepseek-ai/dsh-client-runtime` yet — it ships alongside this plugin as a `core-patches` commit not yet released. Until a `dsh-client-runtime` publish carries it, `src/client/dsh-render-unpublished-shims.d.ts` augments the type so this package can compile against the pinned npm dependency; delete that file once a publish carries the event in its own `.d.ts`.

## Install

Desktop-internal; not published to npm. Pack a tarball (`pnpm pack`) and install it into a profile the same way any local plugin is vendored.
