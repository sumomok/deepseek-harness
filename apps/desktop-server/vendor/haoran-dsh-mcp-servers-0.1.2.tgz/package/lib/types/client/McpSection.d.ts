/**
 * The `settings.section` page this plugin contributes.
 *
 * Two sources feed it, and they answer different questions. The settings scope
 * holds what is stored — which servers exist, what was confirmed about them,
 * which tools were ticked — and is what this page writes. The host read says
 * what is actually happening right now: connected or not, why not, and which
 * tools the server is offering at this moment. A tool can only be ticked once
 * the host has seen it, because the tick records the exact wording the server
 * offered.
 *
 * Saving a new server asks for nothing further: the host connects it and
 * records what it offers. The confirmation control appears only when something
 * stopped matching what was agreed to — the destination was edited, or the
 * server changed the tools it offers — and it stores both fingerprints the
 * host just reported, which is why the page never computes one. It gates the
 * ticking of the tools that changed, and only those: a ticked tool the server
 * left alone stays live, and stays the person's to un-tick.
 *
 * @module @haoran/dsh-mcp-servers/client/McpSection
 */
import { type ReactNode } from 'react';
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { InjectFace, PropsLocale, PropsRuntime, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { McpServersSection } from '../settings-document.ts';
import type { McpServerView } from '../types.ts';
import type { McpServersKey } from './locales.ts';
/** What this section needs from the host and from storage. */
export interface McpSectionInjected {
    /** Read what the servers are doing right now. */
    list: () => Promise<McpServerView[]>;
    /** The bound settings scope over this plugin's own namespace. */
    scope: SettingsScope<McpServersSection>;
    /** How often the page re-reads the host, in milliseconds. */
    pollMs: number;
}
/** Full component props. */
export type McpSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'mcpServers'> & InjectFace<McpSectionInjected>;
/** @param view - one server. @returns the copy key for its status badge. */
export declare function statusKey(view: McpServerView): McpServersKey;
/** @param view - one server. @returns whether its badge should read as trouble. */
export declare function badgeTone(view: McpServerView): 'connected' | 'blocked' | 'neutral';
/**
 * The destination as it is shown. A dropped query is named but never printed:
 * it is a common place for a key, and two records that differ only there must
 * not read as the same destination.
 * @param view - one server.
 * @param t - the translate seat.
 * @returns the endpoint line.
 */
export declare function endpointText(view: McpServerView, t: TranslateNS<'mcpServers'>): string;
/** The confirmation panel's copy, which differs by what stopped matching. */
export interface ConfirmCopy {
    /** Heading key. */
    title: McpServersKey;
    /** Control key. */
    action: McpServersKey;
    /**
     * Whether the panel spells out where the server connects, and what running
     * something there means. A server whose tool set changed is already
     * connected, and was already connected to that same place when the person
     * agreed to it, so repeating either would answer a question nobody asked.
     */
    destination: boolean;
}
/**
 * @param view - one server waiting for a person.
 * @returns the copy its confirmation panel draws itself with.
 */
export declare function confirmCopy(view: McpServerView): ConfirmCopy;
/**
 * @param view - one blocked server.
 * @param t - the translate seat.
 * @returns the sentence explaining why, or the empty string when there is none.
 */
export declare function reasonText(view: McpServerView, t: TranslateNS<'mcpServers'>): string;
/**
 * The registered settings section.
 * @param props - the framework standard kit plus this plugin's host read and settings scope.
 * @returns the page.
 */
export declare function McpSection({ list, scope, pollMs, t }: McpSectionProps): ReactNode;
//# sourceMappingURL=McpSection.d.ts.map