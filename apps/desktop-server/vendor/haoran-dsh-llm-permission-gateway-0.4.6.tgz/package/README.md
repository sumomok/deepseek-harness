# @haoran/dsh-llm-permission-gateway

English | [中文](README.zh.md)

A permission gate for DeepSeek Harness that reviews the tool calls no operating-system wall confines, and answers the sandbox's own escalation prompts on your behalf.

Two questions reach a review model configured apart from the agent's own, and changeable from the settings page. First, every side-effecting call the sandbox does not cover — a `run_code` program body, a call that leaves the machine, a call that acts with a login you own — is judged `allow` or `ask`, with one sentence saying what running it would cost. Second, when a confined `bash`, `pwsh`, `write`, or `edit` call is refused for reaching outside its walls and the agent asks for that refusal to be lifted, the same model answers instead of you, and hands the question over whenever it is unsure.

Rule tables were rejected for the first job because they accumulate until their entries contradict each other and nobody can say what the set as a whole permits; a review model has no such maintenance surface, at the price of latency, money, and a judgment that is not always the same twice.

## Where it sits

`tools/pre-execute` is the only extension point that sees a call's arguments — the approval seam downstream of it is deliberately blind to them, receiving a tool name, a call id, and one sentence. The gate registers there with `prepend: true`, so a listener registered earlier cannot allow a call past it. It also registers on `approval/request`, prepended, which is where a sandbox escalation arrives.

Without this plugin, two things reach a human, and neither covers an ordinary tool:

- A listener returning `{kind:'ask'}` from `tools/pre-execute`. In the harness that is `hooks-claude-code`, `hooks-codex`, and `tool-jobs`, and nothing else.
- The sandbox-escape path, where a refused `bash`, `pwsh`, `write`, or `edit` call asks for a wider mode. A human sees the call only at that point, not when it was made.

A capability plugin that does neither — the normal case — contributes tools that no gate ever examines.

## What has a wall and what does not

The gate spends review where nothing else is watching. Which calls those are is read from the running installation, per call, through `ctx.sandboxPolicy.resolve({ session })`.

| | Confined by the sandbox | Reviewed by this gate |
| --- | --- | --- |
| `bash`, `pwsh` | Yes — the subprocess runs under confined argv | Only where no wall stands: `danger-full-access` with approvals still answered, or no sandbox policy composed |
| `write`, `edit`, `str_replace_editor` | Yes — through the filesystem seam the same policy covers | Same |
| `terminal_open`, `terminal_send` | Yes — the shell is spawned confined | Same |
| `run_code` program body | **No** — it runs on a `node:worker_threads` worker inside the harness process, reaching `node:fs`, `node:child_process`, and `fetch` directly | Always |
| `web_fetch`, `screenshot`, `browser_*`, and other capability tools | No | Always |

`run_code` is the load-bearing row. The shipped `@deepseek-ai/dsh-code-runtime-worker-thread` backend compiles the program as an ordinary async function in the worker's own realm and injects only the tool bindings, the declared error classes, and a `console` shim; there is no `node:vm` isolation and no module allowlist. Its own README states the authority plainly: a program runs with authority comparable to the bash tool. The sandbox seam cannot reach it either — `SandboxProvider.confine()` wraps subprocess argv, and nothing in the code runtime calls it.

Sub-calls a `run_code` program dispatches reach this gate individually, and the same rule decides them. A `bash` sub-call under `workspace-write` is walled and passed through; a `web_fetch` sub-call is reviewed. The duplicate review a wrapper and its sub-call used to cost is left only where neither has a wall.

With no wall at all, every call is reviewed again — as long as a person can still be asked. Which of the three tiers a call runs in is the next section.

## Which tier a call runs in

Two knobs decide it, read per call and never a preset name: whether the operating system confines file effects, and what the session's effective approval policy is. A deployment that renames or reorders its presets changes nothing here.

| Wall | Approval policy | Tier | What this gate does |
| --- | --- | --- | --- |
| `read-only`, `workspace-write` | either | `walled` | Reviews what the wall does not cover, and only while its own switch is on. The switch ships off. |
| none | `ask` | `auto-review` | Reviews every call that is not a local read. Its own switch does not reach this tier. |
| none | `never` | `full-access` | Nothing. No red line, no `alwaysAsk`, no review: every call is delegated and recorded as `unattended`. |

**`full-access` is the tier this gate steps out of, deliberately.** `ApprovalService` resolves every request under `never` to `rejected` before any answerer sees it, so a gate that kept asking there would be converting its own questions into silent refusals of calls nobody objected to — a `browser_auth` prompt the person never saw, reported to the model as `the user rejected tool "browser_auth"`. The person selected a mode whose whole meaning is that nothing stops and nothing asks, and the record file is the only place those calls are counted.

**Where the policy cannot be read, the tier is the one that keeps reviewing.** The approval service is read opportunistically through `ctx.get('approval')`, and the fold mirrors the service's own: the session's `approval/policy` override, else the deployment default, else `ask`. The override comes from the `permissions` session projection where that unit is registered, and from `ApprovalService.overrideOf` otherwise — the same fact, without walking the log on every call. A composition with no approval service at all reads as `ask`.

**A delegated session is governed by the session it came from.** `@deepseek-ai/dsh-subagent` pins every in-process child's approval policy to `never` at the delegation boundary — wherever the approval capability is composed — and seeds the parent's explicit sandbox override beside it, so a child of a wall-less session carries `danger-full-access` + `never`, the `full-access` pair, whichever mode the person actually selected; one `delegate` would otherwise put every subagent call past the review, past `alwaysAsk`, and past both red lines. The tier is read from the session it was delegated from instead, climbing `session.header.parentSession` through `ctx.agents.get()` while the session it stands on is itself a subagent child.

**Delegation is `header.origin === 'subagent'`, and nothing else is.** That is the field the harness writes for a subagent child and reads back to recognize one. `parentSession` is not it: the header defines that field as the session this one was FORKED from, and a person who forks a conversation gets a session carrying it — with its own access mode, its own answerer, and no delegation anywhere. A climb that ends where nothing resolves — a parent no live agent holds, a header naming no parent — reads as nobody reachable and folds its tier as if a person could be asked, so a standing wall is still a wall; the host log says so once per lineage.

**Whether anyone can be asked is read from the calling session.** That is its own effective policy, which is `never` for every delegated child wherever the approval capability is composed — with none composed the policy reads as `ask` and a prompt is raised the way it always was — and for any session whose access mode asks nobody. Where it is `never`, every question this gate would raise becomes a refusal it signs itself, because an approval request there is resolved to `rejected` before any answerer sees it. Records carry both facts, as `delegated` and `humanReachable`.

## Decision order

1. **Cancelled.** A call whose caller signal is already aborted is delegated untouched.
2. **Access tier.** In `full-access` the call is delegated and recorded as `unattended`, and nothing below runs.
3. **Red lines.** Two categories are refused without consulting the review model and without consulting configuration.
4. **`alwaysAsk`.** Tools that always deserve a human glance, asked with the cost sentence configured for them.
5. **The walled tier's review switch.** With it off, everything below is skipped in `walled` and the call is delegated. It does not reach `auto-review`.
6. **`readOnlyTools`.** Skipped, delegating to the rest of the chain.
7. **`walledTools` under a sandbox.** Skipped, and the arguments are remembered in case an escalation follows.
8. **Oversized arguments.** Held rather than reviewed in a shortened form.
9. **Cache.** A verdict already reached for the same tool, the same arguments, and the same wall state in the same agent run.
10. **Review model.** One call, one JSON verdict.

An allow returns `next()`, and an ask is put to `next()` before it is raised, so every other listener on the waterfall still decides either way. What the chain answers then settles the call:

- **The chain's `deny` wins.** The gate can add denials; it never removes another plugin's.
- **The chain's `ask` wins, reason and all.** It is the more specific question, raised by the listener that will act on the answer.
- **Only where the chain allows** does the gate raise its own ask, carrying the review model's reason.

A listener that records its call's pending approval and then checks that record when the tool runs is what the second rule is for: a gate that answered the question in its place would leave the person's approval buying a refusal. The record keeps `downstream` so a replay says which of the three happened.

The second rule has a cost, and it is accepted rather than worked around: where the chain's ask wins, the review model's reason goes to the record and never to the prompt, so the person decides on the other listener's sentence. A listener registered after this gate can replace this gate's reason with its own for the same reason — it answers later, and the later answer is the one raised. The host-log line writes that outcome as `ask→deny(downstream)`, so a chain answer that overrode this gate is visible without opening the file.

A refusal is the one answer that stops the chain — the two red lines, and `onFailure: deny` — because the call will not run whatever the rest of the chain thinks of it.

**A question nobody can answer is a refusal.** Where the calling session's own policy is `never`, the `ask` any of these steps would raise — `alwaysAsk`, an oversized call, a review failure under `onFailure: ask`, an `ask` verdict, a downgraded `deny` — is still put to the chain and then answered with `{kind: 'deny'}`, carrying the step's own sentence and one more saying nobody could be asked. The chain's `deny` or `ask` still wins; the refusal stands only where the chain allowed. The record says `decision: "deny"` with `humanReachable: false`.

## What the review model is shown

One review carries one JSON document: the tool's name, the arguments the call would run with, and — when the registry resolves one — the tool's own `description`, the same sentence its author wrote for the agent.

The system prompt states one thing about the call rather than about the tool: whether an operating-system wall is standing. A reviewer told the wall was holding the line where none is would be reading a false premise in the one state where its own answer is the only boundary left.

The description is read per review through `ctx.tools.get(name, agent)`, with the calling agent as the scope, so a scoped definition shadowing a global one reads here exactly as it did for the call. A tool the registry does not hold, and one whose description is blank, are both reviewed on name and arguments alone: the document then carries the two keys and no third.

The verdict cache does not follow it. An entry is keyed by tool name, argument digest, and wall state, and by nothing else, so a description rewritten, shadowed, or unregistered after a verdict was reached keeps answering with that verdict for the rest of that agent's run. Each record names the description its own verdict was reached against, and `cacheEntries: 0` is what makes every call read the registry again.

It sits inside the fence with the arguments, framed as data on both sides, and never in the system prompt: a description is written by whoever wrote the tool, which for a third-party plugin is not the person this gate protects. The reviewer is told what it is — the author's account of what the tool does, which is how it tells reading from writing for a tool it has never seen — and told that it describes the tool rather than this call, so it is never a reason to allow these arguments.

**One tool has its own reading.** The system prompt tells the reviewer how to read a `content_act` batch: that tool acts on the page the person is looking at, in their place, so the question is what the whole batch would make that page do. `dialogs: "accept"`; a click whose label reads 提交, 支付, 删除, 登录, 授权 or the rest of that list; a fill into 密码, 验证码 or 银行卡; an Enter pressed alongside either; a step the page names nothing, which arrives as an empty `label` beside a `mark`; and a batch that both fills an input and clicks a button the routine list does not name — each of those is an ask. Switching a tab, sorting, paging, opening a detail, running a search, applying a filter, filling a search box, and waiting are routine. A label the reviewer cannot read is an ask.

That text is fixed rather than assembled for the tool under review. A prompt that changed with the tool would be chosen by the call itself, and it would split the identical prefix every review sends. It is also this package's own account of how to read a set of arguments, not the tool author's account of what a tool is for — which is why it can sit in the system prompt where a `description` cannot.

A description is cut at 4000 characters, and it does not count toward `maxArgumentsChars`. That limit holds a call back instead of shortening it because the part left out of the arguments is where a payload would sit; a description is registration text the call cannot change, and its own ceiling answers a different question — one running to thousands of characters would push the arguments it explains out of the reviewer's context.

## The review model cannot refuse

The reviewer answers `allow` or `ask`. An answer of `deny` — which the parser still accepts, because a model told to give two values may give three — becomes an `ask` carrying the model's own reason, and the record keeps `downgraded: true` so the file still says which answer the model gave.

A wrong reading therefore costs an approval prompt rather than a blocked call — wherever there is somebody to prompt. In a session whose own policy answers nobody there is no prompt to cost, and the gate refuses in its own words instead, so an `ask` verdict there does stop the call. Apart from that and from `onFailure: deny`, which refuses a call no verdict was obtained for, the two red lines are the only denials this plugin makes on its own, and wherever it decides a call they consult neither the model nor the configuration.

## Answering the sandbox, not itself

The escalation answerer claims exactly one shape of approval request: a reason reading `escalate sandbox to <mode>: <justification>`, which is what `approveEscalation` writes. Every other approval — a hook bridge's, the jobs tool's, or this gate's own `ask` — falls through to whoever normally answers.

Three more conditions must hold before the model is asked at all. Each failure hands the request to a person and records `source: "escalationUnreviewed"`.

- **The call must be remembered.** The refused command comes from this gate's own note, taken when the call was passed through as walled — the approval request itself carries no arguments. Without that note the review would be judging the agent's account of itself against a prompt that says the command is in front of it. A restart between the call and its escalation, `cacheEntries: 0`, and a `manual` → `auto` switch mid-call all reach that state.
- **The remembered tool must be the tool the request names.** The note is keyed by agent and call id; a request naming a different tool for that id is not describing the call the note holds.
- **The request must not be this gate's own `ask`.** That reason is written by the review model over arguments an attacker can reach, so a reason shaped like the sandbox's sentence would otherwise come back through this listener and could be granted without a person. Every ask is registered against its agent and call id — by identity, not by comparing the words of the reason — and a request under one is handed on untouched.

**Two answers here do not delegate.** An `allow` verdict returns `allowed-once`: answering in the person's place is what this listener is for, and delegating would hand back the prompt the review had just decided not to raise. Under `onFailure: deny`, a review that produced no verdict returns `rejected`: `deny` is the deployment's explicit instruction to refuse when the reviewer cannot be reached, so delegating would put the question to a person the configuration said not to ask. The rule that the review model cannot refuse governs the model's verdicts, not that switch.

**The two notes are per agent, not per call id.** A call id is unique inside one agent and nowhere else: two sessions, or a session and a subagent, routinely mint the same string. Both notes bucket by the agent object, so one session's remembered command can never answer another's escalation, and a bucket vanishes with the agent that owns it. A call made outside an agent falls into one shared bucket, having no session to be confused with.

Both notes exist only between a call and the approval it may raise; `tools/result` closes that window whatever the outcome was.

## Failure never opens the gate

`onFailure` ranges over `ask` and `deny`. There is no `allow` to configure, so a timeout, an unreachable model, an unparsable answer, or arguments too large to review cannot become an allow. This matters more than the review itself: against a fail-open gate an attacker does not have to convince the reviewer, only to make it slow.

Failures are not cached. A single slow moment decides one call, not every later occurrence of it.

**Every review is issued in the provider's JSON mode.** The request carries `responseFormat: { type: 'json_object' }`, so a host whose `dsh-llm` carries the `llm-response-format` patch has the provider itself refuse to emit anything but a legal JSON document, and the format stops depending on the reviewer following an instruction. The prompt keeps saying JSON and keeps showing the example object, because that mode's own documented rule is that a request whose prompt does neither can come back as whitespace up to the output cap. A host without the patch ignores the unknown field, and the tolerance below is what covers it.

**A route that refuses the format is asked again without it, once.** Not every adapter accepts `responseFormat`: the in-tree pi-ai adapter answers a request carrying it with `UNSUPPORTED_OPTION`, which reaches this gate as a failed review. That failure — recognized by the adapter's own machine code, and by the code in the message where the adapter stated none — is reissued immediately without the format, and the route is remembered as one that does not take it, so later reviews carry it no more. The memory is dropped when the route changes or an adapter registers or retires one. A failure after the second turn is a failure like any other, and each record names the `responseFormat` its own review went out under.

**An answer counts when it holds exactly one JSON object.** Prose around that object is tolerated — a reviewer that adds a sentence has still answered once — and one wrapping code fence is stripped. An answer holding two objects is not usable: choosing between them would be this parser searching a text for a decision, which is exactly what someone who can get a second object into the answer would be counting on. An answer holding none, one that leaves a brace open, one whose `decision` is not exactly `allow`, `ask`, or `deny`, and one whose `reason` is not a non-empty string are all unusable the same way.

**An empty answer is named as an empty answer.** The verdict is read from the text channel only: a model that wrote into the reasoning channel instead has not answered, because a verdict it considered and dropped is written into that channel exactly like one it reached. The refusal then says the review model returned an empty answer rather than that it ignored the format, and the record carries `finish` — how the stream ended — with `reasoningTokens` beside it, which together say whether the answer went into thinking.

For an escalation, `onFailure: ask` hands the request back to the person and `onFailure: deny` refuses it outright.

## A call cancelled under review

Nothing this gate can return makes a cancelled call quieter. The registry re-checks the caller signal after the waterfall settles and materializes its own `ABORTED_BEFORE_DISPATCH` result; returning `ask` would raise an approval prompt for a call already given up on, and `deny` would replace that cancellation with a second, gate-authored error. So the gate delegates, and the record carries `source: "cancelled"` with `decision: "cancelled"` — not the `allow` a skip records, because no verdict was reached.

The same holds when the abort lands mid-review: the judge reports `cancelled`, and the gate delegates rather than failing closed.

## Red lines

Neither is configurable, and neither can be disabled. Both hold with the walled tier's review switch on and off, and in both tiers where this gate decides a call. Neither runs in `full-access`, where it decides nothing at all.

**Credential exfiltration** — reading a credential store and sending data off the machine in the same call. Detection is narrow on purpose: it needs a store read together with a way off the machine. **Using a credential is not reading one.** `ssh -i ~/.ssh/id_ed25519 host '…'` hands the path to the client that signs with it, and the key's bytes never leave the machine; so do `-o IdentityFile=`, `--identity-file`, `--key-file`, `--cert`, `--kubeconfig`, `--profile`, and `GIT_SSH_COMMAND='ssh -i …'`. What makes a path a store read is a primitive consuming it — `cat`, `base64`, `xxd`, `strings`, `cp`, `scp`, `rsync`, `tar`, and the file-reading calls of a scripting language — or a dump that names no path at all (`printenv`, `env |`, a keychain lookup). An `Authorization: Bearer $TOKEN` header names a secret and reads no store either, so an ordinary authenticated API call goes to the review model rather than being refused outright.

**Permission-system self-modification** — any argument that reaches this package's own directory, `$DSH_HOME/profiles`, or `$DSH_HOME/settings.yaml`, by resolved path or by literal text including `$DSH_HOME/profiles`, `cordis.patch.yml`, and this package's name. These locations are derived at load from the running installation, not written down as literals.

**The path half compares absolute paths only, and the protected set is fixed.** A relative argument is compared as text and not as a location: the harness resolves a tool's paths against the session's own working directory, which this scan cannot see, so `profiles/web/cordis.patch.yml` is caught by the literal `cordis.patch.yml` rather than by the path. Resolving it against this process's working directory instead made the answer depend on where `dsh` was started. What the literal half catches is the spellings it lists, as substrings: this package's name, `cordis.patch.yml`, and four forms each of the two profile locations — `.dsh/profiles`, `.dsh\profiles`, `$DSH_HOME/profiles`, `${DSH_HOME}/profiles`, and the same four for `settings.yaml`. The leading segment is the harness home's own directory name, so a deployment whose `DSH_HOME` is elsewhere lists that name instead, and there is no `~` in any of them — `~/.dsh/profiles` matches on the `.dsh/profiles` inside it. A relative path naming none of these, `profiles/web/agent.cordis.yml` for one, reaches the review model rather than a refusal. The decision record is deliberately outside the set: reaching it meant reading `verdictLog`, and a red line a `Config` field can move — in both directions — is not a red line.

The second red line exists because a permission plugin that can be edited by the agent it governs is not a permission plugin. Reads are refused along with writes: whether a given `bash` command writes is not decidable from its arguments, and an agent reading the permission configuration is reconnaissance either way. The cost is real — `ls ~/.dsh/profiles` is refused too — and it is not adjustable.

The review model is told about both categories as well, so it can catch forms the scanner does not match; there it answers `ask`, which is the strongest answer it has.

## Turning review on and off

The settings page named **Review settings** is the switch, and `/review` is the same switch from the composer. It is not named after the access mode called 自动审查: that mode reviews every call whatever this switch says.

```
/review           # what is in force right now
/review auto      # Read Only and Workspace Write are reviewed as well
/review manual    # they are not; red lines and alwaysAsk still hold
```

**The switch is a yes/no over the two walled access modes, and nothing more.** It does not reach the mode whose stated behaviour IS the review, and it does not reach the mode that asks nobody. The checkbox names both modes it reaches, in the words the access-mode menu uses for them. The command echoes in Chinese, names the modes it reaches rather than naming itself, says which one it does not reach, and restates that the two red lines hold wherever this gate decides a call.

It is this plugin's own setting rather than a fifth preset row because it is orthogonal to the access modes: "also review where a wall already stands" is a yes/no over two rows, not a row of its own.

The choice is stored as `walledReview` in this plugin's own settings namespace (`llm-permission-gateway`) where a settings provider is composed, and held for the process otherwise; the command's reply says which. Without a commands registry the command is not registered, and without a browser the page is not registered; either way the other entry still throws the switch, and with neither the setting is whatever `config.walledReview` says.

**A document written before 0.4.4 has its switch reset, deliberately.** Up to 0.3.x this namespace stored a `mode` of `auto` or `manual`, and `auto` meant "this gate reviews" — the state a person left it in to have any review at all, which at the time reviewed the walled modes because the tiers did not exist. 0.4.0 made review the behaviour of one access mode and this switch a yes/no over the other two, so a stored `auto` says that person wanted review; it does not say they wanted the two walled modes reviewed, and migrating it would assert that on their behalf. The key is still accepted, so an old document validates, and it is read by nothing: everyone starts from the shipped `false` and turns it back on if they want it.

**It ships off.** Under a wall the operating system is already refusing the file effects a review would object to, and what is left there is work the person chose a confined mode to be able to do without being interrupted. Turning it on buys review of the unwalled calls a confined session still makes — a `run_code` body, a call that leaves the machine, a call that carries a login — at one model round trip each.

## Choosing the review model

The settings page carries the second choice this plugin owns: which model reviews. It lists the providers whose model catalog this installation could read, grouped by provider; a provider with an adapter and an empty catalog appears nowhere. A provider whose own catalog failed to load is named without being offered, unless it is the provider the stored route already names.

Picking a model stores the pair and decides the next call; nothing restarts. Picking **Use the installed setting** clears the pair, and `config.provider`/`config.model` review again.

`config.provider` and `config.model` stay required. They are what a fresh installation is reviewed on, what is in force where no settings provider stores a choice, and what a stored pair falls back to.

**A stored provider no adapter serves falls back rather than blocking.** The host log carries one line naming it — once per provider id, not once per call — and the settings page says the installed setting is in use. Which model reviews is not a decision this gate is allowed to make: it can only ask either way, so a stale choice costs a log line rather than a refused call.

**A stored model id is never checked.** A provider's catalog is advisory and a route can serve a model it stopped advertising, so an id absent from the list is still offered as the stored choice and still issued. An id that really is wrong fails on the first review and reaches `onFailure` the way any other review failure does.

**The effort is settled against the model that will answer.** That model is asked once, through `ctx.llm.resolveModelInfo`, and the answer is kept until the route changes or an adapter registers or retires one. A model reporting no reasoning at all is issued no effort: `dsh-llm` refuses a request naming one for such a model, and a model that cannot think has nothing an omission could buy. A model that offers the effort is issued it, because an omitted effort does not mean "do not think" — it takes that model's own default, `high` on the DeepSeek adapter, and a reviewer that thinks first can spend the output cap before the verdict or answer in the reasoning channel. A model that offers efforts but not this one is reported once on the host log, and the configured route reviews instead. Until that answer arrives the configured effort is issued, which is what the composition asked for; the store asks as it mounts and again whenever the route changes, so a review normally has it already. A lookup that fails stores nothing and claims nothing: the next review asks again, and a route whose adapter really cannot answer fails that review by name.

**The settings page carries the effort as well.** Under the model picker sits one radio per effort the picked model offers — read from the same host catalog the composer's own thinking control is built from, never a list this page invented — beside the row that follows the installed setting, which is the shipped state. Each level is labelled in this page's own language where its dictionary has a word for the id, and otherwise under the name the catalog carries, which is the word that control shows for it. A choice is stored as `judgeReasoningEffort` in this plugin's namespace and cleared whenever the model changes, because an effort id is offered by one model and means nothing on the next. The control is drawn only where the page can name the model the review runs on: which model the installed setting names is host-side, so a page following it says to pick a model first rather than offering levels for a model it cannot see. A picked id is never issued before that model has been found to offer it.

**A review under a picked effort starts wide.** Its first turn is issued at `maxOutputTokens + reasoningBudgetTokens` rather than at the cap alone, and no retry follows it, because the wider cap is where that retry would have gone. The provider counts thinking inside the cap, so a thinking review that started narrow would be truncated and asked again on every call; a cap is a ceiling rather than a spend, so the room a choice of the route's own no-thinking effort does not use costs nothing.

**It still ships `off`.** Every step of a reviewed session waits for this model, and thinking is counted in seconds per step rather than per session. The record is where to settle the trade: each line names the `reasoningEffort` it was reached under beside the `reasoningTokens` it spent and the `latencyMs` it took, so a run at `low` and a run at `off` can be compared instead of argued about. The picker also says where the catalog reports a model that can think before it answers: review on it is slower and costs more.

**Changing the model drops every remembered verdict.** An answer one reviewer gave is not an answer the next one has given, so both verdict caches are emptied. Records keep naming the model that actually reviewed. Three things count as a change: a settings commit; `llm/adapters-updated`, which moves what the route settles to with nothing written to settings; and a settings provider mounting or remounting with a document that already names a route, which moves it without a commit either.

**The page loads the model list once, when it opens.** An adapter that registers or retires routes while the settings panel is open leaves the list as it was; reopening the panel reloads it. There is no browser-side equivalent of `llm/adapters-updated` to refresh it on, and a picker open for a few seconds is not worth polling for — a stale choice falls back with one log line rather than blocking a call.

## Configuration

```yaml
- id: llm-permission-gateway
  name: '@haoran/dsh-llm-permission-gateway'
  config:
    provider: deepseek-official
    model: deepseek-v4-flash
```

| Field | Default | Meaning |
| --- | --- | --- |
| `provider` | required | Registered LLM provider route the review model is reached on wherever the settings page holds no choice. |
| `model` | required | Model id for reviews wherever the settings page holds no choice, chosen independently of the agent's own model. |
| `walledReview` | `false` | Whether the two walled access modes are reviewed as well, for a fresh installation and where no settings provider stores a choice. The tier whose behaviour is the review does not read it. |
| `mode` | — | Retired in 0.4.4. Accepted so a profile that still sets it loads; read by nothing. |
| `reasoningEffort` | `off` | Provider-owned effort id; `''` takes the provider default. |
| `timeoutMs` | `30000` | Wall-clock budget for one review. |
| `maxOutputTokens` | `256` | Output cap for the verdict. |
| `reasoningBudgetTokens` | `2048` | Extra output tokens one retry adds after a verdict that hit the cap having spent thinking tokens; `0` never retries. |
| `maxArgumentsChars` | `200000` | Serialized-argument size above which a call is held instead of reviewed. |
| `onFailure` | `ask` | `ask` or `deny`. No third value exists. |
| `readOnlyTools` | `read`, `read_image`, `glob`, `grep`, `todo_write`, `plan`, `ask_user_question`, `show_chart`, `job_output`, `content_show`, `web_search` | Tools passed straight through: they read local state, draw into the conversation you are already looking at, or — `ask_user_question` — put text in front of the person at the keyboard. |
| `walledTools` | `bash`, `pwsh`, `write`, `edit`, `str_replace_editor`, `terminal_open`, `terminal_send` | Tools the sandbox confines, passed through un-reviewed while it does. |
| `alwaysAsk` | `browser_auth` | Tool name to the cost sentence shown when it is asked about. |
| `cacheEntries` | `512` | Per-agent cap on remembered verdicts, and on the confined calls remembered so an escalation review can read what they asked for. `0` disables both: every call is reviewed afresh, and every escalation goes to a person. |
| `reasonLanguage` | `简体中文` | Language the review model writes the reason in. |
| `verdictLog` | `$DSH_HOME/llm-permission-gateway/verdicts.jsonl` | JSONL file every decision is appended to; `false` writes no file. |
| `verdictLogArgsPreview` | `0` | Characters of each call's serialized arguments kept in its record; `0` keeps none. |

`cacheEntries` does not bound the record of this gate's own asks. That one is a fixed internal limit, because a profile that could set it to zero could switch off the guard that keeps the escalation answerer from granting this gate's own question. Its entries live only from the moment an `ask` is returned to the moment the call settles, so the live count is the number of approvals open at once.

`alwaysAsk` maps a name to a sentence rather than listing names, because the approval event carries only a tool name and a call id. Without a sentence the user is asked to approve `browser_auth` with no way to know that answering yes hands over a live logged-in session. An entry with an empty sentence fails at load.

`reasoningEffort` defaults to `off` because reviewing one call is a single classification, and thinking tokens otherwise crowd the verdict out of `maxOutputTokens` — which fails closed, so the symptom is an approval prompt on every call rather than a silent allow.

`reasoningBudgetTokens` reads a reported thinking count, not a known one. An adapter that does not translate its provider's thinking counter reports none, so a review model that thinks first is truncated and never widened, and every call reaches an approval prompt — fail-closed, and the same symptom this field exists to remove. The DeepSeek adapter reports it (`completion_tokens_details.reasoning_tokens`); an adapter that does not needs `maxOutputTokens` raised instead.

`reasoningBudgetTokens` covers the route where `off` is not in force or not honoured: the provider counts thinking inside the output cap, so a reviewer that thinks first can spend the whole cap before it writes the verdict. Measured on 2026-09-06, `deepseek-v4-pro` reached the 256-token cap having spent 232 of them thinking, on every review. One retry under `maxOutputTokens + reasoningBudgetTokens` follows a truncated answer that spent thinking tokens, inside the same `timeoutMs`; a truncated answer that spent none is not retried, because more room there buys more prose. The default carries a thinking trace an order of magnitude longer than the measured one, and a cap is a ceiling rather than a spend, so room a review does not use costs nothing.

`maxArgumentsChars` and `timeoutMs` are set from measurement rather than from caution. A low argument cap defeats the plugin: the `code` preset's `run_code` calls routinely carry 9-10K characters, so an 8000 cap sends exactly the calls most worth reviewing past the model and into a manual approval prompt. `deepseek-v4-flash` reviews a 200K-character call whole in roughly 5-8 seconds, which the 30-second budget covers.

`reasonLanguage` governs only the review model's own sentence. Everything this plugin writes itself — a red line, an oversized call, a review that produced no verdict, the `/review` echo, the `browser_auth` sentence — is compiled Simplified Chinese, so the default keeps both halves in one language. Setting another value leaves this plugin's own strings in Chinese.

Separating the review model from the agent's model does not defend against a compromised provider. It keeps one model's blind spots from being both the attack surface and the check on it, and a small model keeps review inside the latency budget.

## `ask` needs somewhere to ask

`ask` reaches a human only where an approval answerer is composed. In the harness today that is the Web surface (`@deepseek-ai/dsh-web-app`, through `dsh-host-apiproxy`) and the ACP bridge. Under `@deepseek-ai/dsh-headless`, and in any composition with no answerer, the approval service records the question and returns `unavailable`, so **`ask` is equivalent to `deny`**. The call is refused, the session log still carries the `approval/asked` and `approval/decided` pair, and the model is told an approval channel was unavailable.

That is the correct fail-closed behaviour, and it means a headless deployment gets a gate that refuses rather than a gate that asks. Choose `onFailure` and `alwaysAsk` knowing this.

**Where the policy itself answers nobody, this gate refuses in its own words rather than asking.** An `approval: never` session — a delegated subagent, or a person under a wall who selected a mode with no confirmations — resolves every request to `rejected` before any answerer sees it, so the model was told `the user rejected tool "<name>"` about a call no user was shown. The gate now returns that refusal itself, carrying the step's own sentence and one saying nobody could be asked. Net enforcement is the same; what changes is that the refusal says what it is.

**Where no answerer is composed, the escalation answerer changes an outcome rather than a prompt.** Without it, a sandbox escalation in that deployment ends at `unavailable` and the tool throws `sandbox escalation to "<mode>" requires approval, but no approval channel is available` — the retry always fails. With it, the review model can return `allowed-once` and the retry runs, with no person in the loop at any point. That is a real widening of a headless or server deployment, and it is the one place this plugin grants rather than asks. It is also the walled tier's switch — the only tier that raises an escalation at all — so it is off until that switch is turned on; `onFailure: deny` only covers the case where no verdict was obtained.

**Under the shipped `danger-full-access` preset this gate does not decide at all.** That preset pairs the open sandbox with `approval: never`, and `ApprovalService.decide` returns `rejected` for a `never` policy *before* dispatching the waterfall — deliberately, so a prepended listener cannot weaken the policy. Every `ask` raised there would therefore be a refusal nobody was asked about, so the gate raises none: that pair is the `full-access` tier, and it delegates every call. The `yolo-access` row is `{danger-full-access, ask}`, which is the same open sandbox with the asks still reaching a person.

## The preset row it ships

The patch file carries one preset alongside the plugin row: `yolo-access`, `{sandbox: danger-full-access, approval: ask}`, named 自动审查 and described as 不设操作系统围墙。每一步先交给审查模型看，拿不准的弹给你确认；动到审查功能自身文件、或一边读凭证一边外发，一律直接拒绝。

**The name says review because in this row review is not optional.** The recorded decision it overturns — that no row may name review, since selecting one buys approval prompts a model raises and cannot enforce — was written when review was a switch a user could throw independently of the row. It is not one here: this row's knob pair is exactly what puts a call in `auto-review`, and the walled tier's switch does not reach it. The description states the same three things the name compresses: no wall, prompts you confirm, and two categories refused outright.

**The row stays, and its id never changes.** `permission.defaultPreset` is stored in the settings document under a schema that is a closed union over this table's names, and `SettingsProvider.register` rejects a stored section the schema no longer admits instead of falling back — removing or renaming the id makes the `permission` settings section fail to install for anyone who stored it, silently drops their default, and loses the settings page's permission section.

**Retirement.** This row and the tier behind it exist because the harness ships no reviewed access mode. Upstream 0.1.6-alpha.1 already carries an experimental one (`AUTO_PRESET` / `registerAuto`, id `auto`, kept out of the default composition). When it reaches the default composition or the desktop payload — `git grep -n "AUTO_PRESET\|registerAuto" upstream/master -- packages/bundle/base packages/interaction/permission-presets`, or an `auto` row in the base preset table — this row retires in favour of it, and the walled-tier review switch and the judge-route setting retire with it.

It is offered, never imposed: the patch leaves `defaultPreset` unset, so the default stays whatever the composed sandbox and approval defaults resolve to — `workspace-write` under `@deepseek-ai/dsh-base`, which no position in this table changes, because `derive()` looks the composed knob pair up rather than taking the last row. Declaration order is menu order, and `yolo-access` is declared third: walls, then no walls but still asked, then no walls and never asked. The row carries `glyph: danger-full-access`, so the preset control draws the wall-less shield beside it — the closed glyph set has no fourth. It carries no `tone`: that field marks the row which hands the machine over, and this one still asks a person. The restated `danger-full-access` row does carry `tone: danger`, so both access-mode menus paint it in the danger colour; a host whose `permission` plugin predates the field keeps the key in the table and draws the row plainly.

An id-targeted patch replaces the target row's whole `config`, so the patch restates the three presets `@deepseek-ai/dsh-base` composes, unchanged. That copy is what goes stale: a base release that adds a preset, renames one, or changes a knob pair is shadowed by this file until it is updated, and the symptom is a preset control that quietly keeps offering the old table. `tests/preset-patch.spec.ts` holds the second copy that makes such a change a deliberate two-place edit.

## Cost

Measured against `deepseek-v4-flash` with thinking off: 484 prompt tokens in, roughly 30 out, **median 1.12s** per review (min 0.83s, max 1.33s over six samples). A tool description, where the registry holds one, adds its own tokens to the prompt side of that count, and so does the `content_act` section of the system prompt, which was added after that measurement and is carried by every review.

Five things keep that from multiplying: the tier decides whether any review happens at all, sandbox-confined tools are never reviewed, read-only tools are never reviewed, the verdict is a single turn rather than a conversation, and a repeated call with identical arguments and the same wall state reuses the verdict for the rest of the agent's run.

Replaying one recorded 97-call session: 81 model reviews become 52 in `auto-review` with the walled switch on (28 nested `bash`/`edit` sub-calls become `walled`, three `job_output` records become `readOnly`), 80 with no wall at all, **0 in `full-access`**, and 0 in the shipped walled default, where the switch is off.

**That replay counts no escalation reviews.** This version adds one review per sandbox escalation the model answers, and the recorded file holds none to replay: the version that wrote it answered no escalations and stored no arguments, so a `sandbox_permissions` retry cannot be told apart from any other `bash` call in it. How many a real session raises depends on how often the agent reaches outside its workspace.

## Observability

Every decision appends one JSON line to `$DSH_HOME/llm-permission-gateway/verdicts.jsonl` and writes one summary to the host log — `dsh-server.log` in the desktop app, stdout when `dsh` runs in a terminal.

```
verdict allow run_code 1.2s (model) in=36 out=30 cache=448
verdict allow bash 0.0s (walled)
verdict allow bash 0.0s (unattended)
verdict ask browser_auth 0.0s (alwaysAsk)
verdict deny browser_auth 0.0s (alwaysAsk)
verdict allow bash 1.1s (escalation) in=41 out=28 cache=448
verdict ask edit 0.0s (escalationUnreviewed)
verdict ask demo_upload 20.0s (failure: timeout)
verdict ask→deny(downstream) content_act 1.0s (model) in=39 out=27 cache=448
```

A step that answered without a review shows no token figures, because it spent none.

```sh
tail -f ~/.dsh/llm-permission-gateway/verdicts.jsonl
```

| Field | Meaning |
| --- | --- |
| `at` | When the decision was reached, ISO-8601. |
| `tool`, `callId` | The call, by the same id the approval seam and the session log carry. `callId` is absent only for an escalation whose approval request named no call. |
| `rootCallId` | The enclosing model-requested call; present only for a nested dispatch such as a `run_code` sub-call. |
| `agent` | Session id of the agent the call belongs to; absent for a call made outside an agent. |
| `argsChars` | Serialized size of the call, the number `maxArgumentsChars` is compared against. For an escalation record, the size of the escalation document. |
| `argsDigest` | First 12 characters of the arguments' SHA-256 — the cache key's argument half. Two records sharing it were offered the same arguments. For an escalation record it digests the escalation (tool, requested mode, justification), so a repeated request is countable. |
| `descriptionChars` | Length of the tool's own description as the review carried it, after the 4000-character ceiling. Absent on every record no review carried a description: every skip, every cache hit, every escalation, and every review of a tool the registry resolved none for. |
| `descriptionDigest` | First 12 characters of that description's digest, taken by the function the arguments' digest uses — SHA-256 over the canonical JSON of the text; absent wherever `descriptionChars` is. Two records sharing it were reviewed against the same description text. The text itself is never written to the file: it is registration text a replay can read from the registry, and what the record has to say is which version the reviewer had. |
| `source` | Which step answered: `cancelled`, `unattended`, `redline`, `alwaysAsk`, `manual`, `readOnly`, `walled`, `oversize`, `cache`, `model`, `failure`, `escalation`, `escalationUnreviewed`, `escalationFailure`. |
| `decision` | `allow`, `ask`, `deny`, or `cancelled`. A `readOnly`, `walled`, `manual`, or `unattended` record says `allow`, because delegating admits the call; a `cancelled` record says the call was abandoned, which is not a verdict this gate reached. A step that raises an `ask` says `deny` where `humanReachable` is false; read that with `downstream`, which says whether this gate answered its own question (`allow` there), the rest of the chain answered it first (`deny` or `ask` there), or the chain threw and nothing answered it at all (`none` there, where the error is what the call received). |
| `tier` | `walled`, `auto-review`, or `full-access` — which tier decided the call, read from the delegating session where the call was delegated: the session a person is in, which is a root or a fork of one, and never past it. Absent on an escalation record, and on a call already cancelled when it arrived, for which no tier was read. |
| `policy` | The effective approval policy the tier was folded from, `ask` or `never` — the delegating session's, where the call was delegated; absent wherever `tier` is, and on a delegated call whose lineage did not resolve, where no session's policy decided the tier. Recorded rather than inferred: it is per session and mutable, so no later reader can recover it from the configuration. |
| `delegated` | Whether the calling session was created as a subagent child, by its `origin` header. A session a person forked is not one: it carries a `parentSession` and nothing else, and reads as `false`. Absent wherever `tier` is. |
| `humanReachable` | Whether an approval request for this call would have reached a person — the calling session's own policy is `ask`. False is what turns every question this gate would raise into a refusal it signs itself. Absent wherever `tier` is. |
| `sandboxMode` | The file-effect mode the sandbox policy resolved; absent wherever `tier` is, and where no sandbox policy is composed. |
| `confined` | Whether the operating system actually confined the call — the other half the tier was folded from, and the premise the review prompt stated. Absent wherever `tier` is. |
| `downgraded` | Present when the review model answered `deny` and the gate turned it into an `ask`. |
| `downstream` | What the rest of the chain answered when the gate put its ask to it: `allow`, `ask`, `deny`, or `none` for a chain that threw instead of answering. Absent on a record written without delegating. A `deny` or an `ask` here is the decision the call received, because the chain's answer wins over the gate's own ask. |
| `requestedMode` | The wider sandbox mode asked for; present only on an escalation record. |
| `latencyMs` | Wall-clock time the gate held the call, review round trip included. |
| `model` | On a record a review was issued for, the model it was issued on. On every other record, the route in force when the record was written — what would have reviewed, not who did. |
| `inputTokens`, `outputTokens` | What the review request spent. Present only where a request was issued: every `model` and `escalation` record, and a failure whose stream reported usage before it broke. |
| `cacheReadTokens` | Prompt tokens the provider served from its cache. The counts are disjoint, so one review's billed prompt is `inputTokens + cacheReadTokens`. |
| `reasoningEffort` | The effort the review was issued under; on a record no review was issued for, the one the route in force would issue. Absent where that route names none, which is a request taking the model's own default. |
| `responseFormat` | `json_object` or `text`: the answer format the review went out under, and on every other record the one the route in force would go out under. |
| `reasoningTokens` | Thinking tokens inside the answer, counted inside `outputTokens` rather than beside it; absent at the default `reasoningEffort: off`, which produces none. |
| `budgetRetried` | Present when the review took two turns: the first answer hit the output cap having spent thinking tokens, and `reasoningBudgetTokens` bought a wider second one. The token counts on such a record cover both turns. |
| `redLine` | `credential-exfiltration` or `permission-self-modification`; present only on `redline`. |
| `failureCause` | `timeout`, `cancelled`, `model-error`, or `unparsable-answer`; present only on `failure` and `escalationFailure`. |
| `finish` | How the review stream ended — `stop`, `max-tokens`, `error`, `aborted`, or a kind another package contributes — present only on a failure reached after it ended, so a timeout and a cancellation carry none. |
| `answerPreview` | Opening 160 characters of the answer that could not be used, whitespace collapsed; the empty string where the model answered nothing. Present only on such a failure, and only when `verdictLogArgsPreview` is above zero. |
| `reason` on an `escalationUnreviewed` record | Which of the three preconditions the request failed. It is written to this file only: the request is delegated unchanged, so the person at the approval prompt still sees the host's own `escalate sandbox to <mode>: <justification>` and nothing this gate wrote. |
| `reason` | The sentence attached to the decision, truncated at 300 characters. |
| `argsPreview` | Opening characters of the serialized call, whitespace collapsed; present only when `verdictLogArgsPreview` is above zero. |

**`verdictLogArgsPreview` records the user's own argument text, and the answers this gate could not use.** A digest says two calls were identical without saying what either one asked for, which is enough to count repeated reviews and not enough to read one. The preview closes that gap and is as sensitive as the session log while it does so — a `write` call's preview is the opening of the file being written. The record is created with the process umask under `$DSH_HOME`, so it is protected by whatever protects that directory and by nothing this plugin adds; the host-log summary never carries the preview. Leave it at `0` unless a specific question needs it, and set it to the smallest number that answers the question — `200` is enough to see which file and which command a record was about. The same switch admits `answerPreview`, which is model text about that same call.

### Reading the record

`scripts/verdict-stats.mjs` reports what a record file says. It is a zero-dependency Node program, installed as the `dsh-gateway-verdicts` command, and it only reads.

```sh
dsh-gateway-verdicts                                  # $DSH_HOME/llm-permission-gateway/verdicts.jsonl
dsh-gateway-verdicts --since 2026-08-21T00:00:00Z --last 50
node scripts/verdict-stats.mjs /path/to/verdicts.jsonl --last 0
```

A profile install puts the command in the profile's own `node_modules/.bin`; from a checkout of this workspace, run the file with `node`. The agent cannot run it either way: `$DSH_HOME/profiles` and this package's own directory are both inside the self-modification red line, so a tool call naming either path is refused. Reading the record is something you do, from a terminal.

**An allow is visible nowhere else.** A denial surfaces to the model as a tool error and an `ask` reaches the session log as an `approval/asked` pair, but a call this gate allowed is indistinguishable in the session log from one it never saw. A session event would be the natural home and is not available to an out-of-tree plugin: a `SessionEventMap` member is required-on-read, the harness registers event types in its own tree, and an unknown non-ignorable event makes the host refuse to replay the whole log. Hence a file this package owns, which nothing in the harness reads back.

**In `full-access` this file is the only account of what ran.** That tier raises no `ask` and refuses nothing, so neither of the two session-log traces above is written. Nothing this plugin does protects the file: it is created with the process umask under `$DSH_HOME` and is as readable and as writable as that directory is. Guarding it would have meant reading `verdictLog` inside the red line, which is what makes a red line movable from a profile — so the file is a record, and never evidence.

**The record is an observation, never a control.** Each write is contained, an unwritable path is reported once and then ignored, and no decision depends on the result — a gate that could be jammed by filling a disk would be worse than one that keeps no record. It claims no tamper resistance: an agent that can write files can truncate it, and so can a plugin calling `node:fs` directly.

## What this gateway does not stop

**In `full-access` it stops nothing at all.** Not the red lines, not `browser_auth`, not an oversize call nobody has read. That is the tier's meaning rather than an oversight — the harness already refuses every approval request there without asking anyone — and the `yolo-access` row is the wall-less mode for someone who wants the review instead.

**It gates what the model asks for, not what a plugin does.** A plugin's own work — inside its HTTP route handlers, background timers, and event listeners — produces no tool call at all, so `tools/pre-execute` never sees it. A plugin calling `node:fs` or `node:child_process` directly bypasses this gate *and* the sandbox-escape path, because it never enters the `ctx.fs` or `ctx.shell` seams either. This is not a gap to be closed here; it belongs to sandboxing and process isolation. Reviewing a third-party plugin still means reading it for bare `fs`/`child_process` use and for registered HTTP routes.

**A walled tool is only as confined as the sandbox is.** The gate reads the mode and the mounted executor's `sandboxMode` and trusts both. It does not read `SandboxEnforcement`, which reports `partial` where a backend or kernel cannot govern every promised file effect — `windows-acl` reports `partial` on every Windows host, and an older Landlock ABI does on Linux. Where the wall is partial, a skipped review is a review not performed; `walledTools: []` restores review at that cost.

**Red-line detection is textual.** The self-modification scanner matches resolved paths and literal spellings. It does not follow indirection: a path assembled at runtime, `cd` followed by a relative path, a base64 blob, or a helper script written first and run later can all reach a protected location without matching. The review model is the second layer here, not a proof.

**A verdict is a judgment.** The reviewer can be wrong in both directions, and the same call can be judged differently twice. It is a filter, not a decision procedure — and since it cannot refuse, a wrong `allow` is the failure that costs something.

**An escalation is judged on the agent's own account of itself.** The request carries the requested mode and the agent's `justification`; the refused command comes from this plugin's own memory of the call, and is absent when the call was not remembered (a restart between the call and the escalation, or a `cacheEntries: 0` profile). Nothing in the request says which path the sandbox actually refused.

**Injected text is weighed, not neutralised.** Arguments and justifications are framed as data on both sides of the fence and the model is told that a claim of prior approval is itself an attack signal. That is a defence with a success rate, not a boundary.

**Caching trusts the arguments.** A call whose arguments are byte-identical to one already allowed in the same agent run is allowed again without review, even though the world may have changed in between.

**The gate sees one call at a time.** A sequence that is harmful only in aggregate — reading a file, then writing it elsewhere, then sending the copy — is reviewed as three separately reasonable calls.

**The decision record sits beside the session log, not in it.** A session copied to another machine carries no evidence of what the gate allowed, and deleting the file loses that history with nothing to reconstruct it from.

## Changelog

### 0.4.6

- **An escalation record names the effort its own review was issued at**, the way it already named the model. It read the route in force at record time, so a route that moved while the review was in flight mislabelled what that decision cost.
- **A refusal of the answer format is recognized by the words adapters actually use.** `llm-pi-ai` throws `llm-pi-ai does not support GenerateOptions.responseFormat` with code `UNSUPPORTED_OPTION`; the code still decides wherever one is stated, and the text fallback now reads the request field as well as the code.
- **The effort radios show the catalog's own name for a level this page cannot name**, rather than the provider's machine id — the word the composer's thinking control shows.
- **The model lookup is issued under a cancellation** and ends when the plugin unloads or when what is known about a route is dropped, so an adapter round trip cannot outlive the question or land on a route nothing is issued on.

### 0.4.5

- **Every review is issued in the provider's JSON mode.** `responseFormat: { type: 'json_object' }` rides both questions; on a host carrying the `llm-response-format` core patch the provider refuses to emit anything else, and the tolerant parse stays as the fallback for hosts without it. The prompt keeps saying JSON and showing the example, which that mode requires. A route whose adapter refuses the field — pi-ai answers `UNSUPPORTED_OPTION` — is asked again without it once and remembered, so the cost is one turn per route rather than one per review.
- **The effort is settled against the model that will answer, not against the configuration alone.** 0.4.4 sent the configured id to every picked route, and `dsh-llm` refuses a request naming an effort for a model that reports no reasoning — most models under some adapters — so picking one as the reviewer failed every review. The model is now asked once per route: no reasoning at all omits the effort, an offered id is issued, and an id the model does not offer is reported once with the configured route reviewing instead.
- **How long the reviewer thinks is a settings-page choice.** `judgeReasoningEffort` stores one of the efforts the picked model offers; a review under it starts at the cap plus the thinking budget and is not asked twice. Every record names the effort it was reached under, so the ledger can compare `off` against `low`.
- **The restated `danger-full-access` row carries `tone: danger`.** Both access-mode menus paint it in the danger colour; `yolo-access` stays plain, because it is wall-less and still asks a person.
- **A profile still setting the retired `config.mode` is told so once, at load**, and told which key replaced it. A stored `mode` stays silent: that is a person's old state, not a line someone wrote.

### 0.4.4

- **The walled-mode switch moved to its own settings key, and every old value stops counting.** It is `walledReview`, a boolean defaulting to `false`, written by the checkbox, by `/review auto|manual`, and by `config.walledReview`. Up to 0.3.x the same namespace stored `mode: auto | manual`, where `auto` meant "this gate reviews" — so an installation carrying that document showed the 0.4.x checkbox ticked, reviewing under `read-only` and `workspace-write` against a shipped default of off. The old key is accepted so an old document still validates and is read by nothing; it is not migrated, because `auto` says the person wanted review and not that they wanted these two modes reviewed.
- **A review answer is read as one object wherever it sits in the text, and an empty one is named as empty.** The parser took a bare object only, so a reviewer that wrapped a sentence around the verdict it had already reached cost an approval prompt; it now accepts exactly one balanced `{…}` and refuses two, which is what keeps it from ever picking a decision out of a text. A model that answered only in the reasoning channel used to be reported as one that ignored the format — the refusal now says the answer was empty, and a failure record carries `finish` plus, behind `verdictLogArgsPreview`, the first 160 characters of what came back.
- **The configured `reasoningEffort` now travels to a picked route on another provider too.** Dropping it there did not mean "do not think": the runtime fills in that route's own default, and a reviewer that thinks first spends the output cap before the verdict or answers in the reasoning channel. A route that does not define the id refuses the request by name instead of thinking silently, and `reasoningEffort: ''` is how a profile asks for that route's own default.

### 0.4.3

- **Documentation only, and all of it correcting this package's own prose**: the literal half of the self-modification red line is listed as `resolveProtectedTargets` builds it (four spellings each of two locations, no `~`, the home's own directory name); the record's `tier` row says the delegating session rather than the root of the lineage, which is what the code has read since 0.4.2; `onFailure: deny` is named alongside the two red lines as a denial this gate makes on its own; the `decision` row covers a chain that threw; the judge prompt no longer says a prompt stops a call *only* where nobody can be asked, since a composition with no answerer refuses it too; and the delegated child's pinned `never`, the missing projection sentinel, and one upstream line number are each stated as what they are.

### 0.4.2

- **A forked session is not a delegated one.** 0.4.1 read `header.parentSession` as the test for delegation; the header defines that field as the session this one was forked from, and the fork command writes it for a session a person opened and is sitting in. Forking a conversation whose source agent is no longer live therefore told the person in it 这一步没有人可以答复 for every call that would have asked them, and forking a live one overrode the access mode they had set in it. The test is `header.origin === 'subagent'`, which is what the harness writes for a subagent child and reads back to recognize one; the climb ends at the session a person is in.
- **An unresolvable lineage keeps a standing wall.** Its tier is now folded as if a person could be asked, so `read-only` and `workspace-write` read as `walled` and the walled tier's review switch decides as usual, instead of every call being reviewed under `auto-review` with `confined: true` beside it. Nobody is still reachable there. A child whose header names no session it came from is unresolved too.
- **The permission projection is no longer trusted to answer.** A state carrying no `approval` field — what an upstream rename produces — and a projection that throws rather than folding a log both fall back to `ApprovalService.overrideOf` instead of being read as "this session logged no policy", which would have handed a session pinned to `never` its deployment default.
- **Copy that claimed more than the code does.** "never a blocked call", the package description's "never refuses on the model's word", and the judge prompt's version of it now say what is true in a session nobody can be asked in; the red line's literal half no longer claims to catch any relative path; the record's `decision` row says how to read a `deny` that the rest of the chain made; and the 0.4.1 entry above says which `verdictLog` value guarded the whole harness home.

### 0.4.1

- **A delegated call is governed by the session it came from.** `@deepseek-ai/dsh-subagent` pins every in-process child's approval policy to `never` and seeds the parent's sandbox override beside it, so a child of a wall-less session carried the `full-access` knob pair: one `delegate` put every subagent call past the review, past `alwaysAsk`, and past both red lines. The tier now comes from the root of the `parentSession` lineage, walked through `ctx.agents.get()`; a lineage with a gap in it reviews and reaches nobody, rather than reading the child's own pinned pair.
- **A question nobody can answer is refused in this gate's own words.** Under `approval: never` an approval request resolves to `rejected` before any answerer sees it, so every `ask` this gate raised there became a silent refusal reported to the model as a rejection by a user who was shown nothing — the state of every delegated child, and of a session under a wall whose mode asks nobody. Each such step now answers `{kind: 'deny'}` carrying its own sentence plus one saying nobody could be asked, after the chain has had the call and unless the chain answered for it.
- **New record fields `delegated` and `humanReachable`**, on every record that names a tier; `policy` is now the policy the tier was folded from — the root session's for a delegated call — and is absent where no policy decided it. `dsh-gateway-verdicts` counts delegated records, and the refusals that stood in for an unanswerable question, as their own lines.
- **The decision record left the self-modification red line.** Guarding its directory meant reading `verdictLog`, so a `Config` field decided what an unconditional refusal covered: a record written straight into the harness home (`verdictLog: '~/.dsh/verdicts.jsonl'`) guarded the whole of it, refusing every call that named a session log, and `verdictLog: false` guarded nothing. The record is protected by whatever protects `$DSH_HOME`, and claims nothing more.
- **The red line no longer resolves a relative argument against this process's working directory.** With the cwd inside a protected directory every argument carrying a separator matched, `{"url": "https://example.com"}` included. Only absolute paths, and `~` spellings of them, are compared; a relative path is caught only by the literal spellings the scan lists. The package's own test run from its own directory was failing 19 cases for this reason.
- **The settings section is 审查设置 / Review settings**, not 自动审查, which is the name of an access mode this switch cannot reach. The checkbox names both modes it does reach (`Also review under Read Only and Workspace Write`), and `/review` reports the state of those two modes instead of reporting itself as "自动审查现在是关着的" to someone sitting in the access mode of that name.
- **The session's approval policy is read from the `permissions` session projection** where that unit is registered, instead of `ApprovalService.overrideOf` walking the session log backwards on every tool call. The service's own method stays as the fallback.

### 0.4.0

- **Four access modes, and three tiers behind them.** What this gate does is now folded from the two knobs the harness already has — whether the operating system confines, and the session's effective approval policy — and never from a preset name. `walled` reviews what the wall does not cover; `auto-review` reviews everything that is not a local read; `full-access` is the gate standing aside.
- **`danger-full-access` + `never` no longer turns every question into a silent refusal.** That pair resolves every approval request to `rejected` before any answerer sees it, so this gate's `ask` reached the person as nothing and the model as `the user rejected tool "<name>"`. In that tier the gate now consults nothing at all — no red line, no `alwaysAsk`, no review — and delegates every call, recorded as `unattended`. A customer on Windows was hitting this as a `browser_auth` that failed with no prompt and no explanation.
- **The walled-mode review switch ships off, and says what it reaches.** `config.mode` defaults to `manual`: under a wall the harness already refuses the file effects a review would object to. The switch reaches `read-only` and `workspace-write` only, which `/review` says by naming them.
- **The `yolo-access` row is renamed** 自动审查, moved to third — walls, then no walls but still asked, then no walls and never asked — and describes what selecting it buys. This overturns the recorded rule that no row may name review: review is not a switch in that row, it is what the row's knob pair does. The id is unchanged, because a stored `defaultPreset` naming it is what a rename would break. The row's retirement condition is now written into the patch file: an upstream reviewed access mode reaching the default composition retires it.
- **The review prompt states the wall the call actually has.** It said "the operating system already stops this call from writing outside the working directory" on every review, including the ones with no wall — a false premise in exactly the state where the verdict is the only boundary. The verdict cache key now carries the wall state too, so a verdict reached under a wall is not replayed after the wall is gone.
- **The record says which tier admitted a call, and on what.** New fields `tier`, `policy`, `sandboxMode`, and `confined`; new `source` value `unattended`; `dsh-gateway-verdicts` counts unattended pass-throughs as their own line rather than inside the un-reviewed remainder.
- **The decision record's directory is inside the self-modification red line.** In `full-access` the file is the only account of what ran, and an agent that can truncate it can erase exactly the window it describes.

### 0.3.1

- **A model picked on the configured provider keeps the configured `reasoningEffort`.** Picking one dropped it and took the provider's own default, and a provider whose default is to think first spends the review's whole output cap on thinking: the verdict is truncated, truncation fails closed, and every call reaches an approval prompt. Only a change of provider takes that provider's default now, because that is where a provider-owned effort id stops meaning anything.
- **A verdict crowded out by thinking is asked once more with room for it.** New `reasoningBudgetTokens`, default `2048`: an answer that hit `maxOutputTokens` having spent thinking tokens is re-issued under `maxOutputTokens + reasoningBudgetTokens`, inside the same `timeoutMs`. An answer truncated without thinking tokens is not retried. New record field `budgetRetried`, whose token counts cover both turns.
- **The settings picker says when a picked model can think first.** The catalog reports a model's selectable reasoning efforts; one with more than one gets a line saying review on it is slower and costs more.
- **A settings provider arriving with a route of its own drops the cache too.** Mounting one is not a commit, so nothing announced it: a stored document that already named a route moved what the next call was reviewed on while the verdicts reached under the configured reviewer stayed cached, ready to be served as that route's answers.
- **`dsh-gateway-verdicts` counts a thrown chain as `error`.** `downstream: "none"` was counted under the gate's own `ask`, which reported an approval prompt nobody ever saw: the chain threw, so nothing decided the call.

### 0.3.0

- **The review carries each tool's own description.** It is read per review through `ctx.tools.get(name, agent)`, so a scoped definition shadowing a global one reads here as it did for the call, and it travels inside the fenced JSON with the arguments rather than in the system prompt — it is the tool author's text, not this package's. It is capped at 4000 characters on its own, outside `maxArgumentsChars`, and it is no part of the cache key. New record fields: `descriptionChars` and `descriptionDigest`, absent on every record that carried no description.
- **An ask goes down the chain before it is raised.** Every `ask` this gate produces — from `alwaysAsk`, an oversized call, a review failure, or a verdict — now calls `next()` first and answers with whatever wins: a `deny` or an `ask` further along is returned as it stands, and only an allow leaves this gate's own ask standing. Prepended position no longer hides a call from the listeners behind it, which is what a listener that books an approval its own tool body checks for needs. New record field: `downstream`, carrying `allow`, `ask`, `deny`, or `none` for a chain that threw.
- **The review model is chosen in settings.** A settings page named 自动审查 carries the review switch and a picker over the models this installation can review on, stored in the same `llm-permission-gateway` namespace as `mode`. `config.provider`/`config.model` become the fallback, used where nothing is stored and where the stored provider has no adapter. A change takes effect on the next call and drops every remembered verdict — so does an adapter registering or retiring routes, which moves the route with nothing committed to settings. The record's `model` follows: a record a review was issued for names the model it was issued on, and every other record names the route in force when it was written.
- **`dsh-gateway-verdicts` reports settled decisions and splits reviews by model.** `by decision` counts what a call actually received rather than what this gate answered, so an ask the chain then refused is counted as a `deny`. A `by model` block, drawn once more than one model reviewed, gives each model its own review count, latency quantiles, and token total.

### 0.2.0

- **Only unwalled calls are reviewed.** `walledTools` under a `read-only` or `workspace-write` sandbox are passed through with `source: "walled"`. Under `danger-full-access`, or with no sandbox policy composed, every call is reviewed as before.
- **Sandbox escalations are answered.** A new `approval/request` listener recognizes `escalate sandbox to <mode>: <justification>`, reviews it against the refused call this gate remembered, grants `allowed-once` on `allow`, and delegates to the person on `ask` or under `onFailure: ask`. It delegates without asking the model at all when the call was not remembered, when the request names a different tool than the note holds, or when the request is this gate's own `ask`. Every other approval falls through untouched.
- **The review model can no longer refuse.** A `deny` verdict becomes an `ask`; the record carries `downgraded: true`. The two red lines are unchanged.
- **`/review auto` and `/review manual`.** The mode is this plugin's own setting, persisted in the `llm-permission-gateway` settings namespace. `manual` keeps the red lines and `alwaysAsk` and skips everything else.
- **A cancelled call is abandoned quietly.** An already-aborted caller signal, or one that aborts mid-review, delegates and records `source: "cancelled"` with `decision: "cancelled"` instead of producing an approval prompt or a gate-authored error.
- **Reasons are in Simplified Chinese.** `reasonLanguage` defaults to `简体中文`, and every sentence this plugin writes itself — red lines, oversized calls, review failures, the `browser_auth` cost sentence, the `/review` echo — is Chinese.
- **`readOnlyTools` gains** `show_chart`, `job_output`, `content_show`, and `web_search`.
- **On Windows the walls are `partial`.** `@deepseek-ai/dsh-sandbox-local` reports `windows-acl` enforcement as `partial` unconditionally, for its documented Everyone-ACL and hard-link boundaries. This version stops reviewing the walled tools there as well as on the platforms that report `full`; a Windows deployment that wants those calls reviewed sets `walledTools: []`.
- **The `yolo-access` preset row is renamed** 关闭沙箱（不推荐） and no longer claims model review makes it safe. The row itself stays: removing it breaks the `permission` settings section for anyone whose stored `defaultPreset` names it.
- **New record fields**: `source` gains `cancelled`, `manual`, `walled`, `escalation`, `escalationUnreviewed`, and `escalationFailure`; `decision` gains `cancelled`; records gain `downgraded` and `requestedMode`; `callId` is absent on an escalation whose approval request named no call.
- **A wall counts only where an executor confines.** `sandboxConfines` now requires the mounted shell executor to report a `sandboxMode` as well as the policy service to resolve one, so a deployment over an unconfined executor is reviewed rather than skipped.

## Development

See the workspace README for the build, the tarball-based profile install, and why a `link:` dependency must not be used.

`@deepseek-ai/cordis` is a required peer although this package imports only its types: every harness package declares it, and one cordis instance per composition is what makes service identity work, so declaring it optional would invite a second copy rather than record a real independence. `react` and `react-dom` are the opposite case — `src/client/ReviewSection.tsx` imports their values — and they are optional because the browser half is loaded only by a front-end shell, which supplies them; a Node-only composition mounts the gate without either.
