/**
 * The name of the settings section this plugin owns.
 *
 * Its own module because both halves need it and only one of them can import
 * `./mode.ts`: that module registers the schema through schemastery and the
 * commands registry, neither of which belongs in a browser bundle.
 * @module @haoran/dsh-llm-permission-gateway/settings-namespace
 */
/** Settings namespace this plugin owns; matches its cordis short name. */
export declare const GATEWAY_SETTINGS_NAMESPACE = "llm-permission-gateway";
//# sourceMappingURL=settings-namespace.d.ts.map