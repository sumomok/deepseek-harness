/**
 * Answering the one approval the sandbox itself raises.
 *
 * When a confined `bash`, `pwsh`, `write`, or `edit` call is refused for
 * touching something outside its walls, the agent may retry the same call once
 * with a wider `sandbox_permissions` plus a `justification`. That retry does not
 * run: `approveEscalation` puts the question to `ctx.approval.request()`, which
 * dispatches it as the `approval/request` waterfall. Registering there is what
 * lets the review model answer it instead of the person.
 *
 * The request carries a tool name, a call id, and one sentence of free text —
 * `escalate sandbox to <mode>: <justification>` — because the call's arguments
 * were already logged and presented when it was made. This module recognizes
 * that sentence and nothing else: an approval raised any other way (an `ask`
 * this gate itself returned, or one a hook bridge returned) falls straight
 * through to whoever normally answers.
 *
 * Three conditions must hold before the model is asked at all, and each failure
 * hands the request to the person rather than guessing:
 *
 * - **The call must be remembered.** The refused command comes from this gate's
 *   own note of the call, taken when it was passed through as walled. Without
 *   it the review would be judging the agent's account of itself against a
 *   prompt that says the command is present — a restart, `cacheEntries: 0`, or
 *   a `manual` -> `auto` switch between the call and its escalation all reach
 *   that state.
 * - **The remembered tool must be the tool the request names.** The note is
 *   keyed by agent and call id; a request naming a different tool for that id
 *   is not describing the call the note holds.
 * - **The request must not be this gate's own `ask`.** That reason is written
 *   by the review model over arguments an attacker can reach, so a reason shaped
 *   like the sentence above would otherwise be re-reviewed here and could be
 *   granted without a person. Every ask is registered against its agent and
 *   call id, and a request under one is handed on untouched.
 *
 * `allow` claims the request; `ask` delegates, so the person still decides and
 * still sees the original reason. There is no path here that refuses on the
 * model's word alone unless `onFailure` is `deny`, which refuses only when no
 * verdict was obtained at all.
 * @module @haoran/dsh-llm-permission-gateway/escalation
 */
import type { Context } from '@deepseek-ai/cordis';
import type { JudgeRoute } from './judge.ts';
import type { VerdictProbe } from './probe.ts';
import type { CallNotes, RememberedCall } from './walls.ts';
/** The wider access one escalation asks for, and the agent's stated reason for it. */
export interface EscalationFacts {
    /** The sandbox mode asked for. */
    readonly requestedMode: string;
    /** The agent's own one-sentence justification, verbatim. */
    readonly justification: string;
}
/**
 * Read one approval request's free text as a sandbox escalation.
 * @param reason - the approval request's reason text, when it carries one.
 * @returns the requested mode and justification, or `undefined` when the text is not an escalation.
 */
export declare function parseEscalationReason(reason: string | undefined): EscalationFacts | undefined;
/** What the escalation answerer needs from the surrounding plugin. */
export interface EscalationAnswererOptions {
    /**
     * The judge model and its budget, read per request: the route is a live
     * setting, so an answerer holding one would keep asking a reviewer the user
     * has already replaced.
     */
    readonly route: () => JudgeRoute;
    /**
     * Whether the review model is answering escalations right now.
     *
     * Only a confining composition raises one at all — the sandbox escape face is
     * gated on the mounted executor, and there is no mode wider than
     * `danger-full-access` to escalate to — so this is the walled tier's own
     * review switch, and a `false` hands every escalation to the person.
     */
    readonly reviewing: () => boolean;
    /** Identity and arguments of the calls that can escalate, remembered on `tools/pre-execute`. */
    readonly memo: CallNotes<RememberedCall>;
    /** Calls this gate itself asked about, so its own question is never re-reviewed here. */
    readonly ownAsks: CallNotes<true>;
    /** Where decisions are recorded. */
    readonly probe: VerdictProbe;
    /** What to do when no verdict is obtained; `ask` hands the request to the person. */
    readonly onFailure: 'ask' | 'deny';
}
/**
 * Register the answerer.
 * @param ctx - the plugin context.
 * @param options - the judge route, the mode switch, the two call notes, the record, and the fail-closed choice.
 */
export declare function applyEscalationAnswerer(ctx: Context, options: EscalationAnswererOptions): void;
//# sourceMappingURL=escalation.d.ts.map