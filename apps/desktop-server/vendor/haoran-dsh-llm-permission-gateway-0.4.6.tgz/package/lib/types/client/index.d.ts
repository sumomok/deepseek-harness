/**
 * Browser half of @haoran/dsh-llm-permission-gateway: one settings page over
 * the two choices the host half reads live — whether each step is reviewed, and
 * which model reviews it.
 *
 * There is no Remote of this package's own. The switch and the route are fields
 * of this plugin's settings namespace, reached through `ctx.settingsScope`; the
 * models offered come from `session/modelCatalog`, the same read the model
 * selector performs, which is the only path to a model list a browser has —
 * `llm.listModels` carries no `@Remote`. That catalog holds exactly the
 * provider routes an adapter serves, which is the set a review can be issued
 * on, and it reports a provider whose own list failed to load separately so the
 * page can name it without offering it.
 *
 * @module @haoran/dsh-llm-permission-gateway/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type GatewayKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-llm-permission-gateway` copy. */
        llmPermissionGateway: GatewayKey;
    }
}
export { choiceOf, judgePicker, routeValue, type JudgeChoice, type JudgeChoiceGroup, type JudgeEffort, type JudgePicker, type JudgeSelection, type JudgeUnavailableProvider, } from './catalog.ts';
export { effortLabel, ReviewSection, saveStatusKey, type ReviewSectionProps } from './ReviewSection.tsx';
export { insertStyles, STYLE_TAG } from './styles.ts';
export { en, NS, zh, type GatewayKey } from './locales.ts';
/** Required browser services. */
export declare const inject: string[];
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map