/**
 * The `settings.section` page this plugin contributes: whether each step is
 * reviewed before it runs, and which model does the reviewing.
 *
 * Both live in this plugin's own settings namespace, read and written through
 * the scope every settings row binds through (`ctx.settingsScope.bind`,
 * `@deepseek-ai/dsh-client-ui-settings`), so a change here decides the next
 * call without a restart.
 *
 * The two halves of the route are written in one `mutate`, never as two writes:
 * a section holding one half of a pair names no route, and the host would
 * review on the configured one until the second write landed. The stored
 * reasoning effort is cleared in that same write, because an effort id is
 * offered by one model and means nothing on the next.
 *
 * @module @haoran/dsh-llm-permission-gateway/client/ReviewSection
 */
import { type ReactNode } from 'react';
import type { ModelCatalog } from '@deepseek-ai/dsh-api-session-controller/types';
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { GatewaySettings } from '../mode.ts';
import { type JudgeEffort } from './catalog.ts';
import type { GatewayKey } from './locales.ts';
/** Props the section reads from its composed slot props. */
export interface ReviewSectionProps {
    /** Close the settings panel; unused here — this page has no flow that leaves settings. */
    close: () => void;
    /** The bound settings scope over this plugin's own namespace. */
    scope: SettingsScope<GatewaySettings>;
    /** Read the provider-grouped catalog of models a review can be issued on. */
    read: () => Promise<ModelCatalog>;
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'llmPermissionGateway'>;
}
/** One save action's inline status, shown beneath the controls it settles. */
type SaveState = 'idle' | 'saving' | 'saved' | 'error';
/** @param state - one save action's status. @returns its copy key, or `undefined` while idle. */
export declare function saveStatusKey(state: SaveState): GatewayKey | undefined;
/**
 * The word this page shows for one effort the model offers.
 *
 * The dictionary covers the ids the providers this harness ships use, so those
 * levels read in the page's own language. Anything else is shown under the name
 * the catalog carries — the word the composer's own thinking control shows for
 * that level — rather than under a word this page invented.
 * @param effort - the effort as the catalog reports it.
 * @param t - the translate seat for this plugin's namespace.
 * @returns the label for that radio.
 */
export declare function effortLabel(effort: JudgeEffort, t: TranslateNS<'llmPermissionGateway'>): string;
/**
 * The registered `settings.section` component.
 * @param props - composed slot props.
 * @returns the page, or a placeholder before the first accepted section.
 */
export declare function ReviewSection({ scope, read, t }: ReviewSectionProps): ReactNode;
export {};
//# sourceMappingURL=ReviewSection.d.ts.map