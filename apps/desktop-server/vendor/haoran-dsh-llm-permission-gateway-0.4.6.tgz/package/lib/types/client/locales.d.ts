/**
 * Copy for the settings page this plugin owns.
 *
 * Every line describes this page and nothing else: no other tool is named, and
 * no other place to go is named, because a person reading a settings page is
 * not being told what to do next.
 *
 * The section is named 审查设置 rather than 自动审查 because an access mode
 * already carries that name, and this page's switch is the one thing that does
 * not reach it. The checkbox names the two access modes it does reach, in the
 * words the access-mode menu uses for them.
 *
 * The four effort words are a display mapping over the ids providers happen to
 * use today, never the list itself: which efforts exist is read from the picked
 * model, and one this dictionary has no word for is shown under the id the
 * provider gave it rather than under a word this page invented.
 * @module @haoran/dsh-llm-permission-gateway/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "llmPermissionGateway";
/** Chinese copy (the dictionary that defines the key domain). */
export declare const zh: {
    'settings.nav': string;
    'settings.autoReview': string;
    'settings.model': string;
    'settings.modelDefault': string;
    'settings.mayReason': string;
    'settings.effort': string;
    'settings.effortOff': string;
    'settings.effortLow': string;
    'settings.effortHigh': string;
    'settings.effortMax': string;
    'settings.effortNote': string;
    'settings.effortPickModel': string;
    'settings.unavailableSuffix': string;
    'settings.notAvailable': string;
    'settings.catalogLoading': string;
    'settings.catalogFailed': string;
    'settings.readOnly': string;
    'settings.unavailable': string;
    'settings.loading': string;
    'settings.saving': string;
    'settings.saved': string;
    'settings.error': string;
};
/** English copy. */
export declare const en: Record<GatewayKey, string>;
/** Dictionary key domain. */
export type GatewayKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map