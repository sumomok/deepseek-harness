/**
 * The settings section this plugin owns — whether the walled access modes are
 * reviewed as well, and the route the review model is reached on — and the
 * slash command that throws that switch.
 *
 * The switch is this plugin's own state rather than a fifth permission preset
 * because it is orthogonal to the access modes: it answers "also review where a
 * wall already stands", which is a yes/no over two of the rows rather than a
 * row of its own. The row this plugin does contribute names the tier whose
 * behaviour IS the review, and that tier does not read this switch.
 *
 * Both settings are durable where a settings provider is composed and
 * process-lifetime otherwise; `persists` is what the command's own text reports.
 * Every read goes to the scope at the moment of the read, so a choice made in
 * the settings page decides the next call without a reload.
 * @module @haoran/dsh-llm-permission-gateway/mode
 */
import type { Context } from '@deepseek-ai/cordis';
import type { JudgeRoute } from './judge.ts';
/**
 * The two words `/review` takes, which say what to do with
 * {@link GatewaySettings.walledReview}.
 *
 * `manual` is not "no gate": the two red lines and `alwaysAsk` run either way,
 * and everything else falls through to whatever the harness itself would have
 * done — the sandbox, and a human at the approval prompt. It also reaches only
 * the walled tier: the access mode whose stated behaviour is the review reviews
 * every call under both values, and the one that asks nobody reads neither.
 */
export type ReviewMode = 'auto' | 'manual';
/** The command name, without its leading slash. */
export declare const REVIEW_COMMAND = "review";
/** This plugin's persisted settings section. */
export interface GatewaySettings {
    /**
     * Whether the two walled access modes are reviewed as well. `false` is what a
     * fresh installation and an untouched settings document both answer.
     */
    walledReview: boolean;
    /**
     * The 0.3.x switch, kept in the schema so a stored document carrying it still
     * validates, read by nothing, and deliberately not migrated — the package
     * README says why.
     * @deprecated Since 0.4.4. Superseded by {@link GatewaySettings.walledReview}.
     */
    mode?: ReviewMode;
    /**
     * Provider route the user picked for the review model, or `''` to be reviewed
     * on the route the composition configured. Written together with
     * {@link GatewaySettings.judgeModel}: half a pair names no route.
     */
    judgeProvider: string;
    /** Model id the user picked for the review model; `''` alongside {@link GatewaySettings.judgeProvider}. */
    judgeModel: string;
    /**
     * Reasoning effort the user picked for the review model, or `''` to be
     * reviewed at the effort the composition configured.
     *
     * The id belongs to the provider that defines it and is meaningful only for
     * the model that offers it, so it is checked against that model's own list
     * before it is issued; an id the model does not offer is reported once and
     * the configured effort is used instead.
     */
    judgeReasoningEffort: string;
}
/** What the composition configured, in force until the user chooses otherwise. */
export interface GatewayDefaults {
    /** Whether a fresh installation reviews the two walled access modes as well. */
    readonly walledReview: boolean;
    /** The route a user who picked no review model is reviewed on. */
    readonly route: JudgeRoute;
}
/** Reads and writes the settings this plugin owns, wherever they are stored. */
export interface GatewayStore {
    /** Whether the two walled access modes are reviewed as well, right now. */
    walledReview(): boolean;
    /** Whether a change survives a restart. */
    persists(): boolean;
    /**
     * Change whether the two walled access modes are reviewed as well.
     * @param next - true to review them too.
     */
    setWalledReview(next: boolean): Promise<void>;
    /** The route the next review is issued on, settled afresh on every call. */
    route(): JudgeRoute;
    /**
     * Forget which reasoning efforts each model was found to offer, after a
     * change that can move which adapter answers for a route.
     */
    dropEffortChecks(): void;
    /**
     * Observe changes to the route {@link GatewayStore.route} answers with.
     * @param listener - invoked after a commit that changed either half of the stored pair.
     * @returns the disposer removing this listener.
     */
    onRouteChange(listener: () => void): () => void;
}
/**
 * Create the settings store and attach it to a settings provider when one is
 * composed.
 *
 * The store is returned before any provider attaches, so the gate reads a mode
 * and a route from its first call onward; attaching only moves the answers from
 * the composition config to the user document.
 * @param ctx - the plugin context.
 * @param defaults - the mode and route from the plugin's own config, used until a settings provider attaches and whenever none does.
 * @returns the store the gate, the command, and the record all read.
 */
export declare function createGatewayStore(ctx: Context, defaults: GatewayDefaults): GatewayStore;
/**
 * Register the `/review` command where a commands registry is mounted.
 * @param ctx - the plugin context.
 * @param store - the settings store the command reads and writes.
 */
export declare function applyReviewCommand(ctx: Context, store: GatewayStore): void;
//# sourceMappingURL=mode.d.ts.map