/**
 * Which access tier a pending call runs in, folded from the two knobs the
 * harness already has: whether the operating system confines file effects, and
 * what happens to an approval request.
 *
 * The fold reads the knobs, never a preset id. A preset name is a label a
 * profile chooses for one knob pair, and a composition may mount no preset
 * table at all; the knobs are what actually decide whether a wall stands and
 * whether anyone can be asked. Keying on them also means a deployment that
 * renames or reorders its presets changes nothing here.
 *
 * The approval half mirrors `ApprovalService`'s own three-term fold —
 * `overrideOf(session) ?? config.policy ?? 'ask'` — because that method is
 * private and the gate has to reach the same answer the service will. A copy
 * can drift, so `tests/policy.spec.ts` pins {@link ApprovalPolicyReader}
 * against the real service type: an upstream rename fails the type check rather
 * than silently reading `ask` here. The first term is read from the permission
 * projection where one is registered, which is the same fact at a constant
 * price; see {@link PermissionStateReader}.
 *
 * A delegated session reads its tier from the session it was delegated from.
 * `@deepseek-ai/dsh-subagent` pins every in-process child's approval policy to
 * `never` at the delegation boundary wherever the approval capability is
 * composed, and seeds the parent's explicit sandbox override alongside it, so a
 * child's own knob pair says "no wall, nobody to ask" in every access mode
 * whose parent had no wall — the pair this gate would otherwise read as the
 * person having asked for no gate at all. Which tier such a call runs in is
 * therefore read from the session it was delegated from, and whether anyone can
 * answer a question about it is read from the calling session itself;
 * {@link TierState} carries both.
 *
 * Delegation is `header.origin === 'subagent'` and nothing else. A forked
 * session carries a `parentSession` too — that is what the field means — and a
 * person opened it and is sitting in it, so its own knobs are the ones they
 * chose and its own policy is what says whether they can be asked.
 *
 * Every unknown reads as `ask`, which is the tier that keeps reviewing. Reading
 * an unreadable policy as `never` would switch the whole gate off wherever no
 * approval service is composed.
 * @module @haoran/dsh-llm-permission-gateway/policy
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
/**
 * What happens to an approval request, in the harness's own two-value
 * vocabulary: `ask` dispatches it to the composed answerers, `never` resolves
 * it to `rejected` before any answerer sees it.
 */
export type ApprovalPolicy = 'ask' | 'never';
/**
 * The two public members of `ApprovalService` this fold reads.
 *
 * Declared structurally rather than imported as the service type: the Context
 * augmentation that types `ctx.approval` lives in that package's value entry,
 * which this plugin does not import, and the service is optional in every
 * composition the gate has to keep working in.
 */
export interface ApprovalPolicyReader {
    /** The deployment default, absent when the plugin config omitted it. */
    readonly config: {
        readonly policy?: ApprovalPolicy;
    };
    /**
     * The session's own policy override.
     * @param session - the session whose log carries the override.
     * @returns the last logged policy, or `undefined` when the session logged none.
     */
    overrideOf(session: Agent['session']): ApprovalPolicy | undefined;
}
/**
 * The one projection read this fold uses.
 *
 * Declared structurally, and narrowed to the one key: the `permissions` unit is
 * registered by `@deepseek-ai/dsh-permission-presets`, which this plugin does
 * not depend on, so the registry's own key union does not carry it here and no
 * assignability sentinel is declared for it, the way {@link ApprovalPolicyReader}
 * and {@link AgentLookup} each have one against a package this one keeps as a
 * devDependency. What stands in for that sentinel is {@link loggedPolicy}: a
 * state that carries no `approval` key at all is not read as "this session
 * logged no policy", it sends the read back to the approval service.
 */
export interface PermissionStateReader {
    /**
     * Read the current permission knobs folded from one session's log.
     * @param session - the session whose state is read.
     * @param key - the registered unit, which is `permissions` and nothing else here.
     * @returns the state, or `undefined` where that unit is not registered.
     */
    stateOf(session: Agent['session'], key: 'permissions'): {
        readonly approval?: ApprovalPolicy | null;
    } | undefined;
}
/**
 * The policy every approval request for this call would resolve under.
 * @param ctx - the plugin context; the approval service is read opportunistically through `ctx.get`.
 * @param agent - the calling agent, whose session carries any override; `undefined` outside an agent leaves only the deployment default.
 * @returns the effective policy, or `ask` wherever it cannot be read.
 */
export declare function effectiveApprovalPolicy(ctx: Context, agent: Agent | undefined): ApprovalPolicy;
/**
 * The three ways a call can be governed, and the whole of what this gate
 * branches on.
 *
 * - `walled` — the operating system confines file effects and a person can be
 *   asked. The gate reviews what the wall does not cover, and only while its
 *   own review switch is on.
 * - `auto-review` — no wall, and a person can still be asked. Review is this
 *   tier's own behaviour: every call that is not a local read goes to the
 *   review model, and the switch does not reach it.
 * - `full-access` — no wall, and nobody can be asked. The gate steps aside.
 */
export type AccessTier = 'walled' | 'auto-review' | 'full-access';
/**
 * Fold the two knobs into the tier that decides this call.
 * @param confined - whether the operating system confines file effects for this call.
 * @param policy - the effective approval policy for this call.
 * @returns the tier the call runs in.
 */
export declare function accessTier(confined: boolean, policy: ApprovalPolicy): AccessTier;
/** The id one session names the session it came from by, as the header spells it. */
type ParentSession = NonNullable<Agent['session']['header']['parentSession']>;
/**
 * The one member of `AgentRegistry` the lineage walk reads.
 *
 * Declared structurally for the reason {@link ApprovalPolicyReader} is: the
 * registry is optional in compositions this gate has to keep working in, and
 * `ctx.get` answers whatever is mounted under the name. `tests/policy.spec.ts`
 * pins it against the real registry type.
 */
export interface AgentLookup {
    /**
     * Look up a live agent by the id a child's header names it with.
     * @param id - the shared agent/session id.
     * @returns the agent, or `undefined` when no live agent has that id.
     */
    get(id: ParentSession): Agent | undefined;
}
/**
 * How the tier was reached, which is what a fail-closed derivation is
 * recognized by.
 *
 * - `own` — nobody delegated the calling session, so its own knobs decided.
 * - `root` — the call is delegated, and the session it came from decided.
 * - `unresolved` — the call is delegated and the lineage does not resolve, so
 *   no session's knobs decided; see {@link readTier}.
 */
export type TierLineage = 'own' | 'root' | 'unresolved';
/** Which tier decides a call, and whether a question about it can reach anyone. */
export interface TierState {
    /** The tier this call runs in. */
    readonly tier: AccessTier;
    /**
     * The approval policy the tier was folded from — the delegating session's
     * where the call is delegated. Absent where no session's policy decided the
     * tier, which is the `unresolved` lineage and nothing else.
     */
    readonly policy?: ApprovalPolicy;
    /** Whether the calling session was created as a subagent child (`header.origin`). */
    readonly delegated: boolean;
    /**
     * Whether an approval request raised for this call would reach a person: the
     * CALLING session's own effective policy is `ask`. A delegated child's is
     * pinned to `never` wherever the approval capability is composed, so this is
     * false for every in-process subagent call.
     */
    readonly humanReachable: boolean;
    /** How the tier was reached. */
    readonly lineage: TierLineage;
    /**
     * The parent session the walk stopped at; present only when
     * {@link TierState.lineage} is `unresolved`, and absent even there for a
     * delegated session whose header names no parent to stop at.
     */
    readonly unresolvedParent?: ParentSession;
}
/**
 * Read which tier decides one call, and whether a question about it can reach
 * anyone.
 *
 * A session nobody delegated — a root, or a fork a person opened — is read from
 * its own knobs, because those are the ones that person chose.
 *
 * An unresolvable delegation lineage is fail-closed on both answers: the tier
 * is folded as if a person could be asked, so a standing wall reads as `walled`
 * and no wall reads as `auto-review`; and nobody is reachable, so a question
 * about the call becomes a refusal rather than an approval request no one will
 * see. The alternative — reading the child's own pinned pair — is the
 * `full-access` tier, where this gate consults nothing at all. What each of the
 * two folded tiers then does is its own rule, the walled tier's review switch
 * included.
 * @param ctx - the plugin context; the approval service and the agent registry are read opportunistically through `ctx.get`.
 * @param agent - the calling agent, or `undefined` for a call made outside one.
 * @param confined - whether the operating system confines file effects for this call.
 * @returns the tier, what it was folded from, and whether anyone can be asked.
 */
export declare function readTier(ctx: Context, agent: Agent | undefined, confined: boolean): TierState;
export {};
//# sourceMappingURL=policy.d.ts.map