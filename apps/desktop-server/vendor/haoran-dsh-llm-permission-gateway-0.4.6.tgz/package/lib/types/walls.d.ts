/**
 * Which pending calls the operating system already confines, and the per-agent
 * notes that carry a confined call forward to the approval it may raise.
 *
 * The gate reviews what has no wall around it. A `bash` command under
 * `workspace-write` cannot write outside the workspace whatever the review
 * model thinks of it, and the one place that boundary bends — a sandbox
 * escalation — is a separate question answered in `./escalation.ts`. A
 * `run_code` program body has no such wall at all: it runs on a worker thread
 * inside the harness process, reaching `node:fs` and `node:child_process`
 * directly, so nothing but this gate stands between it and the machine.
 *
 * Turning the sandbox off (`danger-full-access`) removes every wall, and the
 * answer here becomes "nothing is confined" for every tool.
 * @module @haoran/dsh-llm-permission-gateway/walls
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
/**
 * Tools whose file effects the sandbox governs, so review adds no boundary
 * they do not already have.
 *
 * `bash` and `pwsh` run their subprocess under confined argv; `write`, `edit`,
 * and `str_replace_editor` go through the filesystem seam the same policy
 * covers; `terminal_open` confines the shell it spawns, and `terminal_send`
 * types into that already-confined shell.
 */
declare const DEFAULT_WALLED_TOOLS: readonly string[];
export { DEFAULT_WALLED_TOOLS };
/** What the two wall facts say about one call. */
export interface WallState {
    /**
     * The file-effect mode the policy service resolves for this call, absent
     * where no policy service is composed. Read independently of whether an
     * executor confines, so a record can say `danger-full-access` rather than
     * only "nothing confined".
     */
    readonly mode?: string;
    /** Whether the operating system actually confines file effects for this call. */
    readonly confined: boolean;
}
/**
 * Read both wall facts for one call.
 *
 * Two facts have to agree before anything is confined, because either alone can
 * be true while nothing is enforced. The policy service answers what mode a
 * call would run under; the mounted shell executor answers whether any executor
 * confines at all — its base class returns `undefined`, and
 * `@deepseek-ai/dsh-permission-presets` treats that same `undefined` as a
 * misconfiguration for exactly this reason.
 *
 * Every unknown reads as "no wall". A gate that skipped review on a boundary it
 * cannot see would be trusting a wall that may not be there.
 * @param ctx - the plugin context; both services are read opportunistically through `ctx.get`.
 * @param agent - the calling agent, whose session carries any per-session mode override.
 * @returns the resolved mode where one is readable, and whether file effects are confined.
 */
export declare function readWalls(ctx: Context, agent: Agent | undefined): WallState;
/**
 * Whether the operating system currently confines file effects for this
 * agent's calls.
 * @param ctx - the plugin context; both services are read opportunistically through `ctx.get`.
 * @param agent - the calling agent, whose session carries any per-session mode override.
 * @returns true while an executor confines and the resolved mode is `read-only` or `workspace-write`.
 */
export declare function sandboxConfines(ctx: Context, agent: Agent | undefined): boolean;
/** Which skip, if any, answers a call before the size cap, the cache, and the model. */
export type SkipStep = 'readOnly' | 'walled';
/**
 * The one implementation of the skip rule, so the running gate and any offline
 * replay of a decision record read the same lists in the same order.
 * @param tool - the tool about to run.
 * @param readOnlyTools - tools passed through because their effects are local reads or a prompt.
 * @param walledTools - tools the sandbox confines.
 * @param confined - whether the sandbox confines file effects for this call.
 * @returns the skip that answers, or `undefined` when the call is reviewed.
 */
export declare function skipStep(tool: string, readOnlyTools: ReadonlySet<string>, walledTools: ReadonlySet<string>, confined: boolean): SkipStep | undefined;
/**
 * Per-agent notes kept against a call id until the approval that may follow it.
 *
 * An approval request carries a tool name, a call id, and one sentence of free
 * text — deliberately, since the arguments were already logged and presented at
 * the call. Two notes bridge that gap: what a confined call actually asked for,
 * and whether an `ask` under this call id is this gate's own question.
 *
 * **The agent is part of the key, not just the call id.** A call id is unique
 * inside one agent and nowhere else: two sessions, or a session and a subagent,
 * routinely mint the same string. Keying on the call id alone would let one
 * session's remembered command answer another session's escalation, so the
 * store buckets by the agent object — a `WeakMap`, so a bucket vanishes with
 * the agent that owns it — and falls back to one shared bucket only for calls
 * made outside an agent, which have no session to be confused with.
 */
export declare class CallNotes<T> {
    private readonly limit;
    private readonly perAgent;
    private readonly agentless;
    /** @param limit - how many calls one agent may hold; `0` remembers none. */
    constructor(limit: number);
    /** The bucket owning one agent's notes, created on first use. */
    private bucket;
    /**
     * Remember one note, evicting that agent's oldest at the limit.
     * @param agent - the agent the call belongs to; `undefined` for an agentless call.
     * @param callId - the registry call id the approval will name.
     * @param note - the value to keep.
     */
    remember(agent: object | undefined, callId: string, note: T): void;
    /**
     * Read back one call's note.
     * @param agent - the agent the approval names; `undefined` for an agentless call.
     * @param callId - the call id named by the approval request.
     * @returns the remembered note, or `undefined` when this agent did not remember that call.
     */
    recall(agent: object | undefined, callId: string): T | undefined;
    /**
     * Drop one call's note.
     * @param agent - the agent the call belongs to; `undefined` for an agentless call.
     * @param callId - the call id whose note is spent.
     */
    forget(agent: object | undefined, callId: string): void;
}
/**
 * How many live asks one agent may hold in the self-recognition store.
 *
 * Fixed rather than configurable, and deliberately not `cacheEntries`: an entry
 * lives only from the moment this gate returns an `ask` to the moment the call
 * settles, so the live count is the number of approvals open at once. A
 * deployment that could set this to zero could switch off the guard that keeps
 * the escalation answerer from granting this gate's own question.
 */
export declare const OWN_ASK_LIMIT = 512;
/** Identity and arguments of one confined call, kept for the escalation it may raise. */
export interface RememberedCall {
    /** The tool that was called, checked against the tool the approval names. */
    readonly tool: string;
    /** The parsed, deep-frozen call arguments. */
    readonly arguments: unknown;
}
//# sourceMappingURL=walls.d.ts.map