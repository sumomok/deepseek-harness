/**
 * The two denials this gateway makes without consulting the review model and
 * without consulting its own configuration.
 *
 * They exist because a gate whose every decision is delegated has a single
 * point of failure: persuade or degrade the reviewer and the gate opens. These
 * two run first of everything this gate does, on every tool call it decides,
 * and no `Config` field can reach them — that is their whole purpose, so
 * nothing here may become configurable. The one state they do not run in is the
 * `full-access` access tier, where the person has selected a mode whose meaning
 * is that this gate does not decide the call at all.
 *
 * Detection is deliberately narrow. A red line reports only argument text that
 * has no plausible benign reading; everything subtler is left to the review
 * model, which is separately instructed that these two categories are never
 * allowable. Both layers deny; neither can override the other into an allow.
 *
 * Narrow means narrow on both sides of the credential line: USING a key is not
 * READING one. `ssh -i ~/.ssh/id_ed25519 host '…'` hands the path to the client
 * that signs with it, and the bytes never leave the machine — a refusal there
 * costs every ordinary remote command and buys nothing.
 * @module @haoran/dsh-llm-permission-gateway/redline
 */
/** The two categories. A third would need a new release, not a new config key. */
export type RedLine = 'credential-exfiltration' | 'permission-self-modification';
/** One red-line match, carrying the user-facing cost statement for the denial. */
export interface RedLineHit {
    /** Which category matched. */
    readonly line: RedLine;
    /** What running the call would cost, in the words the user sees. */
    readonly reason: string;
}
/**
 * The filesystem locations whose modification would disable or reconfigure this
 * gateway, resolved once at plugin load from the running installation rather
 * than written down as literals.
 */
export interface ProtectedTargets {
    /** Directories and files whose subtree is off limits. */
    readonly paths: readonly string[];
    /** Additional text forms of those locations (`~/.dsh/profiles`, `$DSH_HOME/...`, the package name). */
    readonly literals: readonly string[];
}
/**
 * Resolve the protected locations for the running installation.
 *
 * The set is fixed: this package's own directory, and the two places a profile
 * is composed from. The decision record is deliberately NOT in it — guarding
 * it meant reading `Config.verdictLog`, which made a configuration field decide
 * what the red line covers, in both directions: pointing it at the harness home
 * put every session log behind an unconditional refusal, and `false` removed
 * the guard altogether. The record's own module states what protects it instead.
 * @returns the paths and literal text forms the self-modification red line guards.
 */
export declare function resolveProtectedTargets(): ProtectedTargets;
/**
 * Classify one pending call against both red lines.
 *
 * Ordering is significant: this runs before the read-only skip list, before
 * `alwaysAsk`, before the review switch, and before the review model, so no
 * configuration choice and no model answer can route a call around it. The one
 * thing ahead of it is the access tier, because `full-access` is the person
 * having asked for no gate at all.
 * @param args - the parsed, deep-frozen call arguments.
 * @param targets - the protected locations from {@link resolveProtectedTargets}.
 * @returns the matching red line, or `undefined` when neither applies.
 */
export declare function detectRedLine(args: unknown, targets: ProtectedTargets): RedLineHit | undefined;
//# sourceMappingURL=redline.d.ts.map