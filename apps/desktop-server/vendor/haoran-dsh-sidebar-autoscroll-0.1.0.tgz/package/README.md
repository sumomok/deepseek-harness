# @haoran/dsh-sidebar-autoscroll

English | [中文](README.zh.md)

Scroll the sidebar session tree to the conversation on screen whenever the chat composer gets focus.

## What it does

A workspace can hold far more sessions than the sidebar shows at once, and the one you are talking to is often scrolled out of sight. When focus enters the chat composer — you click into it, or the client restores it as a session opens — this plugin scrolls the session list the minimum needed to reveal the row of the Session the main view is currently showing: the row the browser already marks as current.

One scroll per focus acquisition. The plugin never listens to scrolling, never re-scrolls while you read the tree, and leaves a row that is already visible untouched: the call is `scrollIntoView({ block: 'nearest' })`, the same one the tree uses for its own search reveal. It selects nothing, writes no Session data, and keeps no state between calls.

## Where it hooks in

No fork patch and no harness change: the plugin reads two surfaces the client packages already render, plus one public service.

- **The selected Session** comes from the public `sessions` service: the row whose `retainedBy` reports the `mainView` reference source is the one the conversation shell is displaying, and ui-workspace derives its highlighted row from the same count. The plugin reads that count, not the DOM's selection state.
- **The focus trigger** is the document's own `focusin` event, accepted when its target sits inside `[data-composer-input]` — the attribute the composer's editable host writes and the Web GUI's own test suites drive the composer through. Moving focus inside the composer does not re-trigger it.
- **The target row** is the element keyed `data-row-key="session:<id>"`, which ui-workspace writes for every rendered Session row under the AnimatedRows list contract.

There is no public service or event for "the composer got focus" — the input API exposes only the write side, `SessionInput.focus()` — so focus is observed at the document instead of by patching the editor. Nothing is monkey-patched, no module of another package is imported at runtime, and the browser half requests no shared shell module at all.

## When it does nothing

Silently, by design — no toast, no notice, no console output:

- no Session is retained by the main view yet (the new-session surface, a list still arriving, or the centre showing another panel instead of the conversation);
- the selected row is not rendered — a collapsed Workspace group, the collapsed rail layout, a Session hidden behind its group's watermark, or a search result list;
- the composer already had focus, so the focus move happened inside it.

## Limits

- Both DOM attributes are written by client packages rather than by a versioned public contract. If either is renamed, this plugin stops scrolling and nothing else changes; the `data-row-key` list contract is documented in ui-primitives' README, and `data-composer-input` is what the Web GUI's end-to-end suites select the composer by.
- The reveal runs when focus moves. On a list that is still playing its first entry animation the row's position may settle slightly afterwards; the scroll uses the layout at that moment.
- Programmatic focus counts: on desktop the composer is focused automatically when a Session opens, and that also triggers one reveal. The tree then follows the conversation without a click.
- The desktop application and the Web build share the same client, so the plugin works in both; it does nothing where no composer is rendered.

## Install

Desktop-internal; not published to npm. Pack a tarball (`pnpm pack`) and install it into a profile the same way any local plugin is vendored.
