/**
 * Browser half of @haoran/dsh-sidebar-autoscroll: when keyboard focus enters
 * the chat composer, scroll the sidebar session tree to the row of the Session
 * the main conversation view currently shows.
 *
 * The plugin registers no slot, no store, and no service. The trigger is the
 * document's own `focusin` event and the target is a row the workspace browser
 * already rendered, so nothing is added to the page and no state is written
 * (see `autoscroll.ts` for the two client-owned surfaces it reads).
 *
 * @module @haoran/dsh-sidebar-autoscroll/client
 */
import type { Context } from '@deepseek-ai/cordis';
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * Install the composer-focus reveal for the lifetime of the plugin.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map