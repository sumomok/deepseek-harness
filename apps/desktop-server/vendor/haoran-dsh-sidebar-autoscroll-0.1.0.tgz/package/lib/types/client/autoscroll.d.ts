/**
 * Focus-triggered reveal of the sidebar's selected Session row.
 *
 * The trigger and the target are both surfaces the client packages own and
 * this plugin only reads:
 *
 * - focus entering a chat composer, observed as the document's `focusin`
 *   event whose target sits inside `[data-composer-input]` — the attribute
 *   the composer's editable host writes and the GUI suites drive the composer
 *   through;
 * - the rendered Session row, keyed `data-row-key="session:<id>"` by
 *   ui-workspace under the AnimatedRows list contract.
 *
 * The selected Session itself comes from the public `sessions` service
 * (`selectedSessionId`), never from reading the DOM's selection state, so a
 * row the tree is not currently rendering is simply absent and the reveal
 * does nothing.
 *
 * Nothing here selects a Session, writes Session data, or touches tree state:
 * one `scrollIntoView({ block: 'nearest' })` per focus acquisition, which is
 * also what the tree's own search reveal calls.
 *
 * @module @haoran/dsh-sidebar-autoscroll/client/autoscroll
 */
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client';
/** The slice of the `sessions` service the reveal reads. */
export type SessionsSource = Pick<ISessions, 'list'>;
/** What the reveal needs from the page and from the Session list. */
export interface SidebarAutoscrollOptions {
    /** Session list whose `mainView` retention names the selected Session. */
    readonly sessions: SessionsSource;
    /** Document that owns the composer and the sidebar session tree. */
    readonly document: Document;
    /** Scroll primitive; the browser's `scrollIntoView` unless a test replaces it. */
    readonly scrollIntoView?: (row: Element) => void;
}
/** An installed reveal. */
export interface SidebarAutoscroll {
    /** Remove the focus listener; safe to call more than once. */
    dispose(): void;
}
/**
 * Install the composer-focus reveal.
 * @param options - Session list, owning document, and optional scroll primitive.
 * @returns the installed listener and its disposer.
 */
export declare function installSidebarAutoscroll(options: SidebarAutoscrollOptions): SidebarAutoscroll;
//# sourceMappingURL=autoscroll.d.ts.map