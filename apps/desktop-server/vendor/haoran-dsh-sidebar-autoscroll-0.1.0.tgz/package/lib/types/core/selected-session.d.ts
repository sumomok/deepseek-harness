/**
 * Which Session the main view is showing, read from the public Session list.
 *
 * The list carries one reference count per consumer (`retainedBy`). The
 * conversation shell retains the Session it displays under the `mainView`
 * source, and ui-workspace derives its highlighted row from that same count —
 * this module names the rule for consumers outside the client packages, and
 * adds no second notion of "selected".
 *
 * @module @haoran/dsh-sidebar-autoscroll/core/selected-session
 */
import type { SessionListState } from '@deepseek-ai/dsh-api-session-controller/client';
/**
 * Identity of the Session the main view currently retains.
 * @param state - one Session list snapshot (`sessions.list.getSnapshot()`).
 * @returns the selected Session identity, or `undefined` while the main view holds none.
 */
export declare function selectedSessionId(state: SessionListState): string | undefined;
//# sourceMappingURL=selected-session.d.ts.map