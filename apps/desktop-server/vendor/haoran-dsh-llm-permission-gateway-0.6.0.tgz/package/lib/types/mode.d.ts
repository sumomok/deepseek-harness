/**
 * The four fields of this plugin's profile entry a person changes — whether the
 * walled access modes are reviewed as well, and the route the review model is
 * reached on — and the slash command that throws that switch.
 *
 * The switch is this plugin's own state rather than a fifth permission preset
 * because it is orthogonal to the access modes: it answers "also review where a
 * wall already stands", which is a yes/no over two of the rows rather than a
 * row of its own. The row this plugin does contribute names the tier whose
 * behaviour IS the review, and that tier does not read this switch.
 *
 * All four are volatile Config fields of the entry the bundle inserts. The
 * settings page and `/review` write them through the settings service into
 * `$DSH_HOME/profiles/<profile>/cordis.patch.yml`, and the Loader commits the
 * new values into the references this module reads without reloading the
 * plugin. Every read goes to the reference at the moment of the read, so a
 * choice decides the next call. Where no settings service or no profile entry
 * is composed, `/review` holds its change for the process instead, and
 * `persists` is what the command's own text reports.
 * @module @haoran/dsh-llm-permission-gateway/mode
 */
import type { Context, Volatile } from '@deepseek-ai/cordis';
import type { JudgeRoute } from './judge.ts';
/**
 * The two words `/review` takes, which say what to do with
 * {@link GatewaySettings.walledReview}.
 *
 * `manual` is not "no gate": the two red lines and `alwaysAsk` run either way,
 * and everything else falls through to whatever the harness itself would have
 * done — the sandbox, and a human at the approval prompt. It also reaches only
 * the walled tier: the access mode whose stated behaviour is the review reviews
 * every call under both values, and the one that asks nobody reads neither.
 */
export type ReviewMode = 'auto' | 'manual';
/** The command name, without its leading slash. */
export declare const REVIEW_COMMAND = "review";
/**
 * The four person-changeable fields of this plugin's profile entry, as values.
 * The browser half reads and writes them as the entry's settings form; the host
 * half reads them from {@link GatewayLive}.
 */
export interface GatewaySettings {
    /**
     * Whether the two walled access modes are reviewed as well. `false` is what a
     * fresh installation answers.
     */
    walledReview: boolean;
    /**
     * Provider route reviews run on: `deepseek-official` where the person picked
     * none. Written together with {@link GatewaySettings.judgeModel}. A stored
     * `''` reads as not stored and takes that default (`judgeRouteOf`).
     */
    judgeProvider: string;
    /** Model id reviews run on: `deepseek-flash` where the person picked none; a stored `''` reads the same way. */
    judgeModel: string;
    /**
     * Reasoning effort the user picked for the review model, or `''` to be
     * reviewed at the effort the composition configured.
     *
     * The id belongs to the provider that defines it and is meaningful only for
     * the model that offers it, so it is checked against that model's own list
     * before it is issued; an id the model does not offer is reported once and
     * the configured effort is used instead.
     */
    judgeReasoningEffort: string;
}
/**
 * The same four fields as the Loader hands them to `apply`: references whose
 * value the Loader replaces after a settings write, without reloading the
 * plugin.
 */
export type GatewayLive = {
    readonly [K in keyof GatewaySettings]: Volatile<GatewaySettings[K]>;
};
/** Reads the four fields this plugin's entry carries, and writes the switch. */
export interface GatewayStore {
    /** Whether the two walled access modes are reviewed as well, right now. */
    walledReview(): boolean;
    /** Whether a change is stored in the profile, which is where it survives a restart. */
    persists(): boolean;
    /**
     * Change whether the two walled access modes are reviewed as well: through
     * the settings service into this plugin's profile entry where both are
     * composed, and for the process otherwise.
     * @param next - true to review them too.
     * @throws When the settings service refuses the write; the switch is then unchanged.
     */
    setWalledReview(next: boolean): Promise<void>;
    /** The route the next review is issued on, settled afresh on every call. */
    route(): JudgeRoute;
    /**
     * Forget which reasoning efforts each model was found to offer, after a
     * change that can move which adapter answers for a route.
     */
    dropEffortChecks(): void;
    /**
     * Observe changes to the route {@link GatewayStore.route} answers with.
     * @param listener - invoked after the Loader committed a change to the provider, the model, or the effort.
     * @returns the disposer removing this listener.
     */
    onRouteChange(listener: () => void): () => void;
}
/**
 * Create the store the gate, the command, and the record read the four fields
 * through.
 *
 * The references are the Loader's: a settings write commits the new values into
 * them and then emits `loader/volatile-update` with the changed paths, which is
 * where a change of reviewer is announced. The first import of an old
 * `settings.yaml` writes through the same path, so a route it carries is
 * announced the same way.
 * @param ctx - the plugin context.
 * @param live - the four volatile fields of this plugin's Config.
 * @param fallback - the route from the plugin's own config, reviewed on wherever the fields name none.
 * @returns the store the gate, the command, and the record all read.
 */
export declare function createGatewayStore(ctx: Context, live: GatewayLive, fallback: JudgeRoute): GatewayStore;
/**
 * Register the `/review` command where a commands registry is mounted.
 * @param ctx - the plugin context.
 * @param store - the settings store the command reads and writes.
 */
export declare function applyReviewCommand(ctx: Context, store: GatewayStore): void;
//# sourceMappingURL=mode.d.ts.map