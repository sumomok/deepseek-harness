# @haoran/dsh-auto-compact

English | [中文](README.zh.md)

Compact the conversation before it runs out of room, at a point you choose. A row appears in Settings under **General** with a switch and a slider: turn it on, drag it to the share of the context window you want, and whenever the next model request would go past that share, the conversation is condensed first and the work carries on.

## What you set, and what it does

| Control | Range | What it means |
| --- | --- | --- |
| The switch | on / off | Whether the conversation is condensed on its own at all |
| The slider | 20%–95%, in steps of 5 | The share of the context window that, once the next request would exceed it, condenses the conversation before that request. Steps of 5 are the slider's; the entry accepts any whole number from 20 to 95 |

The percentage is read the same way as the usage ring beside the message box. That ring is the one figure you have already watched climb, and the slider is where you say how far you are willing to let it climb.

One value, for everything. There is no per-conversation override and no per-model one: it is a preference about how you like to work, not a property of any one conversation.

**Turning the switch off does not turn off compaction.** It turns off compacting *early*. When a conversation will not fit at all, the harness still recovers on its own — that is its floor, and this plugin can neither raise nor lower it. What the switch decides is whether anything happens before that point.

## When it happens

Between two steps of a turn: after the previous step's tool results are recorded and before the next model request goes out. Nothing is streaming and no tool is running at that moment, so nothing is interrupted; the turn continues from the condensed conversation. No compaction follows a turn's last reply, because the loop proposes no further step there. A step proposed and then not entered — another plugin refuses it, or its input is rewritten to nothing — can still be preceded by a compaction; that summary is then read by the next request.

While it runs, the conversation shows a **Compacting context…** row, replaced by **Context compacted** with the item and token counts once the summary lands (desktop rc.33 on); from desktop rc.34 on that row stands outside the collapsed process group, so a collapsed group does not hide it. **Stop works during it**: the summary is cancelled, the row disappears, and the turn ends as stopped. One narrow exception: a Stop that lands after the compaction has started but before the summary request is sent is shown as a failure notice, as it is for the harness's own compaction.

**Sub-conversations a task delegated are compacted too**, each in its own steps. A task waiting on a delegated conversation in the foreground waits one summary longer when that conversation compacts; in exchange a long delegated task stays clear of the window's edge instead of being rescued at it.

**A failed attempt is not repeated within the same turn.** The harness's own between-steps compaction tries again at every following step, so a summarising model that is down produces one failure per step for as long as the turn runs. This plugin switches that path off and compacts at the same moment itself, and when an attempt fails for any reason other than Stop, that conversation is not asked again until its next turn: at most one failed attempt per conversation per turn. A routed model with no usable context capacity fails the same way every turn, so this plugin logs it once per conversation. A parent conversation and its delegated sub-conversations back off independently.

## What it condenses

The oldest part of the conversation. The compaction is the harness's own pressure compaction: it first trims oversized tool results, then summarises the history before a retained tail and keeps that tail word for word. With the compaction backend's defaults the tail is 16% of the model's message budget (the context window minus the output the request reserves), set by the backend's `retainRatio` and `retainTokens`, not by this plugin. If one summary does not bring the conversation under your share the backend tries once more (`compactionRetries`, default 1) and then reports the attempt as failed.

The trigger point is the smaller of your share of the window and the window minus the reserved output minus the backend's `headroomTokens` (default 65 536), so on a model with a small window it can fire below the share you set.

## What it is not

It does not measure the context window and it does not write the summary. Whether the conversation is over your share, how much it keeps, and how it summarises are all the compaction backend's, performed through its published `compactIfNeeded` method; the backend reads your share from the service this plugin publishes. What this plugin owns is the switch, the percentage, and whether a given step may ask.

It does not report a compaction that went wrong in the chat itself: a compaction that fails after it started — the summary request fails, for example — is shown by the harness's own failure notice. A failure before it started (the routed model's details cannot be read, or the model has no usable context capacity), or a conversation still above the share after the backend's last attempt, shows nothing in the chat and is only written to this plugin's log. The first request of a new conversation is never preceded by a compaction — the backend has no routed request to price yet.

Its own log lines go through the logger named `auto-compact`. Where those lines are written is up to the host.

## Where it works, and where it does nothing

The row takes `settings.general.item`, the seat the Settings **General** page stacks one preference per row in, at order 21: after the conversation preferences, before the version row. It is registered only while the Host's settings service serves this plugin's entry (`ctx.configForms.whileServed`), so an entry that failed to mount, was turned off, or runs where nothing serves settings leaves no empty row. A build whose settings page has no General page never declares the slot, and then this plugin registers no interface at all. Nothing is version-checked: the declaration is the detection.

The host half reads its own volatile Config on every use. It tells the settings service it draws its own row (`configure({ auto: false })`), so no generated page duplicates it; without a settings service it simply answers the profile's own values and nothing in the page can change them.

**The engine is found per conversation, not once at load.** A preset publishes `compaction` behind an `isolate` realm, which is invisible to the host plane this plugin is mounted on — the shipped desktop profile disables the compaction backend on the host and mounts it inside every preset. So the engine is resolved through `agentPresets.serviceFor(agent, 'compaction')` before every step, falling back to a plain host-plane read for a composition that mounts it there; every conversation, a delegated one included, has its own engine inside its preset. Where neither answers, this plugin says so in the host log once for that conversation and compacts nothing in it.

The policy itself is coarser than that, and deliberately: it takes no conversation, so it reports one answer for the whole process. It keeps reporting the harness's own behaviour until an engine is reached for *some* conversation, and reports `false` from then on. So a composition where every conversation has an engine is fully covered, and a conversation that has none inside a composition that mostly does gets neither path — the host log line is the only notice, and there is no engine there to have compacted it anyway.

## The service it publishes

Under the Cordis service key `compactionPolicy`:

| Method | Answer |
| --- | --- |
| `isEnabled()` | `false` once this plugin has found an engine to compact with for some conversation; `true` — the harness's own behaviour — while it has found none |
| `thresholdRatio()` | The share of the context window, 0–1, the backend compacts at, read live from the entry's Config |

The switch in Settings is *not* what `isEnabled()` returns. It decides whether this plugin asks the backend at a step, and it is read there. `isEnabled()` answers one question only: whether the backend's own between-steps listener should stand down because this plugin now covers the same moment. The two are coupled on purpose — a `false` returned before any engine was found would be a composition that never compacts at all.

The backend reads `thresholdRatio()` each time this plugin asks it to compact, so a share saved in Settings applies from the next step.

## Profile entry and the one-time import

The entry id is `auto-compact`, and both fields are volatile: the settings service edits them in place, writes the changed fields into the profile's own `cordis.patch.yml`, and the Loader hands the new value to the running plugin without a remount.

| Field | Type | Default |
| --- | --- | --- |
| `enabled` | boolean | `true` |
| `thresholdPercent` | whole number, 20–95 | `60` |

A value outside those bounds is refused at the save that produced it, and the value in force stays. The first launch on a `0.1.7` base imports the `auto-compact` section that versions up to 0.2.4 wrote into `$DSH_HOME/settings.yaml` into this entry once — the entry id is that section name — and renames the file to `settings.yaml.imported`. From then on, a field that was imported or saved is fixed in the profile for that person, and a new default shipped in this package reaches only people who never changed that field.

## Configuration

The bundle row carries no `config`: both defaults live in the plugin's schema, so a save writes only the fields a person actually changed. A profile that wants different starting values writes them on its own id-targeted row:

```yaml
- id: auto-compact
  config:
    enabled: true
    thresholdPercent: 60
```

## Compatibility

Built against the `0.1.7-rc.2` harness base; every `@deepseek-ai/dsh-*` peer range is `>=0.1.7-rc.1 <0.2.0-0`, which the harness's plugin compatibility check admits on `0.1.7-rc.x`, `0.1.7`, and later `0.1.x` releases. It needs the settings layer of that base (`ctx.configForms`, volatile Config fields) and reads the preset roster through `@deepseek-ai/dsh-agent-preset-registry`, which replaced `@deepseek-ai/dsh-agent-presets`.

## Install

```sh
dsh plugin --profile <name> add <path-or-tarball>
```
