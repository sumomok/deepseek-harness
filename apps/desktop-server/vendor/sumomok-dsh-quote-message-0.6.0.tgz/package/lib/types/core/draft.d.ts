/**
 * Where a pill-inserted chip lands in the draft.
 *
 * The `@` picker needs none of this — the trigger pipeline hands the source
 * the span of the `@` token it replaces. The selection pill has no such span:
 * it fires while the user is reading the chat, so it takes the composer's own
 * insertion point from the session's input actions.
 *
 * @module @sumomok/dsh-quote-message/core/draft
 */
/** A span in the composer's own coordinates, guarded by the draft revision it was read at. */
export interface CapturedSpan {
    readonly start: number;
    readonly end: number;
    readonly draftRev: number;
}
/**
 * Resolve the insertion span for one pill-inserted chip: the end of the
 * composer's captured selection, zero-width.
 *
 * The capture is `inputActions.captureInsertion()`: the editor's last
 * selection, or the end of the document when the editor never had one. Its
 * offsets are the editor's own coordinates, where an inline chip counts as one
 * position. `InputState.draft` is the clipboard text, where a chip counts as
 * its full text, so an offset read off `draft` lies past the end of the
 * document as soon as it holds a chip, and the input machine refuses the
 * insert. Collapsing to the end keeps text the user selected in the composer
 * instead of replacing it with the chip.
 * @param captured - the span `captureInsertion()` returned at click time.
 * @returns the zero-width span the reference is inserted at, with the same revision guard.
 */
export declare function quoteInsertSpan(captured: CapturedSpan): CapturedSpan;
//# sourceMappingURL=draft.d.ts.map