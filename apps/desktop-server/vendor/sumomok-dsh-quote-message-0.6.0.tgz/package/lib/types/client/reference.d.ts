/**
 * The chip: how one quote becomes a `ReferenceInsert` the host's own
 * reference path can seat, and how it reaches a session's composer from
 * outside the trigger pipeline.
 *
 * @module @sumomok/dsh-quote-message/client/reference
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { ReferenceInsert } from '@deepseek-ai/dsh-client-ui-input-trigger/client';
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import { type CapturedSpan } from '../core/draft.ts';
import { type QuotePayload } from '../core/quote.ts';
import type { QuoteKey } from './locales.ts';
/**
 * Source name of the `@message` picker. It is also the serializer routing key
 * the host stores on every occurrence, so it must stay stable: a chip in a
 * draft is expanded by looking this name up in the source roster.
 */
export declare const QUOTE_SOURCE_NAME = "message";
/** How many characters of the quoted text the chip label keeps before an ellipsis. */
export declare const CHIP_EXCERPT_CHARS = 12;
/**
 * Shortest excerpt worth using as a label. A shorter quote is named by its
 * position and role instead: two or three characters say less about the
 * passage than the number does, and a nearly empty label reads as a glitch.
 */
export declare const CHIP_EXCERPT_MIN_CHARS = 4;
/**
 * The beginning of the quoted text, as a chip label carries it.
 *
 * Whitespace — line breaks, tabs, runs of spaces — collapses to one space, so
 * every line the person selected still fits on the chip's one line. The cut
 * counts code points, not UTF-16 units, so a label never ends inside a
 * surrogate pair.
 * @param text - the quoted text.
 * @returns the excerpt capped to {@link CHIP_EXCERPT_CHARS} with `…` when cut,
 *   or `undefined` when the text is emptier than {@link CHIP_EXCERPT_MIN_CHARS}
 *   and the positional label should be used instead.
 */
export declare function chipExcerpt(text: string): string | undefined;
/**
 * Inline label cached on the occurrence: the beginning of the quoted text
 * (`引用：今天下午的…` / `Quote: The quarterly…`), or the positional
 * `引用 #12 助手` / `Quote #12 assistant` when the text is too short to name
 * the passage or carries no source position at all. The draft shows the label
 * after the `@` glyph.
 * @param payload - the quote payload.
 * @param t - bound translate for this plugin's namespace.
 * @returns the chip label.
 */
export declare function chipLabel(payload: QuotePayload, t: Translate<QuoteKey>): string;
/**
 * Build the reference insert for one quote.
 *
 * `appearance` is `session` — the closest of the three the host's chip
 * renderer knows (session / file / folder), and a quote does point at a
 * message in the current session. It is not decoration: an entry without an
 * appearance renders a bare `@` where every first-party chip renders a domain
 * glyph, so the quote chip would be the one reference in the composer that
 * does not look like a reference.
 * @param payload - the quote payload (the chip carries the text itself).
 * @param label - inline label from {@link chipLabel}.
 * @param clipboardText - the block a copy of the draft carries.
 * @returns the insert the input machine seats as one occurrence.
 */
export declare function quoteReference(payload: QuotePayload, label: string, clipboardText: string): ReferenceInsert;
/**
 * Seat one chip in a session's composer without going through the trigger
 * pipeline (the selection pill's path). The position is the composer's captured
 * insertion point, collapsed by {@link quoteInsertSpan}; its `draftRev` is the
 * machine's CAS guard, so a draft that changed between the click and the
 * dispatch is left alone.
 * @param ctx - the plugin's client root context.
 * @param sessionId - session whose composer receives the chip.
 * @param reference - the insert from {@link quoteReference}.
 * @param captured - `inputActions.captureInsertion()` read at click time.
 * @returns whether the input machine applied it (false = stale draft, or no live scope).
 */
export declare function insertQuoteReference(ctx: Context, sessionId: SessionId, reference: ReferenceInsert, captured: CapturedSpan): boolean;
//# sourceMappingURL=reference.d.ts.map