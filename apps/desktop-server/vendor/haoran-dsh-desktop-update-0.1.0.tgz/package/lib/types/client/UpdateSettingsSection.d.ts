/**
 * The Settings page: which version is running, which one is published, what
 * changed in it, how far the download has got, and the one button that
 * restarts into it.
 *
 * **This is the only place download progress appears.** A transfer nobody
 * asked to watch has no business taking a seat in the sidebar or the chat, so
 * the page is where it lives and the page is where it stays. Outside it, the
 * only thing this plugin ever shows is the ready button, and only once a
 * version is on disk.
 *
 * Pressing restart-and-install restarts the application. The press is the
 * consent; nothing here asks again.
 *
 * @module @haoran/dsh-desktop-update/client/UpdateSettingsSection
 */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { UpdateStoreState } from './store.ts';
/** Registration-side dependencies of {@link UpdateSettingsSection}. */
export interface UpdateSettingsSectionInjected {
    hooks: {
        /** The browser half's own store. */
        update: HostObservable<UpdateStoreState>;
    };
    /** Ask the application to look for a newer version. */
    check: () => void;
    /** Ask the application to fetch the version the last check found. */
    download: () => void;
    /** Ask the application to restart into the downloaded version. */
    install: () => void;
    /**
     * Report this page's presence on screen, which is what the fast polling
     * cadence follows.
     */
    setOpen: (open: boolean) => void;
}
/** Full component props. */
export type UpdateSettingsSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'desktopUpdate'> & InjectFace<UpdateSettingsSectionInjected>;
/**
 * The registered settings section.
 * @param props - the framework standard kit plus this plugin's store and commands.
 * @returns the page.
 */
export declare function UpdateSettingsSection(props: UpdateSettingsSectionProps): ReactNode;
//# sourceMappingURL=UpdateSettingsSection.d.ts.map