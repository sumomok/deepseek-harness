/**
 * The Kimi For Coding member of the adapter registry: resolves the connection
 * facts a subscription-quota read needs ({@link file://./kimi-usage.ts}).
 *
 * Kimi For Coding does not ship as a dedicated harness LLM provider plugin the
 * way DeepSeek does; it is a pi-ai catalog entry (`kimi-coding`). So — like the
 * Moonshot named adapter, and unlike the DeepSeek adapter's hardcoded settings
 * namespace — whether the provider is configured is found through `ctx.llm`'s
 * configurable-provider directory ({@link file://./custom-provider.ts}'s
 * `findConfigurableEntry`). What makes this a *named* adapter is the quota
 * endpoint and its default credential reference: the subscription key
 * (`sk-kimi-*`) the Kimi CLI itself uses, read from `KIMI_CODING_API_KEY` when
 * the profile names no `apiKeyEnv`.
 *
 * The quota endpoint is Kimi's own fixed coding-plan usage route, not the chat
 * base URL a `kimi-coding` model is called at — a configured base URL points
 * the model's own requests somewhere and says nothing about where the usage
 * route lives, so this adapter does not read it. The route is fixed, so it is a
 * constant here rather than configuration.
 *
 * @module @sumomok/dsh-balance/kimi-adapter
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ResolvedConfig } from './config.ts';
import { type KimiUsageRequest } from './kimi-usage.ts';
export { KIMI_CODING_PROVIDER_ID } from './provider-id.ts';
/**
 * Build the resolver the balance reader calls before every read.
 *
 * Connection facts are re-read per call and the key is resolved per call,
 * matching the other named adapters' resolvers: a key rotated through the
 * Models page reaches the next poll without restarting anything.
 * @param ctx - the plugin context.
 * @param config - the resolved plugin config.
 * @returns a resolver yielding the next read's facts, or `null` while unconfigured.
 */
export declare function kimiProviderResolver(ctx: Context, config: ResolvedConfig): () => Promise<KimiUsageRequest | null>;
//# sourceMappingURL=kimi-adapter.d.ts.map