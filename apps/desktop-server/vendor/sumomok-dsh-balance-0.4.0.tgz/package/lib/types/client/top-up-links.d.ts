/**
 * Where each provider this plugin has a named adapter for takes a top-up.
 *
 * **This table is maintained by hand and re-checked at every release.** These
 * are console pages, not an API: a provider can move, rename, or retire one
 * without any signal this plugin could read, and every entry below was opened
 * and confirmed against the provider's own console routing or documentation
 * before it was written down. Nothing here is derived from a base URL.
 *
 * Last re-checked: 2026-09-03.
 *
 * A provider absent from the table shows no button. That is every custom
 * gateway a deployment configures itself: its billing page is not something
 * this plugin can know, and guessing one from the API origin would send the
 * user somewhere arbitrary.
 *
 * @module @sumomok/dsh-balance/client/top-up-links
 */
/**
 * Top-up page per provider id, keyed by the ids this plugin's named adapters
 * serve. Addresses are the canonical ones a provider's own console settles
 * on, so opening one costs no redirect.
 */
export declare const TOP_UP_LINKS: ReadonlyMap<string, string>;
/**
 * The top-up page for one provider.
 * @param provider - provider route id.
 * @returns the page's address, or `undefined` for a provider this table does
 * not name, which renders no button.
 */
export declare function topUpLinkFor(provider: string): string | undefined;
//# sourceMappingURL=top-up-links.d.ts.map