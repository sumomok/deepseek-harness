/**
 * The spend ledger: one line per priced LLM request, and the day/month/all-time
 * totals read off it.
 *
 * The file holds numbers and identifiers, never prompts, completions, API keys,
 * or endpoints. Its directory is created `0o700` and the file `0o600`, and it
 * is compacted to the retention window at startup, so it neither grows without
 * bound nor becomes a second copy of the conversation.
 *
 * It lives in a directory of this plugin's own under the harness home —
 * `$DSH_HOME/dsh-balance/` by default, following the `llm-deepseek` precedent
 * of a plugin-named directory. `$DSH_HOME/storages/` deliberately is not used:
 * that root belongs to the `storage-json` backend, whose children are
 * `<unit>.json` files rather than per-plugin directories.
 *
 * Aggregates are kept per provider, per currency, and per local day rather
 * than per row: the day buckets are bounded by the retention window, so memory
 * does not grow with the number of requests and startup never holds the whole
 * file. Rows priced in one currency are never folded into another's total — a
 * deployment that switches price lists sees its new currency start from zero
 * rather than inheriting a number in the old one — and rows of one provider
 * are never folded into another's: the totals read for a provider are what
 * that route alone cost, so the figure under a provider's balance is its own.
 * A row that recorded no provider (a request whose source named none) counts
 * under the empty provider id, which no picker entry reads.
 *
 * @module @sumomok/dsh-balance/ledger
 */
import type { BalanceUiConfig, SpendView } from './types.ts';
/** One request's row, exactly as a line of the JSONL file. */
export interface LedgerRow {
    /** Epoch milliseconds of the request. */
    t: number;
    /** Session the request belonged to. */
    sessionId: string;
    /** The session-log sequence number of the step this row records. */
    seq: number;
    /** Model id the request ran on. */
    model: string;
    /** Provider route, when the observation carried one. */
    provider?: string;
    /** Input tokens billed at the cache-miss rate. */
    input: number;
    /** Input tokens billed at the cache-hit rate. */
    cacheRead: number;
    /** Tokens billed at the cache-write rate. */
    cacheWrite: number;
    /** Generated tokens excluding reasoning. */
    output: number;
    /** Reasoning tokens. */
    reasoning: number;
    /** Cost of the request; `0` on an unpriced row. */
    cost: number;
    /** ISO 4217 code `cost` is quoted in. */
    currency: string;
    /** Price tier that applied; empty on an unpriced row. */
    schedule: string;
    /** Present only when the price table priced no rate for this model. */
    unpriced?: true;
}
/** Directory name under the harness home this plugin owns. */
export declare const LEDGER_DIR = "dsh-balance";
/** File name under {@link LEDGER_DIR}. */
export declare const LEDGER_FILE = "ledger.jsonl";
/** Owner-only file mode; the ledger is a record of one machine's own spend. */
export declare const LEDGER_MODE = 384;
/** Owner-only directory mode, matching every other harness-home directory. */
export declare const LEDGER_DIR_MODE = 448;
/**
 * Narrow one parsed JSONL line to a row.
 * @param value - the parsed line.
 * @returns the row, or `null` when a required field is missing or mistyped.
 */
export declare function parseLedgerRow(value: unknown): LedgerRow | null;
/**
 * The local calendar day one instant falls in.
 * @param atMs - the instant, in epoch milliseconds.
 * @param timezone - IANA zone the day boundary is taken in.
 * @returns the day as `YYYY-MM-DD`.
 */
export declare function dayKey(atMs: number, timezone: string): string;
/** The timezone the host runs in, used when the deployment names none. */
export declare function hostTimezone(): string;
/** What a ledger needs from its environment. */
export interface LedgerOptions {
    /** Absolute path of the JSONL file. */
    file: string;
    /** Epoch milliseconds. */
    now: () => number;
    /** IANA zone the day and month boundaries are taken in. */
    timezone: string;
    /** Days of rows to keep; older rows are dropped at startup. */
    retentionDays: number;
    /** The price table's `asOf` date, restated on the wire. */
    pricesAsOf: string;
    /** Display facts the deployment configured, restated on the wire. */
    ui: BalanceUiConfig;
}
/**
 * The append-only spend ledger and its in-memory aggregates.
 *
 * {@link Ledger.open} must run before any read; it builds the day buckets and
 * compacts the file to the retention window.
 */
export declare class Ledger {
    private options;
    private readonly byProvider;
    /** Serializes appends so two concurrent requests cannot interleave a line. */
    private writes;
    /**
     * @param options - file location, clock, timezone, retention, and labels.
     */
    constructor(options: LedgerOptions);
    /**
     * Replace the display facts a live settings change supplies fresh — the
     * balance-coloring thresholds and which footer/session-spend
     * surfaces are on. File location, clock, timezone, and retention stay fixed
     * for this ledger's lifetime; only `ui` is ever settings-editable after
     * construction.
     * @param ui - the freshly resolved display facts.
     */
    setUi(ui: BalanceUiConfig): void;
    /**
     * Load the ledger, dropping and rewriting rows past the retention window.
     *
     * Two streaming passes rather than one buffered pass: the first folds the
     * aggregates and counts what retention drops, and the second — which runs
     * only when something was dropped — copies the survivors to a new file.
     * Holding the retained lines from the first pass would instead put the whole
     * file in memory to serve the uncommon case.
     *
     * A malformed line is skipped rather than fatal: the file is appended to by a
     * long-running process, so a truncated final line after a hard kill must not
     * make every later read fail.
     * @returns the number of rows retained.
     */
    open(): Promise<number>;
    /** Stream the file as `[line, parsed]` pairs; an unparseable line pairs with `null`. */
    private lines;
    /**
     * Rewrite the file with the rows inside the retention window, in chunks so
     * neither the survivors nor the discarded rows are ever all in memory.
     */
    private compact;
    /**
     * Append one row and fold it into the aggregates.
     * @param row - the request to record.
     */
    append(row: LedgerRow): Promise<void>;
    /**
     * Current day, month, and all-time spend of one provider in one currency.
     * @param currency - the ISO 4217 code of the active price list; rows priced
     * in any other currency are not counted.
     * @param provider - the provider id whose rows are counted; a provider with
     * no rows reads as zero.
     * @returns the view the footer popover renders.
     */
    spend(currency: string, provider: string): SpendView;
    /** ISO 4217 codes this ledger holds rows for, across every provider. */
    currencies(): readonly string[];
    /** Fold one row into its provider's and currency's day bucket and all-time totals. */
    private fold;
}
/**
 * The ledger file inside one plugin-owned root.
 * @param root - the plugin's directory, `$DSH_HOME/dsh-balance` by default.
 * @returns the absolute path of the JSONL ledger.
 */
export declare function ledgerPath(root: string): string;
//# sourceMappingURL=ledger.d.ts.map