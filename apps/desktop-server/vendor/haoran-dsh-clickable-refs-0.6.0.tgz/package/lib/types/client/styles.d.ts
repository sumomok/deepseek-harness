/**
 * This plugin's whole stylesheet, injected as one tagged `<style>` per client instance.
 *
 * A CSS module would be the shell's own idiom, but (same as every other
 * out-of-repo plugin here) this package's build hands `tsc` output straight
 * to esbuild, which emits no stylesheet for a `.module.css` next to source
 * that no longer exists at that point — so the rules live here as text.
 *
 * The one surface this plugin draws is the prose UNC copy toast. Its class
 * uses the plugin's own `dshcr-` prefix so it cannot collide with a host
 * class, and its colors are `--dsw-*` harness theme tokens, so it follows the
 * same light/dark scheme as the host.
 *
 * @module @haoran/dsh-clickable-refs/client/styles
 */
/** Attribute marking this plugin's style tags. */
export declare const STYLE_TAG = "data-dsh-clickable-refs";
/**
 * The `data-plugin` value on this plugin's style tags: the package name, which
 * is the id the host's client module system gives this plugin. That system
 * stamps every `<style>` without `data-plugin` with the id of the module it is
 * materializing and removes the stamped tags when that module unloads; a tag
 * that already names this plugin is left to this plugin's own disposer.
 */
export declare const STYLE_OWNER = "@haoran/dsh-clickable-refs";
/**
 * Insert this call's own copy of the stylesheet. Every call appends a separate
 * tag, so overlapping client instances of this plugin each hold one and
 * disposing one instance leaves the others styled.
 * @returns a disposer removing only the tag this call inserted.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map