/**
 * Browser half of @haoran/dsh-clickable-refs: clickable references in
 * assistant prose.
 *
 * This plugin provides the optional `proseReferents` scanning service that
 * `dsh-render`'s own chat view consumes and dispatches through directly
 * (`prose-referents-spec.md` §A) — this plugin never dispatches a prose click
 * itself. It keeps a per-session index of the paths the conversation's
 * events name (`referent-index.ts`) and verifies candidates in batches through
 * `remote.session.probeTargets` (`verification-store.ts`), so only a path
 * that exists is drawn as a link. It also listens on `referent/open` to
 * intercept a `chat-prose`-sourced UNC target before that dispatch's own
 * default would open it (`prose-unc-claim.ts`).
 *
 * Tool-call cards are the host's own: bash and web_fetch render through the
 * built-in `tool.call.toolview` entries.
 *
 * @module @haoran/dsh-clickable-refs/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ClickableRefsKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The prose UNC copy confirmation this plugin adds. */
        'clickable-refs': ClickableRefsKey;
    }
}
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * Register the `proseReferents` service, the session referent index, the
 * prose UNC claim, and this plugin's dictionaries.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map