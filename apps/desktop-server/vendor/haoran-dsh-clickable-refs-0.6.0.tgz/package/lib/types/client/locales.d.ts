/**
 * Copy for this plugin's own added UI: the notice the prose UNC copy toast
 * shows after a network-share path from assistant prose was copied instead of
 * opened.
 *
 * @module @haoran/dsh-clickable-refs/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "clickable-refs";
/** Every key this plugin's own added copy uses. */
export type ClickableRefsKey = 'copied';
/** English copy. */
export declare const en: Record<ClickableRefsKey, string>;
/** Chinese copy. */
export declare const zh: Record<ClickableRefsKey, string>;
//# sourceMappingURL=locales.d.ts.map