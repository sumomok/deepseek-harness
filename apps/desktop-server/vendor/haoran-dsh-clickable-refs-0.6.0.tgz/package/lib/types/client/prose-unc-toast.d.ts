/** One mounted toast element and the timer that hides it. */
export interface ProseUncToast {
    /**
     * Show `message` in this toast; a later call replaces the text and restarts
     * this toast's auto-hide timer.
     * @param message - the copied-confirmation text to show.
     */
    show: (message: string) => void;
    /** Stop this toast's timer and remove its element. */
    dispose: () => void;
}
/**
 * Mount a hidden toast element of this call's own into `document.body`. Every
 * call appends a separate element with its own timer, so overlapping client
 * instances each keep a working toast after another one is disposed. With no
 * `document`, both members do nothing.
 * @returns the toast's `show` and `dispose`.
 */
export declare function mountProseUncToast(): ProseUncToast;
//# sourceMappingURL=prose-unc-toast.d.ts.map