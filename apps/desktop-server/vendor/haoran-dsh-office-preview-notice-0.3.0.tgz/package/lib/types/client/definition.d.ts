/**
 * The document-preview registration this plugin contributes: the same file
 * suffixes the document preview's builtin Office renderer claims, ranked in
 * the `extension` band so automatic selection picks this notice first.
 *
 * @module @haoran/dsh-office-preview-notice/client/definition
 */
import type { DocumentPreviewDefinition } from '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/client';
/** Implementation id, shared by the registry entry and the keyed body slot. */
export declare const NOTICE_ID = "@haoran/dsh-office-preview-notice/notice";
/**
 * Suffixes the builtin Office renderer registers in
 * `@deepseek-ai/dsh-client-ui-sidebar-documentpreview` 0.2.0-rc.2
 * (`src/client/office/index.ts`). Spreadsheets belong to the browser-side
 * Excel renderer and stay out.
 */
export declare const OFFICE_EXTENSIONS: readonly ["doc", "docx", "ppt", "pptx"];
/**
 * Describe the notice as a document-preview implementation.
 * @param title - locale-owned label shown in the viewer menu.
 * @returns metadata for a renderer that loads nothing; every suffix is binary,
 * so no plain-text fallback joins the viewer choices.
 */
export declare function noticeDefinition(title: () => string): DocumentPreviewDefinition;
//# sourceMappingURL=definition.d.ts.map