/**
 * When the compaction actually happens: after a turn the user let finish, and
 * never inside one.
 *
 * The harness's own automatic path runs `agent/pre-step`, so a conversation
 * over the threshold compacts between the steps of a turn the user is watching
 * — and a compaction that fails there is only warned about and retried at the
 * very next step, with nothing carried across steps to slow it down. A
 * summarizer that is down therefore produces one failed attempt per step for
 * as long as the turn runs.
 *
 * This module moves the decision to the driver's own exit: the agent has just
 * gone from running to idle. The conversation is settled, the turn is closed,
 * the user is not waiting on a step, and there is one attempt per exit — the
 * next reading happens after the next one, so a failure waits for new work
 * instead of repeating immediately.
 *
 * Two situations are deliberately not acted on, and one signal identifies both:
 * **a turn the user stopped and a conversation being closed** close with
 * `turn/end` carrying `reason.kind === 'aborted'` and then publish an idle
 * status. Pressing Stop must not be followed by an unrequested compaction the
 * composer offers no way to stop (the maintenance phase reports itself as
 * `idle`, so the Stop control is already gone by then); and disposal is
 * `cancel({kind:'disposed'})` followed by `whenIdle()`, which would then wait
 * on a summarization started after the cancellation.
 *
 * **A delegated agent is also skipped, and its cost is real.** Compacting one
 * blocks the conversation that delegated it: every in-process subagent backend
 * finishes a run with `await child.whenIdle()`, and a compaction started from
 * the child's idle transition claims its maintenance phase synchronously, so
 * `whenIdle()` waits out the whole summarization before the parent's tool call
 * can return — measured at 3ms against 803ms with an 800ms stand-in task. The
 * child is then disposed and the summary discarded. The seat has no agent
 * parameter, so `isEnabled(): false` closes the harness's between-steps path
 * for delegated agents too and nothing replaces it: a delegated conversation
 * has the harness's overflow recovery and nothing else. That is the accepted
 * cost, stated in both READMEs and the release notes rather than traded for a
 * summary nobody reads and a parent that stalls for it.
 *
 * The reading is the usage ring's: `projectedTokens` over the routed
 * `contextWindow`, both taken from the `contextPressure` projection the ring
 * itself divides, falling back to `pressureTokens` exactly as the ring does
 * before the first surface movement is folded. Where the token meter is
 * reachable, a measurement that is not anchored on provider usage falls back to
 * its `totalTokens` — the engine's own numerator for that state, and the only
 * reading that prices a routed adapter's images.
 *
 * @module @haoran/dsh-auto-compact/idle-compaction
 */
import type { Context } from '@deepseek-ai/cordis';
import type { TokenMeasurement } from '@deepseek-ai/dsh-token-meter';
import type { ContextPressureProjection } from '@deepseek-ai/dsh-token-meter/client';
import type { AutoCompactSettings } from './section.ts';
/** What this module gives the policy seat: whether it is covering any agent. */
export interface IdleCompaction {
    /**
     * Whether a compaction engine has been reached for at least one agent.
     * @returns true once this module has resolved an engine it can compact with.
     */
    covers(): boolean;
}
/**
 * The share of the window the next request would occupy.
 *
 * Read the way the usage ring beside the message box reads it whenever the
 * measurement is anchored on provider usage: `projectedTokens` is that last
 * prompt-side sample carried forward by the surface's movement since, and
 * `pressureTokens` is the sample alone, which is what the projection publishes
 * before any movement has been folded.
 *
 * A measurement that is NOT usage-anchored takes the meter's own
 * `totalTokens`, which is what the engine's `occupancyTokens` takes in that
 * state and for the same reason: the projection prices everything after its
 * last sample with the route-independent heuristic, so it cannot see a routed
 * adapter's declared image pricing for history no provider has billed. Without
 * a reachable meter that branch has no reading and nothing triggers, which is
 * what the ring renders there too.
 *
 * The denominator is always the projection's recorded route capacity.
 * @param pressure - the session's published `contextPressure` value.
 * @param measurement - the token meter's measurement of the same session, when one is reachable.
 * @returns the occupied share of the window, or null while it is unknown.
 */
export declare function occupiedShare(pressure: ContextPressureProjection | undefined, measurement: TokenMeasurement | undefined): number | null;
/**
 * Compact once a driver exits, when the conversation is full enough.
 *
 * Only the running-to-idle transition acts, and only when the turn it closes
 * was not aborted. The previous status is tracked rather than inferred from the
 * event, because "the conversation just produced something" is this plugin's
 * own rule: an agent observed idle without having been seen running — a session
 * opened, this plugin loaded mid-life — has produced nothing to compact.
 *
 * One attempt per exit, one attempt at a time per agent. A run that leaves the
 * conversation still above the share does not try again here: the next exit is
 * the next decision point. Failures are logged and dropped; the harness's own
 * compaction records already carry them into the conversation.
 *
 * @param ctx - a context with `sessionProjections` composed; its unload removes the listeners.
 * @param section - thunk returning the switch and the share in force right now.
 * @returns the coverage question the policy seat answers from.
 */
export declare function installIdleCompaction(ctx: Context, section: () => AutoCompactSettings): IdleCompaction;
//# sourceMappingURL=idle-compaction.d.ts.map