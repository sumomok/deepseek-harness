/**
 * The user bubble, with its quote blocks lifted out into cards.
 *
 * This renderer shadows the host's own `user` and `steering` node views: a
 * keyed slot renders its cell's LOWEST live priority, so registering at -1
 * puts this component in front of an entry that stays registered. Everything
 * it does not change it delegates to that incumbent, read out of the slot
 * ledger rather than imported — there is no import across plugin bundles, and
 * a value import would be a second copy of the module.
 *
 * The incumbent is memoized and reads every label through its `t`, so it
 * renders in a new language only when that `t` is a new function. The
 * registration declares the incumbent's own `chat` namespace, and the slot
 * runtime hands this view that namespace's locale seat, a new function after
 * every locale revision; the view passes it on unchanged. A language switch in
 * Settings therefore re-renders the bubble behind the shadow as it re-renders
 * the bubble alone. The rationale is the same as crash-resume's header
 * (.agents/notes/2026-10-03-crash-resume-interrupted-header.md).
 *
 * Retirement: if the harness ships native quote rendering for user bubbles,
 * this renderer is deleted and the plugin keeps only its serialization.
 *
 * @module @sumomok/dsh-quote-message/client/QuotedUserNodeView
 */
import { type ReactNode } from 'react';
import type { StoredEntry, Translate, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { QuoteKey } from './locales.ts';
/** A translator bound to one namespace, as `ctx.locale.bind` returns it for a namespace known only at run time. */
type HostTranslate = (key: string, params?: Record<string, unknown>) => string;
/** The props a keyed chat-node entry receives; only the parts this renderer reads are named. */
interface ChatNodeProps {
    readonly node?: {
        readonly data?: {
            readonly content?: readonly unknown[];
        };
    };
    /** The `chat` locale seat the registration declares: a new function per locale revision. */
    readonly t: TranslateNS<'chat'>;
}
/** What the view needs from the plugin context, resolved per render. */
export interface QuotedNodeViewDeps {
    /** The keyed cell this view shadows. */
    readonly slotKey: string;
    /** Live ledger of `conversation.chat.node` entries. */
    readonly entries: () => readonly StoredEntry[];
    /**
     * The namespace this view's registration declares, whose seat arrives as
     * its `t`; also the namespace an incumbent that declares none is bound to.
     */
    readonly seatNamespace: string;
    /**
     * Translate bound to an incumbent namespace other than
     * {@link QuotedNodeViewDeps.seatNamespace}, for an incumbent whose entry
     * declares one; its identity does not change with the locale.
     */
    readonly hostTranslate: (namespace: string) => HostTranslate;
    /** Translate bound to this plugin's namespace, for the cards. */
    readonly t: () => Translate<QuoteKey>;
    /** Header lines this plugin emits, dropped from a card's body. */
    readonly headings: () => readonly string[];
}
/**
 * Build the shadowing renderer for one keyed cell.
 *
 * The component is its own exclusion key when it looks the incumbent up, so
 * the factory returns it rather than exporting a bare component. The return
 * type is the bare function form the slot registration requires; a
 * `ComponentType` union would admit a class, which `SlotComponent` rejects.
 * @param deps - ledger access, the declared seat's namespace, and the two translate bindings.
 * @returns the component to register at `priority: -1` with locale `deps.seatNamespace`.
 */
export declare function createQuotedUserNodeView(deps: QuotedNodeViewDeps): (props: ChatNodeProps) => ReactNode;
export {};
//# sourceMappingURL=QuotedUserNodeView.d.ts.map