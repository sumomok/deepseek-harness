/**
 * The pure half of `visionSwitch/catalog`: given the already-fetched
 * vision-capable models and the resolved config, settle the wire view and
 * the warning line a stale `target` pin earns. Split from `index.ts`'s
 * `VisionSwitchProvider` (a cordis `Service`) so this decision is testable
 * without any cordis machinery.
 *
 * @module @haoran/dsh-vision-switch/resolve-catalog
 */
import { type Config } from './config.ts';
import type { VisionCatalogView, VisionModelEntry } from './types.ts';
/** Result of resolving one catalog read. */
export interface ResolvedCatalog {
    /** The wire view `visionSwitch/catalog` returns. */
    readonly view: VisionCatalogView;
    /** A line to log when `Config.target` names a model the catalog does not have; null otherwise. */
    readonly warn: string | null;
}
/**
 * Settle the wire view and warning for one catalog read.
 * @param config - the schema-validated plugin config.
 * @param models - every vision-capable model {@link listVisionModels} found.
 * @returns the view and an optional warning line.
 */
export declare function resolveCatalogView(config: Config, models: readonly VisionModelEntry[]): ResolvedCatalog;
//# sourceMappingURL=resolve-catalog.d.ts.map