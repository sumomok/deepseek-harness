/**
 * The `visionSwitch` Service Definition and its Typert Remote face.
 *
 * The browser reaches this service only through the harness's own `/api`
 * Typert gateway, which inherits the host's trust fence. This plugin
 * registers no HTTP route of its own. The one method is a read: nothing here
 * mutates the session, the catalog, or any stored configuration.
 *
 * @module @haoran/dsh-vision-switch/service
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { VisionCatalogView } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Vision-capable model catalog reads (provided by `@haoran/dsh-vision-switch`). */
        visionSwitch: VisionSwitchService;
    }
}
/** Read-only vision-capable model catalog capability. */
export declare abstract class VisionSwitchService extends TypertRemoteService {
    /**
     * @param ctx - owning plugin context.
     */
    constructor(ctx: Context);
    /**
     * Every vision-capable model in the runtime catalog, plus the resolved
     * switch target and whether the target is itself vision-capable.
     * @returns the catalog view.
     */
    abstract catalog(): Promise<VisionCatalogView>;
    /**
     * Remote face of {@link VisionSwitchService.catalog}; the decorator cannot
     * mark the abstract member, so this concrete adapter carries the identical
     * contract.
     * @returns the catalog view.
     */
    remoteExportCatalog(): Promise<VisionCatalogView>;
}
export default VisionSwitchService;
//# sourceMappingURL=service.d.ts.map