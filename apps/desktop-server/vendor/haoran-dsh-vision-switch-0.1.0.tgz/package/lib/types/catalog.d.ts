/**
 * The vision-capable model catalog, built the same way the harness's own
 * `session.models`/`llm.models` RPCs build their catalog (`listProviders` then
 * `listModels` then `resolveModelInfo` per model) — except this one keeps
 * `inputModalities` instead of dropping it, which is the one field neither of
 * those RPCs sends to the browser.
 *
 * @module @haoran/dsh-vision-switch/catalog
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ModelPin, VisionModelEntry } from './types.ts';
/**
 * The deployment default a case-1 auto-switch targets when `Config.target`
 * names none: the model `@haoran/dsh-default-model` already makes every new
 * session's starting model, so a deployment running that plugin needs no
 * `target` override to get consistent behavior on both paths.
 */
export declare const DEFAULT_TARGET: ModelPin;
/**
 * Every vision-capable model across every registered provider route.
 *
 * A provider whose `listModels` throws, or a model whose `resolveModelInfo`
 * throws, contributes nothing to the result rather than failing the whole
 * read: this catalog only ever feeds an auto-switch or a chooser list, so a
 * broken route silently narrows the offered models instead of leaving both
 * without any read at all (the `session.models`/`llm.models` RPCs make the
 * same call, but report the failure back for their settings-page reader —
 * nothing here reads that list, so this omits it).
 * @param ctx - host context (needs `ctx.llm`).
 * @returns vision-capable models, in provider/model catalog order.
 */
export declare function listVisionModels(ctx: Context): Promise<VisionModelEntry[]>;
//# sourceMappingURL=catalog.d.ts.map