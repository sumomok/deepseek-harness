/**
 * Plugin configuration. Every field is changeable from `cordis.yml` and
 * validated at load; nothing here is a constant compiled into the code.
 *
 * `target`'s two members deliberately are not `.required()`: schemastery
 * materializes an omitted optional object to `{}`, and a `.required()`
 * member would then fail that materialization even when the deployment set
 * no `target` at all. {@link resolveTarget} reads the settled `{provider:
 * '', model: ''}` as absent and enforces "both or neither" itself — the
 * rule a per-field schema cannot state (same shape as `@sumomok/dsh-balance`'s
 * `compactPriceTable` working around the identical materialization).
 *
 * @module @haoran/dsh-vision-switch/config
 */
import z from '@deepseek-ai/schemastery';
import type { ModelPin } from './types.ts';
/** Plugin configuration. */
export interface Config {
    /** Whether the plugin acts at all; false leaves the host's own gate as the only behavior. */
    enabled?: boolean;
    /** Pin the case-1 auto-switch target; absent uses the deployment's built-in default. */
    target?: ModelPin;
}
export declare const Config: z<Config>;
/**
 * Settle `Config.target`: an empty pair (unset) reads as absent; a
 * half-filled pin is a configuration mistake, not a partial target.
 *
 * `target.provider`/`.model` read with `?? ''`: schemastery materializes an
 * omitted `target` to a bare `{}`, without filling in each member's own
 * string default, so the settled value can hold neither key even though
 * `ModelPin` declares both required.
 * @param config - the schema-validated plugin config.
 * @returns the target pin, or undefined when unset.
 * @throws {Error} when exactly one of `provider`/`model` is set.
 */
export declare function resolveTarget(config: Config): ModelPin | undefined;
//# sourceMappingURL=config.d.ts.map