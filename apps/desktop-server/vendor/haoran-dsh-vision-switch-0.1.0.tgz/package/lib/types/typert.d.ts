/**
 * Host-face Typert manifest, discovered by `@deepseek-ai/dsh-typert-loader`.
 *
 * The loader resolves `<package>/package.json` from the config tree, reads
 * `exports["./typert"]`, imports this module, and registers the `TYPERT`
 * export — so a third-party Remote needs no allowlist and no repository
 * change: the plugin appearing as a Loader entry under its own package name
 * is the whole registration. The manifest is hand-written here because the
 * Typert generator runs over the harness workspace, not over out-of-repo
 * packages; it is structurally what that generator emits, and every codec is
 * a zod v4 schema, which the loader checks.
 *
 * Keep this file free of imports other than `zod`: the loader imports it
 * directly by file path, outside the plugin's own module graph.
 *
 * @module @haoran/dsh-vision-switch/typert
 */
import { z } from 'zod';
import type { VisionCatalogView } from './types.ts';
/** The contribution `dsh-typert-loader` registers for this package. */
export declare const TYPERT: {
    package: string;
    face: string;
    schemas: never[];
    invocations: {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodType<VisionCatalogView, unknown, z.core.$ZodTypeInternals<VisionCatalogView, unknown>>;
        };
    }[];
    model: {
        services: {
            description: string;
            summary: string;
            tags: never[];
            jsDoc: string;
            key: string;
            exportName: string;
            members: {
                kind: string;
                name: string;
                signature: string;
                summary: string;
                jsDoc: string;
            }[];
            types: never[];
        }[];
        events: never[];
        objects: never[];
    };
};
export default TYPERT;
//# sourceMappingURL=typert.d.ts.map