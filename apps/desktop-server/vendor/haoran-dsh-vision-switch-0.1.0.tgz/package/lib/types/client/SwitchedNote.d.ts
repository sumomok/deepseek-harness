/**
 * The subtle note shown for a few seconds right after a case-1 or case-2
 * switch: "Switched to a vision-capable model: <name>". Purely informational
 * — it carries no undo action, matching the no-auto-restore decision.
 *
 * @module @haoran/dsh-vision-switch/client/SwitchedNote
 */
import type { ReactNode } from 'react';
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { VisionSwitchKey } from './locales.ts';
/** Component props. */
export interface SwitchedNoteProps {
    /** Bound translate for this plugin's own namespace. */
    readonly t: Translate<VisionSwitchKey>;
    /** Display name of the model just switched to. */
    readonly name: string;
}
/**
 * The note line.
 * @param props - the note's own props.
 * @returns the line.
 */
export declare function SwitchedNote({ t, name }: SwitchedNoteProps): ReactNode;
//# sourceMappingURL=SwitchedNote.d.ts.map