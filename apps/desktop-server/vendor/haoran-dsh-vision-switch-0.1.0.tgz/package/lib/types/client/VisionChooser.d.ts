/**
 * Case 2's chooser: the default target is absent from the catalog, but other
 * vision-capable models exist. Rendered above the composer while a send
 * attempt waits on a pick or a dismissal.
 *
 * @module @haoran/dsh-vision-switch/client/VisionChooser
 */
import type { ReactNode } from 'react';
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { VisionModelEntry } from '../types.ts';
import type { VisionSwitchKey } from './locales.ts';
/** Component props. */
export interface VisionChooserProps {
    /** Bound translate for this plugin's own namespace. */
    readonly t: Translate<VisionSwitchKey>;
    /** Every vision-capable model to offer. */
    readonly options: readonly VisionModelEntry[];
    /** A model was picked. */
    readonly onPick: (entry: VisionModelEntry) => void;
    /** The chooser was dismissed; the send attempt aborts, draft intact. */
    readonly onCancel: () => void;
}
/**
 * The chooser panel.
 * @param props - the chooser's own props.
 * @returns the panel.
 */
export declare function VisionChooser({ t, options, onPick, onCancel }: VisionChooserProps): ReactNode;
//# sourceMappingURL=VisionChooser.d.ts.map