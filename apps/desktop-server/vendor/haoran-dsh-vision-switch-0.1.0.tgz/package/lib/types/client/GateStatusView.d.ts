/**
 * Pure render of one gate status: the chooser, the blocked message, the
 * switched note, or nothing while idle. Shared between `GateDock` (the
 * docked `conversation.composer.dock` seat) and `GatePortal` (the
 * `document.body` fallback for a session whose dock has not mounted yet)
 * so the two surfaces never diverge in what they show for the same status
 * — only where they show it.
 *
 * @module @haoran/dsh-vision-switch/client/GateStatusView
 */
import type { ReactNode } from 'react';
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { VisionModelEntry } from '../types.ts';
import type { VisionSwitchKey } from './locales.ts';
import type { GateStatus } from './submit-gate.ts';
/** Component props. */
export interface GateStatusViewProps {
    /** Bound translate for this plugin's own namespace. */
    readonly t: Translate<VisionSwitchKey>;
    /** The status to render. */
    readonly status: GateStatus;
    /** A chooser option was picked (only reachable while `status.kind === 'choosing'`). */
    readonly onPick: (entry: VisionModelEntry) => void;
    /** The chooser was dismissed (only reachable while `status.kind === 'choosing'`). */
    readonly onCancel: () => void;
}
/**
 * Render one status.
 * @param props - the status and the actions its interactive cases need.
 * @returns the status's own markup, or nothing while idle.
 */
export declare function GateStatusView({ t, status, onPick, onCancel }: GateStatusViewProps): ReactNode;
//# sourceMappingURL=GateStatusView.d.ts.map