/**
 * Which surface is responsible for rendering a session's current gate
 * status: the docked `conversation.composer.dock` entry (`GateDock.tsx`)
 * once it has mounted, or the `document.body` portal fallback
 * (`GatePortal.tsx`) before it has — a brand new session's first message,
 * when the host has not mounted the dock yet (see `GatePortal.tsx`'s
 * module doc for why). Both entry points call this one function to decide
 * whether they are the surface for the current render, so "never both
 * render the same status" is a property of this function's return type —
 * one tag, never two independent booleans — rather than something each
 * caller has to keep in sync on its own.
 *
 * @module @haoran/dsh-vision-switch/client/fallback-surface
 */
import type { GateStatus } from './submit-gate.ts';
/** Which surface (if any) is responsible for rendering the current status. */
export type GateSurface = 'dock' | 'portal' | 'none';
/**
 * @param status - the session's current gate status.
 * @param dockMounted - whether this session's `conversation.composer.dock`
 * entry is currently mounted (`SessionGate.dockMounts`'s snapshot > 0).
 * @returns `'none'` while idle (nothing to show); otherwise `'dock'` when
 * the dock is mounted, `'portal'` when it is not.
 */
export declare function selectGateSurface(status: GateStatus, dockMounted: boolean): GateSurface;
//# sourceMappingURL=fallback-surface.d.ts.map