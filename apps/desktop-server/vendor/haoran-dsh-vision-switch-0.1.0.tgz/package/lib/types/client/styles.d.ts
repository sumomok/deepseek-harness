/**
 * The browser half's stylesheet, injected once as a tagged `<style>`.
 *
 * Every colour is a harness theme variable rather than a literal, so the
 * chooser, the blocked message, and the switched note follow the light and
 * dark schemes the shell already switches between.
 *
 * @module @haoran/dsh-vision-switch/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-vision-switch";
/**
 * Put the stylesheet in the document, once.
 * @returns a disposer removing the tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map