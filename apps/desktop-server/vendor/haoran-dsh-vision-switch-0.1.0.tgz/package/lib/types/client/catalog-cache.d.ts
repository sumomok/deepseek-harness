/**
 * The browser-side cache over `visionSwitch/catalog`: fetched lazily (never
 * on plugin load, only the first time a send actually needs it), joined
 * rather than duplicated while a fetch is in flight, and served from memory
 * afterward until the catalog or the deployment's routes change.
 *
 * @module @haoran/dsh-vision-switch/client/catalog-cache
 */
import type { VisionCatalogView } from '../types.ts';
/** One RPC result, as the gateway's namespace methods return it. */
export type RemoteResult<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error?: {
        message?: string;
    };
};
/** The namespace face `ctx.get('remote.visionSwitch')` returns once mounted. */
export interface VisionSwitchRemote {
    catalog(): Promise<RemoteResult<VisionCatalogView>>;
}
/**
 * Unwrap one RPC result, turning a transport failure into a throw the caller
 * treats as a catalog-read failure.
 * @param result - the gateway's result.
 * @param method - the called method, named in the fallback message.
 * @returns the value.
 * @throws when the call did not succeed.
 */
export declare function unwrap<T>(result: RemoteResult<T>, method: string): T;
/** Lazy, joined, invalidatable cache over one session-independent catalog read. */
export declare class CatalogCache {
    private readonly remote;
    private value;
    private pending;
    /**
     * @param remote - the mounted Remote face.
     */
    constructor(remote: VisionSwitchRemote);
    /**
     * Read the catalog, fetching only when nothing cached is available and
     * joining an already in-flight fetch rather than starting a second one.
     * @returns the catalog view.
     * @throws when the read fails (the caller degrades to host-only behavior).
     */
    get(): Promise<VisionCatalogView>;
    /** Drop the cached value, so the next {@link get} call re-fetches. */
    invalidate(): void;
    private fetch;
}
//# sourceMappingURL=catalog-cache.d.ts.map