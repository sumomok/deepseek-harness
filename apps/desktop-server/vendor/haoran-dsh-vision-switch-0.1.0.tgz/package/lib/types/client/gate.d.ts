/**
 * Send-attempt gating: resolve what a submit with images should do, using
 * the exact channel a manual model switch uses (`sessions.models` /
 * `sessions.selectModel`, the same calls the composer's own model seat
 * makes) plus this plugin's own vision-capable catalog.
 *
 * @module @haoran/dsh-vision-switch/client/gate
 */
import type { IApiClient, ModelSelection, SessionId } from '@deepseek-ai/dsh-api-remotes/client';
import { type VisionSwitchDecision } from '../core/decision.ts';
import type { ModelPin } from '../types.ts';
import type { CatalogCache } from './catalog-cache.ts';
/** The two stock session calls this plugin drives — the identical pair the model-selection UI uses. */
export type SessionsFace = Pick<IApiClient['sessions'], 'models' | 'selectModel'>;
/**
 * Resolve a send-attempt decision, or `'degraded'` when either read fails —
 * a broken catalog RPC or an unreachable session must never block sending
 * text, so the caller treats `'degraded'` as "proceed, exactly as the host's
 * own gate would have handled it without this plugin".
 * @param sessions - the stock session calls (from `connection.api.sessions`).
 * @param catalog - this plugin's own catalog cache.
 * @param sessionId - the session the draft belongs to.
 * @param hasImages - whether the draft carries at least one image attachment.
 * @returns the decision, or `'degraded'` on read failure.
 */
export declare function resolveGate(sessions: SessionsFace, catalog: CatalogCache, sessionId: SessionId, hasImages: boolean): Promise<VisionSwitchDecision | 'degraded'>;
/**
 * Read the session's current model selection — the same RPC the model
 * popup and the composer's model seat both load through.
 * @param sessions - the stock session calls.
 * @param sessionId - the session to read.
 * @returns the current selection.
 * @throws when the call fails or is rejected.
 */
export declare function currentSelection(sessions: SessionsFace, sessionId: SessionId): Promise<ModelSelection>;
/**
 * Perform the switch — the identical call a manual pick in the model popup
 * or the composer's model seat makes, so the result is session-sticky with
 * no separate persistence path of this plugin's own.
 * @param sessions - the stock session calls.
 * @param sessionId - the session to switch.
 * @param target - the provider/model to select.
 * @throws when the host rejects the switch.
 */
export declare function applySwitch(sessions: SessionsFace, sessionId: SessionId, target: ModelPin): Promise<void>;
//# sourceMappingURL=gate.d.ts.map