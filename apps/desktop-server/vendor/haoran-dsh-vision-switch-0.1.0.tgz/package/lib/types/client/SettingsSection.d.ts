/**
 * The settings page section showing this plugin's resolved state: whether
 * it is enabled, the resolved switch target and its availability, and how
 * many vision-capable models the current catalog holds.
 *
 * Read-only by design: `enabled`/`target` are `Config` fields (schemastery,
 * resolved once from `cordis.yml` at plugin load), not a live `settings`
 * document — writing them back would need a mutation path this plugin has
 * no other use for, so this section documents the current state instead of
 * offering a toggle. See the README for how to change `Config`.
 *
 * @module @haoran/dsh-vision-switch/client/SettingsSection
 */
import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { VisionCatalogView } from '../types.ts';
/** The one read this section performs, bound to the mounted Remote. */
export interface SettingsSectionInjected {
    /** Read the resolved catalog view. */
    read: () => Promise<VisionCatalogView>;
}
/** Full component props. */
export type SettingsSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'visionSwitch'> & InjectFace<SettingsSectionInjected>;
/**
 * The registered settings section.
 * @param props - the framework standard kit plus this plugin's Remote face.
 * @returns the page.
 */
export declare function SettingsSection({ read, t }: SettingsSectionProps): ReactNode;
//# sourceMappingURL=SettingsSection.d.ts.map