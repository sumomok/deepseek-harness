/**
 * Wire types shared by the host Typert service and its browser Remote
 * mirror. Both sides narrow to these shapes independently (the host
 * validates with `zod`, the browser with hand-written codecs), so the
 * interfaces themselves carry no runtime dependency.
 *
 * @module @haoran/dsh-vision-switch/types
 */
/** One provider/model route, naming the {@link GenerateOptions.provider}/`.model` pair a switch selects. */
export interface ModelPin {
    /** Provider route key. */
    readonly provider: string;
    /** Model id on that route. */
    readonly model: string;
}
/** One vision-capable model the runtime catalog advertises. */
export interface VisionModelEntry extends ModelPin {
    /** Human-readable model name, as the provider's adapter names it. */
    readonly name: string;
}
/**
 * The vision-switch host's whole advisory state: whether the plugin acts at
 * all, which target a case-1 auto-switch resolves to, and every
 * vision-capable model a case-2 chooser may offer.
 */
export interface VisionCatalogView {
    /** Resolved `Config.enabled`; false disables auto-switch, the chooser, and the blocking message alike. */
    readonly enabled: boolean;
    /** Resolved switch target: `Config.target` when set, else the deployment's built-in default. */
    readonly target: ModelPin;
    /** Whether `target` names a model this call actually found in the catalog. */
    readonly targetAvailable: boolean;
    /** Every vision-capable model across every registered provider, in provider/model catalog order. */
    readonly models: readonly VisionModelEntry[];
}
//# sourceMappingURL=types.d.ts.map