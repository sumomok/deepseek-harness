/**
 * Host half of @haoran/dsh-vision-switch.
 *
 * The host gate at the harness's own `session.prompt` refuses an image
 * message outright when the session's current model lacks image input, with
 * no path forward for the caller. This plugin does not touch that gate — it
 * exists so the browser half can avoid triggering it: the one thing this
 * host half exports is a read of which models in the runtime catalog accept
 * images, which the browser cannot otherwise learn (`session.models` and
 * `llm.models` both drop `inputModalities` on the wire).
 *
 * @module @haoran/dsh-vision-switch
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.ts';
export { DEFAULT_TARGET, listVisionModels } from './catalog.ts';
export { Config, resolveTarget } from './config.ts';
export { resolveCatalogView, type ResolvedCatalog } from './resolve-catalog.ts';
export { VisionSwitchService } from './service.ts';
export type { ModelPin, VisionCatalogView, VisionModelEntry } from './types.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "vision-switch";
/** Required host services. */
export declare const inject: string[];
/**
 * Mount the vision-capable catalog capability.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map