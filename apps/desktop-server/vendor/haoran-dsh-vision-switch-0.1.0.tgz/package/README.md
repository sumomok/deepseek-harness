# @haoran/dsh-vision-switch

English | [中文](README.zh.md)

Desktop-internal, not published. When a message with an image is sent while the session's current model does not support images, the harness's own gate at `session.prompt` refuses the send outright — a dead end, with no path forward for the person typing. This plugin replaces that dead end with a switch: before the send leaves the browser, it moves the session onto a vision-capable model through the exact channel a manual model switch uses, then lets the send proceed. It never touches the host's gate — it exists so a send with images never trips it in the first place.

## What happens on send

1. **A default target is in the catalog** — switch to it and send. The default is `deepseek-v4-flash-vision-exp` on `deepseek-official`, the same model `@haoran/dsh-default-model` already starts every new session on. A deployment can pin a different `{provider, model}` with `Config.target`.
2. **The target is absent, but other vision-capable models exist** — a small chooser appears: 「当前模型不支持图片，选择一个支持图片的模型继续」, listing every other model by display name. Picking one switches and sends; dismissing it aborts the send with the draft intact.
3. **No vision-capable model exists anywhere** — 「当前没有可用的支持图片的模型」, draft intact, no switch attempted.

After a switch, a subtle note appears near the composer for a few seconds: 「已切换到支持图片的模型：\<name\>」. The switch is session-sticky — the same `sessions.selectModel` call a manual pick in the model popup makes — and nothing restores the previous model automatically.

**Zero interference on the common path.** No images in the draft, or the current model already supports them: nothing runs, nothing is queried, the send proceeds exactly as if this plugin were not installed.

## Why a host half, unlike some sibling plugins

The browser has no way to learn which models accept images. `session.models` and `llm.models` — the two RPCs the client can already reach — both drop `inputModalities` on the wire; only the host's own `ctx.llm.resolveModelInfo` carries it. So this plugin ships a small host half whose entire job is one read: a Typert Remote (`visionSwitch/catalog`) built the same way those two RPCs build their catalog, except it keeps the one field they omit. That host half also carries real `Config` (`enabled`, `target`), which the browser half reads over the same Remote — the plugin does not need `@sumomok/dsh-text-drop`'s "client plugins can't receive config, fall back to exported constants" workaround, because a host half with a Config makes a real, live, cordis.yml-changeable config reachable from the browser.

## The submit interception

`conversation.composer.bar` is a single-kind slot, but it cannot be shadowed the way `@sumomok/dsh-text-drop` shadows `conversation.input.attachments`: the bar's `keyboard` prop is package-internal, computed by `ui-conversation`'s own `inject` from its private `InputHub`, and a third-party registrant has no way to reproduce it — `tsc` rejects a registration that declares this slot's props without that private face.

Instead, this plugin reaches the same object through a public door. `ctx.conversation.input` (`IConversation.input`, a `SessionInputResolver`) is a documented public service, and `SessionInputResolver.for(actx)` returns the identical per-session `SessionInput` singleton `InputBar`'s own `keyboard` prop wraps — both resolve through the same session-keyed cache inside `InputHub`, so it is one object, not a copy. `SessionInput.submit` is the harness's own "complexity sink": every send, from the Enter key to the send button to the public `inputActions.submit()` other plugins already use, ends up calling `submit` on that one object. This plugin replaces that one method on the object it legitimately obtained through the public service (`gateFor` in `client/gate-registry.ts`, installed once per session, first read): before forwarding to the original `submit`, the replacement checks the draft's image ids and, if any are present and the current model lacks vision, resolves the switch (or the chooser, or the block) first. Everything else about the composer — layout, the textarea, every other control, every other method on that object — is untouched.

## The first-message fallback

`conversation.composer.dock` — where the chooser, the blocked message, and the switched note render — only mounts once a session has a turn in its history, so a brand new session's very first message has no dock to draw into. Case 1 (auto-switch) is unaffected: the send itself proceeds, and the switched note renders normally once the dock exists a moment later. Cases 2 and 3 hold the send back before any turn exists, so without a fallback the click would do nothing visible.

`GatePortal.tsx`, registered at the always-mounted `conversation.input.dock` seat, covers that gap: it renders the same chooser/blocked/switched markup through `react-dom`'s `createPortal` to `document.body` whenever the dock has not mounted for the current session. `fallback-surface.ts`'s `selectGateSurface` decides which of the two surfaces — the dock or the portal — is responsible for a given status, so they never both render it. The portal chooser dismisses on Escape or an outside click, aborting the send with the draft intact, the same effect as its own Cancel button; the portal's blocked notice has no dismiss control and clears itself a few seconds after showing. The technique mirrors `@sumomok/dsh-text-drop`'s `DragHintStrip`: a `position: fixed` element left nested inside the composer's own DOM subtree can paint its background but not its own text over the host's `backdrop-filter` layers, which is why the portal targets `document.body` directly rather than a high z-index left in place.

## Configuration

```yaml
- id: vision-switch
  name: '@haoran/dsh-vision-switch'
  config:
    enabled: true
    # target:
    #   provider: deepseek-official
    #   model: some-other-vision-model
```

| Field | Default | Meaning |
| --- | --- | --- |
| `enabled` | `true` | `false` leaves the host's own gate as the only behavior — this plugin does nothing. |
| `target` | unset | Pins the case-1 auto-switch target. Unset resolves to `deepseek-official` / `deepseek-v4-flash-vision-exp`. A pin absent from the catalog falls back to the chooser (case 2), with a warning logged host-side. |

An id-targeted patch in the profile's own `cordis.patch.yml` **replaces the whole `config` block** — restate `enabled` if you add a `target`.

## Settings page

A read-only section (screenshot's own settings section is the precedent) shows whether the plugin is enabled, the resolved target and whether it is currently in the catalog, and how many vision-capable models exist. It has no toggle: `enabled`/`target` are `Config` fields resolved once from `cordis.yml`, not a live `settings` document, and wiring a write path for them would need machinery nothing else in this plugin uses. Change them in `cordis.yml`.

## What this does not do

**Mid-turn `read_image` still needs a vision model already selected.** This plugin only gates the client's own send attempt; it does not touch the agent's tool-call path. If the agent calls `read_image` on a text-only model mid-turn, that call fails exactly as it does today.

**No auto-restore.** Once switched, the session stays on the vision-capable model until something else changes it — this plugin never switches back.

**A non-desktop host without the gate behaves identically.** This plugin decides from the draft's own image attachments and the catalog, never from whether a host enforces the refusal — it acts before any gate exists to trip.

## Install

```sh
pnpm run build
cd packages/vision-switch && pnpm pack --pack-destination /tmp
dsh plugin --profile <name> add /tmp/haoran-dsh-vision-switch-0.1.0.tgz
```

See the workspace README for the tarball-based profile install and why a `link:` dependency must not be used.

## Development

```sh
pnpm run build
pnpm run typecheck
pnpm run test
```
