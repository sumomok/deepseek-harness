/**
 * The settings section this plugin owns — the switch between reviewed and
 * unreviewed operation and the route the review model is reached on — and the
 * slash command that throws the switch.
 *
 * The switch is this plugin's own state rather than a permission preset because
 * the host resolves a preset by looking its `(sandbox, approval)` pair up in a
 * table: two rows sharing a pair both resolve to `custom` and neither stays
 * selectable, and the one free pairing — `approval: never` — is the one that
 * takes away the channel `alwaysAsk` needs. A preset row cannot express "review
 * or not" without colliding with one of those two facts.
 *
 * Both settings are durable where a settings provider is composed and
 * process-lifetime otherwise; `persists` is what the command's own text reports.
 * Every read goes to the scope at the moment of the read, so a choice made in
 * the settings page decides the next call without a reload.
 * @module @haoran/dsh-llm-permission-gateway/mode
 */
import type { Context } from '@deepseek-ai/cordis';
import type { JudgeRoute } from './judge.ts';
/**
 * Whether the review model is consulted at all.
 *
 * `manual` is not "no gate": the two red lines and `alwaysAsk` run in both
 * modes, and everything else falls through to whatever the harness itself
 * would have done — the sandbox, and a human at the approval prompt.
 */
export type ReviewMode = 'auto' | 'manual';
/** The command name, without its leading slash. */
export declare const REVIEW_COMMAND = "review";
/** This plugin's persisted settings section. */
export interface GatewaySettings {
    /** The active review mode. */
    mode: ReviewMode;
    /**
     * Provider route the user picked for the review model, or `''` to be reviewed
     * on the route the composition configured. Written together with
     * {@link GatewaySettings.judgeModel}: half a pair names no route.
     */
    judgeProvider: string;
    /** Model id the user picked for the review model; `''` alongside {@link GatewaySettings.judgeProvider}. */
    judgeModel: string;
}
/** What the composition configured, in force until the user chooses otherwise. */
export interface GatewayDefaults {
    /** The mode a fresh installation starts in. */
    readonly mode: ReviewMode;
    /** The route a user who picked no review model is reviewed on. */
    readonly route: JudgeRoute;
}
/** Reads and writes the settings this plugin owns, wherever they are stored. */
export interface GatewayStore {
    /** The mode in force right now. */
    current(): ReviewMode;
    /** Whether a change survives a restart. */
    persists(): boolean;
    /**
     * Change the mode.
     * @param next - the mode to switch to.
     */
    set(next: ReviewMode): Promise<void>;
    /** The route the next review is issued on, settled afresh on every call. */
    route(): JudgeRoute;
    /**
     * Observe changes to the route {@link GatewayStore.route} answers with.
     * @param listener - invoked after a commit that changed either half of the stored pair.
     * @returns the disposer removing this listener.
     */
    onRouteChange(listener: () => void): () => void;
}
/**
 * Create the settings store and attach it to a settings provider when one is
 * composed.
 *
 * The store is returned before any provider attaches, so the gate reads a mode
 * and a route from its first call onward; attaching only moves the answers from
 * the composition config to the user document.
 * @param ctx - the plugin context.
 * @param defaults - the mode and route from the plugin's own config, used until a settings provider attaches and whenever none does.
 * @returns the store the gate, the command, and the record all read.
 */
export declare function createGatewayStore(ctx: Context, defaults: GatewayDefaults): GatewayStore;
/**
 * Register the `/review` command where a commands registry is mounted.
 * @param ctx - the plugin context.
 * @param store - the settings store the command reads and writes.
 */
export declare function applyReviewCommand(ctx: Context, store: GatewayStore): void;
//# sourceMappingURL=mode.d.ts.map