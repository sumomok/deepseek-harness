/**
 * Copy for the settings page this plugin owns.
 *
 * Every line describes this page and nothing else: no other tool is named, and
 * no other place to go is named, because a person reading a settings page is
 * not being told what to do next.
 * @module @haoran/dsh-llm-permission-gateway/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "llmPermissionGateway";
/** Chinese copy (the dictionary that defines the key domain). */
export declare const zh: {
    'settings.nav': string;
    'settings.autoReview': string;
    'settings.model': string;
    'settings.modelDefault': string;
    'settings.mayReason': string;
    'settings.unavailableSuffix': string;
    'settings.notAvailable': string;
    'settings.catalogLoading': string;
    'settings.catalogFailed': string;
    'settings.readOnly': string;
    'settings.unavailable': string;
    'settings.loading': string;
    'settings.saving': string;
    'settings.saved': string;
    'settings.error': string;
};
/** English copy. */
export declare const en: Record<GatewayKey, string>;
/** Dictionary key domain. */
export type GatewayKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map