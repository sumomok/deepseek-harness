/**
 * The `settings.section` page this plugin contributes: whether each step is
 * reviewed before it runs, and which model does the reviewing.
 *
 * Both live in this plugin's own settings namespace, read and written through
 * the scope every settings row binds through (`ctx.settingsScope.bind`,
 * `@deepseek-ai/dsh-client-ui-settings`), so a change here decides the next
 * call without a restart.
 *
 * The two halves of the route are written in one `mutate`, never as two writes:
 * a section holding one half of a pair names no route, and the host would
 * review on the configured one until the second write landed.
 *
 * @module @haoran/dsh-llm-permission-gateway/client/ReviewSection
 */
import { type ReactNode } from 'react';
import type { ModelCatalog } from '@deepseek-ai/dsh-api-session-controller/types';
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { GatewaySettings } from '../mode.ts';
import type { GatewayKey } from './locales.ts';
/** Props the section reads from its composed slot props. */
export interface ReviewSectionProps {
    /** Close the settings panel; unused here — this page has no flow that leaves settings. */
    close: () => void;
    /** The bound settings scope over this plugin's own namespace. */
    scope: SettingsScope<GatewaySettings>;
    /** Read the provider-grouped catalog of models a review can be issued on. */
    read: () => Promise<ModelCatalog>;
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'llmPermissionGateway'>;
}
/** One save action's inline status, shown beneath the controls it settles. */
type SaveState = 'idle' | 'saving' | 'saved' | 'error';
/** @param state - one save action's status. @returns its copy key, or `undefined` while idle. */
export declare function saveStatusKey(state: SaveState): GatewayKey | undefined;
/**
 * The registered `settings.section` component.
 * @param props - composed slot props.
 * @returns the page, or a placeholder before the first accepted section.
 */
export declare function ReviewSection({ scope, read, t }: ReviewSectionProps): ReactNode;
export {};
//# sourceMappingURL=ReviewSection.d.ts.map