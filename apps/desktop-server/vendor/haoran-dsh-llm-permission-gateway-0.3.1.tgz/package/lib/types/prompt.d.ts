/**
 * The two review requests put to the judge model: one for a pending tool call,
 * one for a sandbox escalation the model has asked for.
 *
 * Three properties of this text are load-bearing. The material under review is
 * injected as a fenced JSON document and framed as data on both sides of the
 * fence, because it is attacker-reachable and would otherwise read as further
 * instructions. The answer contract is a single JSON object with a closed
 * `decision` enum, because {@link parseJudgeResponse} refuses anything else
 * rather than guessing. And the enum offered here is `allow`/`ask` only: this
 * gate never refuses on the model's word, so a call the reviewer would block
 * becomes an approval prompt carrying its reason.
 *
 * The tool's own description travels inside that fence with the arguments and
 * never in the system prompt: it is written by whoever wrote the tool, which
 * for a third-party plugin is not the person this gate protects. What the
 * system prompt does carry about a particular tool — {@link CONTENT_ACT_GUIDANCE}
 * — is written here rather than read from the registry, and states how to read
 * that tool's arguments rather than what the tool is for.
 * @module @haoran/dsh-llm-permission-gateway/prompt
 */
/**
 * Build the reviewer's system prompt for one pending tool call.
 * @param reasonLanguage - the language the human-facing reason must be written in.
 * @returns the system prompt text.
 */
export declare function judgeSystemPrompt(reasonLanguage: string): string;
/**
 * Build the user message carrying the pending call.
 *
 * An absent description omits the key rather than sending an empty one: a call
 * whose tool the registry does not resolve is reviewed on its name and its
 * arguments alone.
 * @param toolName - the tool about to run.
 * @param args - the parsed call arguments.
 * @param description - the tool's own registered description, or `undefined` when none is available.
 * @returns the user message text.
 */
export declare function judgeUserPrompt(toolName: string, args: unknown, description: string | undefined): string;
/**
 * Cut one description to {@link MAX_DESCRIPTION_CHARS}, marking that it was cut.
 *
 * Exported so a caller can measure and digest the text the review actually
 * carries rather than the registered text it was cut from. Applying it to an
 * already-cut description returns that same text, so a caller that caps before
 * calling {@link judgeUserPrompt} does not cut twice.
 * @param description - the tool's registered description.
 * @returns the description as a review carries it.
 */
export declare function capDescription(description: string): string;
/**
 * Build the reviewer's system prompt for one sandbox escalation.
 *
 * The escalation is a different question from a pending call: the operating
 * system has already refused this command, and what is being decided is whether
 * to run it again with that wall lowered for the named paths or hosts. The
 * agent's own justification travels with it and is attacker-reachable text, so
 * it is inside the fence with everything else.
 * @param reasonLanguage - the language the human-facing reason must be written in.
 * @returns the system prompt text.
 */
export declare function escalationSystemPrompt(reasonLanguage: string): string;
/**
 * Build the user message carrying one sandbox escalation.
 * @param request - the command, the access it asks for, and the agent's justification.
 * @returns the user message text.
 */
export declare function escalationUserPrompt(request: unknown): string;
//# sourceMappingURL=prompt.d.ts.map