#!/usr/bin/env node
/**
 * Read the gateway's verdict record and say what the gate did and what it cost.
 *
 * The record is one JSON object per line, appended by `src/probe.ts`. This
 * script is the reader for it: how many calls each step of the decision order
 * answered, how long the review model took, how many tokens it spent, and how
 * much of that spend went on reviewing the same arguments twice — the shape
 * that shows up under Code Mode, where a `run_code` call and the sub-call it
 * dispatches are two separate reviews of one intention.
 *
 * Zero dependencies and read-only on purpose: it runs under whatever Node the
 * installation has, against a file it never writes, so reading the record can
 * never disturb the gate that writes it.
 * @module @haoran/dsh-llm-permission-gateway/scripts/verdict-stats
 */

import { readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

/** Records listed one per line at the end when `--last` is not given. */
const DEFAULT_LAST = 20

/** Two reviews of the same arguments further apart than this are separate intentions, not one duplicate. */
const DUPLICATE_WINDOW_MS = 60000

/** Duplicate pairs printed individually before the rest are summarized. */
const DUPLICATE_EXAMPLES = 10

/** Characters of reason or argument preview kept on a listed line. */
const TEXT_CHARS = 90

const USAGE = `usage: verdict-stats [path] [--last N] [--since <ISO-8601>]

  path         verdict JSONL to read; defaults to
               $DSH_HOME/llm-permission-gateway/verdicts.jsonl ($DSH_HOME defaults to ~/.dsh)
  --last N     records listed one per line at the end (default ${DEFAULT_LAST}; 0 lists none)
  --since T    ignore records written before this instant, e.g. 2026-08-21T00:00:00Z`

/**
 * Where the gate writes when the profile names no path.
 * @returns the absolute default record path.
 */
function defaultLogPath() {
  const home = process.env['DSH_HOME']
  const base = home === undefined || home.length === 0 ? join(homedir(), '.dsh') : home
  return join(base, 'llm-permission-gateway', 'verdicts.jsonl')
}

/**
 * Parse the command line.
 * @param {string[]} argv - arguments after the script name.
 * @returns {{path?: string, last?: number, since?: number, help?: boolean}} the file to read, how many records to list, and the earliest instant kept — or a request for the usage text.
 * @throws {Error} when a flag is unknown, repeated, or given an unusable value.
 */
function parseArgs(argv) {
  let path
  let last = DEFAULT_LAST
  let since = Number.NEGATIVE_INFINITY
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index]
    if (argument === '--help' || argument === '-h') return { help: true }
    if (argument === '--last' || argument === '--since') {
      const value = argv[index + 1]
      if (value === undefined) throw new Error(`${argument} needs a value`)
      index += 1
      if (argument === '--last') {
        last = Number(value)
        if (!Number.isInteger(last) || last < 0) throw new Error(`--last needs a whole number of records, not "${value}"`)
      } else {
        since = Date.parse(value)
        if (Number.isNaN(since)) throw new Error(`--since needs an ISO-8601 instant, not "${value}"`)
      }
      continue
    }
    if (argument.startsWith('-')) throw new Error(`unknown option ${argument}`)
    if (path !== undefined) throw new Error('give at most one path')
    path = argument
  }
  return { path: path ?? defaultLogPath(), last, since, help: false }
}

/**
 * Read the record file into parsed records.
 *
 * A line that is not a JSON object with an `at` and a `decision` is counted and
 * skipped rather than failing the run: the file is appended to by a live
 * process, so its last line can be half-written while this script reads it.
 * @param {string} path - the JSONL file to read.
 * @param {number} since - earliest instant kept, as epoch milliseconds.
 * @returns {{records: object[], skipped: number}} the usable records in file order, and how many lines were not.
 */
function readRecords(path, since) {
  const text = readFileSync(path, 'utf8')
  const records = []
  let skipped = 0
  for (const line of text.split('\n')) {
    if (line.trim().length === 0) continue
    let parsed
    try {
      parsed = JSON.parse(line)
    } catch {
      // A truncated trailing line is the ordinary case; anything else is a
      // hand-edited file. Neither is worth refusing the whole report for.
      skipped += 1
      continue
    }
    if (typeof parsed !== 'object' || parsed === null || typeof parsed.at !== 'string' || typeof parsed.decision !== 'string') {
      skipped += 1
      continue
    }
    const at = Date.parse(parsed.at)
    if (Number.isNaN(at)) {
      skipped += 1
      continue
    }
    if (at < since) continue
    parsed.epoch = at
    records.push(parsed)
  }
  return { records, skipped }
}

/**
 * Count records by one field.
 * @param {object[]} records - the records to count.
 * @param {string} field - the field whose values are counted.
 * @returns {[string, number][]} value and count, most frequent first.
 */
function tally(records, field) {
  const counts = new Map()
  for (const record of records) {
    const value = record[field]
    if (value === undefined) continue
    counts.set(value, (counts.get(value) ?? 0) + 1)
  }
  return [...counts.entries()].sort((left, right) => right[1] - left[1])
}

/** What a record is counted under when the chain threw instead of answering. */
const CHAIN_ERROR = 'error'

/**
 * The decision one call actually received.
 *
 * A `deny` or an `ask` from further down the chain wins over this gate's own
 * ask, so those two are the outcome, and `allow` there leaves the gate's ask
 * standing. `none` is neither: the chain threw, so nobody was asked and nothing
 * decided the call. Counting it as the gate's own ask would report an approval
 * prompt that never reached anyone, so it is counted as {@link CHAIN_ERROR}.
 * @param {object} record - one record.
 * @returns {string} the decision to count this record under.
 */
function settledDecision(record) {
  if (record.downstream === 'none') return CHAIN_ERROR
  return record.downstream === 'deny' || record.downstream === 'ask' ? record.downstream : record.decision
}

/**
 * Count settled decisions.
 * @param {object[]} records - the records to count.
 * @returns {[string, number][]} decision and count, most frequent first.
 */
function tallyDecisions(records) {
  const counts = new Map()
  for (const record of records) {
    const value = settledDecision(record)
    if (value === undefined) continue
    counts.set(value, (counts.get(value) ?? 0) + 1)
  }
  return [...counts.entries()].sort((left, right) => right[1] - left[1])
}

/**
 * Render a tally as one line.
 * @param {[string, number][]} counts - value and count pairs.
 * @returns {string} the counts, most frequent first, or a dash when there are none.
 */
function renderTally(counts) {
  if (counts.length === 0) return '-'
  return counts.map(([value, count]) => `${value} ${count}`).join('   ')
}

/**
 * One quantile of an ascending list.
 * @param {number[]} ascending - sorted values, at least one.
 * @param {number} fraction - the quantile to take, between 0 and 1.
 * @returns {number} the value at that position, taken from the nearest rank.
 */
function quantile(ascending, fraction) {
  const index = Math.min(ascending.length - 1, Math.max(0, Math.ceil(fraction * ascending.length) - 1))
  return ascending[index]
}

/** Count with its noun, pluralized the English way. */
function count(value, noun) {
  return `${value} ${noun}${value === 1 ? '' : 's'}`
}

/** Format milliseconds as seconds with one decimal. */
function seconds(milliseconds) {
  return `${(milliseconds / 1000).toFixed(1)}s`
}

/** Format an instant as `YYYY-MM-DD HH:MM:SS`, in UTC as written. */
function instant(record) {
  return record.at.replace('T', ' ').slice(0, 19)
}

/** Prompt tokens billed for one record: uncached input plus what the cache served. */
function promptTokens(record) {
  return (record.inputTokens ?? 0) + (record.cacheReadTokens ?? 0)
}

/** Every token one record's review spent, cached prompt included. */
function totalTokens(record) {
  return promptTokens(record) + (record.outputTokens ?? 0)
}

/** Whether a record paid for a review of its own. */
function paid(record) {
  return typeof record.inputTokens === 'number'
}

/**
 * Sum the token columns over the records that paid for a review.
 * @param {object[]} records - every record in range.
 * @returns {{reviews: number, input: number, output: number, cacheRead: number, reasoning: number}} the totals.
 */
function tokenTotals(records) {
  const totals = { reviews: 0, input: 0, output: 0, cacheRead: 0, reasoning: 0 }
  for (const record of records) {
    if (!paid(record)) continue
    totals.reviews += 1
    totals.input += record.inputTokens
    totals.output += record.outputTokens ?? 0
    totals.cacheRead += record.cacheReadTokens ?? 0
    totals.reasoning += record.reasoningTokens ?? 0
  }
  return totals
}

/**
 * Find reviews that answered the same arguments twice.
 *
 * A pair qualifies when two records share an argument digest, carry different
 * call ids, sit within {@link DUPLICATE_WINDOW_MS} of each other, and at least
 * one of them is a nested dispatch (`rootCallId` present) — which is the Code
 * Mode shape, where the outer `run_code` and the sub-call it dispatches are
 * reviewed separately. Records with no digest are ignored.
 * @param {object[]} records - every record in range, in file order.
 * @returns {{pairs: {first: object, second: object}[], wasted: object[]}} the pairs found, and the later record of each pair counted once.
 */
function duplicateReviews(records) {
  const byDigest = new Map()
  for (const record of records) {
    if (typeof record.argsDigest !== 'string') continue
    const group = byDigest.get(record.argsDigest)
    if (group === undefined) byDigest.set(record.argsDigest, [record])
    else group.push(record)
  }
  const pairs = []
  const later = new Set()
  for (const group of byDigest.values()) {
    const ordered = [...group].sort((left, right) => left.epoch - right.epoch)
    for (let index = 0; index < ordered.length; index += 1) {
      for (let next = index + 1; next < ordered.length; next += 1) {
        const first = ordered[index]
        const second = ordered[next]
        if (second.epoch - first.epoch > DUPLICATE_WINDOW_MS) break
        if (first.callId === second.callId) continue
        if (first.rootCallId === undefined && second.rootCallId === undefined) continue
        pairs.push({ first, second })
        later.add(second)
      }
    }
  }
  pairs.sort((left, right) => left.second.epoch - right.second.epoch)
  return { pairs, wasted: [...later] }
}

/**
 * Group records by the session that made the call.
 * @param {object[]} records - every record in range.
 * @returns {[string, object[]][]} session id and its records, busiest first; calls made outside an agent group under `(no session)`.
 */
function bySession(records) {
  const groups = new Map()
  for (const record of records) {
    const session = typeof record.agent === 'string' ? record.agent : '(no session)'
    const group = groups.get(session)
    if (group === undefined) groups.set(session, [record])
    else group.push(record)
  }
  return [...groups.entries()].sort((left, right) => right[1].length - left[1].length)
}

/** The sentence or argument text a listed line ends with. */
function lineText(record) {
  const text = record.argsPreview ?? record.reason ?? ''
  const collapsed = String(text).replace(/\s+/g, ' ')
  return collapsed.length <= TEXT_CHARS ? collapsed : `${collapsed.slice(0, TEXT_CHARS)}…`
}

/** The token column of a listed line, empty for a decision no model was paid for. */
function lineTokens(record) {
  if (!paid(record)) return ''
  const cache = record.cacheReadTokens === undefined ? '' : ` cache=${record.cacheReadTokens}`
  return `in=${record.inputTokens} out=${record.outputTokens ?? 0}${cache}`
}

/**
 * Print the whole report.
 * @param {string} path - the file the records came from.
 * @param {object[]} records - every record in range, in file order.
 * @param {number} skipped - lines that were not usable records.
 * @param {number} last - how many records to list at the end.
 */
function report(path, records, skipped, last) {
  const note = skipped === 0 ? '' : `  (${count(skipped, 'unusable line')} skipped)`
  console.log(path)
  if (records.length === 0) {
    console.log(`no records${note}`)
    return
  }
  const first = records.reduce((left, right) => (left.epoch <= right.epoch ? left : right))
  const lastRecord = records.reduce((left, right) => (left.epoch >= right.epoch ? left : right))
  console.log(`${records.length} records  ${instant(first)} → ${instant(lastRecord)}${note}`)

  console.log('')
  console.log(`by source    ${renderTally(tally(records, 'source'))}`)
  // Settled, not as this gate answered: an ask it raised that the chain then
  // refused was a refusal, and counting it as an ask would say a person was
  // asked when nobody was. A chain that threw is counted as `error` for the
  // same reason.
  console.log(`by decision  ${renderTally(tallyDecisions(records))}`)
  console.log(`by tool      ${renderTally(tally(records, 'tool'))}`)
  const redLines = tally(records, 'redLine')
  if (redLines.length > 0) console.log(`red lines    ${renderTally(redLines)}`)

  // Both sources issue a review request: `model` for a pending call,
  // `escalation` for a sandbox request answered on the user's behalf.
  // `escalationUnreviewed` is deliberately absent — that step hands the request
  // to a person without asking the model, so it has no latency to average.
  const reviewed = records.filter(record => record.source === 'model' || record.source === 'escalation')
  console.log('')
  if (reviewed.length === 0) {
    console.log('model reviews  none')
  } else {
    const latencies = reviewed.map(record => record.latencyMs ?? 0).sort((left, right) => left - right)
    console.log(`model reviews  ${reviewed.length} of ${records.length} records`)
    console.log(`  latency      p50 ${seconds(quantile(latencies, 0.5))}   p90 ${seconds(quantile(latencies, 0.9))}   max ${seconds(latencies[latencies.length - 1])}`)
  }

  if (reviewed.length > 0) {
    const models = new Map()
    for (const record of reviewed) {
      const model = typeof record.model === 'string' ? record.model : '(unnamed)'
      const group = models.get(model)
      if (group === undefined) models.set(model, [record])
      else group.push(record)
    }
    if (models.size > 1) {
      console.log('  by model')
      const width = Math.max(...[...models.keys()].map(model => model.length))
      for (const [model, group] of [...models.entries()].sort((left, right) => right[1].length - left[1].length)) {
        const ascending = group.map(record => record.latencyMs ?? 0).sort((left, right) => left - right)
        const spent = group.reduce((sum, record) => sum + totalTokens(record), 0)
        console.log(`    ${model.padEnd(width)} ${count(group.length, 'review').padStart(12)}  p50 ${seconds(quantile(ascending, 0.5))}  p90 ${seconds(quantile(ascending, 0.9))}  ${String(spent).padStart(8)} tokens`)
      }
    }
  }

  const totals = tokenTotals(records)
  if (totals.reviews === 0) {
    console.log('  tokens       none reported')
  } else {
    const per = value => Math.round(value / totals.reviews)
    const prompt = totals.input + totals.cacheRead
    const cached = prompt === 0 ? 0 : (totals.cacheRead / prompt) * 100
    const reasoning = totals.reasoning === 0 ? '' : `   reasoning ${totals.reasoning}`
    console.log(`  requests     ${totals.reviews} billed, failures that still spent tokens included`)
    console.log(`  tokens       in ${totals.input}   out ${totals.output}   cacheRead ${totals.cacheRead}${reasoning}`)
    console.log(`  per request  in ${per(totals.input)}   out ${per(totals.output)}   cacheRead ${per(totals.cacheRead)}`)
    console.log(`  cached       ${cached.toFixed(1)}% of prompt tokens (cacheRead of in + cacheRead)`)
  }

  const { pairs, wasted } = duplicateReviews(records)
  console.log('')
  if (wasted.length === 0) {
    console.log('duplicate reviews  none (same arguments, different call id, ≤60s apart, one of them a nested dispatch)')
  } else {
    const spent = wasted.reduce((sum, record) => sum + totalTokens(record), 0)
    const digests = new Set(wasted.map(record => record.argsDigest))
    console.log(`duplicate reviews  ${count(wasted.length, 'repeat')} over ${count(digests.size, 'set of arguments')}, ${spent} tokens`)
    console.log('  same arguments, different call id, ≤60s apart, one of them a nested dispatch')
    // One repeated record can match several earlier ones; it is shown once,
    // against the first review it repeats, so the list counts intentions
    // rather than combinations.
    const shown = new Set()
    let listed = 0
    for (const pair of pairs) {
      if (shown.has(pair.second)) continue
      shown.add(pair.second)
      listed += 1
      if (listed > DUPLICATE_EXAMPLES) continue
      const gap = seconds(pair.second.epoch - pair.first.epoch)
      console.log(`  ${instant(pair.second)}  ${pair.first.tool} → ${pair.second.tool}  ${pair.second.argsDigest}  +${gap}  ${totalTokens(pair.second)} tokens`)
    }
    if (listed > DUPLICATE_EXAMPLES) console.log(`  … and ${listed - DUPLICATE_EXAMPLES} more`)
  }
  // The digest catches only identical arguments, and a transport wrapper's
  // arguments are never identical to the sub-call it dispatches — a `run_code`
  // program and the `write` inside it differ by the program around it. So the
  // cost of reviewing one intention twice is reported by counting the
  // sub-calls directly, whatever their arguments say. Only the reviewed ones
  // cost anything: a sub-call the sandbox confines is passed through.
  const nested = records.filter(record => record.rootCallId !== undefined)
  const nestedReviewed = nested.filter(record => record.source === 'model')
  const nestedTokens = nestedReviewed.reduce((sum, record) => sum + totalTokens(record), 0)
  console.log(`nested dispatch    ${count(nested.length, 'sub-call record')}, ${nestedReviewed.length} reviewed, ${nestedTokens} tokens — a reviewed sub-call is reviewed on top of the outer call that dispatched it`)

  const sessions = bySession(records)
  console.log('')
  console.log('by session')
  for (const [session, group] of sessions) {
    const groupTotals = tokenTotals(group)
    const spent = groupTotals.input + groupTotals.output + groupTotals.cacheRead
    console.log(`  ${session.padEnd(46)} ${String(group.length).padStart(5)} records  ${String(groupTotals.reviews).padStart(4)} billed  ${String(spent).padStart(7)} tokens`)
  }

  if (last === 0) return
  const listed = records.slice(-last)
  const tokenWidth = listed.reduce((width, record) => Math.max(width, lineTokens(record).length), 0)
  console.log('')
  console.log(`last ${listed.length} records`)
  for (const record of listed) {
    const columns = [
      instant(record),
      String(record.tool ?? '?').padEnd(16),
      // Widths hold the longest values the gate writes: `escalationUnreviewed`
      // and `cancelled`.
      String(record.source ?? '?').padEnd(20),
      String(record.decision).padEnd(9),
      seconds(record.latencyMs ?? 0).padStart(7),
      ...tokenWidth === 0 ? [] : [lineTokens(record).padEnd(tokenWidth)],
      String(record.argsDigest ?? '-'.repeat(12)),
      lineText(record),
    ]
    console.log(`  ${columns.join('  ')}`.trimEnd())
  }
}

/** Read the file named on the command line and print the report. */
function main() {
  let options
  try {
    options = parseArgs(process.argv.slice(2))
  } catch (error) {
    console.error(`${error.message}\n\n${USAGE}`)
    process.exitCode = 1
    return
  }
  if (options.help === true) {
    console.log(USAGE)
    return
  }
  let read
  try {
    read = readRecords(options.path, options.since)
  } catch (error) {
    console.error(`cannot read ${options.path}: ${error.message}`)
    process.exitCode = 1
    return
  }
  report(options.path, read.records, read.skipped, options.last)
}

main()
