# @haoran/dsh-llm-permission-gateway

English | [中文](README.zh.md)

A permission gate for DeepSeek Harness that reviews the tool calls no operating-system wall confines, and answers the sandbox's own escalation prompts on your behalf.

Two questions reach a review model configured apart from the agent's own, and changeable from the settings page. First, every side-effecting call the sandbox does not cover — a `run_code` program body, a call that leaves the machine, a call that acts with a login you own — is judged `allow` or `ask`, with one sentence saying what running it would cost. Second, when a confined `bash`, `pwsh`, `write`, or `edit` call is refused for reaching outside its walls and the agent asks for that refusal to be lifted, the same model answers instead of you, and hands the question over whenever it is unsure.

Rule tables were rejected for the first job because they accumulate until their entries contradict each other and nobody can say what the set as a whole permits; a review model has no such maintenance surface, at the price of latency, money, and a judgment that is not always the same twice.

## Where it sits

`tools/pre-execute` is the only extension point that sees a call's arguments — the approval seam downstream of it is deliberately blind to them, receiving a tool name, a call id, and one sentence. The gate registers there with `prepend: true`, so a listener registered earlier cannot allow a call past it. It also registers on `approval/request`, prepended, which is where a sandbox escalation arrives.

Without this plugin, two things reach a human, and neither covers an ordinary tool:

- A listener returning `{kind:'ask'}` from `tools/pre-execute`. In the harness that is `hooks-claude-code`, `hooks-codex`, and `tool-jobs`, and nothing else.
- The sandbox-escape path, where a refused `bash`, `pwsh`, `write`, or `edit` call asks for a wider mode. A human sees the call only at that point, not when it was made.

A capability plugin that does neither — the normal case — contributes tools that no gate ever examines.

## What has a wall and what does not

The gate spends review where nothing else is watching. Which calls those are is read from the running installation, per call, through `ctx.sandboxPolicy.resolve({ session })`.

| | Confined by the sandbox | Reviewed by this gate |
| --- | --- | --- |
| `bash`, `pwsh` | Yes — the subprocess runs under confined argv | Only under `danger-full-access`, or where no sandbox policy is composed |
| `write`, `edit`, `str_replace_editor` | Yes — through the filesystem seam the same policy covers | Same |
| `terminal_open`, `terminal_send` | Yes — the shell is spawned confined | Same |
| `run_code` program body | **No** — it runs on a `node:worker_threads` worker inside the harness process, reaching `node:fs`, `node:child_process`, and `fetch` directly | Always |
| `web_fetch`, `screenshot`, `browser_*`, and other capability tools | No | Always |

`run_code` is the load-bearing row. The shipped `@deepseek-ai/dsh-code-runtime-worker-thread` backend compiles the program as an ordinary async function in the worker's own realm and injects only the tool bindings, the declared error classes, and a `console` shim; there is no `node:vm` isolation and no module allowlist. Its own README states the authority plainly: a program runs with authority comparable to the bash tool. The sandbox seam cannot reach it either — `SandboxProvider.confine()` wraps subprocess argv, and nothing in the code runtime calls it.

Sub-calls a `run_code` program dispatches reach this gate individually, and the same rule decides them. A `bash` sub-call under `workspace-write` is walled and passed through; a `web_fetch` sub-call is reviewed. The duplicate review a wrapper and its sub-call used to cost is left only where neither has a wall.

Under `danger-full-access` there is no wall at all, so every call is reviewed again.

## Decision order

1. **Cancelled.** A call whose caller signal is already aborted is delegated untouched.
2. **Red lines.** Two categories are refused without consulting the review model and without consulting configuration.
3. **`alwaysAsk`.** Tools that always deserve a human glance, asked with the cost sentence configured for them.
4. **Manual mode.** With `/review manual` in force, everything below is skipped and the call is delegated.
5. **`readOnlyTools`.** Skipped, delegating to the rest of the chain.
6. **`walledTools` under a sandbox.** Skipped, and the arguments are remembered in case an escalation follows.
7. **Oversized arguments.** Held rather than reviewed in a shortened form.
8. **Cache.** A verdict already reached for the same tool and arguments in the same agent run.
9. **Review model.** One call, one JSON verdict.

An allow returns `next()`, and an ask is put to `next()` before it is raised, so every other listener on the waterfall still decides either way. What the chain answers then settles the call:

- **The chain's `deny` wins.** The gate can add denials; it never removes another plugin's.
- **The chain's `ask` wins, reason and all.** It is the more specific question, raised by the listener that will act on the answer.
- **Only where the chain allows** does the gate raise its own ask, carrying the review model's reason.

A listener that records its call's pending approval and then checks that record when the tool runs is what the second rule is for: a gate that answered the question in its place would leave the person's approval buying a refusal. The record keeps `downstream` so a replay says which of the three happened.

The second rule has a cost, and it is accepted rather than worked around: where the chain's ask wins, the review model's reason goes to the record and never to the prompt, so the person decides on the other listener's sentence. A listener registered after this gate can replace this gate's reason with its own for the same reason — it answers later, and the later answer is the one raised. The host-log line writes that outcome as `ask→deny(downstream)`, so a chain answer that overrode this gate is visible without opening the file.

A refusal is the one answer that stops the chain — the two red lines, and `onFailure: deny` — because the call will not run whatever the rest of the chain thinks of it.

## What the review model is shown

One review carries one JSON document: the tool's name, the arguments the call would run with, and — when the registry resolves one — the tool's own `description`, the same sentence its author wrote for the agent.

The description is read per review through `ctx.tools.get(name, agent)`, with the calling agent as the scope, so a scoped definition shadowing a global one reads here exactly as it did for the call. A tool the registry does not hold, and one whose description is blank, are both reviewed on name and arguments alone: the document then carries the two keys and no third.

The verdict cache does not follow it. An entry is keyed by tool name and argument digest and by nothing else, so a description rewritten, shadowed, or unregistered after a verdict was reached keeps answering with that verdict for the rest of that agent's run. Each record names the description its own verdict was reached against, and `cacheEntries: 0` is what makes every call read the registry again.

It sits inside the fence with the arguments, framed as data on both sides, and never in the system prompt: a description is written by whoever wrote the tool, which for a third-party plugin is not the person this gate protects. The reviewer is told what it is — the author's account of what the tool does, which is how it tells reading from writing for a tool it has never seen — and told that it describes the tool rather than this call, so it is never a reason to allow these arguments.

**One tool has its own reading.** The system prompt tells the reviewer how to read a `content_act` batch: that tool acts on the page the person is looking at, in their place, so the question is what the whole batch would make that page do. `dialogs: "accept"`; a click whose label reads 提交, 支付, 删除, 登录, 授权 or the rest of that list; a fill into 密码, 验证码 or 银行卡; an Enter pressed alongside either; a step the page names nothing, which arrives as an empty `label` beside a `mark`; and a batch that both fills an input and clicks a button the routine list does not name — each of those is an ask. Switching a tab, sorting, paging, opening a detail, running a search, applying a filter, filling a search box, and waiting are routine. A label the reviewer cannot read is an ask.

That text is fixed rather than assembled for the tool under review. A prompt that changed with the tool would be chosen by the call itself, and it would split the identical prefix every review sends. It is also this package's own account of how to read a set of arguments, not the tool author's account of what a tool is for — which is why it can sit in the system prompt where a `description` cannot.

A description is cut at 4000 characters, and it does not count toward `maxArgumentsChars`. That limit holds a call back instead of shortening it because the part left out of the arguments is where a payload would sit; a description is registration text the call cannot change, and its own ceiling answers a different question — one running to thousands of characters would push the arguments it explains out of the reviewer's context.

## The review model cannot refuse

The reviewer answers `allow` or `ask`. An answer of `deny` — which the parser still accepts, because a model told to give two values may give three — becomes an `ask` carrying the model's own reason, and the record keeps `downgraded: true` so the file still says which answer the model gave.

A wrong reading therefore costs an approval prompt, never a blocked call. The two red lines are the only unconditional denials in this plugin, and they consult neither the model nor the configuration.

## Answering the sandbox, not itself

The escalation answerer claims exactly one shape of approval request: a reason reading `escalate sandbox to <mode>: <justification>`, which is what `approveEscalation` writes. Every other approval — a hook bridge's, the jobs tool's, or this gate's own `ask` — falls through to whoever normally answers.

Three more conditions must hold before the model is asked at all. Each failure hands the request to a person and records `source: "escalationUnreviewed"`.

- **The call must be remembered.** The refused command comes from this gate's own note, taken when the call was passed through as walled — the approval request itself carries no arguments. Without that note the review would be judging the agent's account of itself against a prompt that says the command is in front of it. A restart between the call and its escalation, `cacheEntries: 0`, and a `manual` → `auto` switch mid-call all reach that state.
- **The remembered tool must be the tool the request names.** The note is keyed by agent and call id; a request naming a different tool for that id is not describing the call the note holds.
- **The request must not be this gate's own `ask`.** That reason is written by the review model over arguments an attacker can reach, so a reason shaped like the sandbox's sentence would otherwise come back through this listener and could be granted without a person. Every ask is registered against its agent and call id — by identity, not by comparing the words of the reason — and a request under one is handed on untouched.

**Two answers here do not delegate.** An `allow` verdict returns `allowed-once`: answering in the person's place is what this listener is for, and delegating would hand back the prompt the review had just decided not to raise. Under `onFailure: deny`, a review that produced no verdict returns `rejected`: `deny` is the deployment's explicit instruction to refuse when the reviewer cannot be reached, so delegating would put the question to a person the configuration said not to ask. The rule that the review model cannot refuse governs the model's verdicts, not that switch.

**The two notes are per agent, not per call id.** A call id is unique inside one agent and nowhere else: two sessions, or a session and a subagent, routinely mint the same string. Both notes bucket by the agent object, so one session's remembered command can never answer another's escalation, and a bucket vanishes with the agent that owns it. A call made outside an agent falls into one shared bucket, having no session to be confused with.

Both notes exist only between a call and the approval it may raise; `tools/result` closes that window whatever the outcome was.

## Failure never opens the gate

`onFailure` ranges over `ask` and `deny`. There is no `allow` to configure, so a timeout, an unreachable model, an unparsable answer, or arguments too large to review cannot become an allow. This matters more than the review itself: against a fail-open gate an attacker does not have to convince the reviewer, only to make it slow.

Failures are not cached. A single slow moment decides one call, not every later occurrence of it.

For an escalation, `onFailure: ask` hands the request back to the person and `onFailure: deny` refuses it outright.

## A call cancelled under review

Nothing this gate can return makes a cancelled call quieter. The registry re-checks the caller signal after the waterfall settles and materializes its own `ABORTED_BEFORE_DISPATCH` result; returning `ask` would raise an approval prompt for a call already given up on, and `deny` would replace that cancellation with a second, gate-authored error. So the gate delegates, and the record carries `source: "cancelled"` with `decision: "cancelled"` — not the `allow` a skip records, because no verdict was reached.

The same holds when the abort lands mid-review: the judge reports `cancelled`, and the gate delegates rather than failing closed.

## Red lines

Neither is configurable, and neither can be disabled. Both hold in `auto` and in `manual`.

**Credential exfiltration** — reading a credential store and sending data off the machine in the same call. Detection is narrow on purpose: it needs a store read (`~/.ssh/id_*`, `~/.aws/credentials`, `.netrc`, a keychain lookup, an environment dump, and similar) together with a way off the machine. An `Authorization: Bearer $TOKEN` header names a secret but reads no store, so an ordinary authenticated API call goes to the review model rather than being refused outright.

**Permission-system self-modification** — any argument that reaches this package's own directory, `$DSH_HOME/profiles`, or `$DSH_HOME/settings.yaml`, by resolved path or by literal text including `$DSH_HOME/profiles`, `cordis.patch.yml`, and this package's name. These locations are derived at load from the running installation, not written down as literals.

The second red line exists because a permission plugin that can be edited by the agent it governs is not a permission plugin. Reads are refused along with writes: whether a given `bash` command writes is not decidable from its arguments, and an agent reading the permission configuration is reconnaissance either way. The cost is real — `ls ~/.dsh/profiles` is refused too — and it is not adjustable.

The review model is told about both categories as well, so it can catch forms the scanner does not match; there it answers `ask`, which is the strongest answer it has.

## Turning review on and off

The settings page named **Automatic review** is the switch, and `/review` is the same switch from the composer.

```
/review           # what is in force right now
/review auto      # the review model answers calls and escalations
/review manual    # neither; red lines and alwaysAsk still hold
```

The command echoes in Chinese, names what each mode does, and restates that the two red lines hold in both. It is a slash command rather than a permission preset because the host resolves a preset by looking its `(sandbox, approval)` pair up in a table: a second row sharing a pair makes both resolve to `custom` and neither stays selectable, and the one free pairing — `approval: never` — removes the channel `alwaysAsk` needs.

The choice is stored in this plugin's own settings namespace (`llm-permission-gateway`) where a settings provider is composed, and held for the process otherwise; the command's reply says which. Without a commands registry the command is not registered, and without a browser the page is not registered; either way the other entry still throws the switch, and with neither the mode is whatever `config.mode` says.

**`auto` is the default.** Mounting this bundle is a deliberate act, and a default of `manual` would make it change nothing until a command was typed. Under `auto` the gate reviews strictly less than it used to — the sandbox keeps everything it already covered — so the default costs the reviews the sandbox cannot make.

## Choosing the review model

The settings page carries the second choice this plugin owns: which model reviews. It lists the providers whose model catalog this installation could read, grouped by provider; a provider with an adapter and an empty catalog appears nowhere. A provider whose own catalog failed to load is named without being offered, unless it is the provider the stored route already names.

Picking a model stores the pair and decides the next call; nothing restarts. Picking **Use the installed setting** clears the pair, and `config.provider`/`config.model` review again.

`config.provider` and `config.model` stay required. They are what a fresh installation is reviewed on, what is in force where no settings provider stores a choice, and what a stored pair falls back to.

**A stored provider no adapter serves falls back rather than blocking.** The host log carries one line naming it — once per provider id, not once per call — and the settings page says the installed setting is in use. Which model reviews is not a decision this gate is allowed to make: it can only ask either way, so a stale choice costs a log line rather than a refused call.

**A stored model id is never checked.** A provider's catalog is advisory and a route can serve a model it stopped advertising, so an id absent from the list is still offered as the stored choice and still issued. An id that really is wrong fails on the first review and reaches `onFailure` the way any other review failure does.

**Effort follows the provider, not the model.** An effort id is defined by a provider, so picking another model on the configured provider keeps `reasoningEffort`; only picking another *provider* takes that provider's own default. The picker says so where the catalog reports a model that can think before it answers: review on it is slower and costs more.

**Changing the model drops every remembered verdict.** An answer one reviewer gave is not an answer the next one has given, so both verdict caches are emptied. Records keep naming the model that actually reviewed. Three things count as a change: a settings commit; `llm/adapters-updated`, which moves what the route settles to with nothing written to settings; and a settings provider mounting or remounting with a document that already names a route, which moves it without a commit either.

**The page loads the model list once, when it opens.** An adapter that registers or retires routes while the settings panel is open leaves the list as it was; reopening the panel reloads it. There is no browser-side equivalent of `llm/adapters-updated` to refresh it on, and a picker open for a few seconds is not worth polling for — a stale choice falls back with one log line rather than blocking a call.

## Configuration

```yaml
- id: llm-permission-gateway
  name: '@haoran/dsh-llm-permission-gateway'
  config:
    provider: deepseek-official
    model: deepseek-v4-flash
```

| Field | Default | Meaning |
| --- | --- | --- |
| `provider` | required | Registered LLM provider route the review model is reached on wherever the settings page holds no choice. |
| `model` | required | Model id for reviews wherever the settings page holds no choice, chosen independently of the agent's own model. |
| `mode` | `auto` | The mode a fresh installation starts in, and the one in force where no settings provider stores a choice. |
| `reasoningEffort` | `off` | Provider-owned effort id; `''` takes the provider default. |
| `timeoutMs` | `30000` | Wall-clock budget for one review. |
| `maxOutputTokens` | `256` | Output cap for the verdict. |
| `reasoningBudgetTokens` | `2048` | Extra output tokens one retry adds after a verdict that hit the cap having spent thinking tokens; `0` never retries. |
| `maxArgumentsChars` | `200000` | Serialized-argument size above which a call is held instead of reviewed. |
| `onFailure` | `ask` | `ask` or `deny`. No third value exists. |
| `readOnlyTools` | `read`, `read_image`, `glob`, `grep`, `todo_write`, `plan`, `ask_user_question`, `show_chart`, `job_output`, `content_show`, `web_search` | Tools passed straight through: they read local state, draw into the conversation you are already looking at, or — `ask_user_question` — put text in front of the person at the keyboard. |
| `walledTools` | `bash`, `pwsh`, `write`, `edit`, `str_replace_editor`, `terminal_open`, `terminal_send` | Tools the sandbox confines, passed through un-reviewed while it does. |
| `alwaysAsk` | `browser_auth` | Tool name to the cost sentence shown when it is asked about. |
| `cacheEntries` | `512` | Per-agent cap on remembered verdicts, and on the confined calls remembered so an escalation review can read what they asked for. `0` disables both: every call is reviewed afresh, and every escalation goes to a person. |
| `reasonLanguage` | `简体中文` | Language the review model writes the reason in. |
| `verdictLog` | `$DSH_HOME/llm-permission-gateway/verdicts.jsonl` | JSONL file every decision is appended to; `false` writes no file. |
| `verdictLogArgsPreview` | `0` | Characters of each call's serialized arguments kept in its record; `0` keeps none. |

`cacheEntries` does not bound the record of this gate's own asks. That one is a fixed internal limit, because a profile that could set it to zero could switch off the guard that keeps the escalation answerer from granting this gate's own question. Its entries live only from the moment an `ask` is returned to the moment the call settles, so the live count is the number of approvals open at once.

`alwaysAsk` maps a name to a sentence rather than listing names, because the approval event carries only a tool name and a call id. Without a sentence the user is asked to approve `browser_auth` with no way to know that answering yes hands over a live logged-in session. An entry with an empty sentence fails at load.

`reasoningEffort` defaults to `off` because reviewing one call is a single classification, and thinking tokens otherwise crowd the verdict out of `maxOutputTokens` — which fails closed, so the symptom is an approval prompt on every call rather than a silent allow.

`reasoningBudgetTokens` reads a reported thinking count, not a known one. An adapter that does not translate its provider's thinking counter reports none, so a review model that thinks first is truncated and never widened, and every call reaches an approval prompt — fail-closed, and the same symptom this field exists to remove. The DeepSeek adapter reports it (`completion_tokens_details.reasoning_tokens`); an adapter that does not needs `maxOutputTokens` raised instead.

`reasoningBudgetTokens` covers the route where `off` is not in force or not honoured: the provider counts thinking inside the output cap, so a reviewer that thinks first can spend the whole cap before it writes the verdict. Measured on 2026-09-06, `deepseek-v4-pro` reached the 256-token cap having spent 232 of them thinking, on every review. One retry under `maxOutputTokens + reasoningBudgetTokens` follows a truncated answer that spent thinking tokens, inside the same `timeoutMs`; a truncated answer that spent none is not retried, because more room there buys more prose. The default carries a thinking trace an order of magnitude longer than the measured one, and a cap is a ceiling rather than a spend, so room a review does not use costs nothing.

`maxArgumentsChars` and `timeoutMs` are set from measurement rather than from caution. A low argument cap defeats the plugin: the `code` preset's `run_code` calls routinely carry 9-10K characters, so an 8000 cap sends exactly the calls most worth reviewing past the model and into a manual approval prompt. `deepseek-v4-flash` reviews a 200K-character call whole in roughly 5-8 seconds, which the 30-second budget covers.

`reasonLanguage` governs only the review model's own sentence. Everything this plugin writes itself — a red line, an oversized call, a review that produced no verdict, the `/review` echo, the `browser_auth` sentence — is compiled Simplified Chinese, so the default keeps both halves in one language. Setting another value leaves this plugin's own strings in Chinese.

Separating the review model from the agent's model does not defend against a compromised provider. It keeps one model's blind spots from being both the attack surface and the check on it, and a small model keeps review inside the latency budget.

## `ask` needs somewhere to ask

`ask` reaches a human only where an approval answerer is composed. In the harness today that is the Web surface (`@deepseek-ai/dsh-web-app`, through `dsh-host-apiproxy`) and the ACP bridge. Under `@deepseek-ai/dsh-headless`, and in any composition with no answerer, the approval service records the question and returns `unavailable`, so **`ask` is equivalent to `deny`**. The call is refused, the session log still carries the `approval/asked` and `approval/decided` pair, and the model is told an approval channel was unavailable.

That is the correct fail-closed behaviour, and it means a headless deployment gets a gate that refuses rather than a gate that asks. Choose `onFailure` and `alwaysAsk` knowing this.

**Where no answerer is composed, the escalation answerer changes an outcome rather than a prompt.** Without it, a sandbox escalation in that deployment ends at `unavailable` and the tool throws `sandbox escalation to "<mode>" requires approval, but no approval channel is available` — the retry always fails. With it, the review model can return `allowed-once` and the retry runs, with no person in the loop at any point. That is a real widening of a headless or server deployment, and it is the one place this plugin grants rather than asks. `/review manual` turns it off; `onFailure: deny` only covers the case where no verdict was obtained.

**Under the shipped `danger-full-access` preset the answerer is never called.** That preset pairs the open sandbox with `approval: never`, and `ApprovalService.decide` returns `rejected` for a `never` policy *before* dispatching the waterfall — deliberately, so a prepended listener cannot weaken the policy. In that state every `ask` this gate returns is a hard refusal, and no escalation is raised at all because the sandbox is off. The `yolo-access` row is `{danger-full-access, ask}` precisely so that asks still reach a person there.

## The preset row it ships

The patch file carries one preset alongside the plugin row: `yolo-access`, `{sandbox: danger-full-access, approval: ask}`, named 关闭沙箱（不推荐）.

It is a plain "sandbox off" row and nothing more. With the sandbox off the gate reviews every call again and can still only ask, so nothing about that state is automatic.

**The row stays because removing it strands a user who selected it.** `permission.defaultPreset` is stored in the settings document under a schema that is a closed union over this table's names, and `SettingsProvider.register` rejects a stored section the schema no longer admits instead of falling back — the `permission` settings section then fails to install, the stored default is silently dropped, and the settings page loses its permission section.

It is offered, never imposed. The patch leaves `defaultPreset` unset and declares `yolo-access` last, so the default stays whatever the composed sandbox and approval defaults resolve to — `workspace-write` under `@deepseek-ai/dsh-base`. The row also carries `glyph: danger-full-access`, so the preset control draws the full-access shield beside it.

An id-targeted patch replaces the target row's whole `config`, so the patch restates the three presets `@deepseek-ai/dsh-base` composes, unchanged. That copy is what goes stale: a base release that adds a preset, renames one, or changes a knob pair is shadowed by this file until it is updated, and the symptom is a preset control that quietly keeps offering the old table. `tests/preset-patch.spec.ts` holds the second copy that makes such a change a deliberate two-place edit.

## Cost

Measured against `deepseek-v4-flash` with thinking off: 484 prompt tokens in, roughly 30 out, **median 1.12s** per review (min 0.83s, max 1.33s over six samples). A tool description, where the registry holds one, adds its own tokens to the prompt side of that count, and so does the `content_act` section of the system prompt, which was added after that measurement and is carried by every review.

Four things keep that from multiplying: sandbox-confined tools are never reviewed, read-only tools are never reviewed, the verdict is a single turn rather than a conversation, and a repeated call with identical arguments reuses the verdict for the rest of the agent's run.

Replaying one recorded 97-call session under this version's rules: 81 model reviews become 52 under `workspace-write` (28 nested `bash`/`edit` sub-calls become `walled`, three `job_output` records become `readOnly`), and 80 under `danger-full-access`.

**That replay counts no escalation reviews.** This version adds one review per sandbox escalation the model answers, and the recorded file holds none to replay: the version that wrote it answered no escalations and stored no arguments, so a `sandbox_permissions` retry cannot be told apart from any other `bash` call in it. How many a real session raises depends on how often the agent reaches outside its workspace.

## Observability

Every decision appends one JSON line to `$DSH_HOME/llm-permission-gateway/verdicts.jsonl` and writes one summary to the host log — `dsh-server.log` in the desktop app, stdout when `dsh` runs in a terminal.

```
verdict allow run_code 1.2s (model) in=36 out=30 cache=448
verdict allow bash 0.0s (walled)
verdict ask browser_auth 0.0s (alwaysAsk)
verdict allow bash 1.1s (escalation) in=41 out=28 cache=448
verdict ask edit 0.0s (escalationUnreviewed)
verdict ask demo_upload 20.0s (failure: timeout)
verdict ask→deny(downstream) content_act 1.0s (model) in=39 out=27 cache=448
```

A step that answered without a review shows no token figures, because it spent none.

```sh
tail -f ~/.dsh/llm-permission-gateway/verdicts.jsonl
```

| Field | Meaning |
| --- | --- |
| `at` | When the decision was reached, ISO-8601. |
| `tool`, `callId` | The call, by the same id the approval seam and the session log carry. `callId` is absent only for an escalation whose approval request named no call. |
| `rootCallId` | The enclosing model-requested call; present only for a nested dispatch such as a `run_code` sub-call. |
| `agent` | Session id of the agent the call belongs to; absent for a call made outside an agent. |
| `argsChars` | Serialized size of the call, the number `maxArgumentsChars` is compared against. For an escalation record, the size of the escalation document. |
| `argsDigest` | First 12 characters of the arguments' SHA-256 — the cache key's argument half. Two records sharing it were offered the same arguments. For an escalation record it digests the escalation (tool, requested mode, justification), so a repeated request is countable. |
| `descriptionChars` | Length of the tool's own description as the review carried it, after the 4000-character ceiling. Absent on every record no review carried a description: every skip, every cache hit, every escalation, and every review of a tool the registry resolved none for. |
| `descriptionDigest` | First 12 characters of that description's digest, taken by the function the arguments' digest uses — SHA-256 over the canonical JSON of the text; absent wherever `descriptionChars` is. Two records sharing it were reviewed against the same description text. The text itself is never written to the file: it is registration text a replay can read from the registry, and what the record has to say is which version the reviewer had. |
| `source` | Which step answered: `cancelled`, `redline`, `alwaysAsk`, `manual`, `readOnly`, `walled`, `oversize`, `cache`, `model`, `failure`, `escalation`, `escalationUnreviewed`, `escalationFailure`. |
| `decision` | `allow`, `ask`, `deny`, or `cancelled`. A `readOnly`, `walled`, or `manual` skip records `allow`, because delegating admits the call; a `cancelled` record says the call was abandoned, which is not a verdict this gate reached. |
| `downgraded` | Present when the review model answered `deny` and the gate turned it into an `ask`. |
| `downstream` | What the rest of the chain answered when the gate put its ask to it: `allow`, `ask`, `deny`, or `none` for a chain that threw instead of answering. Absent on a record written without delegating. A `deny` or an `ask` here is the decision the call received, because the chain's answer wins over the gate's own ask. |
| `requestedMode` | The wider sandbox mode asked for; present only on an escalation record. |
| `latencyMs` | Wall-clock time the gate held the call, review round trip included. |
| `model` | On a record a review was issued for, the model it was issued on. On every other record, the route in force when the record was written — what would have reviewed, not who did. |
| `inputTokens`, `outputTokens` | What the review request spent. Present only where a request was issued: every `model` and `escalation` record, and a failure whose stream reported usage before it broke. |
| `cacheReadTokens` | Prompt tokens the provider served from its cache. The counts are disjoint, so one review's billed prompt is `inputTokens + cacheReadTokens`. |
| `reasoningTokens` | Thinking tokens inside the answer, counted inside `outputTokens` rather than beside it; absent at the default `reasoningEffort: off`, which produces none. |
| `budgetRetried` | Present when the review took two turns: the first answer hit the output cap having spent thinking tokens, and `reasoningBudgetTokens` bought a wider second one. The token counts on such a record cover both turns. |
| `redLine` | `credential-exfiltration` or `permission-self-modification`; present only on `redline`. |
| `failureCause` | `timeout`, `cancelled`, `model-error`, or `unparsable-answer`; present only on `failure` and `escalationFailure`. |
| `reason` on an `escalationUnreviewed` record | Which of the three preconditions the request failed. It is written to this file only: the request is delegated unchanged, so the person at the approval prompt still sees the host's own `escalate sandbox to <mode>: <justification>` and nothing this gate wrote. |
| `reason` | The sentence attached to the decision, truncated at 300 characters. |
| `argsPreview` | Opening characters of the serialized call, whitespace collapsed; present only when `verdictLogArgsPreview` is above zero. |

**`verdictLogArgsPreview` records the user's own argument text.** A digest says two calls were identical without saying what either one asked for, which is enough to count repeated reviews and not enough to read one. The preview closes that gap and is as sensitive as the session log while it does so — a `write` call's preview is the opening of the file being written. The record is created with the process umask under `$DSH_HOME`, so it is protected by whatever protects that directory and by nothing this plugin adds; the host-log summary never carries the preview. Leave it at `0` unless a specific question needs it, and set it to the smallest number that answers the question — `200` is enough to see which file and which command a record was about.

### Reading the record

`scripts/verdict-stats.mjs` reports what a record file says. It is a zero-dependency Node program, installed as the `dsh-gateway-verdicts` command, and it only reads.

```sh
dsh-gateway-verdicts                                  # $DSH_HOME/llm-permission-gateway/verdicts.jsonl
dsh-gateway-verdicts --since 2026-08-21T00:00:00Z --last 50
node scripts/verdict-stats.mjs /path/to/verdicts.jsonl --last 0
```

A profile install puts the command in the profile's own `node_modules/.bin`; from a checkout of this workspace, run the file with `node`. The agent cannot run it either way: `$DSH_HOME/profiles` and this package's own directory are both inside the self-modification red line, so a tool call naming either path is refused. Reading the record is something you do, from a terminal.

**An allow is visible nowhere else.** A denial surfaces to the model as a tool error and an `ask` reaches the session log as an `approval/asked` pair, but a call this gate allowed is indistinguishable in the session log from one it never saw. A session event would be the natural home and is not available to an out-of-tree plugin: a `SessionEventMap` member is required-on-read, the harness registers event types in its own tree, and an unknown non-ignorable event makes the host refuse to replay the whole log. Hence a file this package owns, which nothing in the harness reads back.

**The record is an observation, never a control.** Each write is contained, an unwritable path is reported once and then ignored, and no decision depends on the result — a gate that could be jammed by filling a disk would be worse than one that keeps no record. The file is outside the self-modification red line for the same reason: it is evidence of what happened, and red-lining it would claim a tamper-resistance this plugin cannot provide.

## What this gateway does not stop

**It gates what the model asks for, not what a plugin does.** A plugin's own work — inside its HTTP route handlers, background timers, and event listeners — produces no tool call at all, so `tools/pre-execute` never sees it. A plugin calling `node:fs` or `node:child_process` directly bypasses this gate *and* the sandbox-escape path, because it never enters the `ctx.fs` or `ctx.shell` seams either. This is not a gap to be closed here; it belongs to sandboxing and process isolation. Reviewing a third-party plugin still means reading it for bare `fs`/`child_process` use and for registered HTTP routes.

**A walled tool is only as confined as the sandbox is.** The gate reads the mode and the mounted executor's `sandboxMode` and trusts both. It does not read `SandboxEnforcement`, which reports `partial` where a backend or kernel cannot govern every promised file effect — `windows-acl` reports `partial` on every Windows host, and an older Landlock ABI does on Linux. Where the wall is partial, a skipped review is a review not performed; `walledTools: []` restores review at that cost.

**Red-line detection is textual.** The self-modification scanner matches resolved paths and literal spellings. It does not follow indirection: a path assembled at runtime, `cd` followed by a relative path, a base64 blob, or a helper script written first and run later can all reach a protected location without matching. The review model is the second layer here, not a proof.

**A verdict is a judgment.** The reviewer can be wrong in both directions, and the same call can be judged differently twice. It is a filter, not a decision procedure — and since it cannot refuse, a wrong `allow` is the failure that costs something.

**An escalation is judged on the agent's own account of itself.** The request carries the requested mode and the agent's `justification`; the refused command comes from this plugin's own memory of the call, and is absent when the call was not remembered (a restart between the call and the escalation, or a `cacheEntries: 0` profile). Nothing in the request says which path the sandbox actually refused.

**Injected text is weighed, not neutralised.** Arguments and justifications are framed as data on both sides of the fence and the model is told that a claim of prior approval is itself an attack signal. That is a defence with a success rate, not a boundary.

**Caching trusts the arguments.** A call whose arguments are byte-identical to one already allowed in the same agent run is allowed again without review, even though the world may have changed in between.

**The gate sees one call at a time.** A sequence that is harmful only in aggregate — reading a file, then writing it elsewhere, then sending the copy — is reviewed as three separately reasonable calls.

**The decision record sits beside the session log, not in it.** A session copied to another machine carries no evidence of what the gate allowed, and deleting the file loses that history with nothing to reconstruct it from.

## Changelog

### 0.3.1

- **A model picked on the configured provider keeps the configured `reasoningEffort`.** Picking one dropped it and took the provider's own default, and a provider whose default is to think first spends the review's whole output cap on thinking: the verdict is truncated, truncation fails closed, and every call reaches an approval prompt. Only a change of provider takes that provider's default now, because that is where a provider-owned effort id stops meaning anything.
- **A verdict crowded out by thinking is asked once more with room for it.** New `reasoningBudgetTokens`, default `2048`: an answer that hit `maxOutputTokens` having spent thinking tokens is re-issued under `maxOutputTokens + reasoningBudgetTokens`, inside the same `timeoutMs`. An answer truncated without thinking tokens is not retried. New record field `budgetRetried`, whose token counts cover both turns.
- **The settings picker says when a picked model can think first.** The catalog reports a model's selectable reasoning efforts; one with more than one gets a line saying review on it is slower and costs more.
- **A settings provider arriving with a route of its own drops the cache too.** Mounting one is not a commit, so nothing announced it: a stored document that already named a route moved what the next call was reviewed on while the verdicts reached under the configured reviewer stayed cached, ready to be served as that route's answers.
- **`dsh-gateway-verdicts` counts a thrown chain as `error`.** `downstream: "none"` was counted under the gate's own `ask`, which reported an approval prompt nobody ever saw: the chain threw, so nothing decided the call.

### 0.3.0

- **The review carries each tool's own description.** It is read per review through `ctx.tools.get(name, agent)`, so a scoped definition shadowing a global one reads here as it did for the call, and it travels inside the fenced JSON with the arguments rather than in the system prompt — it is the tool author's text, not this package's. It is capped at 4000 characters on its own, outside `maxArgumentsChars`, and it is no part of the cache key. New record fields: `descriptionChars` and `descriptionDigest`, absent on every record that carried no description.
- **An ask goes down the chain before it is raised.** Every `ask` this gate produces — from `alwaysAsk`, an oversized call, a review failure, or a verdict — now calls `next()` first and answers with whatever wins: a `deny` or an `ask` further along is returned as it stands, and only an allow leaves this gate's own ask standing. Prepended position no longer hides a call from the listeners behind it, which is what a listener that books an approval its own tool body checks for needs. New record field: `downstream`, carrying `allow`, `ask`, `deny`, or `none` for a chain that threw.
- **The review model is chosen in settings.** A settings page named 自动审查 carries the review switch and a picker over the models this installation can review on, stored in the same `llm-permission-gateway` namespace as `mode`. `config.provider`/`config.model` become the fallback, used where nothing is stored and where the stored provider has no adapter. A change takes effect on the next call and drops every remembered verdict — so does an adapter registering or retiring routes, which moves the route with nothing committed to settings. The record's `model` follows: a record a review was issued for names the model it was issued on, and every other record names the route in force when it was written.
- **`dsh-gateway-verdicts` reports settled decisions and splits reviews by model.** `by decision` counts what a call actually received rather than what this gate answered, so an ask the chain then refused is counted as a `deny`. A `by model` block, drawn once more than one model reviewed, gives each model its own review count, latency quantiles, and token total.

### 0.2.0

- **Only unwalled calls are reviewed.** `walledTools` under a `read-only` or `workspace-write` sandbox are passed through with `source: "walled"`. Under `danger-full-access`, or with no sandbox policy composed, every call is reviewed as before.
- **Sandbox escalations are answered.** A new `approval/request` listener recognizes `escalate sandbox to <mode>: <justification>`, reviews it against the refused call this gate remembered, grants `allowed-once` on `allow`, and delegates to the person on `ask` or under `onFailure: ask`. It delegates without asking the model at all when the call was not remembered, when the request names a different tool than the note holds, or when the request is this gate's own `ask`. Every other approval falls through untouched.
- **The review model can no longer refuse.** A `deny` verdict becomes an `ask`; the record carries `downgraded: true`. The two red lines are unchanged.
- **`/review auto` and `/review manual`.** The mode is this plugin's own setting, persisted in the `llm-permission-gateway` settings namespace. `manual` keeps the red lines and `alwaysAsk` and skips everything else.
- **A cancelled call is abandoned quietly.** An already-aborted caller signal, or one that aborts mid-review, delegates and records `source: "cancelled"` with `decision: "cancelled"` instead of producing an approval prompt or a gate-authored error.
- **Reasons are in Simplified Chinese.** `reasonLanguage` defaults to `简体中文`, and every sentence this plugin writes itself — red lines, oversized calls, review failures, the `browser_auth` cost sentence, the `/review` echo — is Chinese.
- **`readOnlyTools` gains** `show_chart`, `job_output`, `content_show`, and `web_search`.
- **On Windows the walls are `partial`.** `@deepseek-ai/dsh-sandbox-local` reports `windows-acl` enforcement as `partial` unconditionally, for its documented Everyone-ACL and hard-link boundaries. This version stops reviewing the walled tools there as well as on the platforms that report `full`; a Windows deployment that wants those calls reviewed sets `walledTools: []`.
- **The `yolo-access` preset row is renamed** 关闭沙箱（不推荐） and no longer claims model review makes it safe. The row itself stays: removing it breaks the `permission` settings section for anyone whose stored `defaultPreset` names it.
- **New record fields**: `source` gains `cancelled`, `manual`, `walled`, `escalation`, `escalationUnreviewed`, and `escalationFailure`; `decision` gains `cancelled`; records gain `downgraded` and `requestedMode`; `callId` is absent on an escalation whose approval request named no call.
- **A wall counts only where an executor confines.** `sandboxConfines` now requires the mounted shell executor to report a `sandboxMode` as well as the policy service to resolve one, so a deployment over an unconfined executor is reviewed rather than skipped.

## Development

See the workspace README for the build, the tarball-based profile install, and why a `link:` dependency must not be used.

`@deepseek-ai/cordis` is a required peer although this package imports only its types: every harness package declares it, and one cordis instance per composition is what makes service identity work, so declaring it optional would invite a second copy rather than record a real independence. `react` and `react-dom` are the opposite case — `src/client/ReviewSection.tsx` imports their values — and they are optional because the browser half is loaded only by a front-end shell, which supplies them; a Node-only composition mounts the gate without either.
