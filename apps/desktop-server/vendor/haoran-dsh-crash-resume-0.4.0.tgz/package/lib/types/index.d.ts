/**
 * Host half of @haoran/dsh-crash-resume.
 *
 * When the server process dies in the middle of a turn, the session log ends
 * inside that turn. At the next launch this plugin continues such a turn
 * once, by sending a logged continuation message, or holds it with a card
 * when continuing could do harm: the turn was waiting for the user, it was
 * itself a continuation, or the app had been stopped on purpose. The card's
 * Continue button sends the same message at the person's request, through
 * the `crashResume` Remote (see `./service.ts`).
 *
 * Which sessions to look at comes from an in-flight registry this plugin
 * keeps while it runs (see `./state-files.ts`), never from scanning the
 * session store. See `.agents/notes/2026-09-27-crash-resume-once-by-message.md`
 * for why each part is where it is.
 *
 * @module @haoran/dsh-crash-resume
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ContextFormed } from '@deepseek-ai/dsh-llm';
import { type Config } from './config.ts';
import { PERSON_TRIGGER, type HeldEventData, type RESUME_SOURCE_KIND } from './shared.ts';
export { Config, DEFAULT_AWAIT_USER_TOOLS, DEFAULT_CONTINUE_SUMMARY_EN, DEFAULT_CONTINUE_SUMMARY_ZH, DEFAULT_CONTINUE_TEXT_EN, DEFAULT_CONTINUE_TEXT_ZH, DEFAULT_MAX_LOG_BYTES, DEFAULT_READ_TIMEOUT_MS, DEFAULT_RESUME_TEXT_EN, DEFAULT_RESUME_TEXT_ZH, DEFAULT_STALE_REGISTRY_MS, resolveConfig, STATE_DIR_NAME, } from './config.ts';
export type { ResolvedConfig } from './config.ts';
export { judge } from './judge.ts';
export type { JudgedEvent, JudgedSession, JudgeOptions, SkipReason, Verdict } from './judge.ts';
export { settingsLanguage } from './language.ts';
export type { Language, LanguageSources } from './language.ts';
export { archivedIds, continueOne, runStartupPass, stillInterrupted } from './recovery.ts';
export type { ContinuationMessage, ContinueResult, ResumeCandidate, StartupInputs, StartupOutcome, Unreadable } from './recovery.ts';
export { CrashResumeService } from './service.ts';
export type { ContinueHeld } from './service.ts';
export { CONTINUE_HELD_RESULTS, HELD_EVENT_TYPE, HELD_REASONS, heldEventData, PERSON_TRIGGER, RESUME_SOURCE_KIND } from './shared.ts';
export type { ContinueHeldResult, HeldEventData, HeldReason } from './shared.ts';
export { BOOT_TOLERANCE_MS, bootTime, formatInFlight, formatSentinel, IN_FLIGHT_DIR, parseInFlight, peekSentinel, processRunning, readRegistries, registryDead, registryPath, removeSentinel, SENTINEL_FILE, STATE_FILE_VERSION, writeSentinelSync, } from './state-files.ts';
export type { FoundRegistry, InFlightFile, InFlightRead, InFlightState, Liveness, SentinelFile, SentinelWriter } from './state-files.ts';
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /**
         * An interrupted turn was not continued automatically; the card asks the
         * user to continue it. Written only through a persistence write handle
         * while no agent owns the session, always with `ignorable: true`.
         * NEVER append it with `Session.append`: that path cannot set
         * `ignorable`, and an unknown event without it makes the session
         * unreadable to every build; on an unpatched upstream base it also
         * breaks session search for all sessions.
         */
        'plugin:crash-resume/held': HeldEventData;
    }
}
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        /**
         * The continuation message this plugin sends, automatically after a crash
         * or when a person presses the held card's Continue button.
         */
        'plugin:crash-resume': {
            readonly kind: typeof RESUME_SOURCE_KIND;
            /** The interrupted turn this message continues. */
            readonly interruptedTurn: number;
            /**
             * `person` when a person asked for the continuation with the held
             * card's button. Absent on the automatic continuation, and on every
             * message a build before 0.4.0 wrote, which a build that knows the
             * field reads as automatic.
             */
            readonly trigger?: typeof PERSON_TRIGGER;
        } & ContextFormed;
    }
}
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "crash-resume";
/** Required host services. */
export declare const inject: string[];
/**
 * Mount crash recovery.
 *
 * Ordering is the contract here.
 * - The stop-signal listeners are installed before the first await, so a
 *   stop request that arrives while the pass runs still leaves the
 *   sentinel. They are the only writer of the sentinel in this process: a
 *   fatal error, a plugin reload, or a disposal without a stop request
 *   leaves none, and the next startup treats the interrupted turns as
 *   crashed.
 * - The launcher awaits every plugin's `apply` before it reports the
 *   application ready. The gateway admits client streams only after that
 *   report, but admits unary `/api` calls before it. The `crashResume`
 *   Remote is constructed after the pass, and cordis resolves a service
 *   only once the fiber that provides it is active, which is when this
 *   `apply` has returned; a call during the pass therefore finds no
 *   service and is refused, and none can open a session the pass is still
 *   reading or writing.
 * - This process's registry, holding every candidate, is written before the
 *   pass and rewritten after it; the registries read at startup and the
 *   sentinel are deleted only after that, so a crash at any point leaves
 *   the next startup at least the same candidates and the same stop fact.
 * - Continuations go through the session controller, which deduplicates
 *   concurrent opens, and wait for the ready report.
 * @param ctx - the plugin context.
 * @param config - the schema-validated config.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map