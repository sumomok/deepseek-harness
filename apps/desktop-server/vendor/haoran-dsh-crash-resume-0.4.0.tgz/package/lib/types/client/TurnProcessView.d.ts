/**
 * The `turn-process` row: the button above a closed turn's work that folds
 * it, labelled "Completed in …".
 *
 * This view shadows the host's `turn-process` renderer at priority -1 and
 * always renders the host's own component, read from the slot ledger, with
 * the host's translator; the button, its label and its accessibility
 * attributes stay the host's. What it adds is one effect: a turn that ended
 * `interrupted` is opened once. The host writes that end reason when it next
 * opens or reads a session whose log stops inside a turn, whether a crash or
 * a quit cut the turn short and whether this plugin continued it, held it, or
 * left it alone (a turn no person started, a subagent's or an archived
 * session's turn, or a turn cut short before the plugin was installed).
 *
 * The same effect records every other closed turn it finds open, without
 * opening anything. When the continuation turn is the earliest turn in the
 * loaded history, the chat shows its opening message as a context row, not a
 * `turn-trigger` row, so the continuation row mounts only after earlier
 * history loads; a turn the reader opened and collapsed before that is then
 * already recorded, and the continuation row leaves it collapsed.
 *
 * @module @haoran/dsh-crash-resume/client/TurnProcessView
 */
import type { ReactNode } from 'react';
import type { TurnProcessOwnerProps } from '@deepseek-ai/dsh-client-ui-chat/client';
import type { ConversationLocation } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { StoredEntry } from '@deepseek-ai/dsh-client-ui-slots';
import { type ExpandedStoreProps } from './expand-once.ts';
/** The props a keyed `turn-process` entry receives; only the parts this view reads are named. */
export type TurnProcessViewProps = {
    readonly node?: {
        readonly location?: ConversationLocation;
    };
    readonly turnProcess?: TurnProcessOwnerProps | undefined;
    readonly t?: unknown;
} & ExpandedStoreProps;
/** What the view needs from the plugin context, resolved per render. */
export interface TurnProcessViewDeps {
    /** Live ledger of `conversation.chat.node` entries. */
    readonly entries: () => readonly StoredEntry[];
    /** Translate bound to the host renderer's namespace. */
    readonly hostTranslate: () => unknown;
}
/**
 * Whether a node belongs to a turn that ended because the app exited in the middle of it.
 * @param node - a chat node; only its location is read.
 * @returns true when the node's turn is closed with end reason `interrupted`.
 */
export declare function isInterruptedTurn(node: {
    readonly location?: ConversationLocation;
} | undefined): boolean;
/**
 * Build the shadowing renderer for the `turn-process` cell.
 * @param deps - ledger access and the host translator.
 * @returns the component to register at `priority: -1` with the record's store.
 */
export declare function createTurnProcessView(deps: TurnProcessViewDeps): (props: TurnProcessViewProps) => ReactNode;
//# sourceMappingURL=TurnProcessView.d.ts.map