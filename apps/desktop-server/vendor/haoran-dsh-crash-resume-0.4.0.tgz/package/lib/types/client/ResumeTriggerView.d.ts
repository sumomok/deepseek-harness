/**
 * The row of the continuation message.
 *
 * The chat renders a message no person sent, which opens a turn, as a
 * `turn-trigger` row titled by the message's source. It does not know this
 * plugin's source, so the title would read "Execution requested". This view
 * shadows the host's `turn-trigger` renderer at priority -1, as
 * `@sumomok/dsh-quote-message` does for user bubbles: it renders the
 * continuation message itself and hands every other trigger back to the
 * host's own component, read from the slot ledger. A continuation a person
 * asked for with the held card's button (`source.trigger: 'person'`) is
 * titled as such; any other, including every one a build before 0.4.0 wrote,
 * reads as automatic.
 *
 * The row stays collapsed, but the turn it opens is opened once after that
 * turn ends, so its work is not folded away under "Completed in …". The chat
 * keeps a running turn open by itself and, once the turn closes, reports this
 * row `foldable: false`, because the row is not part of the turn's folded
 * work; the effect therefore waits for the turn to close and never reads
 * `foldable`.
 *
 * @module @haoran/dsh-crash-resume/client/ResumeTriggerView
 */
import { type ReactNode } from 'react';
import type { TurnProcessOwnerProps } from '@deepseek-ai/dsh-client-ui-chat/client';
import type { ConversationLocation } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { StoredEntry, Translate } from '@deepseek-ai/dsh-client-ui-slots';
import { type ExpandedStoreProps } from './expand-once.ts';
import type { CrashResumeKey } from './locales.ts';
/** The props a keyed chat-node entry receives; only the parts this view reads are named. */
export type TriggerProps = {
    readonly node?: {
        readonly location?: ConversationLocation;
        readonly data?: {
            readonly source?: unknown;
            readonly content?: readonly unknown[];
        };
    };
    readonly turnProcess?: TurnProcessOwnerProps | undefined;
    readonly t?: unknown;
} & ExpandedStoreProps;
/** What the view needs from the plugin context, resolved per render. */
export interface ResumeTriggerDeps {
    /** Live ledger of `conversation.chat.node` entries. */
    readonly entries: () => readonly StoredEntry[];
    /** Translate bound to the host renderer's namespace. */
    readonly hostTranslate: () => unknown;
    /** Translate bound to this plugin's namespace. */
    readonly t: () => Translate<CrashResumeKey>;
}
/**
 * Whether a trigger node carries this plugin's continuation message.
 * @param source - the node's message source.
 * @returns true for this plugin's source kind.
 */
export declare function isResumeSource(source: unknown): boolean;
/**
 * The host's own entry for a keyed cell: the lowest priority other than this view.
 * @param entries - the slot ledger.
 * @param key - the keyed cell.
 * @param own - this view, excluded from the search.
 * @returns the incumbent component, or undefined when this view is alone in the cell.
 */
export declare function pickIncumbent(entries: readonly StoredEntry[], key: string, own: unknown): unknown;
/**
 * Whether a continuation message was sent at a person's request.
 * @param source - the node's message source, already known to be this plugin's.
 * @returns true when its `trigger` is `person`.
 */
export declare function isPersonTrigger(source: unknown): boolean;
/**
 * Build the shadowing renderer for the `turn-trigger` cell.
 * @param deps - ledger access and the two translators.
 * @returns the component to register at `priority: -1` with the record's store.
 */
export declare function createResumeTriggerView(deps: ResumeTriggerDeps): (props: TriggerProps) => ReactNode;
//# sourceMappingURL=ResumeTriggerView.d.ts.map