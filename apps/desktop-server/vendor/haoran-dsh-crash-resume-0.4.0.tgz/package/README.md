# @haoran/dsh-crash-resume

English | [中文](README.zh.md)

When the app exits unexpectedly in the middle of a turn, the next launch continues that turn once. When continuing could do harm, a card titled 「已中断」 / "Interrupted" is left in the conversation instead, with a 「继续」 / "Continue" button that continues the turn when you press it; sending a message works too. In the chat, the work of the interrupted turn and of the turn that continued it is shown unfolded.

Display name: 崩溃恢复 / Crash recovery (working name, pending approval).

## What happens at the next launch

| The interrupted turn… | Result |
| --- | --- |
| was an ordinary turn a person started | continued once, after the app reports it is ready |
| had asked for an approval nobody answered | held: `awaiting-approval` |
| had a question tool waiting for an answer (`ask_user_question`, `exit_plan_mode`, configurable) | held: `awaiting-answer` |
| was itself a continuation, automatic or one you asked for, or carries no message at all and follows an interrupted turn | held: `already-resumed` |
| was started by a person in a session whose goal is active | held: `goal-active` |
| was cut short by a stop request (the app was quit or restarted) | held: `stopped` |
| belongs to a subagent or an archived session, or was opened by a goal round, a schedule, or a job notice | left exactly as it is |

Continuing a turn that waited on a person would turn the wait into a refusal or an unanswerable question. Continuing a continuation again without asking could repeat the crash forever: restart, continue, crash. `turn/start` is logged before the turn's message, so a continuation that died between the two leaves a turn with no message; such a turn after an interrupted one is held for the same reason. A scheduled turn that died at the same point gets the same card, and nothing runs.

The goal service disarms every goal when an agent is created for its session, so after a restart no driver continues a goal until a person resumes it. An automatic continuation of a turn in such a session would work toward the goal without that consent, so the turn is held. A goal round's own turn is not a person's and is left as it is.

When more than one reason applies, the card names the first in the table's order.

## The Continue button

Every held card has the button, whatever its reason. Pressing it sends the same kind of continuation message the automatic path sends, with its own text: it says the turn was cut short when the app exited or restarted, that you chose to continue, that in-flight tool calls were closed with unknown results, and that an approval or question the turn was waiting for no longer applies. It names no tool. A tool call the model makes after that is a new call and is approved like any other.

The button asks the host, through the `crashResume/continueHeld` Remote, and the host decides. It sends the message only when the session is still exactly where the interruption left it: no turn running, nothing waiting in its inbox, and its log ending with the closers of the interrupted turn. It checks this when it opens the session and again after flushing it, with no wait between that last check and the send, so a message you sent first always wins.

| The host answers | The card shows |
| --- | --- |
| `sent` | the button stays disabled and reads 「正在继续…」 / "Continuing…" until the new turn appears |
| `busy` or `settled`: a turn is running, a message is queued, or the session is already past the interrupted turn | 「会话已经有了新的进展，没有从这里继续。」 / "The conversation has moved on, so it was not continued from here." |
| `unopened`: the session could not be opened | 「会话暂时打不开，没有继续。请稍后再试。」 / "The conversation could not be opened, so it was not continued. Try again shortly." |
| `archived`: the session is archived, and an archived session runs no model step | 「这个会话已归档，没有继续。」 / "This conversation is archived, so it was not continued." |
| the call did not reach the host, was refused, or the answer was unknown | 「没能继续，请稍后再试。」 / "Could not continue. Try again shortly." |

After a refusal the button can be pressed again. The button is also disabled while the session runs or holds a message you sent that the host has not taken yet. Once any later turn exists, whether the button or your own message started it, the card keeps only a grey dot, its title and its reason. The card reads this from the conversation itself, so it shows the same after a reload.

- **Active goal.** Continue picks up only the interrupted turn; the goal stays paused until you resume it. The card says so next to the button.
- **A continuation that crashes again.** It carries this plugin's message, so the next launch holds it as `already-resumed`, and it is continued again only if you press the button again.
- **During startup.** The host provides the Remote only once this plugin's startup pass has finished. A press before that reads "Could not continue"; pressing again a moment later works.

## How it knows

**Which sessions to look at.** While it runs, each server process keeps its own registry, `$DSH_HOME/crash-resume/in-flight/<pid>.json`: the ids of top-level sessions whose turn started and has not ended. It adds an id on `turn/start`, observed on the host's `session/event` stream. On `turn/end` it first flushes the session, because storage batches appends and a crash inside that window would leave an open turn no registry lists; it removes the id once the flush completes, unless a new turn started meanwhile. Each write replaces the file atomically (uniquely named temporary file, fsync, rename, directory fsync); writes from a reloaded plugin are queued after the previous load's, and a disposed load writes nothing more. At startup the plugin reads the registries whose writers are gone and the one named by its own pid, and reads only the listed sessions, completely, through the persistence service. The session store is never scanned, older-format sessions are never opened, and the backend's directory layout is never used. A damaged registry means the sessions it listed are not recovered; the plugin says so in the log.

**Two servers on one home.** One registry per process, rather than one shared file under a lock file, means neither server overwrites the other's entries and a crashed server's lock is never left behind. A registry whose writer still runs is left alone. Two servers that start at the same moment can both read the same dead registry; the session store's single-writer ownership decides which one continues or marks each session.

**When a registry's writer is gone.** A pid alone is not enough: after a reboot, or after the pid wraps around, an unrelated live process can hold the same number. Each registry therefore records the machine's boot time (`Date.now()` minus Node's `os.uptime()`, which on macOS matches `sysctl kern.boottime`) and a heartbeat the server rewrites every quarter of `staleRegistryMs`. A registry counts as dead when no process has its pid, when its boot time differs from the current one by more than a minute, or when its heartbeat is older than `staleRegistryMs`. The last rule covers a pid reused within one boot; it can also take over the registry of a live server that did not run for that long, such as one on a machine that slept, and the session store's single-writer ownership then keeps the two from writing the same session.

**Order at startup.** This process's registry, listing every candidate, is written before any log is read. Held markers are written next. The registries read at startup and the sentinel are deleted last. A session to continue stays listed until its continuation's own turn ends, and one that could not be opened stays listed for the next launch. A crash at any point therefore leaves the next launch the same candidates and the same stop fact.

**Whether it was a crash.** A quit leaves the same open turn in the log as a crash does: on Windows the desktop shell force-kills the server, and on macOS the turn's closing events were measured not to reach storage during shutdown. So a deliberate stop is recorded outside the log, in `$DSH_HOME/crash-resume/intentional-stop.json`. This plugin writes it synchronously from its own `SIGTERM`, `SIGINT` and `SIGHUP` listeners (`SIGHUP` is what a closing terminal sends to `dsh web`), which run in the same signal emit as the launcher's before any teardown starts. Nothing else in the server writes it: a fatal error (an uncaught exception or unhandled rejection, which the launcher turns into a disposal and exit code 1), a disposal without a stop request, and a plugin reload leave none, so a turn cut short by a fatal error is continued. The three listeners change no exit behavior: the launcher's own listeners still decide the exit code, and when no other listener handles the signal the plugin removes its listeners and raises the signal again, so the process still ends by it. The desktop shell writes the same file, in the same format, before it force-kills the server on Windows (reason `quit`, `update` or `shutdown`). The next launch holds every interrupted turn it finds while the sentinel is present, and deletes the sentinel after it has written the held markers.

**Whether it was already continued once.** The continuation is an ordinary logged `user/message` whose `source.kind` is `plugin:crash-resume`. The model reads it, and the log keeps it, so the next launch can see it. The rule counts on the log alone, never on memory that dies with the process.

## What it writes into a session

- **The continuation message.** Model-visible, in the language chosen in Settings, read from the same place the desktop shell's boot page reads it, at the moment the message is sent. The text says that the app exited mid-turn, that in-flight tools were closed with unknown results, and that a partial action must be checked before it is repeated. It names no tool. The chat shows it as a collapsed row titled "Continued after an unexpected exit" rather than as something you typed.
- **The continuation you asked for.** The same kind of message, with the `continue*` texts. Its source also carries `trigger: 'person'`, and the chat titles its row 「你确认后继续了上一轮」 / "Continued the previous turn at your request". A message without `trigger`, which includes every message a version before 0.4.0 wrote, reads as automatic; a version before 0.4.0 shows a continuation you asked for with the automatic title.
- **The held marker.** A `plugin:crash-resume/held` event carrying only `interruptedTurn` and `reason` (plus `turn: null`, which the browser's conversation index reads as "between turns"), placed after the interrupted turn's closing events. It is written through a persistence write handle while no agent owns the session, before the app reports it is ready, and always with `ignorable: true`. A build without this plugin skips it; the session stays readable after the plugin is removed. The card text comes from the browser's dictionaries, so it reads in the viewer's language.

`Session.append` cannot write `ignorable`, and an unknown event without it makes a session unreadable to every build. On an unpatched upstream base such an event also makes session search fail for all sessions. That is why the marker is never appended through a live session.

## In the chat

In the Compact, Standard and Detailed work-details modes the chat folds a finished turn's work under a "Completed in …" row. A turn the app's exit cut short gets that row too, so its work looks lost. The plugin opens two kinds of turns, once each:

| Turn | Opens | Recognized by |
| --- | --- | --- |
| a turn that ended `interrupted` | when it is first shown | the turn's `turn/end` reason |
| the turn the continuation message started | once that turn has ended; while it runs the chat shows it open anyway | the source of the message that opened it, `plugin:crash-resume` |

The host ends a turn with `interrupted` when it next opens or reads a session whose log stops inside that turn, whether a crash or a quit cut the turn short: a quit leaves the same open turn in the log as a crash does (see [How it knows](#how-it-knows)). The first row therefore also covers turns this plugin held, `stopped` included, turns it leaves as they are (a subagent's or an archived session's turn, a turn no person started), and turns cut short before the plugin was installed. The 「意外退出后自动继续」 / "Continued after an unexpected exit" row itself stays collapsed: it holds the message the model read, not the turn's work.

The plugin draws no control of its own. It calls the same `setOpen` the "Completed in …" button calls, from a layout effect, which React runs before the browser paints, and records the turn, keyed by the turn number and its answer step, in a store it declares beside the chat's own. A turn it has recorded is never opened again, so collapsing it with that button sticks. It also records every other closed turn it finds open, so a continued turn the reader opened and collapsed by hand stays collapsed when its continuation row appears later. Like the chat's own open state, the record is kept only in memory, so after a reload every interrupted turn and every continued turn opens again. Verbose folds nothing, so there nothing changes visibly; turns opened there stay open after switching to a mode that folds.

## Configuration

Every field is written out in `cordis.patch.yml`.

| Field | Default | Meaning |
| --- | --- | --- |
| `stateDir` | `$DSH_HOME/crash-resume` | Where the registry and the sentinel live. The desktop shell writes to the default path; move both or neither. |
| `awaitUserTools` | `ask_user_question`, `exit_plan_mode` | Tools whose open call means the turn was waiting for an answer. |
| `resumeTextZh` / `resumeTextEn` | see the patch | The continuation message the model reads. |
| `resumeSummaryZh` / `resumeSummaryEn` | see the patch | The one-line summary stored with it. |
| `continueTextZh` / `continueTextEn` | see the patch | The continuation message the model reads when you press Continue. |
| `continueSummaryZh` / `continueSummaryEn` | see the patch | The one-line summary stored with it. |
| `maxLogBytes` | 67108864 (64 MiB) | Largest log the startup pass reads; a larger one is skipped with a warning. Applies where the backend reports a size (JSONL does). |
| `readTimeoutMs` | 15000 | Longest the startup pass waits for one log; a slower one is skipped with a warning. The read itself is not cancelled. |
| `staleRegistryMs` | 3600000 (one hour) | Heartbeat age after which another server's registry counts as dead although its pid is in use. |

## Known limitations

- **On Windows this plugin requires a desktop shell that writes the sentinel (DSH desktop from rc.35).** The shell stops the server with `taskkill /T /F`, which no listener sees; without the shell's sentinel every quit reads as a crash and every interrupted turn is continued.
- **Running out of memory cannot be caught.** A log that makes the startup pass run out of memory kills the process before any handler runs. The plugin records the id it is about to read in its registry and waits for that write before reading; a launch that finds a dead registry still naming an id it was reading skips that session with a warning. One bad log therefore costs one failed launch, not a crash loop. `maxLogBytes` refuses the largest logs before they are read.
- **A crash while the auto-review gateway judges a walled-mode sandbox escalation is held, not continued.** That escalation's `approval/asked` is written before the gateway answers. The log does not say whether a reviewer or a person holds the question, so the plugin treats it as a person's.
- **Questions are recognized by tool name.** A question asked from inside a `run_code` program, or by a plugin calling `ctx.userQuestions` directly, is not recognized, and such a turn is continued.
- **A turn no person started is never continued.** This covers the first turn after an interrupted one when a job notice or a goal round opened it.
- **One sentinel per home.** With two servers on one home, a stop of one can make the other's crash read as a stop. That holds turns that could have been continued and never continues one that should be held.
- **A launch that fails before this plugin loads leaves the sentinel in place.** A crash after that launch is then held as `stopped`.
- **Only the turn's top level opens.** Tool calls and reasoning inside an opened turn stay collapsed group headers; the chat offers plugins no way to open them.
- **A continued turn at the top of the loaded history is not opened.** When the turn the continuation message started is the earliest turn loaded, the event that queued the message lies before the loaded page, so the chat shows the message as context rather than as the continuation row, and the plugin does not recognize the turn. Once 「加载更早」 / "Load earlier" brings in the events before it, the continuation row appears and opens the turn, unless the reader has already opened it.
- **A collapse is not remembered across a reload.** After a reload every interrupted turn and every continued turn opens again, as described in [In the chat](#in-the-chat).
- **Turning the plugin off and on opens them again.** Disabling and re-enabling this plugin without reloading the page starts its record empty, so interrupted and continued turns open again, including ones the reader collapsed.
- **The label is the chat's.** An interrupted turn still reads 「已完成，用时 …」 / "Completed in …", the label the chat gives every end reason except a stop and a failure.
- **The Remote checks the session, not the card.** `crashResume/continueHeld` continues any session whose log ends with the closers of the turn it names, whether or not a held marker follows them. The button exists only on a held card, so in the app this means a held turn; a client that calls the Remote directly can continue an interrupted turn the plugin left alone, such as one a goal round started.

## Requirements

DeepSeek Harness 0.2.0-rc.2 or a later 0.2.x release (every dsh peer is `>=0.2.0-rc.2 <0.3.0-0`), with the session controller, the Typert loader and gateway, and the web client's Remote service (the desktop app and `dsh web` have all of them). On Windows, a desktop shell that writes the sentinel (DSH desktop from rc.35).
