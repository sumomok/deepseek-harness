/**
 * The balance adapter registry: one memoized {@link BalanceReader} per
 * provider id, keyed by provider so a deployment reading several providers
 * (the session-followed one, plus whatever the provider picker last
 * previewed) gets each its own refresh/retry cache instead of sharing one.
 *
 * DeepSeek is the one named member — the query this plugin always had,
 * migrated in unchanged. Every other provider id falls through to the
 * generic fallback adapter, which only ever runs when `ctx.llm`'s own
 * configurable-provider directory names a settings address for that id
 * (`custom-provider.ts`); nothing here special-cases which adapter family
 * registered it. A future named adapter for a specific provider joins this
 * registry the same way DeepSeek does, ahead of the generic fallback.
 *
 * @module @sumomok/dsh-balance/adapters
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ResolvedConfig } from './config.ts';
import type { BalanceView, ProviderOption } from './types.ts';
/**
 * Owns one memoized reader per provider id that has been read at least once.
 * Memoization is what makes the refresh/retry windows mean something: a
 * fresh reader per call would never serve from cache, and the generic
 * adapter's remembered endpoint shape (`generic-adapter.ts`) would never
 * survive between calls either.
 */
export declare class AdapterRegistry {
    private readonly ctx;
    private readonly config;
    private readonly adapters;
    /**
     * @param ctx - the plugin context.
     * @param config - the resolved plugin config.
     */
    constructor(ctx: Context, config: ResolvedConfig);
    /**
     * Read one provider's balance.
     * @param provider - provider route id.
     * @param force - bypass the refresh and retry windows; an in-flight read is joined rather than duplicated.
     * @returns the view. A generic-adapter failure comes back as the quiet
     * `unconfigured` state rather than `unavailable`: see the registry's module doc.
     */
    get(provider: string, force: boolean): Promise<BalanceView>;
}
/**
 * The provider picker's roster: every provider route the harness knows,
 * active or dormant, DeepSeek always included even when `ctx.llm` is not
 * composed (this plugin can still query it through its own settings-only
 * resolver). Carries no adapter or configuration fact — see {@link ProviderOption}.
 * @param ctx - the plugin context.
 * @returns the roster, DeepSeek first, in directory then registration order.
 */
export declare function providerRoster(ctx: Context): ProviderOption[];
/**
 * The provider picker's roster, filtered to providers this deployment can
 * actually show a balance for.
 *
 * Filtering happens in two passes because "configured" (a credential
 * actually resolves) is not knowable without asking each adapter, while
 * "supported" (an adapter exists that could ever resolve one) is a static
 * fact of the directory: {@link supportedProviderIds} narrows the full
 * roster to the statically eligible providers first, then this function
 * probes only those — one `AdapterRegistry.get` read each, sharing the same
 * refresh/retry cache the chip's own balance reads use, so a poll tick
 * already holding a fresh answer costs no extra network call. A candidate
 * whose read comes back `unconfigured` (no credential resolves; see
 * {@link AdapterRegistry.get}'s doc on the generic adapter's quiet failure)
 * is dropped.
 *
 * Carries no notion of which provider is "followed" — the caller's own
 * followed-provider balance read already exercises that id through this same
 * registry, and folding it back into the roster if this filter ever excluded
 * it is the browser half's job ({@link file://./client/store.ts}), not this
 * one's.
 * @param ctx - the plugin context.
 * @param registry - the adapter registry probed for each supported candidate.
 * @returns the filtered roster, in {@link providerRoster}'s order.
 */
export declare function pickableProviderRoster(ctx: Context, registry: AdapterRegistry): Promise<ProviderOption[]>;
//# sourceMappingURL=adapters.d.ts.map