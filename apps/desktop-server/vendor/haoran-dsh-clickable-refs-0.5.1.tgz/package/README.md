# @haoran/dsh-clickable-refs

English | [中文](README.zh.md)

Makes file and directory paths, network-share paths and URLs in the Assistant's prose (plain text, inline code, and Markdown links) clickable in the DSH chat UI. Desktop-internal plugin (`@haoran` private scope) — not published, not part of the community registry: it depends on three fork patches that are not a public contract — `referent-open-seam` (the `referent/open` waterfall and `ReferentRef`), `referent-target-probe` (the `session.probeTargets` batch stat RPC), and `chat-prose-referents` (the chat view's use of the optional `proseReferents` service, including its `resolveLink`/`subscribe` members).

## What it does

A candidate is clickable only after a nominate → verify pipeline passes it (`docs/referents-three-layer-spec.md`). Nomination is syntax detection over a settled model reply, or a Markdown link's own destination. A batched host `stat` (`session.probeTargets`) is the only existence check for a `file`/`dir` candidate. The session index (built from tool-call arguments in the session's events) never verifies by itself — a tool touching a path earlier proves nothing about whether it exists now — it only resolves a basename or relative alias to its one unambiguous absolute path, which then waits for the same `stat` batch as any other candidate. A `url` candidate is exempt from `stat`: its click promise is "open a browser tab," not "this host answers." A UNC candidate (`\\server\share\…`) is never handed to `stat` at all: on Windows a `stat` of a UNC path is itself an SMB connection that can leak the current user's NTLM credentials to whatever host the model's text named, with no user gesture. Its click promise is "copy the path," which never touches the filesystem, so it is clickable unconditionally, like `url`.

- **Provider.** This plugin provides `dsh-render`'s optional `proseReferents` service (`src/client/prose-referents.ts`), bound to the `VerificationStore` (`src/client/verification-store.ts`); a verification tick lights up an already rendered reply in place. Inline code classifies relaxed (a bare word with no extension counts, since a code span is itself a deliberate-reference signal); plain text stays conservative. A relative reference with no `cwd`/`home` to resolve against produces no span rather than a wrong one.
- **Prompt.** A host-side system-prompt section (`src/index.ts`) tells the model to write a file or directory that appeared in the conversation as an absolute-path Markdown link, percent-encoding a space (or wrapping the path in angle brackets), since an unescaped space breaks an unbracketed CommonMark link destination.
- **Click.** The host's own chat view builds the `ReferentRef` (source `chat-prose`) and dispatches it through the `referent/open` waterfall; its default action opens the path through `remote.session.openWorkspacePath`, or a URL in the browser. This plugin listens on that waterfall for one case: a `chat-prose` UNC target is not opened, its path is copied to the clipboard, and a frame-wide toast confirms it (`src/client/prose-unc-claim.ts`, `src/client/prose-unc-toast.ts`). Every other reference goes to the next listener unchanged.

## Tool-call cards

The `bash` and `web_fetch` cards are the host's own. 0.4.x shadowed both with its own views to make terminal output and the fetch card's URL clickable; after the host's tool-card data changed, those views could no longer read the command output, so a finished bash call could not be expanded to show its output (shipped from desktop rc.28 to rc.33). 0.5.0 removes both shadows: the bash card shows its output again, and the web_fetch card's collapsed summary is the host's own link to the fetched URL, which the desktop opens in the external browser. Paths inside terminal output are no longer clickable.

## Install

```sh
pnpm run build
cd packages/clickable-refs && pnpm pack --pack-destination ../../dist
dsh plugin --profile <name> add ../../dist/haoran-dsh-clickable-refs-0.5.1.tgz
```

0.5.0 needs a host whose `@deepseek-ai/*` packages are `>=0.1.7-rc.1 <0.2.0-0` and that carries the three fork patches above.

## Development

```sh
pnpm --filter @haoran/dsh-clickable-refs run typecheck
pnpm --filter @haoran/dsh-clickable-refs run test
```

`src/client/dsh-render-unpublished-shims.d.ts` declares the fork-only types this plugin compiles against — `ReferentRef` and the `referent/open` event, and `session.probeTargets` — which the npm-published `0.1.7-rc.2` packages do not carry; delete a declaration once a package this plugin compiles against carries it.
