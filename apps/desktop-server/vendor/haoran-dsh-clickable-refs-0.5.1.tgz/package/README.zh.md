# @haoran/dsh-clickable-refs

[English](README.md) | 中文

让 DSH 聊天界面里 Assistant 正文（纯文本、行内代码、Markdown 链接）中的文件和目录路径、网络共享路径、URL 变得可点。桌面内部插件（`@haoran` 私域）——不发版、不进社区注册表：它依赖三个 fork 补丁，都不是公开契约——`referent-open-seam`（`referent/open` 瀑布缝与 `ReferentRef`）、`referent-target-probe`（`session.probeTargets` 批量 stat 探针）、`chat-prose-referents`（聊天视图对可选服务 `proseReferents` 的使用，含其 `resolveLink`/`subscribe` 成员）。

## 做什么

候选只有经过「提名→验证」管线才可点（`docs/referents-three-layer-spec.md`）。提名是对已收尾的模型回复做语法检测，或取 Markdown 链接自身的目的地。批量 host `stat`（`session.probeTargets`）是 `file`/`dir` 候选唯一的存在性验证。会话索引（从会话事件里的工具调用参数建账）从不单独判定验证通过——之前某工具接触过这条路径，对它现在是否存在零证明力——它只负责把 basename 或相对别名解析成唯一无歧义的绝对路径，解析结果照样和其他候选一起等同一批 `stat`。`url` 候选免 stat：点击承诺是「打开浏览器标签」，不是「这台主机能应答」。UNC 候选（`\\server\share\…`）从不交给 `stat`：在 Windows 上对 UNC 路径 `stat` 本身就是一次 SMB 连接，可能把当前用户的 NTLM 凭据泄露给模型文本指定的任意主机，且全程没有用户手势。它的点击承诺是「复制路径」，从不触碰文件系统，因此和 `url` 一样无条件可点。

- **提供方。**本插件向 `dsh-render` 提供可选服务 `proseReferents`（`src/client/prose-referents.ts`），绑定 `VerificationStore`（`src/client/verification-store.ts`）；验证 tick 能让已经渲染的回复原地显形。行内代码走放宽规则（无扩展名的裸词也算，因为写进代码片段本身就是刻意引用的信号）；纯文本保持保守。相对引用缺 `cwd`/`home` 可解析时不产生可点 span，而不是产生错的。
- **提示词。**宿主侧一段系统提示词（`src/index.ts`）让模型把对话里出现过的文件或目录写成绝对路径 Markdown 链接，路径带空格时百分号编码（或整段用尖括号包住），因为不转义的空格会破坏无尖括号的 CommonMark 链接目的地。
- **点击。**宿主自己的聊天视图构造 `ReferentRef`（source 为 `chat-prose`），经 `referent/open` 瀑布分发；它的默认动作是通过 `remote.session.openWorkspacePath` 打开路径，或在浏览器里打开 URL。本插件只为一种情况监听这条瀑布：`chat-prose` 来源的 UNC 目标不打开，而是把路径复制到剪贴板，并用画面级 toast 确认（`src/client/prose-unc-claim.ts`、`src/client/prose-unc-toast.ts`）。其余引用原样交给下一个监听者。

## 工具调用卡片

`bash` 和 `web_fetch` 卡片由宿主自己渲染。0.4.x 用自己的视图遮住了这两张卡，好让终端输出和抓取卡的 URL 可点；宿主的工具卡数据变化之后，这两个视图读不到命令输出，成功结束的 bash 调用无法展开看输出（随桌面 rc.28 到 rc.33 出货）。0.5.0 撤掉这两个遮挡：bash 卡重新显示输出，web_fetch 卡收起时的摘要是宿主自己指向所抓 URL 的链接，桌面会在外部浏览器里打开它。终端输出里的路径不再可点。

## 安装

```sh
pnpm run build
cd packages/clickable-refs && pnpm pack --pack-destination ../../dist
dsh plugin --profile <name> add ../../dist/haoran-dsh-clickable-refs-0.5.1.tgz
```

0.5.0 要求宿主的 `@deepseek-ai/*` 包在 `>=0.1.7-rc.1 <0.2.0-0` 之内，并带有上面三个 fork 补丁。

## 开发

```sh
pnpm --filter @haoran/dsh-clickable-refs run typecheck
pnpm --filter @haoran/dsh-clickable-refs run test
```

`src/client/dsh-render-unpublished-shims.d.ts` 声明了本插件编译所需、但 npm 上 `0.1.7-rc.2` 各包没有的 fork 专有类型——`ReferentRef` 与 `referent/open` 事件，以及 `session.probeTargets`；等本插件编译所依赖的包自带某项声明后，删掉对应声明即可。
