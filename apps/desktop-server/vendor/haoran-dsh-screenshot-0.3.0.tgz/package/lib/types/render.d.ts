/**
 * Choosing which of the two backends renders a page.
 *
 * `auto` takes the desktop shell's service whenever it is configured, because a
 * shell that advertises one has an engine already running and knows what its
 * own windows look like. A failure there is reported rather than retried
 * against the system browser: the two engines produce different pixels, and
 * silently swapping them would make a screenshot's provenance unknowable
 * exactly when something is already wrong.
 *
 * A deployment that knows which engine it wants says so instead. `shell` is for
 * one whose captures are only meaningful from the shell — the machine may have
 * no browser at all, and the pages need a session — so a missing render service
 * is a failure naming the remedy rather than a silent change of engine.
 * `browser` is for the opposite case: a shell is running, and the captures are
 * still wanted from the machine's own Chrome.
 *
 * The two backends are not equally capable, and every difference is refused
 * rather than papered over. A system browser started with `--screenshot` cannot
 * be given request headers or cookies, cannot cancel a request the page makes,
 * and writes its PNG only when the page is done, so a call that asks for any of
 * the three fails here with what the backend cannot do. Ignoring a remedy the
 * caller applied is worse than refusing it: the render fails the same way
 * again, and nothing in the answer says the remedy never ran.
 * @module @haoran/dsh-screenshot/render
 */
import type { LaunchBrowser } from './chrome.ts';
import type { ReportHeader } from './report.ts';
import type { RenderSpec } from './request.ts';
/** Which engine produced a screenshot. */
export type RendererName = 'desktop' | 'chrome';
/** Which backend a deployment renders with: whichever is there, or one by name. */
export type BackendChoice = 'auto' | 'shell' | 'browser';
/** One rendered page, the engine that drew it, and what that engine reported. */
export interface RenderedImage {
    /** PNG bytes. */
    readonly data: Uint8Array;
    /** The engine that produced them. */
    readonly renderer: RendererName;
    /**
     * Where the main frame ended up, when the engine reported that as somewhere
     * other than the requested URL. Only the desktop service reports it; a
     * one-shot browser command line says nothing about where it went.
     */
    readonly landedUrl?: string;
    /**
     * What the render service reported about this render. A system browser
     * reports nothing — a one-shot command line has no channel for it — so every
     * capture from that backend carries `{ kind: 'none' }`.
     */
    readonly report: ReportHeader;
}
/** Everything a render reads from outside itself. */
export interface RenderBackends {
    /** The environment the desktop route is read from, per call. */
    readonly env: NodeJS.ProcessEnv;
    /** The system-browser probe, whose answer is cached across calls. */
    readonly locator: {
        locate(): string;
    };
    /** How a system browser is started. */
    readonly launch: LaunchBrowser;
    /** Which backend this deployment renders with. */
    readonly backend: BackendChoice;
}
/** What a deployment pinned to the shell is told when there is no shell to render with. */
export declare const NO_RENDER_SERVICE = "backend is set to \"shell\" and this harness was given no render service: DSH_DESKTOP_RENDER_ENDPOINT and DSH_DESKTOP_RENDER_TOKEN are both unset. Start the desktop shell, or set backend to \"auto\" or \"browser\" in the plugin config";
/**
 * Render one page with whichever backend this deployment has.
 * @param spec - the settled render, which carries its own budget.
 * @param backends - environment, browser probe, and launcher.
 * @param signal - caller cancellation.
 * @returns the PNG bytes, the engine that produced them, and what it reported.
 * @throws when this deployment is pinned to a backend that is not there, or when the chosen backend cannot carry the call's session, host blocking, or partial capture.
 */
export declare function renderScreenshot(spec: RenderSpec, backends: RenderBackends, signal: AbortSignal): Promise<RenderedImage>;
//# sourceMappingURL=render.d.ts.map