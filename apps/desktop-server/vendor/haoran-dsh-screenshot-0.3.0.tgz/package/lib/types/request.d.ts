/**
 * Model arguments to a render request: one explicit resolve step that settles
 * every default and rejects every out-of-range value before any browser starts.
 *
 * Out-of-range width, height, and delay are argument errors rather than silently
 * clamped values. The model asked for a specific viewport; rendering a different
 * one and saying nothing would make it draw conclusions about a page it never saw.
 *
 * One thing is deliberately not an argument. A call names a cookie jar and never
 * a cookie: the name is resolved here against the deployment's configured jars,
 * so the values reach the renderer from the config and never pass through
 * anything a model wrote or a session log keeps.
 * @module @haoran/dsh-screenshot/request
 */
import type { CookieJars, CookieSpec } from './cookies.ts';
/**
 * The smallest deadline the desktop render service accepts. A render opens a
 * window, loads a page, and waits for its load event, so a shorter budget only
 * buys a failure.
 */
export declare const MIN_TIMEOUT_MS = 1000;
/**
 * The largest deadline the desktop render service accepts. It is the shell's
 * own resource invariant — a render holds its single window for its whole
 * deadline — so the plugin documents it and passes the number through rather
 * than clamping to it; a larger value is refused there, by name.
 */
export declare const MAX_TIMEOUT_MS = 120000;
/** What a render does when its deadline passes. */
export type TimeoutBehavior = 'fail' | 'capture';
/** Deployment-resolved bounds every render request is settled against. */
export interface ScreenshotLimits {
    /** Viewport width used when the call names none. */
    readonly defaultWidth: number;
    /** Viewport height used when the call names none. */
    readonly defaultHeight: number;
    /** Post-load wait used when the call names none. */
    readonly defaultDelayMs: number;
    /** Largest viewport width a call may ask for. */
    readonly maxWidth: number;
    /** Largest viewport height a call may ask for. */
    readonly maxHeight: number;
    /** Longest post-load wait a call may ask for. */
    readonly maxDelayMs: number;
    /** Render budget used when the call names none. */
    readonly defaultTimeoutMs: number;
    /** What a render does at its deadline when the call names nothing. */
    readonly defaultOnTimeout: TimeoutBehavior;
    /** Host patterns every render of this deployment cancels, merged with the ones a call names. */
    readonly blockHosts: readonly string[];
    /** The cookie jars a call may name, by name; a call names one and never a cookie. */
    readonly cookieJars: CookieJars;
    /** What every render says it is, absent when this deployment renders under the backend's own. */
    readonly userAgent?: string;
}
/** The `screenshot` tool's arguments, before defaults are settled. */
export interface ScreenshotRequest {
    url: string;
    width?: number;
    height?: number;
    fullPage?: boolean;
    delayMs?: number;
    /** Extra request headers, as the model wrote them; values are checked here. */
    headers?: Record<string, unknown>;
    /** The name of a configured cookie jar, which is the only thing about a cookie a call carries. */
    cookieJar?: string;
    /** How long the render may take, in ms; the renderer owns its own ceiling. */
    timeoutMs?: number;
    /** What the render does at its deadline. */
    onTimeout?: TimeoutBehavior;
    /** Hosts whose requests the render cancels, as an exact host or `*.suffix`. */
    blockHosts?: string[];
}
/** One fully settled render, handed to whichever backend runs it. */
export interface RenderSpec {
    /** Absolute `http:`, `https:`, or `file:` URL. */
    readonly url: string;
    /** Viewport width in px. */
    readonly width: number;
    /** Viewport height in px. */
    readonly height: number;
    /** Whether the whole scrollable page is wanted rather than the viewport. */
    readonly fullPage: boolean;
    /** Extra wait after load, in ms; `0` captures as soon as the page settles. */
    readonly delayMs: number;
    /** Extra request headers, absent when the call named none. */
    readonly headers?: Readonly<Record<string, string>>;
    /**
     * The cookies of the jar the call named, absent when it named none. Their
     * values reach the renderer and nothing else: no tool result, no log line, and
     * no error quotes one.
     */
    readonly cookies?: readonly CookieSpec[];
    /** What the render says it is, absent when this deployment renders under the backend's own. */
    readonly userAgent?: string;
    /** How long the render may take, in ms, measured from the moment the renderer accepts it. */
    readonly timeoutMs: number;
    /** What the render does at its deadline. */
    readonly onTimeout: TimeoutBehavior;
    /**
     * Whether the call asked for {@link RenderSpec.onTimeout} itself rather than
     * taking the deployment's default. A backend that cannot honour it refuses a
     * call that asked and renders one that did not, because a default must not
     * make every capture on that backend fail.
     */
    readonly onTimeoutAsked: boolean;
    /** Hosts whose requests the render cancels, lowercased and deduplicated, absent when there are none. */
    readonly blockHosts?: readonly string[];
}
/**
 * Whether a settled render needs a session the renderer has to be told about.
 * @param spec - the settled render.
 * @returns true when the call carried headers or a cookie jar.
 */
export declare function carriesSession(spec: RenderSpec): boolean;
/**
 * Turn the model's `url` argument into a URL a browser can open.
 * @param raw - the `url` argument as the model wrote it.
 * @returns an `http:`, `https:`, or `file:` URL.
 * @throws when the value is empty, carries an unsupported scheme, or is a relative path.
 */
export declare function normalizeTarget(raw: string): string;
/**
 * Settle one render request against the deployment's limits.
 * @param request - the tool's validated arguments.
 * @param limits - the resolved plugin configuration's bounds and defaults.
 * @returns the render every backend receives.
 * @throws when the target or any bounded argument is unusable.
 */
export declare function resolveRenderSpec(request: ScreenshotRequest, limits: ScreenshotLimits): RenderSpec;
//# sourceMappingURL=request.d.ts.map