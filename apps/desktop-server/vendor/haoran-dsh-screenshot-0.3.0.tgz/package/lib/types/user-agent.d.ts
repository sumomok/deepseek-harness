/**
 * What a render says it is.
 *
 * Both backends announce themselves by default. The desktop shell's Chromium
 * sends `… Chrome/150.0.7871.224 Electron/43.4.0 Safari/537.36`, which tells
 * every page the agent looks at that it is being looked at by an Electron app —
 * and a site that answers a different page for it makes the capture a picture of
 * something the user never sees. A system browser sends its own build's string,
 * which names the machine's browser and version instead.
 *
 * The default here is the ordinary stable-Chrome string for the platform the
 * plugin runs on, with the build and patch numbers zeroed the way Chrome itself
 * reports them since 110. It is a `Config` field, so a deployment that wants a
 * different one sets it, and one that wants the backend's own sets it to the
 * empty string.
 * @module @haoran/dsh-screenshot/user-agent
 */
/**
 * The stable-Chrome user agent for one platform.
 *
 * `process.versions.chrome` is read when there is one — a harness embedded in
 * an Electron process has the version that will actually render — and the
 * written-down major is used otherwise. Only the major is reported either way,
 * which is what Chrome does.
 * @param platform - `process.platform` of the machine the plugin runs on.
 * @param chromeVersion - `process.versions.chrome`, when the runtime has one.
 * @returns the user agent every render of this deployment sends unless it is configured otherwise.
 */
export declare function defaultUserAgent(platform: string, chromeVersion: string | undefined): string;
//# sourceMappingURL=user-agent.d.ts.map