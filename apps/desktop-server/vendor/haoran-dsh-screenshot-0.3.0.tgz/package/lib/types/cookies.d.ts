/**
 * Named cookie jars: the deployment's credentials, and the one thing about them
 * a model ever sees.
 *
 * A cookie value is a bearer credential. Anything a model writes as a tool
 * argument is logged: it enters the session log, every later model request on
 * that session, the transcript a person reads, and whatever ships that
 * transcript somewhere else. So the values live in `cordis.yml`, under a name,
 * and the tool takes the name. The plugin resolves it in the process that holds
 * the config and sends the cookies to the renderer over loopback; nothing that
 * carries a value is ever returned, logged, or quoted into an error.
 *
 * Every member is checked here rather than at the first capture, because a jar
 * is decidable from the config alone and the render it would break is the one a
 * person configured this deployment to make.
 * @module @haoran/dsh-screenshot/cookies
 */
import z from '@deepseek-ai/schemastery';
/** One cookie of a configured jar, as it is written in cordis.yml. */
export interface CookieConfig {
    /** The cookie's name. */
    name: string;
    /** Its value: the credential, which never leaves this process except towards the renderer. */
    value: string;
    /** The host it belongs to, with or without a leading dot; it covers that host's subdomains. */
    domain: string;
    /** The path prefix it is sent for; `/` when the jar names none, so it reaches every request the page makes. */
    path?: string;
    /** Whether it is sent only over https. */
    secure?: boolean;
    /** Whether script on the page is kept from reading it. */
    httpOnly?: boolean;
    /** When it expires, in seconds since the epoch; absent makes it a session cookie, which is what a render wants. */
    expirationDate?: number;
}
/** One named jar of cookies. */
export interface CookieJarConfig {
    /** The cookies this jar holds; a jar with none is refused at load. */
    cookies: CookieConfig[];
}
/** One cookie of a resolved jar, with every attribute the config left out settled. */
export interface CookieSpec {
    /** The cookie's name. */
    readonly name: string;
    /** Its value. */
    readonly value: string;
    /** The host it belongs to, lowercased. */
    readonly domain: string;
    /** The path prefix it is sent for. */
    readonly path: string;
    /** Whether it is sent only over https. */
    readonly secure: boolean;
    /** Whether script on the page is kept from reading it. */
    readonly httpOnly: boolean;
    /** When it expires, in seconds since the epoch, absent for a session cookie. */
    readonly expirationDate?: number;
}
/** The jars of one deployment, by name. */
export type CookieJars = ReadonlyMap<string, readonly CookieSpec[]>;
/** The `cookieJars` config field, validated for its types here and for its grammars at load. */
export declare const CookieJarsConfig: z<Record<string, CookieJarConfig>>;
/**
 * What a call naming a jar this deployment does not have is refused with.
 *
 * The configured names are not listed: the refusal travels into the session
 * log, and which credentials a machine holds is not something to write there.
 * @param name - the jar the call asked for.
 * @returns the refusal the model reads.
 */
export declare function unknownCookieJar(name: string): string;
/**
 * Settle every configured jar at load.
 * @param jars - the `cookieJars` config field.
 * @param plugin - the plugin name, which every refusal opens with.
 * @returns the jars a call may name, by name.
 * @throws when a jar name, a jar, or any cookie in one is unusable.
 */
export declare function resolveCookieJars(jars: Record<string, CookieJarConfig> | undefined, plugin: string): CookieJars;
/**
 * What a jar costs to say out loud: how many cookies it holds, and nothing
 * about them.
 *
 * This is what a log line or a diagnostic may carry about a resolved jar. It
 * exists so that "say the jar, not the cookies" is a call rather than a rule
 * every call site has to remember.
 * @param name - the jar that was used.
 * @param cookies - the cookies it holds.
 * @returns the phrase naming the jar and its size.
 */
export declare function cookieJarSummary(name: string, cookies: readonly CookieSpec[]): string;
//# sourceMappingURL=cookies.d.ts.map