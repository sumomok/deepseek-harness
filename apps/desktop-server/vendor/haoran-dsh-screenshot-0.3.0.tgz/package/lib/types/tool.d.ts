/**
 * The model-facing `screenshot` tool: renders a page, durably commits the PNG
 * through the attachment service, and returns an image block so the rendered
 * page enters model context from the next request onward. A call naming
 * `outputPath` also gets the bytes as a file it can hand to something else.
 *
 * Every capture from the desktop render service also carries that render's
 * report, which the result turns into a few bounded lines: what the main
 * document answered, what is still in flight and on which host, what the page
 * logged, and — for a render that ran out of time — that the image is a
 * partial capture and what to call the tool again with.
 *
 * The tool exists only while an attachment store is mounted — `src/index.ts`
 * registers it inside `ctx.inject(['attachments'], …)` — because an image block
 * must reference a durably committed object by the time the tool result is
 * appended to the session log.
 *
 * The same registration contributes {@link SCREENSHOT_GUIDANCE} to the system
 * prompt, because the argument nobody reads is the capability nobody has.
 * @module @haoran/dsh-screenshot/tool
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { RenderBackends } from './render.ts';
import type { RenderValue } from './report.ts';
import type { ScreenshotLimits } from './request.ts';
/** Everything the tool needs from the plugin that registers it. */
export interface ScreenshotToolOptions {
    /** Argument bounds and defaults from the plugin config, including the render budget. */
    readonly limits: ScreenshotLimits;
    /** The render backends this deployment has. */
    readonly backends: RenderBackends;
}
/**
 * The one line this plugin contributes to the system prompt.
 *
 * It earns the slot the way the harness's own eleven directive lines do: the
 * tool is useless if it is not reached for. Two agents on two platforms hit a
 * login wall with this tool and neither one ever called it again — they wrote
 * cookie proxies instead — because the prompt they read named `screenshot`
 * nowhere, and the tool's own description read as a CSS self-check. The line
 * says what the tool is now for, including the argument that was missing.
 *
 * It is one line and stays one line: the jar names, the backends, and the
 * containment rule on `outputPath` are the tool description's job, which is
 * read at the moment of the call.
 */
export declare const SCREENSHOT_GUIDANCE = "Use the screenshot tool to look at any page as pixels \u2014 your own HTML or CSS work, or a live site you need to see, including one behind a login: pass cookieJar to render it with a session this machine holds, and outputPath to save the PNG as a file as well. It reports why a page was slow or incomplete, and what to call it again with.";
/**
 * Register the `screenshot` tool and its system-prompt guidance.
 *
 * Both are one contribution: a tool the prompt never mentions is a tool the
 * model does not reach for, which is the failure {@link SCREENSHOT_GUIDANCE}
 * exists to end, so they are registered together or not at all.
 * @param ctx - the registration scope; execution uses its `attachments` service and optional `llm`.
 * @param options - argument bounds, capture budget, and render backends.
 */
export declare function applyScreenshotTool(ctx: Context, options: ScreenshotToolOptions): void;
/**
 * Build the tool definition.
 * @param ctx - the context whose services execution reads.
 * @param options - argument bounds, capture budget, and render backends.
 * @returns the registry-ready definition.
 */
export declare function screenshotTool(ctx: Context, options: ScreenshotToolOptions): ToolDefinition;
/** The canonical outcome declared by the `screenshot` output schema. */
export interface ScreenshotValue {
    url: string;
    renderer: 'desktop' | 'chrome';
    /** Where the main frame ended up, when the engine reported somewhere other than `url`. */
    landedUrl?: string;
    /** Whether the image is of a page that had not finished loading when its deadline passed. */
    partial: boolean;
    /**
     * What the renderer reported about this render: the report, `null` where the
     * backend produces none — every system-browser capture, and a desktop shell
     * older than the report protocol — and `'unreadable'` for a report header
     * this client could not read.
     */
    render: RenderValue | 'unreadable' | null;
    /** The file this capture was also written to, when the call asked for one. */
    file?: {
        path: string;
        overwritten: boolean;
    };
    image: {
        attachmentId: string;
        mediaType: 'image/png';
        bytes: number;
        width: number;
        height: number;
        name?: string;
    };
}
/**
 * Project one capture into the model-facing envelope and the image itself.
 *
 * The envelope names the engine as well as the size, because the two backends
 * do not draw identical pixels and a model comparing two screenshots of the
 * same page needs to know when it is also comparing two renderers.
 *
 * It also says the three things a picture cannot: which file the bytes went to,
 * that the page in the image is not the page that was asked for, and what the
 * render itself did. A capture of a sign-in screen returned without comment
 * reads as the requested page having failed, which is what sends a caller off
 * writing a proxy instead of passing a cookie; a partial capture returned
 * without comment reads as a finished page that renders wrongly, which is
 * worse, so it is labelled before the image is described at all.
 * @param value - the canonical capture outcome.
 * @returns the text envelope followed by the image block.
 */
export declare function screenshotContent(value: ScreenshotValue): ContentBlock[];
//# sourceMappingURL=tool.d.ts.map