/**
 * The gate-checking `submit` wrapper, framework-free: everything
 * `gate-registry.ts` needs to gate one session's submit, factored out so it
 * is testable by calling `submit`/`pick`/`cancel` directly and asserting the
 * `keyboard.submit` calls and `onStatus` transitions they produce — no
 * React, no DOM, no cordis.
 *
 * @module @haoran/dsh-vision-switch/client/submit-gate
 */
import type { SessionId } from '@deepseek-ai/dsh-api-remotes/client';
import type { VisionModelEntry } from '../types.ts';
import type { CatalogCache } from './catalog-cache.ts';
import { type ModelSelectionFace } from './gate.ts';
/**
 * The composer's `submit` arguments, forwarded opaquely and exactly as
 * received: the delivery mode (the real `InputSubmitMode` is private to
 * `@deepseek-ai/dsh-client-ui-conversation`) and which control sent it.
 */
export type SubmitArgs = [mode?: unknown, source?: 'click' | 'enter'];
/** The one live read and the one write this plugin needs from a session's real input facade. */
export interface KeyboardFace {
    /**
     * Whether the draft currently carries at least one image attachment, read
     * live off the session's own draft registry. A draft of text plus .pcap,
     * .csv or any other non-image file answers false and is sent untouched:
     * those reach the model as uploaded-file references that no model's image
     * support gates. A throw (the draft can no longer be read the way the
     * caller reads it) falls through to `submit` unchanged.
     */
    hasImageAttachment(): boolean;
    /** Submit with the caller's own arguments. */
    submit(...args: SubmitArgs): void;
}
/** Why a send was blocked: no vision-capable model at all, or none whose provider has a credential. */
export type BlockedReason = 'no-vision-model' | 'missing-credential';
/** UI status a submit attempt leaves behind for the caller to render. */
export type GateStatus = {
    readonly kind: 'idle';
} | {
    readonly kind: 'choosing';
    readonly options: readonly VisionModelEntry[];
} | {
    readonly kind: 'blocked';
    readonly reason: BlockedReason;
} | {
    readonly kind: 'switched';
    readonly name: string;
};
/** The gated submit face a caller hands `keyboard.submit`'s replacement, plus the chooser actions. */
export interface GatedSubmit {
    /** Replacement for `keyboard.submit`: resolves the gate before forwarding (or not forwarding) the real call. */
    submit(...args: SubmitArgs): void;
    /** A chooser option was picked: switch to it, then submit with the pending arguments. */
    pick(entry: VisionModelEntry): void;
    /** The chooser was dismissed: abort, draft intact — `keyboard.submit` is never called for this attempt. */
    cancel(): void;
}
/** How long the "switched" status stays before it clears itself back to idle. */
export declare const SWITCHED_STATUS_MS = 6000;
/**
 * Build one gated submit face for one session's keyboard.
 *
 * A background switch or gate check that settles after the caller has moved
 * on (a session switch, an unmount) still fires its `keyboard.submit`/
 * `onStatus` calls: `keyboard` is bound to the session it was read for, not
 * to whichever session is currently displayed, so a late call submits into
 * the session the draft actually belonged to rather than corrupting
 * whatever is on screen now — the harmless outcome, and not worth an
 * AbortController for a handful of milliseconds of round trip.
 * @param selection - the composer picker read and the session write.
 * @param catalog - this plugin's own catalog cache.
 * @param sessionId - the session the draft belongs to.
 * @param keyboard - the session's real input facade, narrowed to what this plugin reads and wraps.
 * @param onStatus - called whenever the UI status changes.
 * @returns the gated submit face.
 */
export declare function createGatedSubmit(selection: ModelSelectionFace, catalog: CatalogCache, sessionId: SessionId, keyboard: KeyboardFace, onStatus: (status: GateStatus) => void): GatedSubmit;
//# sourceMappingURL=submit-gate.d.ts.map