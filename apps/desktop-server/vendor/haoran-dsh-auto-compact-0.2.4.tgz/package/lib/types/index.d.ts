/**
 * Compact the conversation before it runs out of room, at a point the person
 * using it chose.
 *
 * A long conversation eventually reaches the end of the model's context
 * window. What happens there is not a matter of taste — the work stops — so
 * the harness already recovers from an overflow. This plugin is about the
 * moment *before* that: at what share of the window the conversation should
 * make room for itself, and whether it should do so at all.
 *
 * That is a preference, and it belongs to the person, not to the profile.
 * Someone who wants every last token of history before anything is summarised
 * sets it high; someone who would rather never run close to the edge sets it
 * low; someone who wants to decide each time switches it off. So this plugin
 * owns exactly two things — a switch and a percentage — and it owns *when*:
 * the conversation is compacted after a turn ends, never between the steps of
 * one.
 *
 * Two halves make that one behavior. The `compactionPolicy` service answers
 * `isEnabled(): false`, which is what turns the harness's own between-steps
 * compaction off; the idle path watches each agent settle and compacts there
 * instead, on the switch and the percentage a person set. The seat answers
 * `false` only while that idle path has an engine to compact with, so the two
 * can never come apart into a composition that compacts nowhere.
 *
 * Overflow recovery is untouched by both halves: that is the harness's own
 * floor and this plugin can neither raise nor lower it.
 *
 * @module @haoran/dsh-auto-compact
 */
import type { Context } from '@deepseek-ai/cordis';
import { type Config } from './config.ts';
export { Config, resolveAutoCompactConfig } from './config.ts';
export { installIdleCompaction, occupiedShare } from './idle-compaction.ts';
export type { IdleCompaction } from './idle-compaction.ts';
export { createCompactionPolicy } from './policy.ts';
export type { CompactionPolicy } from './policy.ts';
export { AUTO_COMPACT_SETTINGS_NAMESPACE, DEFAULT_ENABLED, DEFAULT_THRESHOLD_PERCENT, THRESHOLD_MAX_PERCENT, THRESHOLD_MIN_PERCENT, THRESHOLD_STEP_PERCENT, } from './section.ts';
export type { AutoCompactSettings } from './section.ts';
export { autoCompactSettingsSchema, installAutoCompactSettings } from './settings.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "auto-compact";
/**
 * Mount the end-of-reply compaction and the policy seat that clears the way
 * for it.
 *
 * Both live in one injection so they cannot come apart: the seat's `false` is
 * what closes the harness's own between-steps path, and closing it without the
 * idle path installed would leave a composition that never compacts at all.
 * The injected service is the host-plane projection registry the context
 * reading comes from. The compaction engine itself is resolved per agent,
 * because a preset publishes it behind an `isolate` realm no injection can
 * see.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map