/**
 * The `compactionPolicy` service: the two answers the agent loop asks for
 * before it starts a step.
 *
 * **`isEnabled()` is how this plugin turns the harness's own between-steps
 * compaction off**, and that is the whole of what the seat is used for here:
 * compacting in the middle of a turn interrupts work the user is watching, and
 * the loop retries a failed attempt at every following step with nothing held
 * between the attempts. This plugin triggers its own compaction once a reply
 * finishes (`./idle-compaction.ts`). The switch a person sets is read there,
 * not here.
 *
 * It answers `false` only once the idle path has actually reached a compaction
 * engine. Before the first agent exists, and in a composition whose engine this
 * plugin can address for no agent at all, it answers `true` — the harness's own
 * behaviour, unchanged.
 *
 * The coupling is per process, not per conversation: the seat takes no agent,
 * so one answer governs every agent the engine serves. Reaching an engine for
 * one conversation therefore closes the harness's path for all of them, and the
 * idle path has to cover all of them in turn — which is why it acts on
 * delegated agents as well. A conversation whose own composition mounts no
 * engine is reported in the host log and left alone; it has no engine to close
 * a path in either.
 *
 * `thresholdRatio()` reads through to the settings source on every call, so it
 * answers the share in force right now rather than the one stored at mount.
 * The engine stops asking once `isEnabled()` answers false — that closes the
 * only path that reads it — and it stays because it is half of a published
 * service key any backend may read.
 *
 * @module @haoran/dsh-auto-compact/policy
 */
import type { AutoCompactSettings } from './section.ts';
/** Live automatic-compaction policy a host-plane plugin provides from user settings. */
export interface CompactionPolicy {
    /**
     * Whether pressure-triggered compaction runs at all; overflow recovery is unaffected.
     * @returns false once this plugin's own end-of-reply compaction can run, true while it cannot.
     */
    isEnabled(): boolean;
    /**
     * Share of the model's context window (0–1) at which the next step compacts first.
     * @returns the live threshold ratio; a value outside (0, 1], or one the retained tail
     *   would not clear, is refused and the configured ratio governs instead.
     */
    thresholdRatio(): number;
}
/**
 * The service key, declared here because this package is the only one that
 * can: the agent loop that reads it at runtime lives in the harness checkout,
 * and this plugin builds against the published packages, which do not carry
 * the declaration. Retire this block if a published `@deepseek-ai/dsh-*` ever
 * declares the key itself — two augmentations of one interface member must
 * agree exactly, and the other one would then be the authority.
 */
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Automatic-compaction policy, provided by `@haoran/dsh-auto-compact`. */
        compactionPolicy: CompactionPolicy;
    }
}
/**
 * Build the policy over a settings source and the idle path's own coverage.
 * @param source - thunk returning the section in force right now; the settings
 * scope while one is attached, the composition entry otherwise.
 * @param covers - whether the idle path has reached an engine it can compact with.
 * @returns the policy to provide under `compactionPolicy`.
 */
export declare function createCompactionPolicy(source: () => AutoCompactSettings, covers: () => boolean): CompactionPolicy;
//# sourceMappingURL=policy.d.ts.map