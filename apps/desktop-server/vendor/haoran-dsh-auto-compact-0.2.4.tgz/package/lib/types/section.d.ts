/**
 * What one person's automatic-compaction choice is, and the range it lives in.
 *
 * This module is the one home for those facts and imports nothing, because
 * both halves need them: the host half registers the settings namespace and
 * reads it, and the browser half registers its card under the same namespace
 * and draws the slider over the same range. A client bundle may not reach the
 * host half (it would pull the schema library into the page), so the shared
 * facts live below both.
 *
 * The three bounds are not configuration. They are the shape of the control —
 * below the floor compaction would fire on a conversation that has barely
 * started, and above the ceiling it would fire too late to leave room for the
 * step it is making room for. What a deployment does choose is the pair of
 * values this range is entered at, which are this plugin's `Config` fields.
 *
 * @module @haoran/dsh-auto-compact/section
 */
/** Settings namespace this plugin owns, and the key its card is dispatched under. */
export declare const AUTO_COMPACT_SETTINGS_NAMESPACE = "auto-compact";
/** One person's automatic-compaction choice. */
export interface AutoCompactSettings {
    /** Whether compaction runs on context pressure at all. */
    enabled: boolean;
    /** Share of the context window, in percent, that triggers it. */
    thresholdPercent: number;
}
/** Lowest share the slider offers. */
export declare const THRESHOLD_MIN_PERCENT = 20;
/** Highest share the slider offers. */
export declare const THRESHOLD_MAX_PERCENT = 95;
/** Distance between two slider positions. */
export declare const THRESHOLD_STEP_PERCENT = 5;
/** Shipped default for the switch; `Config.enabled` is what changes it. */
export declare const DEFAULT_ENABLED = true;
/** Shipped default for the share; `Config.thresholdPercent` is what changes it. */
export declare const DEFAULT_THRESHOLD_PERCENT = 60;
//# sourceMappingURL=section.d.ts.map