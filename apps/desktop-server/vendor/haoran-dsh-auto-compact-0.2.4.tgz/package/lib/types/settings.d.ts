/**
 * The durable side: one settings namespace, and the live source the policy
 * reads through.
 *
 * Attachment is optional. `installSection` hands back the composition entry as
 * the authoritative value while no settings provider is composed and swaps in
 * the resolved scope when one attaches, so the policy answers from its first
 * call onward and a deployment that stores no settings still gets the
 * behaviour its profile asked for — it just cannot change it from Settings.
 *
 * The schema is the whole admission rule: an integer inside the slider's own
 * range. There is no cross-field constraint for a `validate` hook to carry,
 * and restating the range there would give one fact two homes that could
 * disagree.
 *
 * @module @haoran/dsh-auto-compact/settings
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type AutoCompactSettings } from './section.ts';
/**
 * Build the namespace schema around one composition entry.
 *
 * The entry supplies the schema defaults as well as the `base` layer, so a
 * configuration surface rendering the schema alone reports the same starting
 * values the deployment actually starts people on.
 * @param entry - the composition entry this section is layered over.
 * @returns the schema resolving the namespace.
 */
export declare function autoCompactSettingsSchema(entry: AutoCompactSettings): z<AutoCompactSettings>;
/**
 * Register the namespace where a settings provider is composed, and hand back
 * the reader the policy answers from.
 * @param ctx - the plugin context; its unload removes the namespace.
 * @param entry - the composition entry, used as the base layer and as the
 * value while no provider is attached.
 * @returns a thunk returning the section in force right now.
 */
export declare function installAutoCompactSettings(ctx: Context, entry: AutoCompactSettings): () => AutoCompactSettings;
//# sourceMappingURL=settings.d.ts.map