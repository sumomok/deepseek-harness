/**
 * Plugin configuration: the two values a deployment starts people on. Both are
 * changeable from `cordis.yml` and validated at load.
 *
 * They are the composition layer, not the answer: a person who moves the
 * switch or the slider writes a user layer over them, and that is what the
 * policy reads from then on. Changing them in a profile therefore changes what
 * someone who has never opened Settings gets, and nothing else.
 *
 * @module @haoran/dsh-auto-compact/config
 */
import z from '@deepseek-ai/schemastery';
import { type AutoCompactSettings } from './section.ts';
/** Plugin configuration. */
export interface Config {
    /** Whether automatic compaction starts switched on. */
    enabled?: boolean;
    /** The share of the context window it starts set to, in percent. */
    thresholdPercent?: number;
}
export declare const Config: z<Config>;
/**
 * Settle defaults into the composition entry the settings section is layered
 * over.
 * @param config - the schema-validated plugin config.
 * @returns the section as it stands before any user layer.
 */
export declare function resolveAutoCompactConfig(config: Config): AutoCompactSettings;
//# sourceMappingURL=config.d.ts.map