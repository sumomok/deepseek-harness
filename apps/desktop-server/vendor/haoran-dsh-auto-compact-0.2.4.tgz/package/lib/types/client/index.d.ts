/**
 * Browser half: one card in Settings, under Plugins.
 *
 * **No new navigation entry.** Settings already has a page whose whole job is
 * to hold the cards of plugins that expose a preference, and it dispatches them
 * by settings namespace, so this plugin's card arrives there by registering
 * under the same namespace its host half registers on the Host. A build whose
 * settings page has no such page declares no such slot, `ctx.slots.inject`
 * never fires, and this plugin puts nothing on screen — which is the right
 * outcome, and needs no version check.
 *
 * Everything here reads and writes one namespace through `ctx.settingsScope`.
 * This half makes no call of its own, holds no copy of the policy, and never
 * talks to its own host half: the two meet at the settings document.
 *
 * @module @haoran/dsh-auto-compact/client
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type AutoCompactKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-auto-compact` copy. */
        autoCompact: AutoCompactKey;
    }
}
export { AutoCompactCard } from './AutoCompactCard.tsx';
export type { AutoCompactCardProps } from './AutoCompactCard.tsx';
export { AutoCompactCardController, snapThresholdPercent } from './card-controller.ts';
export type { AutoCompactCardFace, AutoCompactCardState } from './card-controller.ts';
export { en, fill, NS, zh } from './locales.ts';
export type { AutoCompactKey } from './locales.ts';
export type { SettingsPluginItemOwnerProps } from './slot-contract.ts';
export { insertStyles, STYLE_TAG } from './styles.ts';
/** Required browser services. */
export declare const inject: string[];
/**
 * Mount the card.
 * @param ctx - the browser plugin context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map