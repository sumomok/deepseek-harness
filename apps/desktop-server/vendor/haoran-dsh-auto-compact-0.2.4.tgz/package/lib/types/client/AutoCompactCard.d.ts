/**
 * The card: a switch, a slider, and one line saying what the number means.
 *
 * Two controls do not need a save button. A switch that waits to be saved is a
 * switch that lies about its own position, and a slider whose figure is the
 * one the person just dragged to is already the confirmation a save would give
 * them. So both write on the gesture that ends them — the toggle, and the
 * release of the slider — and the line under the title re-reads the value back.
 *
 * The slider stays visible while the switch is off. Hiding it would lose the
 * figure the person chose, and greying it out says the same thing without
 * making the card change height.
 *
 * @module @haoran/dsh-auto-compact/client/AutoCompactCard
 */
import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { AutoCompactCardFace } from './card-controller.ts';
/** Props the renderer binds for this card. */
export type AutoCompactCardProps = PropsRuntime<'settings.plugin.item'> & PropsLocale<'autoCompact'> & InjectFace<AutoCompactCardFace>;
/**
 * Render the automatic-compaction card.
 * @param props - locale copy, the card snapshot, and its two writes.
 * @returns the card, or nothing while the Host does not serve this namespace.
 */
export declare function AutoCompactCard(props: AutoCompactCardProps): ReactNode;
//# sourceMappingURL=AutoCompactCard.d.ts.map