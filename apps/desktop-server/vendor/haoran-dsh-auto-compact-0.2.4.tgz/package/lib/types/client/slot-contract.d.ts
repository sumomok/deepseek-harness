/**
 * The seat this card takes: `settings.plugin.item`, the keyed slot the
 * configurable-plugins tab dispatches once per settings namespace it serves.
 *
 * **Keying on the namespace is the whole mechanism.** The tab renders the
 * intersection of two ledgers — the namespaces the Host reports and the cards
 * registered into this slot — and never learns what any namespace means. A
 * plugin distributed outside the harness therefore gets a card by doing the two
 * halves of its own job: registering its namespace on the Host, and registering
 * a card under that same key in the browser.
 *
 * A build whose settings page has no such tab never declares the key, so
 * `ctx.slots.inject` never fires and this plugin contributes no interface at
 * all. That is the intended outcome, and it needs no version check.
 *
 * @module @haoran/dsh-auto-compact/client/slot-contract
 */
/**
 * Owner share of a plugin card (the tab supplies nothing).
 *
 * Declared here because this package is the only one that can: the tab that
 * declares the slot at runtime lives in the harness checkout, and this plugin
 * builds against the published packages, which do not carry the declaration.
 * Retire this file if a published `@deepseek-ai/dsh-client-ui-*` ever declares
 * the key itself — two augmentations of one interface member must agree
 * exactly, and the other one would then be the authority.
 */
export interface SettingsPluginItemOwnerProps {
    /** Marker field: card owner props are intentionally empty. */
    children?: never;
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /** One plugin's card inside the plugin configuration section (see module JSDoc). */
        'settings.plugin.item': {
            kind: 'keyed';
            scope: 'root';
            owner: SettingsPluginItemOwnerProps;
        };
    }
}
//# sourceMappingURL=slot-contract.d.ts.map