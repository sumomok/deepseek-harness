# @haoran/dsh-desktop-update

English | [中文](README.zh.md)

Update the DeepSeek Harness desktop application itself, from inside it. An **Updates** page appears in Settings showing the running version, whether a newer one has been published, what changed in it, and — while one is being fetched — how far the download has got. Once a version is on disk, one compact button appears in the sidebar foot, and pressing it opens that page.

## What you see, and when

| Where | When | What |
| --- | --- | --- |
| Settings → **Updates** | Always | Running version, whether a newer one is published, release notes, the last check's time, a **Check now** button, a **Download the new version** button when a newer version was found, and the download's own progress bar |
| Sidebar foot | Only at the moment a downloaded version is waiting | A compact **Update to latest** button, which opens the page above |
| Anywhere else | Never | — |

Three product rules decide that table, and each one is deliberate:

- **An update is not part of the work you came here to do.** It waits in Settings, with the other application-wide choices, rather than interrupting a session.
- **Nothing is prominent while it downloads.** Progress belongs to whoever went looking for it. A transfer nobody asked to watch stays on the page and nowhere else — there is nothing to do about it anyway.
- **The one visible affordance appears only when it is actionable.** Not while checking, not while downloading. `ready` is the first moment with an action behind it.

Pressing **Restart and install** restarts the application into the new version. **That press is the consent** — nothing asks a second time, here or in the shell.

Only one line on the page carries a version number: the one naming the version you are running. Nothing names the version being offered — neither the page, nor the sidebar button, nor its accessible name.

## Where it works, and where it does nothing

This plugin needs the loopback update service the desktop shell lends the server it starts — `DSH_DESKTOP_UPDATE_ENDPOINT` and `DSH_DESKTOP_UPDATE_TOKEN` in that one child process's environment. A `dsh web` on a server sets neither. There, `state()` answers `available: false` with phase `unsupported`, the browser half registers no page and no button, and nothing appears in Settings — the right outcome for a feature nobody there can use, rather than a page that opens onto an apology.

There is no second path. This plugin never reads an update feed, never checks a signature, never writes a file, and never restarts anything. Every one of those belongs to the shell, which is the only thing on the machine that can replace the running application.

## The contract with the shell

The shell serves four routes on a loopback origin. All four require `Authorization: Bearer <token>` with the token from the environment.

| Route | Answer |
| --- | --- |
| `GET /state` | `{ phase, currentVersion, latestVersion?, releaseNotes?, percent?, transferredBytes?, totalBytes?, reason?, checkedAt? }` |
| `POST /check` | `{ ok: true }` or `{ ok: false, error }` |
| `POST /download` | `{ ok: true }` or `{ ok: false, error }` |
| `POST /install` | `{ ok: true }` or `{ ok: false, error }` — and the application restarts into the new version immediately |

`phase` is one of `idle`, `checking`, `downloading`, `ready`, `failed`. (`unsupported` is this plugin's own sixth value for a deployment with no service at all; the shell never sends it.) A field the shell spells with a type this build does not expect is dropped rather than carried into the page; a body with no readable `phase` is refused, because the whole page is a projection of that one field.

`/check` and `/download` start work and answer; progress and the ending arrive through `/state`. `/install` may not answer at all — the application goes away while the call is in flight — and that is the expected ending, not a fault.

## Permissions / security

- **The browser never sees the endpoint or the token.** Both are read once from the process environment on the host side. The browser half reaches the host only through the harness's own `/api` Typert gateway, and this plugin registers no HTTP route of its own. A build check asserts neither variable name reaches the browser bundle.
- **A caller cannot name a version, a URL, or a file.** All four methods take no parameters at all. The version installed is the one the shell's own check found.
- **The shell owns every decision that matters** — which feed, which signature, which file, and when to restart. This plugin composes four requests and reads four answers.
- **Nothing here can fail a launch.** Every failure it can meet — no service, a service that stopped answering, a body it cannot read — becomes a sentence on the page. No exception crosses the gateway.

## Where the button sits

Two seats can hold the ready button, and which one exists depends on the build:

| Seat | Declared by | Position |
| --- | --- | --- |
| `settings.trigger.action` | A core patch in the harness checkout | Right-aligned on the settings row itself |
| `sidebar.footer.action` | `@deepseek-ai/dsh-client-ui-sidebar`, always | The sidebar foot, above the settings row |

**The choice is made from the live slot declaration ledger, not from a version check.** `ctx.slots.inject(key, …)` runs its callback once per declaration lifetime of `key` and never runs it while the key is undeclared, so injecting on the patched key *is* the detection: the callback firing means the seat exists. The fallback registers only while that has not happened and stands down the moment it does, which also covers the order the declarations arrive in — the sidebar declares its foot before the settings shell it contains can declare anything.

Which seat it took decides how it is drawn, and the seat's own `openSection` is how it knows: in the settings row the button paints no surface of its own — no border, no background, none on hover — because that row owns the hover fill across its whole width, and the label brightens together with the gear beside it instead of sitting in a second box inside that fill. In the sidebar foot the button is a row of its own with nothing painting underneath it, so it keeps the bordered pill that marks it as pressable.

## How the button opens the page

**The settings shell publishes no way to open itself.** Checked against the harness at `0.1.5-rc.1`: `@deepseek-ai/dsh-client-ui-settings` declares the slot types and `ctx.settingsScope`, and nothing else; the shell that renders the panel (`ui-settings-general`'s `SettingsRoot`) keeps both `open` and the active section id in component-local `useState`, and the one opener it hands out — `openSection(id)` — reaches exactly one audience, the occupants of the `settings.onboarding` slot. There is no cordis service, no command, and no event.

So the button does what a person does: it presses the shell's own controls — the settings trigger, then the nav row for this page. The trigger is found by walking out from the button that was clicked rather than by searching the document, because `button[aria-haspopup="dialog"][aria-expanded]` also matches the chat's stat pills and nothing in the markup tells them apart. When the seat's owner hands down an `openSection` of its own, that is used instead and no DOM is touched.

Every failure on that path is silent and harmless: nothing found means nothing pressed, and Settings opens the way it always could.

## Configuration

| Key | Default | What it does |
| --- | --- | --- |
| `activePollMs` | `3000` | How often the page re-reads the state while it is open or a transfer is running |
| `idlePollMs` | `60000` | How often it re-reads the rest of the time; this is what decides how soon the ready button appears for someone who never opened Settings |
| `requestTimeoutMs` | `60000` | How long the host half waits for one answer from the shell |

Both intervals are resolved on the host and carried in every view, so the browser half decides no number of its own. Every read is one loopback request that touches no network.

The protocol is not configuration and is not configurable: the two environment variable names, the four route paths, and the bearer scheme are fixed facts of the shell this plugin talks to.

## Compatibility

Requires the desktop shell's update service, which ships from `apps/desktop` in the harness repository. Built against the `0.1.x` harness line, including the `0.1.5-rc.1` base — which is why the `@deepseek-ai/*` peer ranges are spelled `>=0.1.2-alpha.2 <0.2.0-0 || >=0.1.5-rc.1 <0.2.0-0`: a comparator set admits a prerelease only for a `major.minor.patch` tuple one of its own comparators names, so the first set alone would reject `0.1.5-rc.1`.

## Install

```sh
pnpm run build && pnpm pack
dsh plugin --profile desktop add /absolute/path/to/haoran-dsh-desktop-update-0.1.0.tgz
```

## Out of scope

Downloading, verifying, staging, and restarting. All four are the shell's, and none of them can be done from inside a Node process the shell started. Plugin updates are a different subject with a different fence — that is `@haoran/dsh-plugin-updates`.
