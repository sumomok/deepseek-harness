/**
 * Writing a capture to a file beside the image block it always returns.
 *
 * An image block is what a model can look at, and nothing else; it is not a
 * file, and the attachment store behind it is content-addressed, so two
 * identical captures produce one object and no path an agent can hand to
 * anything. Work that ends in files — a document with figures, a report, a
 * directory of evidence — needs the PNG on disk under a name the agent chose.
 *
 * There is no filesystem capability in this plugin's reach: `ctx.fs` writes
 * UTF-8 text and has no byte write, so a PNG cannot go through it. The write
 * is therefore an ordinary `node:fs` write, fenced by the one boundary this
 * plugin can establish honestly — the calling session's own workspace. A path
 * outside it is refused rather than written; an absent parent directory inside
 * it is created; an existing file is replaced and the replacement is reported,
 * because a capture that silently overwrote a file the agent still needed would
 * be discovered later, by something else.
 *
 * The containment is checked twice, because one check is not the boundary it
 * looks like. Resolving the path settles `..`, and resolving the symbolic links
 * of the directory it lands in settles the rest: a directory inside the
 * workspace can be a link to one outside it, and a path that reads as contained
 * would then be written outside. Both are checked before anything is created,
 * so a refusal leaves no directory behind either.
 *
 * Security: This module defends against CWE-59 (link following) and TOCTOU
 * (time-of-check to time-of-use) attacks:
 * - Dangling symlinks are rejected, not followed
 * - Symlinks pointing outside the workspace are rejected
 * - The write operation itself uses O_NOFOLLOW when possible to prevent
 *   following symlinks that appear after the check but before the write
 * - A temporary file is written and then renamed after re-verification to
 *   mitigate TOCTOU during the render wait period
 * @module @haoran/dsh-screenshot/output
 */
/** One capture written to disk. */
export interface WrittenOutput {
    /** The absolute path written. */
    readonly path: string;
    /** Whether a file was already there and has been replaced. */
    readonly overwritten: boolean;
}
/**
 * Settle the `outputPath` argument against the session's workspace.
 *
 * A relative path is resolved against the workspace, matching every other
 * file-writing tool in the harness; an absolute one is kept but must still land
 * inside it. Both rules need a workspace, so a call with no session — an
 * agentless invocation — cannot ask for a file at all.
 *
 * The lexical check settles `..`; the second check settles the symbolic links,
 * by comparing the deepest existing part of the path against the resolved
 * workspace. A directory inside the workspace that links outside it is the case
 * the first check cannot see.
 *
 * SECURITY: This function rejects dangling symlinks (realAncestor will throw)
 * and symlinks pointing outside the workspace. The target path itself is checked
 * if it exists - it must not be a symlink or a directory.
 * @param raw - the `outputPath` argument as the model wrote it.
 * @param workspace - the calling session's workspace directory, when it has one.
 * @returns the absolute path to write.
 * @throws when the value is empty, there is no workspace, the path leaves the workspace,
 *         the path or any parent is a dangling symlink, or the target is a symlink/directory.
 */
export declare function resolveOutputPath(raw: string, workspace: string | undefined): Promise<string>;
/**
 * Write one capture to the settled path, safely.
 *
 * SECURITY: This implements multiple defenses against symlink attacks and TOCTOU:
 * 1. Writes to a temporary file in the same directory first
 * 2. Re-verifies the target path before the final rename
 * 3. Rejects symlinks at the target path
 * 4. Uses O_NOFOLLOW when opening files on platforms that support it
 *
 * The temporary file is created with a random suffix to avoid conflicts and
 * is cleaned up on error. The rename is atomic, which provides additional
 * protection against race conditions.
 * @param path - the absolute path from {@link resolveOutputPath}.
 * @param data - the PNG bytes.
 * @returns the path written and whether it replaced a file.
 * @throws when the filesystem refuses the write, or the target becomes a symlink.
 */
export declare function writeOutput(path: string, data: Uint8Array): Promise<WrittenOutput>;
//# sourceMappingURL=output.d.ts.map