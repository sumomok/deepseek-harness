# @haoran/dsh-default-model

The deployment's factory default model. It ships with the desktop app, so a fresh installation opens its first session on `deepseek-flash` — DeepSeek-V4.1-Flash — which is also the only model the picker offers.

## What it changes

Two id-targeted overrides on top of whatever `@deepseek-ai/dsh-base` composed, and nothing else — no plugin is inserted, no runtime code is loaded.

| Entry | Change |
| --- | --- |
| `agent-default-model` | `provider: deepseek-official`, `model: deepseek-flash` — the selection every Agent created without an explicit model starts from. |
| `llm-deepseek` | The advisory `models` catalog, replaced by a single `deepseek-flash` row that restates the factory row. |

`@deepseek-ai/dsh-base` names the same `deepseek-official` / `deepseek-flash` pair; this layer keeps it so the desktop's starting model does not move if upstream changes its base default. Only a profile whose user has not picked a model follows it: a pick is written into the profile's own patch row, which outranks this layer from then on (see [Precedence](#precedence)).

**The catalog is one row because DeepSeek retired the others.** Its pricing page says of `deepseek-flash` that 「旧模型名 deepseek-v4-flash、deepseek-v4-flash-vision-exp 仍可调用，但对应模型已下线，请求将由 DeepSeek-V4.1-Flash 模型提供服务，并按 Flash 价格计费。」, and of `deepseek-v4-pro` that from 12:00 Beijing on 2026-09-14 its requests route to V4.1 Flash and bill at V4.1 Flash prices as well. Every id the old table offered is served by this one model, so listing them would offer a choice that is not one.

The row restates the adapter's own factory `deepseek-flash` row — `contextWindow: 1000000`, `inputModalities: [text, image]`, `systemPromptUpdate: in-history`, `toolUpdate: addition-only` — with this deployment's `name` and an added `description`. It is named for the model rather than labelled `default`: with a single row there is nothing to mark out, and a picker whose only entry reads `default` says less than one that names the model.

### If your stored selection names a retired model

A user who picked `deepseek-v4-flash` or `deepseek-v4-flash-vision-exp` before this release still has that id in their stored `agent-default-model` selection, and that selection outranks this layer. On a dsh `0.1.7-rc` host the selection lives in the profile's own patch row (`$DSH_HOME/profiles/<name>/cordis.patch.yml`): the host imports an older `$DSH_HOME/settings.yaml` once, on first start, and writes its `agent-default-model:` section there. Text keeps working — DeepSeek serves those names with V4.1 Flash. Images do not: the adapter treats a model absent from the catalog as text-only (`resolveModelInfo` falls back to `inputModalities: ['text']` for an uncatalogued id, and the host refuses a prompt carrying an image on such a model with `session/attachment-invalid`, reason `MODEL_DOES_NOT_SUPPORT_IMAGES`), and the retired ids are not in this table. Picking **DeepSeek-V4.1-Flash** in the model picker rewrites the stored selection and restores image input.

## A patch-only bundle

This package has no `src/`, no `lib/`, and no entry point. That works because the harness never imports a bundle: `loadProfile` reads the bundle package's `package.json`, takes the path in `dsh.bundle.patch`, and parses that YAML file (`packages/boot/app-boot/src/profile.ts`). Resolution goes through a `package.json`-existence probe rather than `require.resolve`, so the package does not even need to export an entry. `dsh plugin add` decides a dependency is a layer by the same `dsh.bundle.patch` declaration, so a patch-only package installs and activates like any other.

The `pnpm run build` step in this workspace therefore produces nothing for this package, by design.

## Precedence

Layers, weakest first:

1. **The plugins' own schema defaults.** `agent-default-model` has none: `provider` and `model` are required, and a composition must supply them. The `llm-deepseek` factory catalog carries `deepseek-flash` and `deepseek-v4-pro`.
2. **Bundle patch layers**, in `dsh.profile.bundles` order — `@deepseek-ai/dsh-base` first, then this package. Both of the entries above are settled here.
3. **The profile's own `cordis.patch.yml`** (`$DSH_HOME/profiles/<name>/cordis.patch.yml`), applied after every bundle layer. A machine-local override belongs here, and so does every choice the user makes in the UI: picking a model makes `agent-default-model` write the selection into this file's `agent-default-model` row through `configEditor.edit`, and from that moment this package's default no longer applies to that user. That is the intended behaviour: a factory default is what you get before you have chosen, not a choice imposed over yours.

There is no settings-document layer any more. On its first start a dsh `0.1.7-rc` host renames `$DSH_HOME/settings.yaml` to `settings.yaml.imported` and imports each section into the profile row of the entry with that id; after that nothing reads the file. Its `agent-default-model:` section (`provider`, `model`, `reasoningEffort`) and its `llm-deepseek:` section (the adapter's 19 settings, `models` among them) are both importable.

**An imported `llm-deepseek` section fixes the whole adapter config in the profile.** The import writes the entry's whole merged configuration, not only the keys the section named: a section holding nothing but `apiKeyEnv` still writes the `models` table and `retryPolicy` that the bundle layers composed at that moment into the profile row. Because that row outranks every bundle layer, a later change to this catalog, or to the desktop's own `llm-deepseek` row, does not reach such a profile. A `models` table stored by an older release also lacks `systemPromptUpdate` and `toolUpdate`, so those users keep rewriting the system prompt in place and restarting the request sequence when the tool list changes, until the row is rewritten.

## An id-targeted patch replaces the whole `config`

`applyEntryPatches` (`vendor/include/src/index.ts` in the harness checkout) matches a patch to an entry by `id` and then assigns each of the patch's top-level keys onto that entry. `config` is one such key, so the patch's config object **replaces** the entry's config; there is no per-field merge, and any key the earlier layer set and this one omits falls back to the plugin's schema default.

Both blocks in `cordis.patch.yml` are complete values for that reason. It costs nothing here — `dsh-base` gives `llm-deepseek` no config at all, and gives `agent-default-model` the same two keys this package sets — but it is the rule any later layer has to follow too. A profile `cordis.patch.yml` that overrides `llm-deepseek` to set an `apiKeyEnv` and says nothing about `models` restores the factory catalog: the picker then lists `deepseek-v4-pro` again, and `deepseek-flash` under the factory name `DeepSeek-V41-Flash` without this deployment's description.

## Keeping the catalog in sync

`models` is a whole-table replacement of the adapter's factory catalog — `resolveModels` reads `config.models ?? DEFAULT_MODELS` and never merges the two. That is what lets this table hold one row where the factory catalog carries two, and it is also the cost: a model upstream adds, or a field upstream adds to the `deepseek-flash` row, does not reach the picker until it is added here. That is why the row restates the factory row instead of stating one of its own. A field it left out would be lost, not inherited: without `systemPromptUpdate: in-history` a mid-session system prompt change rewrites the first system node and invalidates the prefix cache from its first token, and without `toolUpdate: addition-only` any change to the tool list restarts the request sequence. `imagePixelBudget` and `imageMaxBytes` are absent from the factory row and from this one, so the adapter's own image defaults apply.

`tests/patch.spec.ts` holds the table to the installed packages. It reads the factory catalog of `@deepseek-ai/dsh-llm-deepseek-api-key` — the package dsh-base mounts as `llm-deepseek`, which the test also asserts — through `plainOptions(Config({}))`, and asserts that this row's keys are the factory row's keys plus `description` and that every value except `name` and `description` is equal; a field upstream adds to that row fails the test until it is restated here. It also asserts that the factory ids this table leaves out are exactly `deepseek-v4-pro`. The same file reads `@deepseek-ai/dsh-base`'s `cordis.patch.yml` and asserts both patched ids still exist in it: an id-targeted patch whose target is gone applies to nothing and warns nowhere, so a rename upstream has to fail a test to be visible at all. These checks are only as current as the `@deepseek-ai/dsh-base`, `@deepseek-ai/dsh-llm-deepseek` and `@deepseek-ai/dsh-llm-deepseek-api-key` devDependencies, which are pinned to the version the deployment ships.

On the desktop, the `llm-deepseek` row of the desktop's own bundle layer replaces this row again, so a change here is visible only where this package is the last layer that states the catalog.

The package has no scripts; run its test with `pnpm --filter @haoran/dsh-default-model exec vitest run`.

## Install

Shipped with the desktop app: the tarball is vendored into the embedded server closure and the package name is seeded into the web profile's `dsh.profile.bundles` on first launch. Installing it by hand into any other profile is the ordinary path:

```sh
cd packages/default-model && pnpm pack --pack-destination ../../dist
dsh plugin --profile <name> add ../../dist/haoran-dsh-default-model-0.3.1.tgz
```

Order matters: this layer must come after `@deepseek-ai/dsh-base` in `dsh.profile.bundles`, which is where an appended layer lands.

To confirm what a profile actually composes, without booting it:

```sh
dsh --profile <name> --dump-config
```
