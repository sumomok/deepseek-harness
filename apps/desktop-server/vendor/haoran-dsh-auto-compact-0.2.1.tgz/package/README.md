# @haoran/dsh-auto-compact

English | [中文](README.zh.md)

Compact the conversation before it runs out of room, at a point you choose. A card appears in Settings under **Plugins** with a switch and a slider: turn it on, drag it to the share of the context window you want, and whenever a reply finishes with the conversation that full, it is condensed before you send the next one.

## What you set, and what it does

| Control | Range | What it means |
| --- | --- | --- |
| The switch | on / off | Whether the conversation is condensed on its own at all |
| The slider | 20%–95%, in steps of 5 | The share of the context window that, once a turn ends above it, condenses the conversation |

The percentage is read the same way as the usage ring beside the message box. That ring is the one figure you have already watched climb, and the slider is where you say how far you are willing to let it climb.

One value, for everything. There is no per-conversation override and no per-model one: it is a preference about how you like to work, not a property of any one conversation.

**Turning the switch off does not turn off compaction.** It turns off compacting *early*. When a conversation will not fit at all, the harness still recovers on its own — that is its floor, and this plugin can neither raise nor lower it. What the switch decides is whether anything happens before that point.

## When it happens

After a reply finishes, and never inside one. *This plugin's* compaction, that is — the harness's own overflow recovery still runs mid-reply when a request will not fit at all, and nothing here can move that.

The harness's own automatic compaction runs between the steps of a turn, and this plugin switches that off. Two things are wrong with the earlier moment. A reply you are watching stops while its history is summarised. And a summarisation that fails there is simply logged, with the very next step trying again — nothing is carried between the attempts — so a summarising model that is down produces one failed attempt per step for as long as the turn runs.

The moment the driver goes idle has neither problem. Nothing is in flight, so nothing is interrupted; and there is one attempt, because the next reading is not taken until the next time it goes idle. A run that fails, or that leaves the conversation still above your share, waits rather than trying again immediately.

Strictly it is once per *driver exit*, not once per turn: several messages queued while a reply runs are drained as consecutive turns inside one running stretch, and they share one compaction at the end of it.

Three endings are deliberately skipped. **A reply you stopped**, because being answered with an unrequested full-conversation summary is not what Stop means — and while that summary runs the composer shows no Stop button, since the session reports itself as idle throughout. **A conversation being closed**, which is a stop followed by a wait for quiet, and would otherwise wait on a summary started after the stop. **A delegated sub-conversation**, whose history is usually discarded as soon as it answers.

## What it condenses

Everything it safely can. The compaction is the same operation the `/compact` command performs: everything from the start of the conversation up to the last balanced boundary becomes one summary, and only the final message survives word for word. The harness's between-steps compaction kept a longer tail, sized by the compaction backend's own `retainRatio` and `retainTokens`, because it was making room for a request that was about to go out. This one is not, so it takes the whole reduction at once and the next reply starts from the summary.

## What you give up by not compacting mid-reply

One long reply can outgrow the context window on its own — a chain of tool calls, each returning a large result. The harness's between-steps path existed for that, and this plugin closes it. What is left for that case is overflow recovery: the provider refuses the request, the harness compacts and retries, and by default it does that **once** before the failure reaches you (`maxOverflowRetries`, default 1, raised per deployment in the compaction backend's own config). A deployment that expects very long tool-heavy replies should raise it.

## What it is not

It does not measure the context window and it does not write the summary. The reading comes from the projection the usage ring reads, and the compaction is the harness's own, performed through its published seam. What this plugin owns is the switch, the percentage, and the moment.

The reading has a second source for one case the ring cannot show. A conversation no provider has billed yet — image-heavy history above all — publishes no usage figure, so the ring reads nothing and, on that alone, nothing would ever be compacted. Where the token meter is reachable, that state falls back to the meter's own total, which is the number the harness's own trigger used there and the only one that prices a routed model's images.

It does not report a compaction that went wrong, either: a failed compaction is shown by the failure card in the chat (host builds from rc.33 on), because the harness records the failure itself and the conversation view already renders it.

## Where it works, and where it does nothing

The card takes the keyed seat the Settings **Plugins** page dispatches once per settings namespace it serves — the same seat the harness's own configurable-plugin cards take. A build whose settings page has no such seat never declares the key, and then this plugin registers no interface at all. Nothing is version-checked: the declaration is the detection.

The host half registers its namespace wherever it is composed; without a settings provider it simply answers the profile's own values and nothing can change them.

**The engine is found per conversation, not once at load.** A preset publishes `compaction` behind an `isolate` realm, which is invisible to the host plane this plugin is mounted on — the shipped desktop profile disables the compaction backend on the host and mounts it inside every preset. So the engine is resolved through `agentPresets.serviceFor(agent, 'compaction')` when a conversation opens, falling back to a plain host-plane read for a composition that mounts it there. Where neither answers, this plugin says so in the host log once per conversation and changes nothing: the policy keeps reporting the harness's own behaviour, so the harness goes on compacting between steps rather than nothing compacting at all.

## The service it publishes

Under the Cordis service key `compactionPolicy`:

| Method | Answer |
| --- | --- |
| `isEnabled()` | `false` once this plugin has found an engine of its own to compact with; `true` — the harness's own behaviour — while it has not |
| `thresholdRatio()` | The share of the context window, 0–1, this plugin triggers at, read live from the settings document |

The switch in Settings is *not* what `isEnabled()` returns. It decides whether this plugin's compaction runs, and it is read there. `isEnabled()` answers one question only: whether the harness should stop compacting between steps because something else now will. The two are coupled on purpose — a `false` with nothing behind it would be a conversation that never compacts at all.

No shipped backend reads `thresholdRatio()` while `isEnabled()` answers false — the one path that consulted it is the one being switched off — and it stays because it is half of a published key another backend may read.

## Settings namespace

`auto-compact`, with two fields:

| Field | Type | Default |
| --- | --- | --- |
| `enabled` | boolean | `true` |
| `thresholdPercent` | whole number, 20–95 | `60` |

A section outside those bounds is refused, at the write that produced it.

## Configuration

Both fields of `cordis.patch.yml` are the composition layer — what someone who has never opened Settings gets. Moving the switch or the slider writes a user layer over them.

```yaml
- insert:
    - id: auto-compact
      name: '@haoran/dsh-auto-compact'
      config:
        enabled: true
        thresholdPercent: 60
```

## Install

```sh
dsh plugin --profile <name> add <path-or-tarball>
```
