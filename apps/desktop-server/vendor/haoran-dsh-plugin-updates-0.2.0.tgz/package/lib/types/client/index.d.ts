/**
 * Browser half: the Updates tab inside plugin settings.
 *
 * The only host path is the Typert Remote this package's host half exports,
 * mounted here through `ctx.remote.$mount()`. This plugin fetches nothing
 * itself and knows no token, no endpoint, and no path.
 *
 * **The tab is not registered at all where updating is impossible.** A `dsh web`
 * on a server lends no package manager, and a tab that opens onto an
 * explanation of why a feature does not work is worse than no tab: the person
 * did not ask for it, cannot act on it, and now has one more thing in Settings.
 * So the first thing this does is read the host once, and a `available: false`
 * answer ends the registration before it starts.
 *
 * **The count rides in the tab's own label.** `settings.plugins.tab` projects a
 * registrant's label as plain text — the section renders `{row.label}` into a
 * button and nothing else — so there is no badge seat to contribute to. The
 * label therefore becomes `更新 (2)`, and because a label is fixed at
 * registration time, a change to that count re-registers the entry. That is
 * also the ledger bump the section re-renders on, so one mechanism does both.
 *
 * @module @haoran/dsh-plugin-updates/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type UpdatesKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-plugin-updates` copy. */
        pluginUpdates: UpdatesKey;
    }
}
export type { UpdatesSettingsTabInjected, UpdatesSettingsTabProps } from './UpdatesSettingsTab.tsx';
export { createUpdatesStore, outdatedCount } from './store.ts';
export type { Busy, Notice, RepairAction, RepairBusy, RepairNotice, UpdatesApi, UpdatesState, UpdatesStore } from './store.ts';
export { en, fill, NS, zh } from './locales.ts';
export type { UpdatesKey } from './locales.ts';
export { CONTRIBUTION, parseRelaunchOutcome, parseRepairOutcome, parseRepairsView, parseUpdateOutcome, parseUpdatesView, } from './contribution.ts';
/** Required browser services. */
export declare const inject: string[];
/**
 * The label the tab carries, with the count when there is one.
 * @param t - the bound translate seat.
 * @param count - how many rows have a newer version.
 * @returns the label text.
 */
export declare function tabLabel(t: (key: UpdatesKey) => string, count: number): string;
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 */
export declare function apply(ctx: Context): Promise<void>;
//# sourceMappingURL=index.d.ts.map