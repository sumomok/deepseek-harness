# @haoran/dsh-btw

English | [中文](README.zh.md)

Ask a question about what you are working on without spending the rest of the conversation on it. `/btw why is this slow?` sends the conversation so far plus your question, shows the answer in a row of its own, and leaves the conversation exactly as it was: the next thing the assistant does cannot see the question or the answer.

That is the whole feature. It is worth having because the ordinary way to ask — typing the question into the conversation — costs you twice: the assistant answers instead of continuing, and the question and its answer sit in the context of every request after it.

## What it costs

**One full request, priced like an ordinary turn.** The input is the whole conversation plus your question; the output is the answer. A side question in a long conversation costs what a turn in that conversation costs.

Each one is billed at the conversation's full length on its own. Asking a side question does not make the next one cheaper, and it does not ride on anything the ongoing conversation has already saved.

It is one request, not two: there is no summarizing pass and no second model. The route is the conversation's own, so the answer comes from the model you are already talking to; a side question asked before the conversation has a route of its own — `/btw` as the very first thing you type — follows the deployment's default model.

## Where the question and the answer live

In the session log, as the command's own two events:

| Event | Carries |
| --- | --- |
| `command/run` | `name: 'btw'` and the question verbatim in `args` |
| `command/done` | `kind` and the answer, or the reason there is none, in `text` |

Both are log-only event types the harness already ships, and neither is a *surface* event. `Session.deriveMessages()` — the one function that builds the message list of a model request — walks only surface events, so nothing this plugin writes can reach a later request. That is a structural guarantee, not a convention: `Session.append` accepts a surface marker only on the three surface event types, and the projection returns nothing for every other type.

Recording them is not optional. The question goes into a model request, and the harness's rule is that anything a model request sees must be reconstructable from the session log.

### Why no event of its own

A richer record — the question, the answer, the model, the token usage, in one structured payload — would need an event type this plugin declares. It cannot have one. A session log is refused on reload when it carries an event type outside the harness's own generated vocabulary, unless the event's envelope is marked `ignorable: true`, and `Session.append` has no parameter that writes that field. An out-of-repo plugin therefore has no way to add an event type without making every session that used it unreadable after a restart. The Agent Note in `.agents/notes/2026-09-06-btw-side-question.md` records the probe.

So the model id rides at the end of the answer instead, on an attribution line — `— deepseek-v4-flash` — which the row turns into a subtitle. Token usage is not recorded.

## The row

The chat dispatches its command row by command name, so `/btw` gets its own renderer and every other command keeps the generic card. The row shows the question, the answer, and who answered; while the answer is still coming it says so.

It is rebuilt from those two events every time the session is opened, so it is there after a reload and after a restart. Closing it keeps one line carrying the question, and clicking that line brings the card back. The closed state is remembered in the browser's own storage, keyed by the command, so a row you put away is still away the next time you open the session — on that browser only, with nothing about it in the session log. A browser that refuses site data shows the row open.

**Not streamed yet.** The answer appears complete rather than word by word, because the only channel that could carry the increments to the browser is a session event, and this plugin writes none. A later version can stream over a Typert stream remote instead; that is a second seam, and it is not built.

## Stopping

**A running side question cannot be stopped from the interface yet.** The stop control the interface shows for a running agent turn does not reach a command: the client passes no cancellation to the command it started, so an answer that has been asked for runs to its end. Closing the card with × only collapses the row: the answer still arrives and is still recorded. A stop belongs to a later release.

A request still running at `timeoutMs` is abandoned, and the row shows this plugin's own wording for it.

The host half handles a cancellation anyway, because a caller that does pass a signal — anything but the shipping client — gets the same treatment: the command registry aborts a running handler itself and writes `signal.reason` as a message, which supersedes this plugin's own "Cancelled" line. That stored text is English and technical — `This operation was aborted`, or the registry's `command aborted` fallback — so a failed `/btw` whose text carries the word "abort" is shown as **Cancelled** in the interface language, with the stored text on hover. The recognition lives in the row rather than in what gets written because the stored text is not this plugin's to write: a deployment without this plugin's browser half falls back to the generic command card, which shows the original.

## Configuration

Every field below is this plugin's own default, restated in `cordis.patch.yml` so a profile can see what it is changing. An id-targeted patch replaces the whole `config` block, so restate every key you want to keep.

| Key | Default | What it does |
| --- | --- | --- |
| `system` | see below | The instruction ahead of the conversation. A side question arrives with the conversation as context but **without** the agent's own system prompt and without tools, so this is the only thing telling the model what kind of answer is wanted. |
| `maxOutputTokens` | `2000` | Output cap for one answer. An answer that hits it is shown with a note saying so. |
| `timeoutMs` | `120000` | End-to-end deadline. Partial output is discarded, because half a sentence is not an answer. |
| `provider`, `model` | absent | Pin the side question to one route. Absent — the shipped state — means it follows the conversation's own route, and the deployment's default model while the conversation has none, so a model switch carries over with no configuration. Set both or neither; setting one alone fails at load. |

```
You are answering a side question about the conversation above.
No tools are available for this answer: answer from what you already know, or say plainly that answering would need a tool. Never write a tool call.
Answer the question directly and briefly. Do not continue the task, propose next steps, or write code unless the question asks for code.
Reply in the language the question is written in.
```

The line about tools is load-bearing. The conversation reaches the model with every tool call it already contains, and the request itself carries no tool schema, so a model left to infer the situation can answer by writing a tool call as text — markup the provider passes straight through, since it has nothing to parse a call against. Replace `system` without that line and the failure comes back: an answer carrying tool-call markup is refused with the same "the model asked to run a tool" line as a real one, rather than shown as the answer.

## Wording

The row's own chrome — the title, the close button, "Answering…", "Answered by …", "Cancelled" — follows the interface language.

The host half's own lines do not, because it runs with no locale service and what it writes is durable: the session log keeps it, and the generic command card shows it verbatim when this plugin's browser half is not installed. Those lines therefore carry both languages, Chinese first: `等太久，没有答完。 / Took too long, so there is no answer.`

Eight of them can reach the log: the usage line; three failures — no model, the deadline, an empty answer; the `没能问成 / Could not ask:` prefix and the two reasons that fold into it — the model asked to run a tool, whether by finish reason or by writing the markup into its answer, and a finish reason this build does not know; and the truncation note, which rides on an answer that hit its length limit. The truncation note and the tool-call refusal are the two the ordinary path can reach. A ninth, `已取消。 / Cancelled.`, never reaches the log: the registry settles a stopped command with its own text first. It is kept because it is what the host half returns to any other caller.

## Install

```sh
dsh plugin --profile <name> add @haoran/dsh-btw
```
