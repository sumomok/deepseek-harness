/**
 * Host half of @haoran/dsh-btw: the `/btw` side-question command.
 *
 * A slash command runs against the receiving agent without being sent to the
 * model, which is what makes a side question possible at all: the question and
 * its answer reach the person through the command's own lifecycle events, and
 * neither is a surface event, so neither can enter the context of any later
 * request. See `./ask.ts` for the three ways that guarantee could be lost and
 * how this plugin avoids each.
 *
 * @module @haoran/dsh-btw
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.ts';
export { askSideQuestion, linkedDeadline, resolveRoute } from './ask.ts';
export type { SideQuestionRoute } from './ask.ts';
export { Config, DEFAULT_SYSTEM, resolveConfig } from './config.ts';
export type { ResolvedConfig } from './config.ts';
export { ATTRIBUTION_PREFIX, attribution, CANCELLED, failed, NO_ANSWER, NO_ROUTE, splitAttribution, TIMED_OUT, TOOL_CALL_ASKED, TRUNCATED, USAGE, } from './copy.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "btw";
/** Required host services. */
export declare const inject: string[];
/**
 * Register the `/btw` command.
 *
 * `recordInput` is left at its default, so `command/run` keeps the question
 * verbatim in `args`. The question goes into a model request, and anything a
 * model request sees has to be reconstructable from the session log.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map