import type { CommandRowOwnerProps } from '@deepseek-ai/dsh-client-ui-chat/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/**
 * The `/btw` row: the question, the answer, and who answered.
 *
 * Everything shown here is rebuilt from the command's own two log events, so
 * the card is identical on the run that produced it and on every later reload
 * of that session. Closing is remembered per browser: the state is keyed by
 * `commandId` in `localStorage`, so a row put away is still away when the
 * session is opened again on that browser and open everywhere else. Nothing
 * about it reaches the session log.
 */
export type BtwCardProps = CommandRowOwnerProps & PropsLocale<'btw'>;
export declare function BtwCard({ node, t }: BtwCardProps): import("react").JSX.Element;
//# sourceMappingURL=BtwCard.d.ts.map