# @haoran/dsh-clickable-refs

[English](README.md) | 中文

让 DSH 聊天界面里终端（`bash` 工具）输出、网页抓取卡片的 URL、以及 Assistant 正文（纯文本、行内代码、Markdown 链接）都变得可点。桌面内部插件（`@haoran` 私域）——不发版、不进社区注册表：它依赖若干 fork 专有缝，都不是公开契约的一部分——`@deepseek-ai/dsh-client-ui-primitives` 导出的 `parseAnsiLines`；`@deepseek-ai/dsh-client-runtime`/`@deepseek-ai/dsh-client-ui-conversation` 的 `referent/open` 瀑布缝、其 `openPath` 的 `not-found` 错误码、`host.probeTargets` 批量 stat 探针，以及 `proseReferents` 可选服务的 Context 合并（含其 `resolveLink`/`subscribe` 成员）。

## 做什么

聊天界面里三块最大的死字区变活，统一走「提名→验证→打开」三层管线（`docs/referents-three-layer-spec.md`）：提名层（语法检测，或 Markdown 链接自身的目的地）找出的候选，只有经 `VerificationStore` 验证通过才渲染可点——批量 host `stat`（`host.probeTargets`）是 `file`/`dir` 候选唯一的存在性验证。会话真值索引（从工具调用参数、产出文件位置、抓取过的 URL 等结构化字段建账）从不单独判定验证通过——本次会话某工具接触过这条路径，对它现在是否仍在磁盘上零证明力——索引唯一剩下的作用是把 basename/相对别名解析成其唯一无歧义的绝对项，解析结果照样要和任何其他候选一样排队等同一批 `stat`（索引命中不免检、也不插队）。`url` 候选免 stat（B5）：点击承诺是"打开浏览器标签"，不是"这台主机能应答"。UNC 候选（`\\server\share\…`）同样从不交给 store——无论终端还是正文两个界面——因为对 UNC 路径 `stat` 本身就是一次 SMB 连接，可能把当前用户的 NTLM 凭据泄露给模型/工具文本指定的任意主机，且全程零用户手势，本插件干脆不发起这次 `stat`（宿主侧 `host.probeTargets` 这条 wire 边界也独立拒绝同一调用，但本插件不单靠那一层）。它的点击承诺是"拒绝并复制路径"，从不触碰文件系统，因此和 `url` 一样无条件可点。

- **终端输出**（`bash` 键控工具视图）：命令输出里检测到的每个 POSIX 路径、Windows 盘符/UNC/反斜杠相对路径（`src\foo.ts`，按调用自身的 cwd 解析，与运行本代码的宿主 OS 无关）、`localhost`/回环地址 URL、常见 TLD 裸域名，验证通过后变成可点的行内元素——悬停下划线、键盘可达，且不影响周围的 ANSI 着色。检测按时间片分块推进——首个可见分块同步扫描，其余在空闲时间片里继续，直到整段输出都有结果，大段输出不会留下扫不到的尾巴（`src/client/bash/progressive-scan.ts`）；每一分块检出的候选随即经共享的 `VerificationStore`（`src/client/verification-store.ts`）过滤，验证 tick 能让已经画出的卡片原地显形，无需重新扫描。
- **网页抓取卡**（`web_fetch` 键控工具视图）：卡片的 URL 走同一条缝，而不是由浏览器直接跳转。
- **Assistant 正文**（模型回复已收尾后的纯文本、行内代码、Markdown 链接）：本插件向 `dsh-render` 提供通用的 `proseReferents` 可选服务（`src/client/prose-referents.ts`），现绑定同一个 `VerificationStore`。宿主侧一段系统提示词（`src/index.ts`）让模型把本轮真正产出或触及的文件/目录写成绝对路径 Markdown 链接，路径带空格时要求百分号编码（或整段用尖括号包住）——不转义的空格会直接破坏一个无尖括号包裹的 CommonMark 链接目的地；`dsh-render` 的 `render.tsx` 把这类链接的目的地经 `resolveLink` 路由，而非走协议白名单——两种转义写法真实解析后都能原样存活到 `resolveLink`（已在 `dsh-render` 自己的测试套件里实测确认）。「扫描→点击」的接线仍由宿主自己的聊天视图完成——按设计核心保持零检测。行内代码走放宽规则（无扩展名的裸词也算数，因为把它写进代码片段本身就是刻意引用的信号）；纯文本则和终端检测一样保守，现在还额外要求索引/stat 验证通过才会真正回传 span。

每次点击都构造一个 `ReferentRef`，通过 `referent/open` 瀑布分发（`@deepseek-ai/dsh-client-runtime`），树上任何位置的监听者都能在本插件自己的默认打开动作跑之前先认领它。默认动作：

- `url` → `window.open(target, '_blank', 'noopener,noreferrer')`。
- UNC 网络共享路径（`\\server\share\…`）→ 永不直接打开（在 Windows 上访问会触发 SMB 身份验证，可能把当前用户的 NTLM 凭据泄露给 target 指向的任意主机，而 target 是不可信的模型/工具文本）——改为提供复制：终端卡片内联一个「复制」按钮，正文侧因为没有逐 span 的提示位，改用画面级的 toast。
- `file`/`dir` → 先过一份固定、不可配置的拒开名单（可执行/脚本/快捷方式类扩展名，`exe msi bat cmd com scr ps1 vbs jar app command sh bash zsh fish desktop dmg pkg appimage lnk reg url webloc terminal workflow`，大小写不敏感，跨所有操作系统的并集）——命中则提供「打开所在文件夹」而非直接打开；否则调用 `workspaces.openPath(target)`，把 `not-found` 结果降级为本次渲染内的瞬时提示 + 死字。这份名单只防一类窄问题——误点后无二次确认就立即执行或跳转——不承诺拦住宿主自身应用能做的每一种危险打开；真正的安全底线是 `referent/open` 缝本身的用户手势不变量，加上宿主操作系统自己的隔离层（`src/core/refusal-list.ts`）。

检测原则保守：相对引用缺 `cwd`/`home` 可解析时宁可不产生可点 span，也不产生错误的一个；在此之上，提名出的候选未经验证一律不可点。本仓库的 `docs/clickable-refs-spec.md`、`docs/prose-referents-spec.md` 与 `docs/referents-three-layer-spec.md` 是权威设计文档——第三份取代前两份的正文标记行为，复用其终端/拒开/UNC/分块部分。

## 外观一致性

两个视图都与其内置版本的 chrome 保持 1:1——同样的折叠行为、同样的终端卡几何尺寸、同样的抓取卡标记（URL 部分用的是内置视图同一套公开的 `WebBlock`/`DisclosureRow` 原语）——直接从 `dsh-render` 源码读出，因为内置的 `BashRow` 及其终端卡/行模型推导逻辑都不在任何已发布 npm 包的导出面上。

## 安装

```sh
pnpm run build
cd packages/clickable-refs && pnpm pack --pack-destination ../../dist
dsh plugin --profile <name> add ../../dist/haoran-dsh-clickable-refs-0.3.2.tgz
```

## 开发

```sh
pnpm vitest run --dir packages/clickable-refs
```

`src/client/dsh-render-unpublished-shims.d.ts` 记录了本插件依赖的 `dsh-render` 特性：它们存在于该仓库 `develop` 分支源码中，但尚未进入其最新的 npm 发版——`referent/open` 瀑布及其 `Events` 类型、`ReferentRef`、`parseAnsiLines`/`AnsiLine`、`proseReferents` 可选服务（`ProseReferents`/`ProseReferentSpan`，其 `resolveLink`/`subscribe` 成员，加上 `ctx.proseReferents` 的 Context 合并），以及 `IWorkspaces.probeTargets`/`ProbeResult`。待发版跟上后删除该文件即可。
