# @haoran/dsh-clickable-refs

English | [中文](README.zh.md)

Makes terminal (`bash` tool) output, the web-fetch card's URL, and Assistant prose (plain text, inline code, and Markdown links) clickable in the DSH chat UI. Desktop-internal plugin (`@haoran` private scope) — not published, not part of the community registry: it depends on fork-specific seams not yet a public contract — `parseAnsiLines`'s export from `@deepseek-ai/dsh-client-ui-primitives`; the `referent/open` waterfall, its `openPath` `not-found` error code, the `host.probeTargets` batch stat RPC, and the `proseReferents` optional-service Context merge (including its `resolveLink`/`subscribe` members) from `@deepseek-ai/dsh-client-runtime`/`@deepseek-ai/dsh-client-ui-conversation`.

## What it does

Three of the chat UI's largest dead-text areas become clickable, gated by a nominate → verify → open pipeline (`docs/referents-three-layer-spec.md`): a candidate a nomination pass (syntax detection, or a Markdown link's own destination) finds renders clickable only once a `VerificationStore` confirms it — and a batched host `stat` (`host.probeTargets`) is the SOLE existence verifier for a `file`/`dir` candidate. The session truth index (built from structured session fields: tool-call arguments, produced-file locations, fetched URLs) never verifies by itself — a tool touching a path earlier this session proves nothing about whether it still exists now — its only remaining role is resolving a basename/relative alias to its one unambiguous absolute owner before that target queues for the same `stat` batch as any other candidate (an index hit earns no shortcut and no priority). A `url` candidate is exempt from `stat` (B5): the click promise is "open a browser tab," not "this host answers." A UNC candidate (`\\server\share\…`) is likewise never handed to the store at all, on either surface (terminal or prose) — `stat`-ing a UNC path is itself an SMB connection that can leak the current user's NTLM credentials to whatever host model/tool text named, with no user gesture, so this plugin never issues that `stat` in the first place (the host-side `host.probeTargets` wire boundary independently refuses the same call, but this plugin does not rely on that alone). Its click promise is "refuse and copy the path," which never touches the filesystem, so it renders clickable unconditionally, same as `url`.

- **Terminal output** (the `bash` keyed toolview): every POSIX path, Windows drive/UNC/backslash-relative path (`src\foo.ts`, resolved against the call's own cwd regardless of the host OS running this code), `localhost`/loopback URL, and common-TLD bare domain detected in a command's output becomes a clickable span once verified — hover-underlined and keyboard-reachable, without touching the ANSI coloring around it. Detection runs progressively — the first visible chunk scans synchronously, the rest continues across idle-time slices until the full output has a result, so a large command never leaves an unscanned tail (`src/client/bash/progressive-scan.ts`); each chunk's candidates are then filtered through the shared `VerificationStore` (`src/client/verification-store.ts`), and a verification tick lights up an already-painted card in place with no rescan.
- **The web-fetch card** (the `web_fetch` keyed toolview): its URL routes through the same seam instead of the browser navigating it directly.
- **Assistant prose** (plain text, inline code, and Markdown links in a settled model reply): this plugin provides `dsh-render`'s generic `proseReferents` optional service (`src/client/prose-referents.ts`), now bound to the same `VerificationStore`. A host-side system-prompt section (`src/index.ts`) tells the model to write a file/directory it actually produced or touched as an absolute-path Markdown link, percent-encoding a space (or wrapping the path in angle brackets) since an unescaped space breaks an unbracketed CommonMark link destination outright; `render.tsx` in `dsh-render` routes such a link's destination through `resolveLink` instead of the protocol allowlist — both escapes already survive real CommonMark parsing unmodified by the time they reach `resolveLink` (confirmed in `dsh-render`'s own test suite). The host's own chat view still does the scanning-to-click wiring — core stays detection-free by design. Inline code classifies relaxed (a bare word with no extension counts, since writing it in a code span is itself the deliberate-reference signal); plain text stays exactly as conservative as terminal detection, and now additionally requires index/stat verification before a span is ever handed back.

Every click constructs a `ReferentRef` and dispatches it through the `referent/open` waterfall (`@deepseek-ai/dsh-client-runtime`), so a listener anywhere in the tree can claim it before this plugin's own default open action runs. The default action:

- `url` → `window.open(target, '_blank', 'noopener,noreferrer')`.
- a UNC network-share path (`\\server\share\…`) → never opened (accessing one on Windows triggers SMB authentication, which can leak the current user's NTLM credentials to whatever host the target names, and the target is untrusted model/tool text) — offered for copy instead, both on the terminal card (an inline "Copy" button) and in prose (a frame-wide toast, since prose has no per-span notice slot).
- `file`/`dir` → checked against a fixed, non-configurable refusal list of executable/script/shortcut extensions (`exe msi bat cmd com scr ps1 vbs jar app command sh bash zsh fish desktop dmg pkg appimage lnk reg url webloc terminal workflow`, case-insensitive, union of every OS's) — a hit offers "open containing folder" instead of opening the file; otherwise `workspaces.openPath(target)`, downgrading a `not-found` result to a transient inline notice and dead text for that render. The list defends against one narrow class — a misclick immediately executing or redirecting with no further confirmation — not every dangerous open the host's own application could perform; the real safety floor is the `referent/open` seam's user-gesture invariant plus the host OS's own quarantine layer (`src/core/refusal-list.ts`).

Detection is conservative by design: a relative reference with no `cwd`/`home` to resolve against produces no span at all, rather than a wrong one; on top of that, a nominated candidate never renders clickable until verified. `docs/clickable-refs-spec.md`, `docs/prose-referents-spec.md`, and `docs/referents-three-layer-spec.md` (this workspace) are the authoritative design — the third supersedes the first two's prose-marking behavior while reusing their terminal/refusal/UNC/chunking parts.

## Chrome parity

Both views mirror their built-in counterpart's chrome 1:1 — same collapse behavior, same terminal-card geometry, same fetch-card markup (the URL is the SAME `WebBlock`/`DisclosureRow` public primitives the built-in view uses) — read directly from `dsh-render`'s source, since neither the built-in `BashRow` nor its terminal-card/row-model derivation is part of any published npm package's export surface.

## Install

```sh
pnpm run build
cd packages/clickable-refs && pnpm pack --pack-destination ../../dist
dsh plugin --profile <name> add ../../dist/haoran-dsh-clickable-refs-0.3.2.tgz
```

## Development

```sh
pnpm vitest run --dir packages/clickable-refs
```

`src/client/dsh-render-unpublished-shims.d.ts` documents the `dsh-render` features this plugin depends on that exist in that repository's `develop` branch source but are not yet in its latest npm publish — the `referent/open` waterfall and its `Events` type, `ReferentRef`, `parseAnsiLines`/`AnsiLine`, the `proseReferents` optional service (`ProseReferents`/`ProseReferentSpan`, its `resolveLink`/`subscribe` members, plus the `ctx.proseReferents` Context merge), and `IWorkspaces.probeTargets`/`ProbeResult`; delete that file once a publish catches up.
