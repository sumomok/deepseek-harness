/**
 * The lowercased extension (without its dot) of a path's final segment, or
 * null when it has none — including a dotfile whose name starts with the
 * only dot it carries (`.bashrc`), which has no extension to check.
 * @param path - a resolved path, in either path syntax.
 * @returns the lowercased extension, or null.
 */
export declare function extensionOf(path: string): string | null;
/**
 * Whether a path's extension is on the refusal list.
 * @param path - a resolved path, in either path syntax.
 * @returns true when the path must not be opened directly.
 */
export declare function isRefusedPath(path: string): boolean;
/**
 * The directory to offer instead of opening a refused path directly.
 * @param path - the refused path.
 * @returns its parent directory, under the path's own syntax.
 */
export declare function refusedPathFolder(path: string): string;
//# sourceMappingURL=refusal-list.d.ts.map