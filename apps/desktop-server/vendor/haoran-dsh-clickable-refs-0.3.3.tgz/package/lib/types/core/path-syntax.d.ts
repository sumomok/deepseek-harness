/**
 * Path-syntax classification and pure path arithmetic shared by detection,
 * the refusal list's "open containing folder", and relative-path resolution.
 * A path's own spelling decides whether it parses under Windows syntax
 * (drive letter or UNC share) or POSIX syntax — never the host OS running
 * this code, since a terminal can echo either syntax (an SSH session onto
 * another OS, a WSL path inside a Windows shell, and so on).
 *
 * @module @haoran/dsh-clickable-refs/core/path-syntax
 */
/**
 * Whether a path string parses under Windows syntax: a drive letter or a UNC
 * share root. Anything else — including a path using backslashes with
 * neither of those roots — parses as POSIX.
 * @param path - the path text (quotes and any line-number suffix already stripped).
 * @returns true for a drive-letter or UNC path.
 */
export declare function isWin32Path(path: string): boolean;
/**
 * Whether a path string is a UNC network-share root or a path under one
 * (`\\server\share`, `\\server\share\sub\file`) — narrower than
 * {@link isWin32Path}, which also accepts a plain drive letter.
 * @param path - the path text (quotes and any line-number suffix already stripped).
 * @returns true for a UNC path.
 */
export declare function isUncPath(path: string): boolean;
/** A path split into its root (drive/UNC/`/`/none) and its segments, in root-to-leaf order. */
export interface SplitPath {
    readonly root: string;
    readonly segments: readonly string[];
}
/**
 * Split a path into its root and segments under the given syntax.
 * @param path - the path to split.
 * @param win32 - true to parse as Windows syntax (see {@link isWin32Path}).
 * @returns the root (empty string when the path carries none) and its segments.
 */
export declare function splitPath(path: string, win32: boolean): SplitPath;
/**
 * Rejoin a root and its segments into a path string.
 * @param root - a root from {@link splitPath} (possibly empty).
 * @param segments - path segments, root-to-leaf.
 * @param win32 - true to join with backslashes.
 * @returns the joined path.
 */
export declare function joinPath(root: string, segments: readonly string[], win32: boolean): string;
/**
 * Resolve a relative path (`.`/`..` segments included) against a base
 * directory, under the base's own syntax (see {@link isWin32Path}). Used both
 * for a `./`/`../`/bare-relative detection target and for `~/…` expansion
 * (base = home, rel = the text after `~/`).
 * @param base - the absolute directory the relative text resolves against.
 * @param rel - the relative text, possibly carrying `.`/`..` segments.
 * @returns the resolved absolute path.
 */
export declare function resolveRelative(base: string, rel: string): string;
/**
 * Resolve a BACKSLASH-relative path (`src\foo.ts`, B4) against a base
 * directory, joined using the base's own separator — but `rel`'s own
 * backslashes are always the split points, regardless of whether `base`
 * itself parses as Windows or POSIX syntax. `resolveRelative` cannot be
 * reused here: it infers which separator to split `rel` on from `base`'s
 * own syntax (correct for `~/…` expansion and a POSIX-slash relative
 * target, both of which always share `base`'s separator), but a
 * backslash-relative candidate's separator is baked into its OWN spelling
 * independently of `base` — a terminal can echo a Windows-style relative
 * reference against a POSIX session `cwd`, and the reverse.
 * @param base - the absolute directory the relative text resolves against.
 * @param rel - the relative text, backslash-separated, `.`/`..` segments included.
 * @returns the resolved absolute path, joined using `base`'s own separator.
 */
export declare function resolveBackslashRelative(base: string, rel: string): string;
/**
 * Collapse `.`/`..` segments within an already-absolute path — a joined path
 * that carries them (`/w/app/..`) displays as the directory it names (`/w`),
 * not as the literal segments. Symmetric with {@link resolveRelative}: that
 * function folds a relative text onto a base's segments, this one folds a
 * path's own segments onto themselves.
 * @param path - an absolute path, possibly carrying `.`/`..` segments.
 * @returns the same path with those segments resolved.
 */
export declare function normalizePath(path: string): string;
/**
 * The parent directory of an absolute path, under the path's own syntax.
 * Used by the refusal list's "open containing folder" recovery: the folder
 * must open under the SAME syntax the refused path was spelled in, not the
 * syntax of the machine running this code.
 * @param path - an absolute or already-resolved path.
 * @returns the parent directory, or the path's own root when it already
 * names one (a drive root, a UNC share root, or POSIX `/`) with no parent to climb to.
 */
export declare function parentDirectory(path: string): string;
//# sourceMappingURL=path-syntax.d.ts.map