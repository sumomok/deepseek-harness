/**
 * Bare-domain URL nomination for B5 of the three-layer spec
 * (`docs/referents-three-layer-spec.md`): a schemeless token shaped like
 * `word.tld` (optionally `www.`-prefixed, ported, or path-bearing) counts as
 * a URL when its trailing label is on a curated common-TLD allowlist. A
 * handful of those TLDs also spell common file extensions (`sh`, `md`,
 * `rs`, `app`, `zip`, `mov`) — for those, a file reading wins unless the
 * token carries a `www.` prefix, a port, or a path, any of which a real
 * filename never does.
 *
 * URL spans never `stat`: the click promise is "open a browser tab", which
 * is self-consistent regardless of whether the host actually answers.
 *
 * @module @haoran/dsh-clickable-refs/core/tld-domains
 */
/**
 * Curated common top-level domains (gTLDs plus a handful of high-traffic
 * ccTLDs) — not an exhaustive IANA mirror, a practical set for real-world
 * chat/terminal mentions.
 */
export declare const COMMON_TLDS: ReadonlySet<string>;
/**
 * TLDs that double as common file extensions: a bare `name.tld` token with
 * none of `www.`/port/path reads as a file, not a URL.
 */
export declare const FILE_COLLIDING_TLDS: ReadonlySet<string>;
/**
 * Classify a schemeless token as a bare-domain URL.
 * @param text - a single whitespace-delimited token (or quoted-span inner
 * text), already ruled out as a full-scheme or loopback URL by the caller.
 * @returns the URL target (defaulted to `https://`), or `null` when the
 * token is not domain-shaped, its TLD is unrecognized, or it collides with
 * a file extension with no `www.`/port/path to disambiguate it as a URL.
 */
export declare function classifyBareDomain(text: string): {
    kind: 'url';
    target: string;
} | null;
//# sourceMappingURL=tld-domains.d.ts.map