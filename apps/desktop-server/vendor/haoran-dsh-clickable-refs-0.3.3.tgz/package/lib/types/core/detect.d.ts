/** What a detected span resolves to. */
export type RefKind = 'file' | 'dir' | 'url';
/** One clickable hit within a line. */
export interface DetectedRef {
    /** Start offset within the line (inclusive), UTF-16 code units. */
    readonly start: number;
    /** End offset within the line (exclusive). */
    readonly end: number;
    /** The line's own text for `[start, end)` — keeps a line-number suffix, drops trailing punctuation. */
    readonly raw: string;
    readonly kind: RefKind;
    /** The resolved target `referent/open` acts on: an absolute path, or a full `http(s)://` URL. */
    readonly target: string;
}
/** Resolution bases for a relative reference. */
export interface DetectOptions {
    /** Session workspace root; resolves `./…`, `../…`, and a bare relative with a separator. Absent: those produce no span. */
    readonly cwd?: string | undefined;
    /** Host account home; resolves `~`/`~/…`. Absent: those produce no span. */
    readonly home?: string | undefined;
}
/**
 * Detect every clickable reference in one line of plain text.
 * @param line - ANSI-stripped line text.
 * @param opts - resolution bases for a relative reference.
 * @returns detected spans in left-to-right order, never overlapping.
 */
export declare function detectRefs(line: string, opts?: DetectOptions): DetectedRef[];
/**
 * Classify one inline-code token as a single whole candidate — relaxed
 * relative to {@link detectRefs}' bareword-needs-extension rule (a bare
 * `myfile`, with no extension and no separator, counts here: writing it
 * inside a code span is itself the deliberate-reference signal prose
 * scanning otherwise approximates with a real-looking extension). A
 * surrounding matched quote pair (`'…'`/`"…"`) is unwrapped first, exactly
 * as {@link detectRefs}' quoted-span pass does; no trailing-punctuation
 * stripping runs, since a code span's boundaries are already exact, unlike
 * free running text. Multi-token content (`cd /tmp && ls`) still classifies
 * as nothing: only a token that is, as a WHOLE, one recognized shape lights
 * up — unquoted internal whitespace disqualifies it outright, before
 * classification runs. The one exception is a quote-unwrapped span itself:
 * a quote pair is the deliberate-single-reference signal, so a quoted path
 * that legitimately contains a space (`'My Documents/report.txt'`) still lights up.
 * @param text - the exact inline-code content (already line-ending-normalized to spaces by the renderer).
 * @param opts - resolution bases for a relative reference.
 * @returns one candidate spanning the classified text within `text`, or null when nothing classifies.
 */
export declare function detectInlineCodeCandidate(text: string, opts?: DetectOptions): DetectedRef | null;
//# sourceMappingURL=detect.d.ts.map