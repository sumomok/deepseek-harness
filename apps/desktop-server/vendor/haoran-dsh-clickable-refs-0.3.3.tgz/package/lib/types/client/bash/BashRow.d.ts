/**
 * This plugin's `bash` keyed toolview: a close port of the built-in
 * `BashRow` (`bash-sample.tsx` in `dsh-render`, referenced per
 * docs/clickable-refs-spec.md §2) whose terminal output carries clickable
 * spans instead of dead text. Chrome, collapse behavior, and the line-count
 * badge mirror the source; the only change is `ClickableTerminalBlock` in
 * place of `TerminalBlock`.
 *
 * `createBashRow` is a factory, not the component itself, because the click
 * plumbing (`openRef`/`openFolder`) is built once in `apply()` from `ctx` and
 * `ctx.workspaces` — services a toolview component cannot reach on its own —
 * and closed over here, the same technique the sibling
 * `@sumomok/dsh-quote-message` plugin uses for its own shadowing view
 * (`QuotedUserNodeView.tsx`). This plugin's own owner prop `openFile` is
 * never called: the click chokepoint is `openRef` alone (spec §3).
 *
 * @module @haoran/dsh-clickable-refs/client/bash/BashRow
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ToolCallViewProps } from '@deepseek-ai/dsh-client-ui-tool/client';
import type { DetectedRef } from '../../core/detect.ts';
import type { ClickOutcome } from '../referent-click.ts';
import type { VerificationStore } from '../verification-store.ts';
/** Full row props: the toolview runtime share plus the host's own `conversation` locale seat. */
type BashRowProps = ToolCallViewProps & PropsLocale<'conversation'>;
/** Click plumbing built once in `apply()` and closed over by every row instance. */
export interface BashRowDeps {
    /** Open one detected reference through the seam. */
    openRef: (ref: DetectedRef, sessionId: string | undefined) => Promise<ClickOutcome>;
    /** Open a refused target's parent folder directly. */
    openFolder: (folder: string) => void;
    notFoundLabel: () => string;
    refusedLabel: () => string;
    openFolderLabel: () => string;
    uncLabel: () => string;
    copyLabel: () => string;
    copiedLabel: () => string;
    /** Verification gate for every terminal card this row renders (B6 — see `ClickableTerminalBlock`'s own `store` doc). */
    store: VerificationStore;
}
/**
 * Build the `bash` keyed toolview component.
 * @param deps - click plumbing from `apply()` (see {@link BashRowDeps}).
 * @returns the component to register at `tool.call.toolview` key `'bash'`.
 */
export declare function createBashRow(deps: BashRowDeps): (props: BashRowProps) => ReactNode;
export {};
//# sourceMappingURL=BashRow.d.ts.map