/**
 * This plugin's `web_fetch` keyed toolview: 1:1 chrome with the built-in
 * `WebRow` (`web-row.tsx` in `dsh-render`) — same `DisclosureRow` chrome
 * (public in `@deepseek-ai/dsh-client-ui-primitives`) and the SAME `WebBlock`
 * component for the fetch card body, so the card itself is byte-identical.
 * The only change: a capture-phase click handler on the card wrapper routes
 * the fetch URL's anchor click through `referent/open` instead of letting
 * the browser navigate it directly (spec §2/§3). `web_search` is out of
 * scope (`web-model.ts`'s header explains why).
 *
 * `createWebRow` is a factory closing over the click plumbing built once in
 * `apply()`, the same technique `bash/BashRow.tsx` uses.
 *
 * @module @haoran/dsh-clickable-refs/client/web/WebRow
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ToolCallViewProps } from '@deepseek-ai/dsh-client-ui-tool/client';
import type { ReferentRef } from '@deepseek-ai/dsh-client-runtime/client';
/** Full row props: the toolview runtime share plus the host's own `conversation` locale seat. */
type WebRowProps = ToolCallViewProps & PropsLocale<'conversation'>;
/** Click plumbing built once in `apply()` and closed over by every row instance. */
export interface WebRowDeps {
    /** Open the fetch card's URL through the seam. */
    openUrl: (ref: ReferentRef) => Promise<void>;
}
/**
 * Build the `web_fetch` keyed toolview component.
 * @param deps - click plumbing from `apply()` (see {@link WebRowDeps}).
 * @returns the component to register at `tool.call.toolview` key `'web_fetch'`.
 */
export declare function createWebRow(deps: WebRowDeps): (props: WebRowProps) => ReactNode;
export {};
//# sourceMappingURL=WebRow.d.ts.map