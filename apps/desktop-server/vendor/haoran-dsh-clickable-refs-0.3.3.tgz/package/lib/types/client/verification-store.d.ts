/**
 * B3 of the three-layer spec (`docs/referents-three-layer-spec.md`): the
 * verification layer between nomination (`core/detect.ts`) and the render
 * seam's `scan`/`resolveLink`. `host.probeTargets` (`stat`, the A4 RPC,
 * ≤64 paths per call) is the SOLE existence verifier for a `file`/`dir`
 * candidate — the session truth index (`referent-index.ts`) never
 * verifies by itself. Recording that a tool touched a path during this
 * session only proves it existed at THAT moment: a file deleted since (or
 * a hand-authored session fixture that never existed on disk at all)
 * would otherwise render clickable and then fail on click, violating the
 * standing 蓝=必开 invariant — the defect a functional-conformance pass
 * caught in this store's first cut, which resolved an index hit straight
 * to verified with no `stat` at all. The index's remaining role is
 * resolving a basename/relative alias to its one unambiguous absolute
 * owner before a target is ever queued (`resolveAlias`); every candidate,
 * index-known or not, then queues for the same `stat` batch identically.
 * Results land in `verified`/`rejected` caches and a tick fires through
 * `subscribe` — the same channel `ProseReferents.subscribe` forwards, so a
 * host that already rendered a candidate as plain text can re-scan and
 * reveal it the moment it verifies. Index GROWTH still matters: a fresh
 * recorded fact ticks this store's own subscribers (the constructor wires
 * that forwarding), which drives the caller to re-`scan`/re-filter and
 * call `check()` again — now correctly enqueueing a `stat` rather than
 * resolving instantly, since a growing index no longer verifies anything
 * by itself.
 *
 * @module @haoran/dsh-clickable-refs/client/verification-store
 */
import type { ReferentIndexReader } from './referent-index.ts';
/** One `host.probeTargets` result row, this store's only shape for the host stat batch — kept narrow so a test double needs no other field. */
export interface ProbeResult {
    readonly path: string;
    readonly exists: boolean;
    readonly kind?: 'file' | 'dir';
}
/** Batch prober: `ctx.workspaces.probeTargets` in production, a scripted stub in tests. */
export type ProbeTargets = (paths: readonly string[]) => Promise<readonly ProbeResult[]>;
/**
 * Verification cache + host-stat batch scheduler for `file`/`dir`
 * candidates. `url` candidates never reach this store — B5 exempts them
 * from `stat` entirely (the click promise is "open a browser tab", not
 * "this host answers").
 */
export declare class VerificationStore {
    private readonly index;
    private readonly probe;
    private readonly verified;
    private readonly rejected;
    private readonly queued;
    private dispatching;
    private readonly listeners;
    private readonly unsubscribeIndex;
    /**
     * @param index - session truth index consulted before ever queueing a `stat`.
     * @param probe - batch prober; called with at most {@link MAX_BATCH} paths.
     */
    constructor(index: ReferentIndexReader, probe: ProbeTargets);
    /** Stop forwarding index ticks (owner teardown). */
    dispose(): void;
    /**
     * Synchronous, IO-free check: verified kind, or `undefined` when not
     * (yet, or ever) verified. `stat` — a completed `host.probeTargets`
     * batch — is this store's SOLE existence verifier; the index is
     * consulted only to resolve `target` as a basename/relative alias to
     * its one unambiguous absolute owner ({@link ReferentIndexReader.resolveAlias}
     * — a no-op when `target` is not a recorded alias, which an
     * already-absolute path never is). An index-known path and a wholly
     * unknown one are then queued identically: knowing a tool touched a
     * path this session proves nothing about whether it still exists NOW,
     * so it earns no verification shortcut (deliberately not priority-queued
     * ahead of an unknown path either — a disclosed simplification, not a
     * correctness requirement). A miss that is not already queued or
     * rejected enqueues it for the next `stat` batch as a side effect —
     * callers do not need a separate "ensure" call.
     * @param target - absolute path (or a basename/relative alias text the
     * index may resolve — this store resolves nothing else itself; the
     * nomination layer resolves everything else before a candidate ever
     * reaches this method).
     * @returns the verified kind, from the `stat` batch's own authoritative
     * report — or `undefined` when not (yet, or ever) verified.
     */
    check(target: string): 'file' | 'dir' | undefined;
    /**
     * Subscribe to verification progress (index growth and completed `stat`
     * batches alike).
     * @param listener - called with no arguments on every tick.
     * @returns unsubscribe function.
     */
    subscribe(listener: () => void): () => void;
    private scheduleDispatch;
    private dispatch;
    private notify;
}
//# sourceMappingURL=verification-store.d.ts.map