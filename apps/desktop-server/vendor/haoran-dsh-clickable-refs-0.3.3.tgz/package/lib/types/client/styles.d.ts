/**
 * This plugin's whole stylesheet, injected once as a tagged `<style>`.
 *
 * A CSS module would be the shell's own idiom, but (same as every other
 * out-of-repo plugin here) this package's build hands `tsc` output straight
 * to esbuild, which emits no stylesheet for a `.module.css` next to source
 * that no longer exists at that point — so the rules live here as text.
 *
 * The bash/web chrome rules are a close port of the built-in `BashRow`
 * (`bash-sample.tsx`/`.module.css`), `TerminalBlock` (ui-primitives), and the
 * generic `ToolRow`/`DisclosureRow` chrome this plugin's own `WebRow`
 * composes from the public `DisclosureRow` primitive — read from
 * `dsh-render`'s source (docs/clickable-refs-spec.md §2 requires matching it)
 * and re-authored under this plugin's own `dshcr-` class prefix so it cannot
 * collide with the host's identically-named classes. Every color is a
 * `--dsw-*` harness theme token, exactly as the built-ins use them, so both
 * surfaces follow the same light/dark scheme.
 *
 * @module @haoran/dsh-clickable-refs/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-clickable-refs";
/**
 * Put the stylesheet in the document, once.
 * @returns a disposer removing the tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map