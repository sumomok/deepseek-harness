/**
 * The handful of `ToolCallBlock` → display-text derivations both the bash
 * and web row models need — split out so neither duplicates the other,
 * mirroring the built-in `tool-call-model.ts`'s own `resultText`/summary
 * helpers narrowly (only the parts a `bash`/`web_fetch` keyed toolview uses).
 *
 * @module @haoran/dsh-clickable-refs/client/tool-model-shared
 */
import type { ToolResultNode } from '@deepseek-ai/dsh-client-runtime/client';
/** The first line of text (no trailing newline), or the whole string when it carries none. */
export declare function firstLine(text: string): string;
/** Flatten a settled result's content blocks: text verbatim, everything else as pretty JSON; an empty, failed result falls back to its structured error. */
export declare function resultText(node: ToolResultNode): string;
/** Parse a call's raw JSON args, or null for empty/non-object/unparseable input (mid-stream truncation). */
export declare function parseArgs(argsRaw: string): Record<string, unknown> | null;
/**
 * The first non-empty string value found under `keys`, in order, falling
 * back to the first non-empty string value anywhere in the parsed args, then
 * to the raw args text — the built-in `deriveSummary`'s fallback chain.
 * @param argsRaw - the call's raw JSON args text.
 * @param keys - preferred keys, in order.
 * @returns the summary text (its first line only).
 */
export declare function deriveSummary(argsRaw: string, keys: readonly string[]): string;
//# sourceMappingURL=tool-model-shared.d.ts.map