/**
 * The `proseReferents` optional-service provider (`ctx.provide('proseReferents', …)`,
 * consumed by `@deepseek-ai/dsh-client-ui-conversation`'s chat view). B4/B1
 * of the three-layer spec: `core/detect.ts` still does 100% of nomination
 * (unchanged), but `scan`/`resolveLink` now filter every candidate through
 * the {@link VerificationStore} before returning it — an unverified
 * candidate never leaves this module, which is what makes "blue = openable"
 * hold structurally at the render layer (`dsh-render`'s `MarkdownProseReferents`
 * never receives an unverified span to begin with). `subscribe` forwards
 * the store's own tick channel straight through, unwrapped.
 *
 * @module @haoran/dsh-clickable-refs/client/prose-referents
 */
import type { ProseReferents } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { VerificationStore } from './verification-store.ts';
/**
 * Build the `ProseReferents` service this plugin provides, bound to one
 * session's {@link VerificationStore}.
 * @param store - verification cache/scheduler for the active session (the
 * plugin owns one instance, rebuilt on session switch — see `client/index.ts`).
 * @returns the service to `ctx.provide('proseReferents', …)`.
 */
export declare function createProseReferents(store: VerificationStore): ProseReferents;
//# sourceMappingURL=prose-referents.d.ts.map