/**
 * Progressive full-output reference scanning for a settled terminal card:
 * the first time-boxed chunk runs synchronously (so the lines a reader sees
 * at first paint are already clickable), the rest continues across
 * idle-time slices — regardless of the head/tail collapse state — until
 * every line has a result, never leaving a "the rest stays unscanned" tail
 * however large the output is. A chunk budgets itself against a clock
 * (`performance.now` by default, injectable for deterministic tests) and
 * yields via `requestIdleCallback` where the host provides one, `setTimeout(0)`
 * otherwise.
 *
 * @module @haoran/dsh-clickable-refs/client/bash/progressive-scan
 */
import { type DetectedRef, type DetectOptions } from '../../core/detect.ts';
/** Injectable clock/scheduler seam so a test can bound and step chunks deterministically; production uses the real globals. */
export interface ProgressiveScanClock {
    /** Monotonic milliseconds, matching `performance.now()`'s contract. */
    now: () => number;
    /** Schedule `run` for the next idle slice. */
    scheduleIdle: (run: () => void) => void;
}
/** No detections yet — the line not having reached its scan chunk, distinct from a scanned line with zero hits. */
export declare const UNSCANNED: readonly DetectedRef[];
/**
 * Incremental scanner over a fixed list of plain-text lines. `ensure` is the
 * only entry point: called every render, it synchronously scans the first
 * time-boxed chunk (and schedules continuations) the first time a given
 * `lines`/`opts` identity appears, and is a cheap read of accumulated
 * progress on every call after that — a different identity resets and
 * restarts from the top.
 */
export declare class ProgressiveLineScanner {
    private lines;
    private optsKey;
    private opts;
    private results;
    private nextIndex;
    private onProgress;
    private readonly clock;
    /** @param clock - defaults to the real `performance.now()`/idle-callback pair; tests inject a controlled one. */
    constructor(clock?: ProgressiveScanClock);
    /**
     * @param lines - the full output's plain-text lines, in order; a new array
     * identity (a fresh command settling) resets all progress.
     * @param opts - resolution bases for a relative reference.
     * @param onProgress - called once per completed continuation chunk, so the
     * owning component can re-render as spans activate.
     * @returns per-line results, same length as `lines`; an index not yet
     * reached is {@link UNSCANNED}.
     */
    ensure(lines: readonly string[], opts: DetectOptions, onProgress: () => void): readonly (readonly DetectedRef[])[];
    private scanChunk;
}
//# sourceMappingURL=progressive-scan.d.ts.map