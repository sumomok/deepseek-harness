/**
 * Turn one parsed ANSI output line into React children with its detected
 * spans made clickable, keeping every other run's color intact.
 *
 * `parseAnsiLines` (ui-primitives) keeps the color; the caller supplies this
 * line's already-detected spans (`core/detect.ts`'s `detectRefs`, run over
 * the line's own plain text — `AnsiSpan.text` concatenated — by the owning
 * card's {@link ../bash/progressive-scan.ts | ProgressiveLineScanner}, not
 * here, so a card with many lines never blocks its render on scanning all of
 * them at once). A detected span's `[start, end)` plain-text offsets are
 * mapped back onto the colored `AnsiSpan` runs, splitting a run at a
 * boundary that falls inside it. A detected span crossing more than one
 * colored run — a path whose color changes mid-string — becomes ONE
 * clickable wrapper around every part it touches, each part keeping its own
 * style, rather than one wrapper per run: a second click handler over half a
 * path would answer a click on that half differently from the other.
 *
 * @module @haoran/dsh-clickable-refs/client/bash/terminal-render
 */
import type { ReactNode } from 'react';
import type { AnsiLine } from '@deepseek-ai/dsh-client-ui-primitives';
import type { DetectedRef } from '../../core/detect.ts';
import { type ClickableSpanProps } from '../ClickableSpan.tsx';
/** Handlers a clickable line needs, shared by every hit on it (bound once per render by the owning row). */
export type ClickHandlers = Pick<ClickableSpanProps, 'onOpen' | 'onOpenFolder' | 'notFoundLabel' | 'refusedLabel' | 'openFolderLabel' | 'uncLabel' | 'copyLabel' | 'copiedLabel'>;
/**
 * Render one parsed output line, wrapping every already-detected reference
 * in a {@link ClickableSpan}. A line with no span (either genuinely none, or
 * not yet reached by the owning card's progressive scan — see
 * `progressive-scan.ts`) renders exactly what the built-in `TerminalBlock`'s
 * own line renderer would — bare text or styled spans, no wrapper — so an
 * ordinary or not-yet-scanned line stays byte-identical chrome; a span
 * activates the moment its chunk lands, with no change to this function.
 * @param line - the line's colored runs.
 * @param refs - this line's detected spans (its plain-text `[start, end)`
 * offsets), in ascending order; empty for a not-yet-scanned or hit-free line.
 * @param handlers - per-hit click plumbing, bound by the owning row (see {@link ClickHandlers}).
 * @returns the line's children.
 */
export declare function renderClickableLine(line: AnsiLine, refs: readonly DetectedRef[], handlers: (ref: DetectedRef) => ClickHandlers): ReactNode;
//# sourceMappingURL=terminal-render.d.ts.map