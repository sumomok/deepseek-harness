/**
 * Copy for this plugin's own added UI: the not-found and refusal-list
 * messages a click can surface. Everything else this plugin renders (the
 * mirrored bash/web chrome) borrows the host's own `conversation` namespace
 * (see BashRow.tsx/WebRow.tsx), so a locale switch keeps that text in step
 * with the built-in views it shadows without a second copy to maintain here.
 *
 * @module @haoran/dsh-clickable-refs/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "clickable-refs";
/** Every key this plugin's own added copy uses. */
export type ClickableRefsKey = 'notFound' | 'refused' | 'openFolder' | 'unc' | 'copy' | 'copied';
/** English copy. */
export declare const en: Record<ClickableRefsKey, string>;
/** Chinese copy. */
export declare const zh: Record<ClickableRefsKey, string>;
//# sourceMappingURL=locales.d.ts.map