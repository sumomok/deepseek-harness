import type { DetectedRef } from '../../core/detect.ts';
import type { VerificationStore } from '../verification-store.ts';
import { type ProgressiveScanClock } from './progressive-scan.ts';
import { type ClickHandlers } from './terminal-render.tsx';
/** Display copy this block needs, bound by the owning row to the host's own `conversation` namespace (§2's text-parity choice — see BashRow.tsx). */
export interface TerminalLabels {
    signal: (signal: string) => string;
    exitCode: (exitCode: number) => string;
    running: string;
    failed: string;
    done: string;
    copy: string;
    copied: string;
    noOutput: string;
    collapseAria: string;
    collapse: string;
    expandAria: (hidden: number) => string;
    expand: (hidden: number) => string;
}
export interface ClickableTerminalBlockProps {
    command: string;
    cwd?: string | undefined;
    home?: string | undefined;
    output?: string | undefined;
    exitCode?: number | undefined;
    signal?: string | undefined;
    running?: boolean | undefined;
    maxLines?: number | undefined;
    labels: TerminalLabels;
    /** Per-hit click plumbing, bound by the owning row. */
    handlers: (ref: DetectedRef) => ClickHandlers;
    /**
     * Verification gate (B6, three-layer spec): a nominated `file`/`dir`
     * candidate renders inert plain text until this store's own `stat`
     * batch confirms it — the sole existence verifier; an index hit alone
     * earns no shortcut. A `url` candidate is always verified
     * (B5 — URL spans never `stat`), and a UNC candidate (`\\server\share\…`)
     * is likewise always verified and never enqueued into this store at all —
     * a `stat` on a UNC path is an SMB connection that can leak NTLM
     * credentials, so this gate never asks for one. Ticks re-run this filter
     * without rescanning, so a candidate that verifies after this card already
     * rendered still lights up in place.
     */
    store: VerificationStore;
    /** Clock/scheduler override for the progressive scan; production omits it (real `performance.now`/idle callback). */
    scanClock?: ProgressiveScanClock | undefined;
}
/**
 * A shell-command terminal surface whose output lines carry clickable spans.
 * @param props - see {@link ClickableTerminalBlockProps}.
 * @returns the terminal block element.
 */
export declare function ClickableTerminalBlock({ command, cwd, home, output, exitCode, signal, running, maxLines, labels, handlers, store, scanClock, }: ClickableTerminalBlockProps): import("react").JSX.Element;
//# sourceMappingURL=ClickableTerminalBlock.d.ts.map