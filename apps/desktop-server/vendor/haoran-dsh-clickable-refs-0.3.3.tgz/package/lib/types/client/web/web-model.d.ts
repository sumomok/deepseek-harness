/**
 * `web_fetch`-only row/card derivation, narrowed from the built-in
 * `toolRowModel`/`webCardModel` the same way `bash/terminal-model.ts`
 * narrows the bash pair (see that module's header for why this is a local
 * re-derivation rather than a shared import). `web_search` is out of scope:
 * its card is a source-citation list, each already its own safe external
 * link, not the one-URL fetch summary this plugin's spec targets.
 *
 * @module @haoran/dsh-clickable-refs/client/web/web-model
 */
import type { ToolCallBlock } from '@deepseek-ai/dsh-client-runtime/client';
/** Row state semantic (mirrors the built-in `ToolRowState`). */
export type WebRowState = 'running' | 'ok' | 'error' | 'stopped';
/** The completed fetch card's own data (mirrors `WebFetchBlockProps`). */
export interface WebFetchCard {
    readonly url: string;
    readonly statusCode: number;
    readonly truncated: boolean;
}
/** Everything `WebRow` needs, derived once from the frozen call slice. */
export interface WebRowModel {
    readonly state: WebRowState;
    readonly summary: string;
    readonly errorSummary: string | null;
    readonly output: string | null;
    /** Present exactly once the call has settled with a fetch card; null while running or on the generic path. */
    readonly card: WebFetchCard | null;
}
/**
 * Derive the web_fetch row model from a frozen call slice.
 * @param block - RunningToolCall or ToolResultNode off the owner's `block` prop.
 * @returns the derived model.
 */
export declare function webFetchRowModel(block: ToolCallBlock): WebRowModel;
//# sourceMappingURL=web-model.d.ts.map