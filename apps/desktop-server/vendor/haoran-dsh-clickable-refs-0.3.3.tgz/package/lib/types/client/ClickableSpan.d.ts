/**
 * One clickable hit inside a mirrored bash/web view: hover-underline + a
 * pointer cursor, keyboard-reachable (`tabIndex` + Enter), and a small inline
 * notice for what the click did — a not-found hint that fades on its own
 * while permanently downgrading the span to dead text FOR THIS RENDER (never
 * persisted; a fresh render re-attempts), a refusal notice with an "open
 * containing folder" recovery button that stays until the next click, or a
 * UNC notice with a "copy" button (clipboard) that stays until the next
 * click. The click itself is never handled here: `onOpen` is the one
 * chokepoint (`referent-click.ts`'s `openReferentTarget`), injected by the
 * owning row so this component stays a pure function of its props and is
 * testable without cordis or the real runtime package.
 *
 * @module @haoran/dsh-clickable-refs/client/ClickableSpan
 */
import { type ReactNode } from 'react';
import type { ClickOutcome } from './referent-click.ts';
export interface ClickableSpanProps {
    /** The styled text to render — ANSI spans for a terminal line, or the plain URL for the web card. */
    readonly children: ReactNode;
    /** Open this reference through the seam; returns what happened. */
    readonly onOpen: () => Promise<ClickOutcome>;
    /** Open the refused target's parent folder directly (never re-enters the seam). */
    readonly onOpenFolder: (folder: string) => void;
    readonly notFoundLabel: string;
    readonly refusedLabel: string;
    readonly openFolderLabel: string;
    /** "This is a network share path, not opened automatically" — the UNC notice's message. */
    readonly uncLabel: string;
    readonly copyLabel: string;
    readonly copiedLabel: string;
}
/**
 * One detected reference, rendered as a clickable inline span.
 * @param props - see {@link ClickableSpanProps}.
 * @returns the span, plus any inline notice its last click produced.
 */
export declare function ClickableSpan(props: ClickableSpanProps): import("react").JSX.Element;
//# sourceMappingURL=ClickableSpan.d.ts.map