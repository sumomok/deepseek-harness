/**
 * Feedback channel for a UNC path copied from Assistant prose. The terminal
 * card's own UNC notice (`ClickableSpan`) renders inline because that
 * component owns a per-span notice slot; a prose hit has none — core's
 * generic `proseReferents` seam renders a plain button with no room for
 * extra JSX (`dsh-render`'s `render.tsx`, by design: the renderer never
 * carries per-kind presentation). This module is the plugin's own answer for
 * that one surface: a transient frame-wide toast, mounted the same way
 * `styles.ts` mounts this plugin's stylesheet — one plain DOM element,
 * inserted and removed directly, no framework slot required.
 *
 * @module @haoran/dsh-clickable-refs/client/prose-unc-toast
 */
/**
 * Mount the (initially hidden) toast element into `document.body`, once.
 * @returns a disposer removing it.
 */
export declare function mountProseUncToast(): () => void;
/**
 * Show `message` in the mounted toast; a later call replaces the text and
 * restarts the auto-hide timer. A no-op when the toast was never mounted
 * (no `document`, or `mountProseUncToast` never ran).
 * @param message - the copied-confirmation text to show.
 */
export declare function showProseUncCopyToast(message: string): void;
//# sourceMappingURL=prose-unc-toast.d.ts.map