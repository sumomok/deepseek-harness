/**
 * Host half of @haoran/dsh-clickable-refs. The row in cordis.patch.yml
 * mounts this half so the loader sees a real cordis plugin and the
 * client-modules registry serves the browser half declared in `dsh.client`.
 * No host service, no route, no session event — the one thing this half
 * contributes is B1 of the three-layer spec
 * (`docs/referents-three-layer-spec.md`): the system-prompt line that gets
 * the model nominating file/directory mentions as Markdown links in the
 * first place (the browser half's `MutableReferentIndex`/verification
 * layer then decides which of those links actually turn clickable).
 * Registered through the existing `dsh-system-prompt` seam (A5 of the
 * spec's recon: `ctx.systemPrompt.section` already exists and every prompt
 * section already lands in the durable session log as part of the
 * request header — `dsh-session`'s `'request/header'` event, log-only,
 * reconstructs the assembled prompt on replay — so no core change was
 * needed to satisfy model-visible ⟺ logged for this content; the sibling
 * `@deepseek-ai/dsh-client-ui-deliverables` package's own
 * `ui:deliverable-file-references` section, order 190, is this same
 * seam's precedent for a client-side renderer supplying its own prompt
 * guidance).
 *
 * @module @haoran/dsh-clickable-refs
 */
import type { Context } from '@deepseek-ai/cordis';
/** Plugin name in the loader's entry roster. */
export declare const name = "clickable-refs";
/** Services required host-side. */
export declare const inject: string[];
/**
 * B1's finalized instruction: nominate a file/directory mention as an
 * absolute-path Markdown link, restricted to files that actually appeared
 * in this conversation — ordinary words never become links. Also names the
 * two CommonMark-legal escapes for a space (or other link-breaking
 * character) in the path — an unbracketed, unencoded space breaks the link
 * destination outright, and the model does not reach for an escape on its
 * own consistently (observed both encoding and not, live). Wording may be
 * tuned without changing this meaning (spec's own "执行时可微调措辞但语义不变").
 */
export declare const PROSE_LINK_PROMPT: string;
/**
 * Apply the host half: register the prose-link system-prompt section.
 * @param ctx - loader context (must inject `systemPrompt`).
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map