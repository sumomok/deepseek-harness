/**
 * The review call itself: one prompt, one model turn, one parsed verdict.
 * Two questions share it — a pending tool call and a sandbox escalation.
 *
 * Every way this can go wrong returns {@link JudgeFailure} rather than a
 * verdict, and the failure type carries no verdict of its own — the caller
 * decides, and its only choices are the fail-closed ones. Nothing in this
 * module can produce `allow` except a model answer that parsed as `allow`.
 * @module @haoran/dsh-llm-permission-gateway/judge
 */
import type { Context } from '@deepseek-ai/cordis';
import type { TokenUsage } from '@deepseek-ai/dsh-llm';
/**
 * The answer set the parser accepts. `deny` is still parsed because a model
 * told to answer with two values may answer with three; the gate downgrades it
 * rather than letting an unrecognized word become a fail-closed failure.
 */
export type JudgeVerdict = 'allow' | 'ask' | 'deny';
/** A parsed model answer. */
export interface JudgeResult {
    /** The verdict the model returned. */
    readonly verdict: JudgeVerdict;
    /** The model's one-sentence statement of what running the call would cost. */
    readonly reason: string;
}
/** Why no verdict was obtained. Carries no verdict, so no failure path can allow. */
export interface JudgeFailure {
    /** Short machine-ish label for the failure mode, recorded and quoted into the fail-closed reason. */
    readonly cause: 'timeout' | 'cancelled' | 'model-error' | 'unparsable-answer';
    /** Detail for the fail-closed reason shown to the user, in the user's own language. */
    readonly detail: string;
}
/**
 * The judge's outcome: either a parsed verdict or a failure.
 *
 * `usage` rides both members because a review that produced no verdict can
 * still have been paid for — a truncated answer is billed like any other — and
 * a cost record that counted only the successful reviews would understate what
 * the gate spends. It is absent when the stream reported no usage chunk, and it
 * covers both turns of a widened review rather than only the one that answered.
 *
 * `budgetRetried` marks an outcome reached after {@link JudgeRoute.reasoningBudgetTokens}
 * bought a second turn; see {@link JudgeRoute.reasoningBudgetTokens} for when
 * that happens.
 */
export type JudgeOutcome = {
    readonly kind: 'verdict';
    readonly result: JudgeResult;
    readonly usage?: TokenUsage;
    readonly budgetRetried?: true;
} | {
    readonly kind: 'failure';
    readonly failure: JudgeFailure;
    readonly usage?: TokenUsage;
    readonly budgetRetried?: true;
};
/** Where the judge model lives and how long it may take. */
export interface JudgeRoute {
    /** Registered LLM provider route (`ctx.llm` adapter selector). */
    readonly provider: string;
    /** Model id, chosen independently of the agent's own model. */
    readonly model: string;
    /** Provider-owned reasoning effort id, or `undefined` to take the provider default. */
    readonly reasoningEffort: string | undefined;
    /** Output cap; the answer is one small JSON object. */
    readonly maxOutputTokens: number;
    /**
     * Extra output tokens one retry adds after an answer that hit
     * {@link JudgeRoute.maxOutputTokens} having spent thinking tokens; `0` never
     * retries.
     *
     * The provider counts thinking inside the output cap, so a reviewer that
     * thinks first can exhaust the cap before it writes the verdict — which is a
     * fail-closed failure, and therefore an approval prompt on every call. The
     * retry is issued inside the same {@link JudgeRoute.timeoutMs} budget and
     * happens at most once.
     */
    readonly reasoningBudgetTokens: number;
    /** Wall-clock budget for the whole review call. */
    readonly timeoutMs: number;
    /** Language for the human-facing reason. */
    readonly reasonLanguage: string;
}
/**
 * One sandbox escalation put to the review model: the operating system has
 * already refused a command, and the agent is asking for the refusal to be
 * lifted for this one call.
 */
export interface EscalationReview {
    /** The tool whose call was refused (`bash`, `pwsh`, `write`, `edit`). */
    readonly tool: string;
    /** The wider sandbox mode being asked for. */
    readonly requestedMode: string;
    /** The agent's own stated reason, verbatim; a claim about itself, not evidence. */
    readonly justification: string;
    /**
     * Arguments of the refused call, as this gate saw them on `tools/pre-execute`.
     * Required, because the prompt tells the model the refused call is in front of
     * it: an escalation whose call was not remembered goes to a person instead of
     * reaching this function.
     */
    readonly arguments: unknown;
}
/**
 * Parse a model answer into a verdict.
 *
 * The whole answer must be one JSON object: no prose around it, and no search
 * for a decision word anywhere in the text. An answer that does not parse, or
 * whose `decision` is not exactly one of the three enum members, or whose
 * `reason` is not a non-empty string, yields `undefined` and therefore the
 * caller's fail-closed outcome.
 * @param text - the model's raw output.
 * @returns the parsed result, or `undefined` when the answer is not usable.
 */
export declare function parseJudgeResponse(text: string): JudgeResult | undefined;
/**
 * Review one pending call.
 *
 * The description is passed explicitly, and explicitly as `undefined` where the
 * registry resolves none, so that whether the judge sees one is decided by the
 * caller that read the registry rather than defaulted here.
 * @param ctx - context exposing the `llm` service.
 * @param route - the independently configured judge model and its budget.
 * @param toolName - the tool about to run.
 * @param args - the parsed call arguments.
 * @param description - the tool's own registered description, or `undefined` when none is available.
 * @param confined - whether the operating system confines this call's file effects, which is the premise the prompt states.
 * @param callerSignal - the tool call's own cancellation.
 * @returns the parsed verdict, or the failure the caller must fail closed on, with the tokens the request reported.
 */
export declare function judgeCall(ctx: Context, route: JudgeRoute, toolName: string, args: unknown, description: string | undefined, confined: boolean, callerSignal: AbortSignal): Promise<JudgeOutcome>;
/**
 * Review one sandbox escalation on the user's behalf.
 * @param ctx - context exposing the `llm` service.
 * @param route - the independently configured judge model and its budget.
 * @param request - the refused call, the wider access asked for, and the agent's justification.
 * @param callerSignal - the approval request's own cancellation, when it carries one.
 * @returns the parsed verdict, or the failure the caller must fail closed on, with the tokens the request reported.
 */
export declare function judgeEscalation(ctx: Context, route: JudgeRoute, request: EscalationReview, callerSignal: AbortSignal): Promise<JudgeOutcome>;
//# sourceMappingURL=judge.d.ts.map