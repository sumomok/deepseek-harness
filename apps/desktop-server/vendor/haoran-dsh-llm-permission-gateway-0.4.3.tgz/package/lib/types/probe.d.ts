/**
 * The trace this gate leaves behind, so a decision can be inspected after the
 * fact instead of inferred from a latency bump.
 *
 * Only two of the gate's answers are visible anywhere else: a denial surfaces
 * to the model as a tool error, and an `ask` reaches the session log as an
 * `approval/asked` pair. An allow is silent — indistinguishable in the log from
 * a call this plugin never saw — which leaves the most common outcome, and the
 * one the review model actually spends money on, unaccounted for. Under the
 * `full-access` tier neither of those two happens at all: the gate refuses
 * nothing and asks nobody, so this file is the only place the calls it admitted
 * are counted.
 *
 * Nothing in this plugin protects the file. It is written with the process
 * umask under `$DSH_HOME` and is as readable and as writable as that directory
 * is. The self-modification red line covers the gate's own files and the
 * profile, and deliberately not this path: reaching it meant reading
 * `Config.verdictLog`, and a red line a configuration field can move is not a
 * red line.
 *
 * A session event would be the natural home for it and is not available: a
 * `SessionEventMap` member is required-on-read, the harness registers event
 * types in its own tree, and an unknown non-ignorable event makes the host
 * refuse to replay the whole session log. So the record goes to a file this
 * package owns and to the host log, neither of which the harness reads back.
 *
 * Nothing here is part of a decision. Every write is contained, a failing write
 * is reported once and then ignored, and no path returns a value the caller's
 * verdict depends on.
 * @module @haoran/dsh-llm-permission-gateway/probe
 */
import type { TokenUsage } from '@deepseek-ai/dsh-llm';
import type { JudgeOutcome, JudgeVerdict } from './judge.ts';
import type { AccessTier, ApprovalPolicy } from './policy.ts';
import type { RedLine } from './redline.ts';
/**
 * Which step of the decision order answered. The names match the README's
 * numbered order, so a record says not just what was decided but which layer
 * decided it — a `cache` allow and a `model` allow cost very different things.
 */
export type VerdictSource = 'redline' | 'alwaysAsk' | 'readOnly' | 'walled' | 'manual' | 'cancelled' | 'unattended' | 'oversize' | 'cache' | 'model' | 'failure' | 'escalation' | 'escalationUnreviewed' | 'escalationFailure';
/**
 * What a record says was decided. `cancelled` is not a verdict the gate reached
 * — the call was abandoned before one was needed — so it is its own value
 * rather than an `allow` that would be counted as a call this gate admitted.
 */
export type ProbeDecision = JudgeVerdict | 'cancelled';
/**
 * What the rest of the `tools/pre-execute` chain answered when this gate put
 * its own `ask` to it before raising it.
 *
 * `none` is a chain that threw instead of answering: the error is on its way to
 * the registry, and the record says the ask was delegated without saying it was
 * answered. A record with no `downstream` at all is one this gate wrote before
 * delegating, or one where it did not delegate.
 */
export type DownstreamAnswer = 'allow' | 'ask' | 'deny' | 'none';
/** Identity, size, and content of the call a record describes. */
export interface ProbeCall {
    /** The tool the model asked to run. */
    readonly tool: string;
    /**
     * Registry call id, the same one the approval seam and the session log carry.
     * Absent only for a sandbox escalation whose approval request named no call.
     */
    readonly callId?: string;
    /** Root model-requested call owning this execution tree; omitted when it is the call itself. */
    readonly rootCallId?: string;
    /** Session id of the agent the call belongs to; omitted for a call made outside an agent. */
    readonly agent?: string;
    /**
     * Canonical JSON of the whole call. Its length is the number
     * `maxArgumentsChars` is compared against, and its opening characters are
     * what an enabled preview keeps.
     */
    readonly serialized: string;
    /**
     * Full hex digest of the call's arguments — the argument half of the cache
     * key, so two records sharing it were offered the same arguments. The record
     * keeps its first {@link DIGEST_CHARS} characters.
     */
    readonly argsDigest: string;
}
/** What the gate decided and what reaching that decision cost. */
export interface ProbeOutcome {
    /**
     * The model the review was issued on, present on every record a review was
     * issued for and no other. It overrides {@link RecordFormat.model}, so a
     * verdict stays attributed to the reviewer that produced it even when the
     * route changes while the review is in flight.
     */
    readonly model?: string;
    /** The step that answered. */
    readonly source: VerdictSource;
    /**
     * The answer; `readOnly`, `walled`, `manual`, and `unattended` record `allow`,
     * because delegating admits the call.
     */
    readonly decision: ProbeDecision;
    /**
     * Which access tier decided the call. Absent on a record written before the
     * tier was read — a call already cancelled when it arrived — and on an
     * escalation record, which is answered outside the tier branch.
     */
    readonly tier?: AccessTier;
    /**
     * The effective approval policy the tier was folded from — the delegating
     * session's, where the call was delegated. Absent wherever
     * {@link ProbeOutcome.tier} is, and on a delegated call whose lineage did not
     * resolve, where no session's policy decided the tier. Recorded because it is
     * per-session and mutable, so no later reader can recover it from the plugin
     * config.
     */
    readonly policy?: ApprovalPolicy;
    /**
     * Whether the calling session was created as a subagent child, by its
     * `header.origin`; absent wherever {@link ProbeOutcome.tier} is. A forked
     * session is not one of these: a person opened it and is sitting in it.
     */
    readonly delegated?: boolean;
    /**
     * Whether an approval request for this call would have reached a person;
     * absent wherever {@link ProbeOutcome.tier} is. False turns every question
     * this gate would raise into a refusal it signs itself.
     */
    readonly humanReachable?: boolean;
    /**
     * The file-effect mode the sandbox policy resolved; absent wherever
     * {@link ProbeOutcome.tier} is, and also where no sandbox policy is composed.
     */
    readonly sandboxMode?: string;
    /**
     * Whether the operating system actually confined this call's file effects,
     * which is the other half the tier was folded from and the premise the review
     * prompt stated; absent wherever {@link ProbeOutcome.tier} is.
     */
    readonly confined?: boolean;
    /** Wall-clock time this gate held the call, including any review round trip. */
    readonly latencyMs: number;
    /** Which red line matched; present only when `source` is `redline`. */
    readonly redLine?: RedLine;
    /** Why no verdict was obtained; present only when `source` is `failure` or `escalationFailure`. */
    readonly failureCause?: string;
    /** The wider sandbox mode asked for; present only on an escalation record. */
    readonly requestedMode?: string;
    /** Set when the review model answered `deny` and this gate turned it into an `ask`. */
    readonly downgraded?: true;
    /** Set when the review spent a second, wider turn after thinking crowded the first answer out. */
    readonly budgetRetried?: true;
    /** What the rest of the chain answered; present only on an `ask` this gate delegated first. */
    readonly downstream?: DownstreamAnswer;
    /** The reason sentence attached to the decision, before truncation. */
    readonly reason?: string;
    /**
     * Length of the tool description the review request carried, as it carried it
     * — after the review prompt's own ceiling cut it. Absent on a record no
     * review was issued for, and on one whose tool resolved no description.
     */
    readonly descriptionChars?: number;
    /**
     * Full hex digest of that same text, by the digest the arguments use, so a
     * replay can tell which version of a description a verdict was reached
     * against. The record keeps its first {@link DIGEST_CHARS} characters.
     *
     * The description itself never enters a record: it is registration text a
     * replay can read from the registry, and what the file has to say is which
     * text was in front of the reviewer, not what it said.
     */
    readonly descriptionDigest?: string;
    /**
     * What the review request spent. Present only when a review was actually
     * issued — a `model` decision and a `failure` whose stream reported usage
     * before it broke — so summing these numbers over a file counts every token
     * this gate bought and nothing else.
     */
    readonly usage?: TokenUsage;
}
/**
 * One decision, as written to the probe file. Field order is the write order,
 * so the JSONL is readable without a parser.
 *
 * The token counts are the harness's disjoint ones: `inputTokens` excludes the
 * cached prefix, so one review's billed prompt is `inputTokens +
 * cacheReadTokens`.
 */
export interface VerdictRecord {
    /** When the decision was reached, ISO-8601. */
    readonly at: string;
    /** The tool the model asked to run. */
    readonly tool: string;
    /** Registry call id; absent only for a sandbox escalation whose approval request named no call. */
    readonly callId?: string;
    /** Root model-requested call owning this execution tree; absent when it is the call itself. */
    readonly rootCallId?: string;
    /** Session id of the agent the call belongs to; absent for a call made outside an agent. */
    readonly agent?: string;
    /** Serialized size of the call, the number `maxArgumentsChars` is compared against. */
    readonly argsChars: number;
    /** First {@link DIGEST_CHARS} characters of the argument digest; equal digests mean equal arguments. */
    readonly argsDigest: string;
    /**
     * Length of the tool description the review carried, after the review
     * prompt's own ceiling; absent on every record no review carried one, which
     * includes every skip, every cache hit, and every escalation record.
     */
    readonly descriptionChars?: number;
    /**
     * First {@link DIGEST_CHARS} characters of that description's digest, taken
     * the way the arguments' is; absent wherever `descriptionChars` is. Two
     * records sharing it were reviewed against the same description text.
     */
    readonly descriptionDigest?: string;
    /** The step that answered. */
    readonly source: VerdictSource;
    /** The answer. */
    readonly decision: ProbeDecision;
    /** Which access tier decided the call; absent on an escalation record and on a call cancelled before the tier was read. */
    readonly tier?: AccessTier;
    /** The effective approval policy the tier was folded from — the delegating session's, where the call was delegated; absent wherever `tier` is, and on a delegated call whose lineage did not resolve. */
    readonly policy?: ApprovalPolicy;
    /** Whether the calling session was created as a subagent child (`header.origin`); absent wherever `tier` is. */
    readonly delegated?: boolean;
    /** Whether an approval request for this call would have reached a person; absent wherever `tier` is. */
    readonly humanReachable?: boolean;
    /** The file-effect mode the sandbox policy resolved; absent wherever `tier` is, and where no policy service is composed. */
    readonly sandboxMode?: string;
    /** Whether the operating system confined this call's file effects; absent wherever `tier` is. */
    readonly confined?: boolean;
    /** Wall-clock time this gate held the call, rounded to whole milliseconds. */
    readonly latencyMs: number;
    /**
     * On a record a review was issued for, the model it was issued on. On every
     * other record, the route in force when the record was written — which says
     * what would have reviewed, not who did.
     */
    readonly model: string;
    /** Uncached prompt tokens the review spent; absent when no review was issued. */
    readonly inputTokens?: number;
    /** Answer tokens the review spent; absent when no review was issued. */
    readonly outputTokens?: number;
    /** Prompt tokens served from the provider's cache; absent when the provider reported none. */
    readonly cacheReadTokens?: number;
    /** Thinking tokens inside the answer; absent when the provider reported none. */
    readonly reasoningTokens?: number;
    /** Which red line matched; absent unless `source` is `redline`. */
    readonly redLine?: RedLine;
    /** The wider sandbox mode asked for; absent unless the record is an escalation. */
    readonly requestedMode?: string;
    /** Present when the review model answered `deny` and this gate turned it into an `ask`. */
    readonly downgraded?: true;
    /**
     * Present when the review was issued twice: the first answer reached the
     * output cap having spent thinking tokens, and `reasoningBudgetTokens` bought
     * a wider second turn. The token counts cover both turns, so a record with
     * this field says what the whole review cost, not what the turn that answered
     * cost.
     */
    readonly budgetRetried?: true;
    /**
     * What the rest of the chain answered before this gate raised its `ask`;
     * absent on a record written without delegating. A `deny` or an `ask` here is
     * the decision the call actually received, because the chain's answer wins
     * over this gate's own.
     */
    readonly downstream?: DownstreamAnswer;
    /** Why no verdict was obtained; absent unless `source` is `failure` or `escalationFailure`. */
    readonly failureCause?: string;
    /** The reason sentence, truncated to {@link MAX_REASON_CHARS}; absent when the step produced none. */
    readonly reason?: string;
    /**
     * Opening characters of the serialized call, whitespace collapsed; absent
     * unless {@link RecordFormat.argsPreviewChars} is above zero. This is the
     * user's own argument text, so it is off by default.
     */
    readonly argsPreview?: string;
}
/**
 * The two host-log methods this module uses, stated locally so the probe stays
 * a plain Node module rather than importing the plugin context.
 */
export interface ProbeLog {
    /** One-line decision summary. */
    info(message: string): void;
    /** Reported once, when the record file cannot be written. */
    warn(message: string): void;
}
/** What every record carries beyond the call itself, and how much of the call it keeps. */
export interface RecordFormat {
    /** Judge route's model id, stamped on a record whose outcome names none. */
    readonly model: string;
    /** Characters of serialized argument text kept in each record; `0` keeps none. */
    readonly argsPreviewChars: number;
}
/** How a probe writes. */
export interface VerdictProbeOptions {
    /** Absolute path of the JSONL record, or `false` to write no file. */
    readonly logPath: string | false;
    /**
     * The judge route's model id, read once per record and used for a record
     * whose outcome names none. A function and not a value because the route is a
     * live setting: a probe holding one id would name a reviewer that no longer
     * decides anything.
     */
    readonly model: () => string;
    /** Characters of serialized argument text kept in each record; `0` keeps none. */
    readonly argsPreviewChars: number;
    /** Host log receiving the one-line summary, and the single unwritable-file warning. */
    readonly log: ProbeLog;
}
/** Records decisions; every method returns nothing and throws nothing. */
export interface VerdictProbe {
    /**
     * Record one decision.
     * @param call - identity, size, and content of the call that was decided.
     * @param outcome - what was decided, by which step, and at what cost.
     */
    record(call: ProbeCall, outcome: ProbeOutcome): void;
}
/**
 * What a record says about one review's cost.
 *
 * Both fields are absent unless the review reported them, so an outcome
 * contributes nothing where the stream carried no usage chunk and the review
 * was answered on its first turn.
 * @param outcome - the review's outcome, of either kind.
 * @returns the record fields naming what the review spent and whether it took a second turn.
 */
export declare function reviewSpend(outcome: JudgeOutcome): Pick<ProbeOutcome, 'usage' | 'budgetRetried'>;
/**
 * Where decisions are recorded when the profile names no path.
 *
 * Under the harness home rather than beside the package, because the package
 * directory is reinstalled on every version bump and is also inside this
 * plugin's own self-modification red line.
 * @returns the absolute default record path.
 */
export declare function defaultVerdictLogPath(): string;
/**
 * Build the record for one decision.
 * @param call - identity, size, and content of the call that was decided.
 * @param outcome - what was decided, by which step, at what cost, and on which model where a review was issued.
 * @param format - the reviewer stamped on a record whose outcome names none, and how much of the call it keeps.
 * @returns the record to serialize, with absent optional fields left out entirely.
 */
export declare function verdictRecord(call: ProbeCall, outcome: ProbeOutcome, format: RecordFormat): VerdictRecord;
/**
 * Render a record as the one line that goes to the host log.
 *
 * Neither the reason nor the argument preview is included: both are text about
 * the user's own arguments, and the host log is a coarser-grained place than
 * the record file. Read the file for them.
 *
 * A chain answer that overrode this gate's own ask is written into the decision
 * as `ask→deny(downstream)`, because that ask is not what the call received:
 * the chain's `deny` or `ask` wins, and a `none` means the chain threw instead
 * of answering. A chain that allowed left this gate's ask standing, so it adds
 * nothing to the line.
 * @param record - the record to summarize.
 * @returns a single line, no trailing newline.
 */
export declare function verdictSummary(record: VerdictRecord): string;
/**
 * Create the probe used for the lifetime of one plugin instance.
 * @param options - where to write, what to stamp and keep, and the host log.
 * @returns a probe whose `record` never throws and never blocks on the host log.
 */
export declare function createVerdictProbe(options: VerdictProbeOptions): VerdictProbe;
//# sourceMappingURL=probe.d.ts.map