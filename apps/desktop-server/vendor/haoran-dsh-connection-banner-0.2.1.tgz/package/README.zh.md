# @haoran/dsh-connection-banner

[English](README.md) | 中文

在 DeepSeek Harness 网页界面里，服务器连接断开、客户端正在重连时，在页面顶部显示一条横幅。

## 它做什么

客户端本来就会带指数退避自行重试断线重连——这个插件把这个状态显形出来，而不是让界面卡住却没有任何说明。它监听 `@deepseek-ai/dsh-client-connection` 的 `connection/state` 客户端事件，一旦连接在两个非连接态（`'connecting'` 或 `'disconnected'`）中累计停留超过 5 秒（一次很快恢复的短暂掉线——几次重试内就恢复——不会弹出提示），就在页面顶部显示一条固定的小横幅：「连接已断开，正在重连…」（按语言本地化）。连接一恢复，横幅立即消失。

这条横幅没有按钮，也绝不会拦截页面其它位置的点击；它通过 `role="status"` 向辅助技术宣告自己。

## 安装

仅限桌面内部使用，未发布到 npm。打包成 tarball（`pnpm pack`）后按本地插件的常规方式装进某个 profile。
