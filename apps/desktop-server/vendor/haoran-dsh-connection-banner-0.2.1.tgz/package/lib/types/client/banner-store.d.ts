/**
 * Debounces `connection/state` transitions into one boolean: whether the
 * banner should be visible. A minimal `getSnapshot`/`subscribe` observable —
 * `@deepseek-ai/dsh-client-store` ships a real `SnapshotStore` engine, but
 * importing its *value* export runs that package's whole pre-built browser
 * bundle at module load, which touches `window` at the top level and throws
 * in a plain Node/vitest run (every real consumer only ever imports it from
 * inside an actual browser bundle). This plugin's state is one boolean set
 * wholesale on every transition, never a partial mutation, so the engine's
 * immer/zustand/persist machinery buys nothing here.
 *
 * `state === 'connected'` is the only branch this store distinguishes:
 * `ConnectionState`'s two non-connected members ('connecting' while a
 * physical-carrier attempt is in flight, 'disconnected' between attempts)
 * both arm/keep the same show timer, matching the single 'reconnecting'
 * state this store's logic originally keyed off before `ConnectionState`
 * split that one state into two.
 *
 * @module @haoran/dsh-connection-banner/client/banner-store
 */
import type { ConnectionState } from '@deepseek-ai/dsh-client-connection/client';
/**
 * How long 'reconnecting' must persist before the banner shows. A brief
 * reconnect (a dropped frame the transport recovers from within a couple of
 * backoff attempts) should not flash a banner the user has no time to read.
 */
export declare const SHOW_DELAY_MS = 5000;
/** The subset of a `SnapshotStore<boolean>` this plugin actually uses. */
export interface BannerStore {
    /** Whether the banner should currently be visible. */
    getSnapshot(): boolean;
    /** Subscribe to visibility changes; returns an unsubscribe function. */
    subscribe(listener: () => void): () => void;
    /** Feed one `connection/state` transition. */
    onState(state: ConnectionState): void;
    /** Cancel any pending show timer and force the banner hidden. */
    dispose(): void;
}
/**
 * Create a connection-banner visibility store.
 *
 * 'reconnecting' arms a {@link SHOW_DELAY_MS} timer (a redundant
 * 'reconnecting' while one is already pending, or while already visible, is
 * a no-op — the upstream `connection/state` emitter already deduplicates
 * same-state transitions, but this store does not trust that as its only
 * guard). 'connected' clears any pending timer and hides the banner
 * immediately, which also re-arms a fresh {@link SHOW_DELAY_MS} wait on the
 * next 'reconnecting'.
 * @returns the store.
 */
export declare function createBannerStore(): BannerStore;
//# sourceMappingURL=banner-store.d.ts.map