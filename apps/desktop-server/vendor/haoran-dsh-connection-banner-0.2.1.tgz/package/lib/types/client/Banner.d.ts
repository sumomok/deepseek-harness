/**
 * The banner strip itself.
 *
 * `@deepseek-ai/dsh-client-ui-primitives` used to export this exact component
 * (`ConnectionBanner`) — a plain fixed-position text strip, `null` while not
 * reconnecting. It was retired (`dsh-render` git history, commit
 * `19b4d7f26c` — "feat(web): add connection recovery indicator") with no
 * page-banner-shaped replacement: the commit's own replacement,
 * `ConnectionIndicator`, is a small inline pill wired into the Settings
 * panel's trigger row (`ui-settings-general/SettingsRoot.tsx`), not a
 * `position: fixed` strip a plugin with no Settings-panel seat can reuse.
 * This plugin's whole purpose is exactly that fixed strip — visible from
 * first paint, with no Settings panel to open first — so it now owns a 1:1
 * port of the retired component instead of a shim: there is no real function
 * anywhere in `dsh-render`'s source for a shim to merge onto, only a type
 * declaration would misrepresent what a future publish could ever carry.
 * `styles.ts` carries the matching ported stylesheet.
 *
 * @module @haoran/dsh-connection-banner/client/Banner
 */
/**
 * Render the reconnecting banner.
 * @param props.reconnecting - true while the connection is in backoff/retry.
 * @param props.label - banner text; the owner passes localized copy.
 * @returns the banner, or null when connected.
 */
export declare function ConnectionBanner({ reconnecting, label }: {
    reconnecting: boolean;
    label: string;
}): import("react").JSX.Element | null;
//# sourceMappingURL=Banner.d.ts.map