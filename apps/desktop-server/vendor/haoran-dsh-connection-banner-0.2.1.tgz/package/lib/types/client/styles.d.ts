/**
 * This plugin's whole stylesheet, injected once as a tagged `<style>`.
 *
 * `@deepseek-ai/dsh-client-ui-primitives` retired its `ConnectionBanner` atom
 * with no direct replacement (`ConnectionIndicator` replaced it for the
 * Settings panel's inline pill, not a page-wide banner — see `Banner.tsx`'s
 * own header) — same as every other out-of-repo plugin here, this package's
 * build hands `tsc` output straight to esbuild, which emits no stylesheet for
 * a `.module.css` next to source that no longer exists at that point, so this
 * plugin's one rule lives here as text rather than importing a CSS module.
 * The rule is a direct port of the retired `ConnectionBanner.module.css`
 * (`dsh-render` git history, commit `19b4d7f26c` — "feat(web): add connection
 * recovery indicator" — deleted it), re-authored under this plugin's own
 * `dshcb-` class prefix so it cannot collide with the host's identically
 * named classes. Every color is a `--dsw-*` harness theme token, exactly as
 * the built-ins use them, so the banner follows the host's light/dark scheme.
 *
 * @module @haoran/dsh-connection-banner/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-connection-banner";
/**
 * Put the stylesheet in the document, once.
 * @returns a disposer removing the tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map