/**
 * Browser half of @haoran/dsh-connection-banner.
 *
 * Listens for `@deepseek-ai/dsh-client-connection`'s `connection/state`
 * client event and feeds every transition into a {@link BannerStore}, whose
 * debounced visibility drives one `shell.overlay` list entry
 * ({@link createConnectionBannerEntry}).
 *
 * @module @haoran/dsh-connection-banner/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ConnectionBannerKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The banner text this plugin adds. */
        'connection-banner': ConnectionBannerKey;
    }
}
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * Register this plugin's dictionary, wire the `connection/state` listener
 * into a visibility store, and register the `shell.overlay` entry.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map