# @haoran/dsh-vision-switch

English | [中文](README.zh.md)

Desktop-internal, not published. When a message with an image is sent while the session's current model does not support images, the harness's own gate at `session.prompt` refuses the send outright — a dead end, with no path forward for the person typing. This plugin replaces that dead end with a switch: before the send leaves the browser, it moves the session onto a vision-capable model through the exact channel a manual model switch uses, then lets the send proceed. It never touches the host's gate — it exists so a send with images never trips it in the first place.

## What happens on send

1. **A default target is in the catalog and its provider has a configured credential** — switch to it and send. The default is `deepseek-flash` on `deepseek-official`, the image-capable model the dsh 0.2 factory catalog ships and the one upstream base's `agent-default-model` starts new sessions on. A deployment can pin a different `{provider, model}` with `Config.target`.
2. **The target is absent or its provider has no configured credential, but other vision-capable models whose provider has one exist** — a chooser card appears below the input box, in the shape of the harness's own question card and at the same width: 「当前模型不支持图片，选择一个支持图片的模型继续」 over one row per such model, by display name. A row only ever selects — by click, by Enter or Space on the row the focus is on, or by the navigation keys, which move focus and choice together (↓/→ next, ↑/← previous, both wrapping, Home and End to the ends). Unlike the question card this borrows its shape from, where answering and pressing Enter submits, **Enter here never sends**: 「切换并发送」 does, reached by Tab. That is deliberate — a key that confirms rather than selects confirms the row chosen earlier, which need not be the row you are looking at. 「取消」 and Escape abort the send with the draft intact. The card takes no focus from the composer and hands back whatever held it when it closes.
3. **Vision-capable models exist, but none of their providers has a configured credential** — the send goes out unchanged and the host refuses it with its own notice that the current model does not support images, leaving the draft in the input box; above it, 「缺少 API key：支持图片的模型都没有配置凭据，这张图片仍按当前模型发送」 names the reason no switch happened, and it goes as soon as the draft changes. A switch would move the session, and the default model it saves, onto a model whose every request then fails for want of a key.
4. **No vision-capable model exists anywhere** — 「当前没有可用的支持图片的模型，图片不会被处理」, draft intact, no switch attempted.

After a switch, a subtle note appears near the composer for a few seconds: 「已切换到支持图片的模型：\<name\>」. The switch is session-sticky — the same `sessions.selectModel` call a manual pick in the model popup makes — and nothing restores the previous model automatically. That call also saves the target as the default model, so new sessions start on it too (`packages/api/session-controller/src/commands.ts:171` at dsh-v0.2.0-rc.2).

**Zero interference on the common path.** No images in the draft, or the current model already supports them: nothing runs, nothing is queried, the send proceeds exactly as if this plugin were not installed.

## Why a host half, unlike some sibling plugins

The browser has no way to learn which models accept images. `session.models` and `llm.models` — the two RPCs the client can already reach — both drop `inputModalities` on the wire; only the host's own `ctx.llm.resolveModelInfo` carries it. So this plugin ships a small host half whose entire job is one read: a Typert Remote (`visionSwitch/catalog`) built the same way those two RPCs build their catalog, except it keeps the one field they omit. That host half also carries real `Config` (`enabled`, `target`), which the browser half reads over the same Remote — the plugin does not need `@sumomok/dsh-text-drop`'s "client plugins can't receive config, fall back to exported constants" workaround, because a host half with a Config makes a real, live, cordis.yml-changeable config reachable from the browser.

**Whether a provider has a credential is read the same way, without any key.** The catalog read also lists the providers among those models that have no configured credential (`missingCredential`). The configurable-provider directory (`llm.listConfigurableProviders`) says where each provider's settings live; the redacted settings value (`settings.describe({ redactSecrets: true })`) gives the reference its `apiKeyEnv` names, a field redaction keeps because it holds a name, not a secret; and `credentials.describe(ref).configured` says whether that reference resolves. Nothing here calls `credentials.resolve` or reads a record. A provider whose settings name no reference — the DeepSeek account route, which lists models only while signed in, or a pi-ai provider that finds its own key or login — counts as having one, the reading the upstream Models page makes too. The host half reaches `settings` and `credentials` through `ctx.get` and fails the read when either is not composed; the gate then stands aside and the send goes out unchanged.

## The submit interception

`conversation.composer.bar` is a single-kind slot, but it cannot be shadowed the way `@sumomok/dsh-text-drop` shadows `conversation.input.attachments`: the bar's `keyboard` prop is package-internal, computed by `ui-conversation`'s own `inject` from its private `InputHub`, and a third-party registrant has no way to reproduce it — `tsc` rejects a registration that declares this slot's props without that private face.

Instead, this plugin reaches the same object through a public door. `ctx.conversation.input` (`IConversation.input`, a `SessionInputResolver`) is a documented public service, and `SessionInputResolver.for(actx)` returns the identical per-session `SessionInput` singleton `InputBar`'s own `keyboard` prop wraps — both resolve through the same session-keyed cache inside `InputHub`, so it is one object, not a copy. `SessionInput.submit` is the harness's own "complexity sink": every send, from the Enter key to the send button to the public `inputActions.submit()` other plugins already use, ends up calling `submit` on that one object. This plugin replaces that one method on the object it legitimately obtained through the public service (`gateFor` in `client/gate-registry.ts`): before forwarding to the original `submit`, the replacement resolves the draft's attachment ids to their kinds and, if one of them is an image and the current model lacks vision, resolves the switch (or the chooser, or the block) first. Everything else about the composer — layout, the textarea, every other control, every other method on that object — is untouched.

The gate is installed on the facade instance rather than on the session id, and at most once per instance. `InputHub` drops a session's `SessionInputShell` together with its scope and builds a new one when the session is rematerialized, so `gateFor` compares the instance it patched against the one the resolver hands back now: a new instance is patched, and one already carrying this gate is never wrapped a second time (a facade can outlive the scope record for the moment between the controller pruning it and the fiber's own dispose, and a gate around a gate would run the whole switch twice for one send). What it reads there is typed off `InputState['attachmentIds']` in `@deepseek-ai/dsh-client-ui-conversation`, so a harness rename of that field fails `tsc` in this package instead of throwing inside a live composer, and every failure the replacement can meet — the state read, the catalog decision, the status sink — forwards the send to the original `submit` rather than throwing, because a `submit` that throws leaves the send button, Enter and Cmd+Enter all doing nothing. The stock `submit` is called at most once per attempt: it keeps working after it has handed the send on (dismissing the command popup, re-tracking the input trigger — both reachable by other plugins), so a throw arriving from it is reported to the browser console, never answered with a second send. The gate is installed when `GatePortal` renders at `conversation.input.dock`: the host renders that seat whenever the session has an input machine, in the same pass as the input bar, and keeps it mounted while a composer-chain entry takes the composer over, so the install always precedes that input bar's first submit. The session list offers no other install point: its snapshot names no current session and does not publish when the user switches sessions, and `sessions.scope(id)` only borrows a scope the controller already retains. A submit that does not come from the input bar is not gated until that session's input bar has rendered once.

**Only an image counts.** `InputState` publishes draft attachment ids and nothing more, so the ids alone cannot tell an attached image from an attached file. The kinds live on the draft registry behind `ctx.conversation` — `ConversationController.resolveDraftAttachments`, which answers `kind: 'image' | 'file'` per id — and the gate resolves the draft's own ids through it before deciding anything. `ctx.conversation` is *declared* as `IConversation`, which does not publish that method; the object registered under that name is the `ConversationController` instance, and `ui-conversation` narrows it back to the class wherever it needs the same registry, so this plugin does the same and holds the class to its own declared face with `GatedConversation`. A draft of text plus `.pcap`, `.csv` or any other non-image file is therefore indistinguishable here from a draft with nothing attached: it is sent untouched, because those reach the model as uploaded-file references that no model's image support gates. Counting ids without asking what they were is the 0.2.4 defect — two `.pcap` files and the question 「分析下这个文件」 put the chooser on screen. A resolution that throws, and ids whose descriptors have already been released, both fall open: the send goes out unchanged.

**Which model the gate compares against is the one the composer's picker displays.** The effective selection is the session's durable `modelSelection` projection when it carries one, and the deployment default (`agent-default-model`, a live user setting) when it does not — a conversation that has not sent a message yet has neither `next` nor `lastUsed`. `ui-model-selection` owns that resolution for both of its own entries, and `ctx.modelDirectories.directoryFor(sessionId).store` publishes it, so this plugin reads it there rather than deriving a second answer from the projection alone. Deriving it was the 0.2.2 defect: a first message with an image, on a machine whose stored default named a model the catalog no longer advertises, resolved nothing here while the picker and the host's own image gate both resolved that default — the gate stood aside and the send met the host's refusal instead of a switch. A selection the picker resolves is never a reason to stand aside, whatever it names; an id the catalog dropped is precisely what this plugin exists to switch away from. `'degraded'` is reserved for the three states where nothing can be compared: a session whose directory the picker's own resolver refuses (no live scope or binding), a vision catalog read that failed, and a session whose `modelSelection` frame has not arrived, where the picker displays nothing either. Every stand-aside prints one `@haoran/dsh-vision-switch: gate stood aside: <reason>` line to the browser console, so the field symptom is never just the host's own toast. The gate itself rides `ctx.inject(['conversation', 'modelDirectories'], …)`: bundle application is concurrent, so a one-shot read of either service would depend on which plugin happened to register first, and the injection scope also puts every patched facade back if it unloads.

## The first-message fallback

`conversation.composer.dock` — where the chooser, the blocked message, and the switched note render — only mounts once a session has a turn in its history, so a brand new session's very first message has no dock to draw into. Case 1 (auto-switch) is unaffected: the send itself proceeds, and the switched note renders normally once the dock exists a moment later. Cases 2 and 4 hold the send back before any turn exists, so without a fallback the click would do nothing visible.

`GatePortal.tsx`, registered at the `conversation.input.dock` seat the host renders for every session with an input machine, covers that gap: it renders the same chooser/blocked/switched markup through `react-dom`'s `createPortal` to `document.body` whenever the dock has not mounted for the current session. `fallback-surface.ts`'s `selectGateSurface` decides which of the two surfaces — the dock or the portal — is responsible for a given status, so they never both render it. Escape dismisses on either surface, from the chooser's own document listener rather than from the card, which has unfocusable regions a card-scoped handler would miss; the portal adds an outside click, and its blocked notice has no dismiss control and clears itself a few seconds after showing, or at once when the draft changes. The technique mirrors `@sumomok/dsh-text-drop`'s `DragHintStrip`: a `position: fixed` element left nested inside the composer's own DOM subtree can paint its background but not its own text over the host's `backdrop-filter` layers, which is why the portal targets `document.body` directly rather than a high z-index left in place.

## Configuration

```yaml
- id: vision-switch
  name: '@haoran/dsh-vision-switch'
  config:
    enabled: true
    # target:
    #   provider: deepseek-official
    #   model: some-other-vision-model
```

| Field | Default | Meaning |
| --- | --- | --- |
| `enabled` | `true` | `false` leaves the host's own gate as the only behavior — this plugin does nothing. |
| `target` | unset | Pins the case-1 auto-switch target. Unset resolves to `deepseek-official` / `deepseek-flash`. A pin absent from the catalog falls back to the chooser (case 2), with a warning logged host-side; so does a pin whose provider has no configured credential. |

An id-targeted patch in the profile's own `cordis.patch.yml` **replaces the whole `config` block** — restate `enabled` if you add a `target`.

## Settings page

A read-only section (screenshot's own settings section is the precedent) shows whether the plugin is enabled, the resolved target, whether it is currently in the catalog and whether its provider has a configured credential, and how many vision-capable models exist. It has no toggle: `enabled`/`target` are `Config` fields resolved once from `cordis.yml`, not a live `settings` document, and wiring a write path for them would need machinery nothing else in this plugin uses. Change them in `cordis.yml`.

## What this does not do

**Mid-turn `read_image` still needs a vision model already selected.** This plugin only gates the client's own send attempt; it does not touch the agent's tool-call path. If the agent calls `read_image` on a text-only model mid-turn, that call fails exactly as it does today.

**No auto-restore.** Once switched, the session stays on the vision-capable model until something else changes it — this plugin never switches back.

**A non-desktop host without the gate behaves identically, except in case 3.** This plugin decides from the draft's own image attachments and the catalog, never from whether a host enforces the refusal — it acts before any gate exists to trip. In case 3 it leaves the refusal to that gate.

**Two credential states read as present.** A pi-ai provider that names no `apiKeyEnv` and authenticates through an OAuth login (for example `openai-codex`) counts as having its credential while signed out, and a change to the harness process's own environment after it started is not observed. The upstream Models page reads both the same way.

## Changes

### 0.4.2

- Ties each patched `SessionInput` facade's teardown to its session scope (`actx.effect`) and tears down the prior facade on rematerialization, so closing or switching sessions unsubscribes the draft listener, restores `submit`, and releases all references to closed facades instead of retaining them until plugin unload. Installing onto an already unloading or disposed scope aborts before mutating the facade.

### 0.4.1

- The blocked notice names a missing credential. When vision-capable models exist but none of their providers has one, the send still goes out unchanged and the composer now shows 「缺少 API key：支持图片的模型都没有配置凭据，这张图片仍按当前模型发送」 instead of leaving the host's refusal unexplained; it clears as soon as the draft changes. An empty catalog's notice now also says the image will not be processed.

### 0.4.0

- Needs a host whose `@deepseek-ai/*` packages are `>=0.2.0-rc.2 <0.3.0-0`; on a `0.1.7` host (the rc.35 desktop base is `0.1.7-rc.2`) use 0.3.x.
- The gated `submit` forwards every argument the composer passes, including the `source` 0.2 adds (`'click'` or `'enter'`).
- A send with an image no longer switches onto a model whose provider has no configured credential, which left the session, and the default model the switch saves, failing every request with `MISSING_CREDENTIAL`. The chooser lists only models whose provider has one; when none does, the send goes out unchanged and the host's own notice applies. `visionSwitch/catalog` returns `missingCredential`, and the catalog cache is dropped on `credentials/reference-updated` and `credentials/record-updated`.

### 0.3.1

- Every client instance inserts its own stylesheet tag and removes only that tag when it is disposed. Two overlapping instances in one page no longer leave the survivor without styles.

### 0.3.0

- Needs a host whose `@deepseek-ai/*` packages are `>=0.1.7-rc.1 <0.2.0-0`; on an older host (the rc.33 desktop base is `0.1.5-rc.2`) use 0.2.x.
- The Typert codec on both halves carries the `create()` factory the `0.1.7-rc` loader and registry require.
- The gate is installed only from `GatePortal` at `conversation.input.dock`. The eager install over `sessions.list` is gone: the list snapshot no longer names a current session.
- The default switch target is `deepseek-official` / `deepseek-flash`. The `0.1.7-rc` host refuses a `selectModel` to a model outside its catalog, and `deepseek-v4-flash-vision-exp` is not in it.

### 0.2.7

- The chooser's rows answer the full radio-group key set: ↓/→ next, ↑/← previous, both wrapping, Home and End to the ends.
- The card's title is a heading element, matching the card it restates.
- Escape that another open layer has already claimed closes that layer and leaves the chooser up; the next Escape dismisses it.
- **Enter never sends** — documented here, in the Chinese README and in the source, along with why this departs from the question card it borrows its shape from.

### 0.2.6

- The chooser's rows follow the radiogroup convention: one row in the tab order at a time, and Enter or Space selects the row the focus is on instead of confirming an earlier choice. The send goes out only from 「切换并发送」.
- The card states its own width, so it fills the composer column instead of shrinking onto its longest model name, and carries the elevated surface's hairline stroke and scrollbar colours.
- The card takes no focus when it opens, and returns the focus to whatever held it when it closes.
- Escape dismisses from both the docked seat and the portal fallback.
- The package's tests compile: `tsconfig.test.json` puts `tests` in a program of its own, and the workspace `vitest.config.ts` gives the root run the same settings as the per-package run.

### 0.2.5

- The gate resolves each draft attachment's kind and applies only when at least one of them is an image; a draft carrying non-image files alone is sent untouched.
- The chooser is a card shaped like the harness's own question card — one selectable row per model, and a confirm/cancel button pair — instead of a strip of pills.

## Install

```sh
pnpm run build
cd packages/vision-switch && pnpm pack --pack-destination /tmp
dsh plugin --profile <name> add /tmp/haoran-dsh-vision-switch-0.4.2.tgz
```

See the workspace README for the tarball-based profile install and why a `link:` dependency must not be used.

## Development

```sh
pnpm run build
pnpm run typecheck
pnpm run test
```
