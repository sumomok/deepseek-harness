/**
 * This plugin's whole stylesheet, injected as one tagged `<style>` per client instance.
 *
 * `@deepseek-ai/dsh-client-ui-primitives` retired its `ConnectionBanner` atom
 * with no direct replacement (`ConnectionIndicator` replaced it for the
 * Settings panel's inline pill, not a page-wide banner — see `Banner.tsx`'s
 * own header) — same as every other out-of-repo plugin here, this package's
 * build hands `tsc` output straight to esbuild, which emits no stylesheet for
 * a `.module.css` next to source that no longer exists at that point, so this
 * plugin's one rule lives here as text rather than importing a CSS module.
 * The rule is a direct port of the retired `ConnectionBanner.module.css`
 * (`dsh-render` git history, commit `19b4d7f26c` — "feat(web): add connection
 * recovery indicator" — deleted it), re-authored under this plugin's own
 * `dshcb-` class prefix so it cannot collide with the host's identically
 * named classes. Every color is a `--dsw-*` harness theme token, exactly as
 * the built-ins use them, so the banner follows the host's light/dark scheme.
 *
 * @module @haoran/dsh-connection-banner/client/styles
 */
/** Attribute marking this plugin's style tags. */
export declare const STYLE_TAG = "data-dsh-connection-banner";
/**
 * The `data-plugin` value on this plugin's style tags: the package name, which
 * is the id the host's client module system gives this plugin. That system
 * stamps every `<style>` without `data-plugin` with the id of the module it is
 * materializing and removes the stamped tags when that module unloads; a tag
 * that already names this plugin is left to this plugin's own disposer.
 */
export declare const STYLE_OWNER = "@haoran/dsh-connection-banner";
/**
 * Insert this call's own copy of the stylesheet. Every call appends a separate
 * tag, so overlapping client instances of this plugin each hold one and
 * disposing one instance leaves the others styled.
 * @returns a disposer removing only the tag this call inserted.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map