/**
 * The owner's behavior tree, as one pure function: given what the browser
 * half already knows about a send attempt, decide what happens before the
 * message leaves the client. No I/O, no React, no cordis — every fact this
 * needs is resolved by the caller first, which is what keeps this testable
 * without a live session or a mounted Remote.
 *
 * @module @haoran/dsh-vision-switch/core/decision
 */
import type { ModelPin, VisionModelEntry } from '../types.ts';
/** Proceed with the send unchanged: nothing attached, or the current model already accepts images. */
export interface ProceedDecision {
    readonly kind: 'proceed';
}
/** Switch to the resolved target, then proceed (case 1: the target is in the catalog). */
export interface AutoSwitchDecision {
    readonly kind: 'auto-switch';
    readonly target: VisionModelEntry;
}
/** Offer every other vision-capable model and wait for a pick or a dismissal (case 2). */
export interface ChooseDecision {
    readonly kind: 'choose';
    readonly options: readonly VisionModelEntry[];
}
/** No vision-capable model exists anywhere in the catalog; refuse without switching (case 3). */
export interface BlockedDecision {
    readonly kind: 'blocked';
}
export type VisionSwitchDecision = ProceedDecision | AutoSwitchDecision | ChooseDecision | BlockedDecision;
/**
 * Decide what a send attempt does, given the facts already resolved.
 * @param input.hasAttachments - whether the draft carries at least one attachment of any kind.
 * @param input.currentIsVision - whether the session's current model already accepts images.
 * @param input.target - the resolved switch target: `Config.target` or the built-in default.
 * @param input.visionModels - every vision-capable model the runtime catalog advertises.
 * @returns the decision; the caller carries out whichever kind it names.
 */
export declare function decideVisionSwitch(input: {
    readonly hasAttachments: boolean;
    readonly currentIsVision: boolean;
    readonly target: ModelPin;
    readonly visionModels: readonly VisionModelEntry[];
}): VisionSwitchDecision;
//# sourceMappingURL=decision.d.ts.map