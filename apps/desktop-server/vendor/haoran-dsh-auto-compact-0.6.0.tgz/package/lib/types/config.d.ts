/**
 * Plugin configuration: the switch and the share one person sets, stored on
 * this plugin's own profile entry.
 *
 * Both fields are volatile. The harness's settings layer edits exactly the
 * volatile fields of an entry and writes the result into the profile patch;
 * the Loader commits the new value into the references `apply` received
 * without remounting the plugin, and the policy reads them on every call.
 *
 * Every field this Config has must stay volatile. The first launch on a
 * `0.1.7` or later base imports the `auto-compact` section of an older `settings.yaml`
 * into this entry, and one key in that section that is not a volatile field
 * fails the whole section. An ordinary field would also be written into the
 * profile patch with every save, freezing the bundle layer's value for that
 * person.
 *
 * @module @haoran/dsh-auto-compact/config
 */
import type { Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type AutoCompactSettings } from './section.ts';
/** Default for how many steps of a turn to wait before asking again after a failed compaction. */
export declare const DEFAULT_RETRY_AFTER_STEPS = 3;
/** Plugin configuration, as `apply` receives it. */
export interface Config {
    /** Whether automatic compaction runs at all. */
    enabled: Volatile<boolean>;
    /**
     * The share of the context window that triggers it, in percent: a whole
     * number from 20 to 95, of which a share below 40 compacts at 40.
     */
    thresholdPercent: Volatile<number>;
    /**
     * Steps of the same turn to wait before asking the engine again after a
     * failed compaction: a whole number from 1 to 50, three by default. The
     * harness's own between-steps path retries at every step; this plugin waits
     * this many steps and then makes one more attempt, so a summarizer that is
     * down costs one failed request per this many steps instead of one per step.
     */
    retryAfterSteps: Volatile<number>;
}
/** The schema the Loader resolves this entry's `config` with. */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    enabled: z<boolean, boolean, "volatile-defined">;
    thresholdPercent: z<number, number, "volatile-defined">;
    retryAfterSteps: z<number, number, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    enabled: z<boolean, boolean, "volatile-defined">;
    thresholdPercent: z<number, number, "volatile-defined">;
    retryAfterSteps: z<number, number, "volatile-defined">;
}>>, "plain">;
/**
 * Read the switch and the share the entry stores right now.
 * @param config - the Config `apply` received; the Loader updates its references in place.
 * @returns the stored values; `effectiveThresholdPercent` gives the share compaction runs at.
 */
export declare function readAutoCompact(config: Config): AutoCompactSettings;
/**
 * Read how many steps to wait before asking again after a failed compaction.
 * @param config - the Config `apply` received; the Loader updates its references in place.
 * @returns the stored number of steps.
 */
export declare function readRetryAfterSteps(config: Config): number;
//# sourceMappingURL=config.d.ts.map