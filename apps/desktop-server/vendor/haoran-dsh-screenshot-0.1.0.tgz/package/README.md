# @haoran/dsh-screenshot

A `screenshot` tool for DeepSeek Harness: it renders a page in a headless browser and returns the pixels as an image block, so the agent can look at its own visual work.

## Why an agent needs this

An agent writing HTML, CSS, or a component is working blind. It can read back every byte it wrote and still not know that two elements overlap, that a colour is unreadable on its background, or that the layout collapses at the width it was asked for. Source is not appearance, and no amount of re-reading the source turns one into the other.

`screenshot` closes that loop: render the page, look at it, fix what is wrong. The tool description says so in the words the model reads, because a tool the model does not think to call is a tool that does not exist.

The current model must accept image input. On a text-only route the tool refuses instead of returning an image, because a tool result enters durable session history and would then ride every later request on that session.

## Install

```sh
pnpm run build
cd packages/screenshot && pnpm pack --pack-destination ../../dist
dsh plugin --profile <name> add ../../dist/haoran-dsh-screenshot-0.1.0.tgz
```

The manifest declares `dsh.bundle.patch`, so the install appends the package to the profile's `dsh.profile.bundles` and its patch layer mounts the plugin. Nothing needs to be added to the profile's own `cordis.patch.yml` unless you are changing a default.

The tool registers only while an attachment store is mounted — every shipped app bundle mounts one — because the image block it returns must reference durably committed bytes.

## The tool

```
screenshot(url, width?, height?, fullPage?, delayMs?)
```

| Argument | Default | Meaning |
| --- | --- | --- |
| `url` | required | `http(s)://` URL, `file://` URL, or an absolute path to an `.html` file. |
| `width` | `defaultWidth` | Viewport width in px. |
| `height` | `defaultHeight` | Viewport height in px. |
| `fullPage` | `false` | Capture the whole scrollable page instead of the viewport. |
| `delayMs` | `defaultDelayMs` | Extra wait after load, for animations or scripts. |

An absolute path becomes a `file://` URL. A relative path is refused: the browser would resolve it against its own working directory rather than the agent's, so it would render a different file than the model meant, or none. Every scheme other than `http`, `https`, and `file` is refused by name.

An out-of-range `width`, `height`, or `delayMs` is an argument error, not a clamped value. The model asked to see a specific viewport; rendering a different one silently would let it draw conclusions about a page it never saw.

The result is a two-block reply: an envelope naming the URL, the image size, the byte count, and the engine that drew it, followed by the image itself.

```
<url>file:///tmp/page.html</url>
<type>image</type>
<content>
image/png image, 1024x768 px, 24631 bytes (renderer: chrome)
</content>
```

The engine is named because the two backends below do not produce identical pixels, and a model comparing two screenshots of the same page needs to know when it is also comparing two renderers.

## Two backends, in this order

**1. The desktop shell's render service**, whenever `DSH_DESKTOP_RENDER_ENDPOINT` and `DSH_DESKTOP_RENDER_TOKEN` are both set in the harness process environment. A shell that advertises one already has a browser engine running and knows what its own windows look like. Its protocol is specified below.

**2. A system browser in headless mode.** Chrome, Edge, Chromium, and Brave all accept the same `--headless=new --screenshot` command line, and one of them is installed on nearly every machine that runs the desktop app, so this plugin probes for one instead of adding a hundred-megabyte browser download to a screenshot tool. Nothing is downloaded, ever.

The probe order is `browserPath` from the config, then `CHROME_PATH` from the environment, then the platform's install locations:

| Platform | Probed, in order |
| --- | --- |
| macOS | `/Applications/Google Chrome.app`, `~/Applications/Google Chrome.app`, `/Applications/Microsoft Edge.app`, `/Applications/Chromium.app`, `/Applications/Brave Browser.app` (each `…/Contents/MacOS/<binary>`) |
| Windows | `%ProgramFiles%` and `%ProgramFiles(x86)%` and `%LocalAppData%` `\Google\Chrome\Application\chrome.exe`, then `%ProgramFiles(x86)%` and `%ProgramFiles%` `\Microsoft\Edge\Application\msedge.exe` |
| Linux and others | `google-chrome`, `google-chrome-stable`, `chromium`, `chromium-browser`, `microsoft-edge` on `PATH` |

The first executable found is remembered for the life of the plugin. `browserPath` and `CHROME_PATH` are the two explicit settings, and a path that is not an executable file is reported rather than probed past: a path someone wrote down and got wrong is a mistake to hear about, not a reason to render with a different browser. With nothing installed anywhere, the tool answers:

```
no headless-capable browser found; install Google Chrome/Edge or set screenshot.browserPath in cordis.patch.yml
```

**A shell failure is not retried against the system browser.** Once a render service is configured it is the renderer; falling back would swap engines silently, exactly when something is already wrong, and make a screenshot's provenance unknowable.

## Configuration

```yaml
- id: screenshot
  name: '@haoran/dsh-screenshot'
  config:
    defaultWidth: 1024
    defaultHeight: 768
    defaultDelayMs: 0
    maxDelayMs: 10000
    timeoutMs: 30000
    maxWidth: 4096
    maxHeight: 4096
```

| Field | Default | Meaning |
| --- | --- | --- |
| `defaultWidth` | `1024` | Viewport width for a call that names none. |
| `defaultHeight` | `768` | Viewport height for a call that names none. |
| `defaultDelayMs` | `0` | Post-load wait for a call that names none. |
| `maxDelayMs` | `10000` | Longest wait a call may ask for. |
| `timeoutMs` | `30000` | Wall-clock budget for one capture, whichever backend runs it. |
| `maxWidth` | `4096` | Largest viewport width a call may ask for. |
| `maxHeight` | `4096` | Largest viewport height a call may ask for. |
| `browserPath` | unset | Absolute path of the browser binary; unset means probe. |

The defaults reach the model: they are the `default` annotations on the tool's own parameter schema, so a deployment that renders at 1440 wide tells the model that, rather than leaving it to guess.

An id-targeted patch in the profile's `cordis.patch.yml` **replaces the whole `config` block**, so restate every key you want to keep. A default above its own maximum is refused at load, because the call it would break is the one that names no size at all.

## Desktop renderer protocol

This is the contract a desktop shell implements. The plugin is the client; nothing in this package serves it.

**Discovery.** The shell puts two variables in the environment of the harness process it launches. Both are required: an endpoint without a token is rejected on every call, and a token without an endpoint names nothing.

| Variable | Value |
| --- | --- |
| `DSH_DESKTOP_RENDER_ENDPOINT` | Origin of the service, for example `http://127.0.0.1:53412`. A trailing slash is ignored. |
| `DSH_DESKTOP_RENDER_TOKEN` | Bearer token the shell minted for this harness process. |

They are read on every call rather than at load, so a shell that starts its render service after the harness is up is used from the next screenshot onward.

**Request.**

```http
POST {endpoint}/render
authorization: Bearer {token}
content-type: application/json
accept: image/png

{"url":"https://example.com","width":1024,"height":768,"fullPage":false,"delayMs":0}
```

| Field | Type | Meaning |
| --- | --- | --- |
| `url` | string | An `http:`, `https:`, or `file:` URL. Already normalized: the plugin never sends a bare path or another scheme. |
| `width` | integer | Viewport width in px, at least 1. |
| `height` | integer | Viewport height in px, at least 1. |
| `fullPage` | boolean | Capture the whole scrollable page rather than the viewport. A shell that can measure the document should honour this exactly; that is the main thing it does better than the command-line backend. |
| `delayMs` | integer | Wait after load before capturing, in ms, at least 0. |

**Success.** `200` with `content-type: image/png` and the PNG bytes as the body. A `200` whose content type is not `image/png` is refused by the client, with the received type in the message — the alternative is bytes that fail magic-byte validation several steps later, under a message about attachments.

**Failure.** Any non-`200`. The body is read as text and the first 500 characters are quoted into the tool error the model sees, so write a sentence there rather than a code:

```
the desktop renderer refused to render https://example.com (HTTP 422): no window is available to render into
```

**Timeout.** The client aborts the request after `timeoutMs`. A shell that cannot render in that budget should answer with a failure rather than holding the connection.

**Authentication.** The plugin sends the token it was given and does nothing else about it; comparing it is the shell's job. Bind the service to loopback: it renders arbitrary URLs, including `file:` URLs, for anyone who can reach it with the token.

## Pairing with `@haoran/dsh-llm-permission-gateway`

`screenshot` is reviewed by the gate like any other side-effecting call, and it should be. **Do not add it to `readOnlyTools`.** It makes a network request to whatever URL the model chose, and with a `file:` URL it reads a local file through the browser rather than through `ctx.fs` — so neither the filesystem sandbox nor the workspace root applies to what it can render. Both are worth a review model's attention.

The review cost is one verdict per capture, next to a capture that already takes seconds.

## What this tool does not do

**`fullPage` is an approximation.** Headless `--screenshot` captures the window, not the document, so a full-page capture renders into a 4000px-tall window. A longer page is cut off, and a shorter one is padded with its background colour. `maxHeight` bounds what a call may ask for and deliberately does not bound this internal height. A desktop shell that can measure the document should implement `fullPage` properly; that is the main reason the first backend exists.

**No interaction.** There is no click, scroll, type, hover, or login. A page behind authentication renders logged out, and a widget that only appears after a click never appears. Every capture starts from a fresh throwaway profile, so there are no cookies, no `localStorage`, and no extensions. Driving a page is a different tool with a different risk profile; it is not this one.

**A capture is not free.** The browser writes the PNG and, on macOS, keeps running, so a capture ends when the file appears and stops growing — two 200ms polls — rather than when the process exits. The process group is terminated either way. Expect roughly two to three seconds per screenshot with the command-line backend.

**Chrome will not run as root without `--no-sandbox`,** which this plugin does not pass and will not: it would turn off the browser's own sandbox for every page the agent renders. In a container that runs as root, point `browserPath` at a wrapper script that adds the flag, and know what you turned off.

**The image is what the browser saw.** A page that fails to load renders as the browser's own error page, which the model then reads correctly as "this did not load". That is the intended behaviour, not a gap.

## Development

See the workspace README for the build, the tarball-based profile install, and why a `link:` dependency must not be used.

The suite runs without a browser. One opt-in spec starts a real one:

```sh
pnpm vitest run --dir packages/screenshot                    # no browser started
SCREENSHOT_E2E=1 pnpm vitest run --dir packages/screenshot   # renders a local page in the installed browser
```
