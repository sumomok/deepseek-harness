/**
 * The model-facing `screenshot` tool: renders a page, durably commits the PNG
 * through the attachment service, and returns an image block so the rendered
 * page enters model context from the next request onward.
 *
 * The tool exists only while an attachment store is mounted — `src/index.ts`
 * registers it inside `ctx.inject(['attachments'], …)` — because an image block
 * must reference a durably committed object by the time the tool result is
 * appended to the session log.
 * @module @haoran/dsh-screenshot/tool
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { RenderBackends } from './render.ts';
import type { ScreenshotLimits } from './request.ts';
/** Everything the tool needs from the plugin that registers it. */
export interface ScreenshotToolOptions {
    /** Argument bounds and defaults from the plugin config. */
    readonly limits: ScreenshotLimits;
    /** Wall-clock budget for one capture. */
    readonly timeoutMs: number;
    /** The render backends this deployment has. */
    readonly backends: RenderBackends;
}
/**
 * Register the `screenshot` tool into the given context.
 * @param ctx - the registration scope; execution uses its `attachments` service and optional `llm`.
 * @param options - argument bounds, capture budget, and render backends.
 * @returns the disposer returned by the tool registry.
 */
export declare function applyScreenshotTool(ctx: Context, options: ScreenshotToolOptions): () => void;
/**
 * Build the tool definition.
 * @param ctx - the context whose services execution reads.
 * @param options - argument bounds, capture budget, and render backends.
 * @returns the registry-ready definition.
 */
export declare function screenshotTool(ctx: Context, options: ScreenshotToolOptions): ToolDefinition;
/** The canonical outcome declared by the `screenshot` output schema. */
export interface ScreenshotValue {
    url: string;
    renderer: 'desktop' | 'chrome';
    image: {
        attachmentId: string;
        mediaType: 'image/png';
        bytes: number;
        width: number;
        height: number;
        name?: string;
    };
}
/**
 * Project one capture into the model-facing envelope and the image itself.
 *
 * The envelope names the engine as well as the size, because the two backends
 * do not draw identical pixels and a model comparing two screenshots of the
 * same page needs to know when it is also comparing two renderers.
 * @param value - the canonical capture outcome.
 * @returns the text envelope followed by the image block.
 */
export declare function screenshotContent(value: ScreenshotValue): ContentBlock[];
//# sourceMappingURL=tool.d.ts.map