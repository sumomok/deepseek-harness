/**
 * A tool that lets the agent look at a page instead of reasoning about its source.
 *
 * An agent writing HTML, CSS, or a component is working blind: it can read back
 * every byte it wrote and still not know that two elements overlap, that a
 * colour is unreadable on its background, or that a layout collapses at the
 * width it was asked for. `screenshot` renders the page and returns the pixels
 * as an image block, which is the only form of that information a model can
 * actually check.
 *
 * Two backends render, chosen in this order:
 *
 * - The desktop shell's own render service, when the shell advertises one
 *   through `DSH_DESKTOP_RENDER_ENDPOINT` and `DSH_DESKTOP_RENDER_TOKEN`. Its
 *   wire protocol is stated in the package README.
 * - A system browser — Chrome, Edge, Chromium, or Brave — in headless mode,
 *   probed at the platform's install locations. Nothing is downloaded.
 *
 * The tool registers only while an attachment store is mounted, because the
 * image block it returns must reference durably committed bytes.
 *
 * Configuration reference and known limits live in the package README.
 * @module @haoran/dsh-screenshot
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { BrowserLocator, browserCandidates, isExecutableFile, NO_BROWSER_FOUND } from './browser.ts';
export type { BrowserLocatorOptions } from './browser.ts';
export { chromeArguments, launchBrowser, renderWithChrome } from './chrome.ts';
export type { BrowserProcess, ChromeRenderOptions, LaunchBrowser } from './chrome.ts';
export { desktopRouteFromEnv, ENDPOINT_ENV, renderWithDesktop, TOKEN_ENV } from './desktop.ts';
export type { DesktopRoute } from './desktop.ts';
export { renderScreenshot } from './render.ts';
export type { RenderBackends, RenderedImage, RendererName } from './render.ts';
export { normalizeTarget, resolveRenderSpec } from './request.ts';
export type { RenderSpec, ScreenshotLimits, ScreenshotRequest } from './request.ts';
export { applyScreenshotTool, screenshotContent, screenshotTool } from './tool.ts';
export type { ScreenshotToolOptions, ScreenshotValue } from './tool.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "screenshot";
/** The registry the tool is contributed to. */
export declare const inject: string[];
/** Plugin configuration; every field is changeable from cordis.yml and validated at load. */
export interface Config {
    /** Viewport width used when a call names none. */
    defaultWidth?: number;
    /** Viewport height used when a call names none. */
    defaultHeight?: number;
    /** Post-load wait used when a call names none. */
    defaultDelayMs?: number;
    /**
     * Longest post-load wait a call may ask for. A call asking for more is an
     * argument error rather than a silently shortened wait, because a capture
     * taken before the page settled looks like a page that renders wrongly.
     */
    maxDelayMs?: number;
    /** Wall-clock budget for one capture, whichever backend runs it. */
    timeoutMs?: number;
    /** Largest viewport width a call may ask for. */
    maxWidth?: number;
    /** Largest viewport height a call may ask for. */
    maxHeight?: number;
    /**
     * Absolute path of the browser binary to render with. Leave it unset to probe
     * the platform's install locations; set it for a browser installed somewhere
     * else, or to pin which of several installed browsers renders. A path that is
     * not an executable file fails on the first capture rather than being skipped.
     */
    browserPath?: string;
}
export declare const Config: z<Config>;
/**
 * Register the tool.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map