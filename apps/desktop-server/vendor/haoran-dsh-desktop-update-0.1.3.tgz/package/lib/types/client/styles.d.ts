/**
 * The browser half's stylesheet, injected once as a tagged `<style>`.
 *
 * Every colour is a harness theme variable rather than a literal, so the page
 * and the button follow the light and dark schemes the shell already switches
 * between. The button is an ordinary flex item wherever it lands: no absolute
 * positioning, and no assumption that it owns either edge of its row, because
 * both seats it can take are shared with other plugins. It also paints no
 * surface of its own — no border, no background, not even on hover — because
 * the row it sits in owns the hover surface and a second painted box inside
 * that surface reads as a separate control. Hover changes only the label
 * colour; the focus ring is the one outline the button draws itself.
 *
 * @module @haoran/dsh-desktop-update/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-desktop-update";
/**
 * Put the stylesheet in the document, once.
 * @returns a disposer removing the tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map