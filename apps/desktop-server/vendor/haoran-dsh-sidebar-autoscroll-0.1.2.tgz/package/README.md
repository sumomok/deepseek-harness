# @haoran/dsh-sidebar-autoscroll

English | [中文](README.zh.md)

Scroll the sidebar session tree to the conversation on screen whenever the chat composer gets focus, centring that conversation's row in the list.

## What it does

A workspace can hold far more sessions than the sidebar shows at once, and the one you are talking to is often scrolled out of sight. When focus enters the chat composer — you click into it, or the client restores it as a session opens — this plugin scrolls the session list so that the row of the Session the main view is currently showing sits in the middle of the list: the row the browser already marks as current.

While the Session's Workspace group is collapsed the row is not rendered, so the plugin centres that Workspace's own header instead. The sidebar then still shows which group holds the conversation you are talking to. The plugin never expands the group: a collapsed Workspace is the reader's choice, and its header already names the right place.

One scroll per focus acquisition. The plugin never listens to scrolling and never re-scrolls while you read the tree: the call is `scrollIntoView({ block: 'center' })`, and the browser clamps it near either end of the list, where centring is impossible. It selects nothing, writes no Session or Workspace data, and keeps no state between calls.

## Where it hooks in

No fork patch and no harness change: the plugin reads three surfaces the client packages already render, plus two public services.

- **The selected Session** comes from the public `sessions` service: the row whose `retainedBy` reports the `mainView` reference source is the one the conversation shell is displaying, and ui-workspace derives its highlighted row from the same count. The plugin reads that count, not the DOM's selection state.
- **The owning Workspace** comes from the public `workspaces` service: the Workspace whose `sessionIds` account for the selected Session names the group header, and a Session no Workspace accounts for maps to the browser's ungrouped bucket.
- **The focus trigger** is the document's own `focusin` event, accepted when its target sits inside `[data-composer-input]` — the attribute the composer's editable host writes and the Web GUI's own test suites drive the composer through. Moving focus inside the composer does not re-trigger it; a pointer down in an already-focused composer runs the reveal again.
- **The target rows** are the elements keyed `data-row-key="session:<id>"` and `data-row-key="workspace:<id>"`, which ui-workspace writes for rendered Session rows and group headers under the AnimatedRows list contract.

There is no public service or event for "the composer got focus" — the input API exposes only the write side, `SessionInput.focus()` — so focus is observed at the document instead of by patching the editor. Nothing is monkey-patched, no module of another package is imported at runtime, and the browser half requests no shared shell module at all.

## When it does nothing

Silently, by design — no toast, no notice, no console output:

- no Session is retained by the main view yet (the new-session surface, a list still arriving, or the centre showing another panel instead of the conversation);
- neither the selected row nor its owning Workspace header is rendered — the collapsed rail layout, a search result list, a list still arriving, or a Workspace tree folded above the owning header;
- the Workspace list has not reported its first snapshot yet, so the owner cannot be named;
- the composer already had focus, so the focus move happened inside it.

## Limits

- The DOM attributes and service fields this plugin reads are written by client packages rather than by a versioned public contract. If one is renamed, this plugin stops scrolling and nothing else changes; the `data-row-key` list contract is documented in ui-primitives' README, and `data-composer-input` is what the Web GUI's end-to-end suites select the composer by.
- Centring is a request: the browser clamps the scroll at the top and bottom of the list, so the first and last rows cannot sit exactly in the middle.
- The reveal runs when focus moves. On a list that is still playing its first entry animation the row's position may settle slightly afterwards; the scroll uses the layout at that moment.
- Programmatic focus counts: on desktop the composer is focused automatically when a Session opens, and that also triggers one reveal. The tree then follows the conversation without a click.
- The desktop application and the Web build share the same client, so the plugin works in both; it does nothing where no composer is rendered.

## Install

Desktop-internal; not published to npm. Pack a tarball (`pnpm pack`) and install it into a profile the same way any local plugin is vendored.
