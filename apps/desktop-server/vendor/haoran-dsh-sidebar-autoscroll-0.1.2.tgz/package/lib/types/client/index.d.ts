/**
 * Browser half of @haoran/dsh-sidebar-autoscroll: when keyboard focus enters
 * the chat composer, scroll the sidebar session tree to the row of the Session
 * the main conversation view currently shows, centred in the list. While that
 * Session's Workspace group is collapsed the row is not rendered, so the
 * reveal centres the group header instead.
 *
 * The plugin registers no slot, no store, and no service. The trigger is the
 * document's own `focusin` event and the target is a row the workspace browser
 * already rendered, so nothing is added to the page and no state is written
 * (see `autoscroll.ts` for the client-owned surfaces and public services it
 * reads).
 *
 * @module @haoran/dsh-sidebar-autoscroll/client
 */
import type { Context } from '@deepseek-ai/cordis';
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * Install the composer-focus reveal for the lifetime of the plugin.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map