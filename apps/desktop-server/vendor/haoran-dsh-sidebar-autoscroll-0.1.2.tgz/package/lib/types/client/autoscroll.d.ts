/**
 * Focus-triggered reveal of the sidebar's current Session.
 *
 * The trigger and the target are both surfaces the client packages own and
 * this plugin only reads:
 *
 * - focus entering a chat composer, observed as the document's `focusin`
 *   event whose target sits inside `[data-composer-input]` — the attribute
 *   the composer's editable host writes and the GUI suites drive the composer
 *   through;
 * - the rendered Session row, keyed `data-row-key="session:<id>"` by
 *   ui-workspace under the AnimatedRows list contract.
 *
 * The selected Session itself comes from the public `sessions` service
 * (`selectedSessionId`), and its row is centred in the list so the
 * conversation on screen sits in the middle of the sidebar. While the
 * Session's Workspace group is collapsed the row is not rendered; the reveal
 * then centres that Workspace's own header
 * (`data-row-key="workspace:<id>"`), found through the public `workspaces`
 * service. It never expands the group: a collapsed Workspace is the reader's
 * choice, and the header still says which group holds the current
 * conversation.
 *
 * Nothing here selects a Session, writes Session data, or touches tree state:
 * one `scrollIntoView({ block: 'center' })` per focus acquisition.
 *
 * @module @haoran/dsh-sidebar-autoscroll/client/autoscroll
 */
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client';
import type { IWorkspaces } from '@deepseek-ai/dsh-api-workspace-controller/client';
/** The slice of the `sessions` service the reveal reads. */
export type SessionsSource = Pick<ISessions, 'list'>;
/** The slice of the `workspaces` service the reveal reads. */
export type WorkspacesSource = Pick<IWorkspaces, 'list'>;
/** What the reveal needs from the page and from the client services. */
export interface SidebarAutoscrollOptions {
    /** Session list whose `mainView` retention names the selected Session. */
    readonly sessions: SessionsSource;
    /** Workspace list that maps a Session id to its collapsed group header. */
    readonly workspaces: WorkspacesSource;
    /** Document that owns the composer and the sidebar session tree. */
    readonly document: Document;
    /** Scroll primitive; the browser's `scrollIntoView` unless a test replaces it. */
    readonly scrollIntoView?: (row: Element) => void;
}
/** An installed reveal. */
export interface SidebarAutoscroll {
    /** Remove the focus listener; safe to call more than once. */
    dispose(): void;
}
/**
 * Install the composer-focus reveal.
 * @param options - Session and Workspace services, owning document, and optional scroll primitive.
 * @returns the installed listener and its disposer.
 */
export declare function installSidebarAutoscroll(options: SidebarAutoscrollOptions): SidebarAutoscroll;
//# sourceMappingURL=autoscroll.d.ts.map