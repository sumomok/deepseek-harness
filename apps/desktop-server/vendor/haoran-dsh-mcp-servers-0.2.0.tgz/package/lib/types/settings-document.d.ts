/**
 * The stored server list this plugin owns: its durable-boundary parse, and the
 * one write the host itself makes into it.
 *
 * Two layers on the read, deliberately: the `servers` Config field accepts any
 * array of records, because a schema failure there refuses the whole value and
 * would strand every server over one bad row; the zod parse below then judges
 * each record on its own and drops only the ones it cannot read, warning about
 * each.
 *
 * @module @haoran/dsh-mcp-servers/settings-document
 */
import type { Context } from '@deepseek-ai/cordis';
import type { McpServersDocument } from './types.ts';
/**
 * A server id: the tool-name namespace, so it is limited to what the
 * harness's own `serverName` grammar accepts (`[A-Za-z0-9_-]{1,32}`),
 * narrowed further to lowercase so two records cannot differ by case alone.
 */
export declare const SERVER_ID_PATTERN: RegExp;
/**
 * Read the stored server list into records this plugin can act on.
 *
 * A record it cannot read is dropped with a warning rather than failing the
 * list: one hand-edited row must not take every other server offline.
 * @param servers - the live `servers` value, as the Config field holds it.
 * @param warn - receives one message per dropped record.
 * @returns the readable records, in stored order, ids unique.
 */
export declare function parseServers(servers: readonly unknown[], warn: (message: string) => void): McpServersDocument;
/**
 * Stores what one server is trusted at, in the same `servers` field the
 * settings page writes.
 *
 * The host writes this field for exactly one reason: the tool set a server
 * turns out to offer is only knowable after connecting, and a person who
 * stored the record already consented to it, so nothing is gained by asking
 * them to click again for a fingerprint they cannot compute. Every other
 * change to this field still comes from the settings page.
 */
export interface ConfirmationWriter {
    /**
     * Record one server's confirmation.
     * @param id - the record's id; an id the list no longer holds is ignored.
     * @param endpoint - the destination fingerprint now trusted.
     * @param tools - the tool-set fingerprint now trusted.
     * @returns settlement once the profile row holds it.
     * @throws {Error} whatever the settings service raises for a refused write,
     *   and its own conflict once the retries below are spent.
     */
    write(id: string, endpoint: string, tools: string): Promise<void>;
}
/**
 * The writer this plugin runs on.
 *
 * A whole-array write rather than one path-addressed edit per record: the page
 * writes the array wholesale for every change it makes, and one write per
 * confirmation keeps the two writers symmetric.
 *
 * Writing an array wholesale is a lost update waiting to happen, because the
 * page does the same thing from its own snapshot. The settings service has the
 * primitive for it: `update` takes the revision the caller read and refuses the
 * write with `SETTINGS_CONFLICT` when the entry moved since. So this reads the
 * entries and their revision together, writes with it, and on a conflict
 * rebuilds from a fresh reading rather than overwriting what landed in between.
 * @param ctx - the plugin context; without a settings service this writes nothing.
 * @param entryId - this plugin's own profile entry id; undefined (a programmatic
 *   mount, with no profile row to write) writes nothing.
 * @returns the writer.
 */
export declare function settingsConfirmationWriter(ctx: Context, entryId: string | undefined): ConfirmationWriter;
//# sourceMappingURL=settings-document.d.ts.map