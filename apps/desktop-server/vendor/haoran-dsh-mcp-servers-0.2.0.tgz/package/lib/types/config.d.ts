/**
 * Plugin configuration. Every field is changeable from `cordis.yml` and
 * validated at load.
 *
 * `servers` is the one volatile field: the settings page and the one-time
 * import of the removed `settings.yaml` write it into this entry's profile row,
 * and the running plugin takes the new list without a restart. Every other
 * field is ordinary, so changing it reloads the plugin.
 *
 * The entry id is not a field: the browser half addresses the same entry and
 * has no config channel of its own, so it is a shared constant instead
 * (`entry-id.ts`).
 *
 * @module @haoran/dsh-mcp-servers/config
 */
import type { Volatile } from '@deepseek-ai/cordis';
import s from '@deepseek-ai/schemastery';
/** Which channel asks whether a server may be connected. */
export type ConfirmChannel = 'settings' | 'approval';
/** Plugin configuration. */
export interface Config {
    /** Whether the plugin acts at all; false leaves the composition without MCP servers. */
    enabled?: boolean;
    /**
     * The stored server records, live. Each element stays `any` here because a
     * schema failure refuses the whole value and would strand every server over
     * one bad row; `parseServers` judges each record on its own.
     */
    servers: Volatile<unknown[]>;
    /**
     * Which channel asks whether a server may be connected.
     *
     * `settings` takes the stored confirmation in the settings document as the
     * answer. `approval` asks through the harness approval channel, which can
     * only reach someone while exactly one conversation is open and mid-turn,
     * and refuses otherwise.
     */
    confirm?: ConfirmChannel;
    /**
     * Per-tool-call timeout handed to every server connection, in milliseconds.
     * A finite number from 1 to {@link MAX_TIMEOUT_MS}.
     */
    toolCallTimeoutMs?: number;
    /**
     * How long one server's FIRST connection may take before this plugin gives
     * up on it, in milliseconds.
     *
     * The upstream client hands the MCP SDK its own default request timeout for
     * `initialize` and offers no way to shorten it, so a server that accepts a
     * connection and then says nothing would otherwise hold this plugin for a
     * minute. Servers connect in parallel, so this bounds one server rather than
     * the whole pass; a slow machine, or a server that indexes something before
     * it answers, is what this is raised for. A finite number from 1 to
     * {@link MAX_TIMEOUT_MS}.
     */
    connectTimeoutMs?: number;
}
/**
 * The longest delay `setTimeout` keeps. Past it a timer fires immediately, so
 * a larger budget would mean no budget at all.
 */
export declare const MAX_TIMEOUT_MS = 2147483647;
/** The schema; typed by inference, since the volatile field's input is a plain array. */
export declare const Config: s<Schemastery.ObjectS<NoInfer<{
    enabled: s<boolean, boolean, "defined">;
    servers: s<NoInfer<any[]>, NoInfer<any[]>, "volatile-defined">;
    confirm: s<"settings" | "approval", "settings" | "approval", "defined">;
    toolCallTimeoutMs: s<number, number, "defined">;
    connectTimeoutMs: s<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    enabled: s<boolean, boolean, "defined">;
    servers: s<NoInfer<any[]>, NoInfer<any[]>, "volatile-defined">;
    confirm: s<"settings" | "approval", "settings" | "approval", "defined">;
    toolCallTimeoutMs: s<number, number, "defined">;
    connectTimeoutMs: s<number, number, "defined">;
}>>, "plain">;
/** The two timeouts, after the one explicit resolve step. */
export interface ResolvedTimeouts {
    /** Per-tool-call timeout handed to every server connection. */
    toolCallTimeoutMs: number;
    /** Budget for one server's first connection. */
    connectTimeoutMs: number;
}
/**
 * The one explicit resolve step from raw config to the timeouts this plugin
 * runs on, so a value the schema cannot judge fails the plugin at load rather
 * than silently becoming a one-millisecond budget.
 * @param config - the plugin config.
 * @returns the resolved timeouts.
 * @throws {Error} when either timeout is not a usable number of milliseconds.
 */
export declare function resolveTimeouts(config: Pick<Config, 'toolCallTimeoutMs' | 'connectTimeoutMs'>): ResolvedTimeouts;
//# sourceMappingURL=config.d.ts.map