/**
 * Host-face Typert manifest, discovered by `@deepseek-ai/dsh-typert-loader`.
 *
 * The loader resolves `<package>/package.json` from the config tree, reads
 * `exports["./typert"]`, imports this module, and registers the `TYPERT`
 * export, so a third-party Remote needs no allowlist and no repository change.
 * The manifest is hand-written because the Typert generator runs over the
 * harness workspace, not over out-of-repo packages; it is structurally what
 * that generator emits: every strict codec exposes `create()`, which returns a
 * zod v4 schema on first use, and the loader refuses a codec without it.
 *
 * Keep this file free of imports other than `zod`: the loader imports it
 * directly by file path, outside this plugin's own module graph.
 *
 * @module @haoran/dsh-mcp-servers/typert
 */
import { z } from 'zod';
import type { McpServerView } from './types.ts';
/** The contribution `dsh-typert-loader` registers for this package. */
export declare const TYPERT: {
    package: string;
    face: string;
    schemas: never[];
    invocations: {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            create: () => z.ZodType<McpServerView[], unknown, z.core.$ZodTypeInternals<McpServerView[], unknown>>;
        };
    }[];
    model: {
        services: {
            description: string;
            summary: string;
            tags: never[];
            jsDoc: string;
            key: string;
            exportName: string;
            members: {
                kind: string;
                name: string;
                signature: string;
                summary: string;
                jsDoc: string;
            }[];
            types: never[];
        }[];
        events: never[];
        objects: never[];
    };
};
export default TYPERT;
//# sourceMappingURL=typert.d.ts.map