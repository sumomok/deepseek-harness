/**
 * The `settings.section` page this plugin contributes: the low/critical-balance
 * thresholds and whether the footer chip masks its figure, read and written
 * through this entry's config form (`ctx.configForms.get('balance')`,
 * `@deepseek-ai/dsh-client-ui-settings`), and the active price table, shown
 * read-only. The three editable fields are volatile Config fields, so a save
 * lands in the profile row and the running host takes it without a reload.
 *
 * The page follows the shipped General page's row layout — a title and a
 * one-line description on the left, the control on the right, a hairline
 * between rows — and draws its controls from
 * `@deepseek-ai/dsh-client-ui-primitives` (`Input`, `Switch`,
 * `SegmentedControl`, `Tag`). Each save reports its own status beside the
 * title of the row that started it.
 *
 * Prices are not edited here. The table comes from the plugin maintainer's
 * feed (or its cached copy, or the table shipped with the plugin), unless the
 * plugin configuration sets `pricesOverride`; the page reads it with
 * `accountBalance/prices` and says which of those it is and how fresh. It
 * shows one line per model with its three main rates and, for a model with
 * time-of-day prices, a sentence describing them, in a box that scrolls on its
 * own with the header row kept in view.
 *
 * A saved masking switch is pushed onto the chip by this page, through the
 * injected `refresh`: the chip renders the flag the last spend read carried,
 * not this form, so nothing else would move it before the next
 * poll tick. The thresholds reach the chip on that tick instead — they change
 * a tint, not what is on a screen someone is about to share.
 *
 * @module @sumomok/dsh-balance/client/PriceTableSection
 */
import { type ReactNode } from 'react';
import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { PriceEntry } from '../prices.ts';
import type { BalanceSettings } from '../settings-shape.ts';
import type { PricesView, PriceStatus } from '../types.ts';
import type { BalanceKey } from './locales.ts';
/** Props the section reads from its composed slot props. */
export interface PriceTableSectionProps {
    /** Close the settings panel; unused here — this page has no flow that leaves settings. */
    close: () => void;
    /** The config form over this plugin's own profile entry. */
    form: ConfigForm<BalanceSettings>;
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'balance'>;
    /**
     * Read the followed provider's balance and spend again. The masking switch
     * calls it with `force` after its own save so the chip stops showing the
     * amount without waiting for a poll tick: the flag rides on the spend read,
     * which the host answers straight off the ledger with no cache window, and
     * `force` is what keeps this read from being joined to an ordinary refresh
     * already in flight (`client/store.ts`). Its cost is the balance read
     * alongside it, which then bypasses the host's refresh window — one extra
     * provider call per flip of the switch.
     */
    refresh: (force: boolean) => void;
    /** Read the active price table and where it came from (`accountBalance/prices`). */
    readPrices: () => Promise<PricesView>;
}
/** One save action's inline status, shown beside its own control. */
type SaveState = 'idle' | 'saving' | 'saved' | 'error';
/** @param state - one save action's status. @returns its copy key, or `undefined` while idle. */
export declare function saveStatusKey(state: SaveState): BalanceKey | undefined;
/**
 * @param text - a form field's raw text.
 * @param fallback - value when the text is empty or not a number.
 * @returns the parsed number.
 */
export declare function numberOr(text: string, fallback: number): number;
/**
 * @param value - a rate, token count, or multiplier to show.
 * @returns it as plain decimal text, never exponent notation (`1e-7` reads
 * `0.0000001`).
 */
export declare function decimalText(value: number): string;
/**
 * One read-only sentence per time-of-day tier of a price entry, built from
 * its windows, days, multiplier or rates, and the entry's timezone. Windows
 * on the same days are listed together after their days.
 * @param entry - a price-table entry.
 * @param t - the page's translator.
 * @returns one sentence per schedule, in the entry's order; none when it has no tiers.
 */
export declare function tierSentences(entry: PriceEntry, t: TranslateNS<'balance'>): string[];
/**
 * @param atMs - epoch milliseconds of the event.
 * @param nowMs - epoch milliseconds now.
 * @param t - the page's translator.
 * @returns how long ago it was, in whole minutes, hours, or days.
 */
export declare function agoText(atMs: number, nowMs: number, t: TranslateNS<'balance'>): string;
/**
 * The line saying where the active price table came from and how fresh it is.
 * @param status - the table's status.
 * @param nowMs - epoch milliseconds now.
 * @param t - the page's translator.
 * @returns the line.
 */
export declare function freshnessText(status: PriceStatus, nowMs: number, t: TranslateNS<'balance'>): string;
/**
 * The registered `settings.section` component.
 * @param props - composed slot props.
 * @returns the page, or a loading/unavailable placeholder before the first accepted section.
 */
export declare function PriceTableSection({ form, t, refresh, readPrices }: PriceTableSectionProps): ReactNode;
export {};
//# sourceMappingURL=PriceTableSection.d.ts.map