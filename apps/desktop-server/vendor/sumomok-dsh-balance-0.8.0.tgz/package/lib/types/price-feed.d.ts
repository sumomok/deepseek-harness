/**
 * The maintainer's price feed: one JSON price table at a configured URL,
 * fetched at start and then every `priceFeedRefreshMs`, checked with the same
 * schema and host rules as a configured table, and cached in this plugin's own
 * directory so the next start has it before its first fetch returns.
 *
 * The request is a plain `GET` with no credentials, no identifiers, and no
 * header beyond what `fetch` sends by default: the feed learns only that some
 * installation asked. A redirect is not followed. A response that is not a
 * 200, is longer than `priceFeedMaxBytes`, takes longer than `timeoutMs`, is
 * not JSON, or fails the checks (which here also require every currency to
 * list at least one model) is dropped and logged, and the table in use is
 * kept. A cache file that fails the same checks is ignored the same way.
 *
 * A table dated before the plugin's shipped prices (`floorAsOf`) is never
 * adopted, from the cache or from a fetch, so an upgrade that ships newer
 * prices uses them until the feed catches up; nor is a fetched table dated
 * before the one already held.
 *
 * @module @sumomok/dsh-balance/price-feed
 */
import { type PriceTable } from './prices.ts';
import type { PricesView } from './types.ts';
/** The cache file's name inside the plugin's directory. */
export declare const PRICE_FEED_CACHE_FILE = "price-feed.json";
/**
 * @param root - the plugin's directory.
 * @returns the feed cache file's path.
 */
export declare function priceFeedCachePath(root: string): string;
/**
 * Check a price table read from outside the process, with the schema and the
 * host rules a configured table gets, and one rule of its own: every currency
 * lists at least one model, since an empty list would leave that currency's
 * spend unpriced.
 * @param value - parsed JSON.
 * @returns the resolved table.
 * @throws {Error} naming why the value is not a usable price table.
 */
export declare function checkPriceTable(value: unknown): PriceTable;
/** What the feed is built with. */
export interface PriceFeedOptions {
    /** The feed URL. */
    url: string;
    /** Largest response body read, in bytes. */
    maxBytes: number;
    /** Wall-clock budget for one fetch. */
    timeoutMs: number;
    /** The cache file. */
    cacheFile: string;
    /** The shipped table's `asOf`; a table dated before it is never adopted. */
    floorAsOf: string;
    /** The `fetch` implementation; the global one in the plugin. */
    fetch: typeof fetch;
    /** Epoch milliseconds. */
    now: () => number;
    /** Receives each dropped response or cache file, with why. */
    log: (message: string) => void;
}
/** The table the feed holds, and where it came from. */
export interface FeedTable {
    table: PriceTable;
    /** `feed` for a table fetched by this process, `cache` for one read from the cache file. */
    origin: 'feed' | 'cache';
}
/**
 * @param error - what a fetch or a check threw.
 * @returns its message, followed by its `cause`'s when it has one: `fetch`
 * rejects a refused redirect, a DNS failure, or a TLS failure alike as
 * "fetch failed" and names the reason only in `cause`.
 */
export declare function failureText(error: unknown): string;
/**
 * The feed's table and the times of its last successful and failed checks.
 * Every failure is contained: {@link PriceFeed.refresh} resolves `false`
 * rather than rejecting.
 */
export declare class PriceFeed {
    private readonly options;
    private held;
    private checked;
    private failed;
    private inFlight;
    private disposed;
    /** The `asOf` last refused as stale, so one refused table is logged once rather than on every fetch. */
    private refusedAsOf;
    /** @param options - see {@link PriceFeedOptions}. */
    constructor(options: PriceFeedOptions);
    /** The table the feed or its cache supplied; `undefined` before either did. */
    get current(): FeedTable | undefined;
    /** Epoch milliseconds of the fetch that produced the held table; `null` before one did. */
    get checkedAt(): number | null;
    /** Epoch milliseconds of the last failed fetch, when it came after the last good one; otherwise `null`. */
    get failedAt(): number | null;
    /**
     * Stop adopting: a fetch still in flight neither changes the held table nor
     * writes the cache once this has run.
     */
    dispose(): void;
    /**
     * Why `table` is not adopted over what is held, or `undefined` when it is.
     * @param table - a table that passed the checks.
     * @returns the reason, for the log.
     */
    private staleness;
    /**
     * Adopt the cache file's table, when there is a usable one.
     * @returns whether a table was adopted.
     */
    loadCache(): Promise<boolean>;
    /**
     * Fetch the feed once; a call while one is in flight joins it.
     * @returns whether a usable table arrived and is now held.
     */
    refresh(): Promise<boolean>;
    /** One fetch, check, adopt, and cache write. */
    private fetchOnce;
    /**
     * @returns the response body as text.
     * @throws {Dropped} for a non-200 response or a body over the byte cap;
     * `fetch`'s own error for a network failure, a redirect, or the timeout.
     */
    private download;
    /**
     * Replace the cache file whole: a temporary file renamed over it, so a crash
     * leaves either the old file or the new one. A failed write is logged; the
     * table stays held for this process.
     * @param cache - what to write.
     */
    private writeCache;
}
/**
 * Fetch the feed now and then every `everyMs`, handing each usable table to
 * `onTable`. Nothing is handed on once the returned stop has run, including a
 * fetch already in flight.
 * @param feed - the feed.
 * @param everyMs - the refresh interval.
 * @param onTable - called after each fetch that produced a usable table.
 * @returns the stop, which clears the interval and disposes the feed.
 */
export declare function startPriceFeed(feed: Pick<PriceFeed, 'refresh' | 'dispose'>, everyMs: number, onTable: () => void): () => void;
/**
 * Pick the active price table: the configured override, else the feed's (or
 * its cache's) table, else the shipped defaults.
 * @param override - the resolved `pricesOverride`, when configured.
 * @param feed - the feed, when one is configured.
 * @param defaults - the table shipped with the plugin.
 * @returns the table and where it came from.
 */
export declare function activePrices(override: PriceTable | undefined, feed: Pick<PriceFeed, 'current' | 'checkedAt' | 'failedAt'> | undefined, defaults: PriceTable): PricesView;
//# sourceMappingURL=price-feed.d.ts.map