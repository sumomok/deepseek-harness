/**
 * The settings page's form value: this entry's four volatile fields as plain
 * JSON, which is what the host projects to the browser. The host `Config`
 * types the same fields as `Volatile`, which the page never sees.
 *
 * The only import is type-only and erased at build, so the browser half can
 * load this module by value.
 *
 * @module @sumomok/dsh-balance/settings-shape
 */
import type { PriceTable } from './prices.ts';
/** The values the settings form carries; the page writes the last three. */
export interface BalanceSettings {
    /**
     * The volatile `prices` field, which the plugin no longer reads (see
     * `config.ts`); the page shows the active table from `accountBalance/prices`.
     */
    prices: PriceTable;
    /** Balance below which the chip is tinted as a warning. */
    lowBalance: number;
    /** Balance below which the chip is tinted as critical. */
    criticalBalance: number;
    /** Whether the footer chip shows dots in place of its figure. */
    maskBalance: boolean;
}
/** The form's keys: exactly the volatile fields of the host `Config`. */
export declare const BALANCE_SETTINGS_KEYS: readonly ["prices", "lowBalance", "criticalBalance", "maskBalance"];
//# sourceMappingURL=settings-shape.d.ts.map