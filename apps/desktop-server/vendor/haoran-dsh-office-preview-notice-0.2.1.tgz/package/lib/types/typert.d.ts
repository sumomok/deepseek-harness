/**
 * Host-face Typert manifest, discovered by `@deepseek-ai/dsh-typert-loader`
 * through `exports["./typert"]`. Hand-written because the Typert generator
 * runs over the harness workspace, not over out-of-repo packages; every
 * codec's `create()` returns a zod v4 schema.
 *
 * Keep this file free of imports other than `zod`: the loader imports it
 * directly by file path, outside the plugin's own module graph.
 *
 * @module @haoran/dsh-office-preview-notice/typert
 */
import { z } from 'zod';
import type { CommandOutcome, EngineView } from './types.ts';
/** The contribution `dsh-typert-loader` registers for this package. */
export declare const TYPERT: {
    package: string;
    face: string;
    schemas: never[];
    invocations: {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            create: () => z.ZodType<EngineView, unknown, z.core.$ZodTypeInternals<EngineView, unknown>>;
        } | {
            mode: string;
            typeSymbol: string;
            create: () => z.ZodType<CommandOutcome, unknown, z.core.$ZodTypeInternals<CommandOutcome, unknown>>;
        };
    }[];
    model: {
        services: {
            description: string;
            summary: string;
            tags: never[];
            jsDoc: string;
            key: string;
            exportName: string;
            members: {
                kind: string;
                name: string;
                signature: string;
                summary: string;
                jsDoc: string;
            }[];
            types: never[];
        }[];
        events: never[];
        objects: never[];
    };
};
export default TYPERT;
//# sourceMappingURL=typert.d.ts.map