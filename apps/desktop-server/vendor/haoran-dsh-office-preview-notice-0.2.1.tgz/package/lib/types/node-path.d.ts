/**
 * Keep the engine's `NODE_PATH` entry out of the processes the harness starts.
 *
 * The desktop shell names the engine's `node_modules` in the harness process's
 * `NODE_PATH`, because the converter resolves its engine from its own
 * directory and takes no path from configuration. Node reads `NODE_PATH` once,
 * at startup, so removing the entry from `process.env` afterwards leaves this
 * process resolving through it while every child spawned from `process.env`
 * — a shell command, a package install — no longer inherits it. The entry is
 * named in {@link ENGINE_MODULES_ENV}; any other `NODE_PATH` entry is kept.
 *
 * @module @haoran/dsh-office-preview-notice/node-path
 */
/** Environment variable the shell names the engine's `NODE_PATH` entry in. */
export declare const ENGINE_MODULES_ENV = "DSH_DESKTOP_OFFICE_ENGINE_MODULES";
/**
 * Remove the engine entry from an environment's `NODE_PATH`, in place.
 * Calling it again changes nothing.
 * @param env - the environment to edit; `process.env` in production.
 * @returns true when an entry was removed.
 */
export declare function stripEngineNodePath(env: NodeJS.ProcessEnv): boolean;
//# sourceMappingURL=node-path.d.ts.map