/**
 * The `officeEngine` Service Definition and its Typert Remote face.
 *
 * The browser reaches this service only through the harness's own `/api`
 * Typert gateway. The shell's endpoint and token are read on the host side and
 * never leave it. A caller can ask the application to confirm a download, stop
 * one, or report where it stands; it cannot name a package, a version, or a
 * directory, and nothing downloads until the person answers the shell's own
 * native confirmation.
 *
 * @module @haoran/dsh-office-preview-notice/service
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { CommandOutcome, EngineView } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The desktop Office preview engine (provided by `@haoran/dsh-office-preview-notice`). */
        officeEngine: OfficeEngineService;
    }
}
/** The desktop Office preview engine: its state, and the download of it. */
export declare abstract class OfficeEngineService extends TypertRemoteService {
    /**
     * @param ctx - owning plugin context.
     */
    constructor(ctx: Context);
    /**
     * Where the engine stands, whether this deployment downloads one at all,
     * and how often to ask again.
     * @returns the current view; `available: false` where nothing lends an engine service.
     */
    abstract state(): Promise<EngineView>;
    /**
     * Ask the application to confirm with the person and download the engine.
     * @returns whether the confirmation went up.
     */
    abstract download(): Promise<CommandOutcome>;
    /**
     * Ask the application to stop the running download.
     * @returns whether a download was stopped.
     */
    abstract cancel(): Promise<CommandOutcome>;
    /**
     * Remote face of {@link OfficeEngineService.state}; the decorator cannot
     * mark the abstract member, so this adapter carries the same contract.
     * @returns the current view.
     */
    remoteExportState(): Promise<EngineView>;
    /**
     * Remote face of {@link OfficeEngineService.download}.
     * @returns whether the confirmation went up.
     */
    remoteExportDownload(): Promise<CommandOutcome>;
    /**
     * Remote face of {@link OfficeEngineService.cancel}.
     * @returns whether a download was stopped.
     */
    remoteExportCancel(): Promise<CommandOutcome>;
}
export default OfficeEngineService;
//# sourceMappingURL=service.d.ts.map