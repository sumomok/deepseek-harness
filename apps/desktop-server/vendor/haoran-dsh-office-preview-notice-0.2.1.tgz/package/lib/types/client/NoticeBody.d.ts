/**
 * Document body for a Word or PowerPoint file while no preview engine is
 * installed.
 *
 * It is laid out like the document preview's own empty states: the file's
 * type icon, one headline line, and the actions under it, centered in the
 * tab. The two actions sit side by side at equal width and stack when the
 * tab is too narrow for both:
 *
 * - **Open in Office/WPS** (primary) hands the file to the computer's default
 *   application ({@link OpenFile}). It is offered only where the Host opens
 *   files on the person's own desktop, stays usable while the engine
 *   downloads, and says so in plain words when the file did not open. It opens only a
 *   path that ends in a Word or PowerPoint suffix.
 * - **Preview here** (secondary) starts the engine download, with the
 *   download size under it. The shell's confirmation step, the download's
 *   progress with a way to stop it, and a download that did not finish all
 *   show in the same place.
 *
 * With neither action — a deployment that neither opens files nor downloads
 * an engine — the body is the headline and one line telling the person to
 * open the file in Office or WPS. Once the engine is installed the plugin
 * withdraws this body and the document preview's own Office renderer takes
 * the tab.
 *
 * Every color and radius comes from the design platform's `--dsw-*`
 * variables, so both themes apply without a branch here.
 *
 * The document preview hands a `renderer`-mode body a load request per
 * content revision. This body reads no bytes, so it ends each revision with
 * `failed()`, which only clears the pending load; `loaded()` would record a
 * file version and arm the preview's "file changed" bar for a body that never
 * shows the file.
 *
 * @module @haoran/dsh-office-preview-notice/client/NoticeBody
 */
import { type CSSProperties, type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { DocumentContent } from '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/client';
import { type NS } from './locales.ts';
import { type OpenFile } from './open.ts';
import type { EngineStore } from './store.ts';
/**
 * The standard `useResource` seat, narrowed to the one field this body reads
 * from a `file` address: the file's Host path. The slot runtime puts the seat
 * on every slot component's props; its type is declared by
 * `@deepseek-ai/dsh-client-resources` and the `file` protocol's owner, which
 * this package does not compile against, so the composed props this package
 * sees do not name it.
 */
export interface ResourceSeat {
    /**
     * @param address - a `dsh-resource://file/…` address.
     * @returns the address's snapshot; `value` is absent until the metadata arrives.
     */
    readonly useResource: (address: string) => {
        readonly value?: {
            readonly absolutePath?: string;
        } | undefined;
    };
}
/** Props this body reads: the preview's content request and file address, its dictionary, and the two optional actions. */
export type NoticeBodyProps = {
    readonly content: DocumentContent;
    /** The file's resource address, as the document preview passes it. */
    readonly resourceAddress: string;
    /** The engine store; absent where no download can be offered. */
    readonly engine?: EngineStore;
    /** The opener; absent where files do not open on the person's desktop. */
    readonly open?: OpenFile;
} & PropsLocale<typeof NS>;
/** Width below which one action no longer fits beside the other; the pair then stacks. */
export declare const ACTION_MIN_WIDTH = 160;
/**
 * The action row. It wraps, so two columns that cannot both reach
 * {@link ACTION_MIN_WIDTH} stack, each then taking the full width.
 * @param count - how many actions the row holds.
 * @returns the row's style.
 */
export declare function actionsStyle(count: number): CSSProperties;
/**
 * The percentage a progress report stands at.
 * @param transferred - bytes so far.
 * @param total - total bytes, when known.
 * @returns 0–100, or undefined without a total.
 */
export declare function percentOf(transferred: number | undefined, total: number | undefined): number | undefined;
/**
 * Settle the current load request and show the notice, its actions, or the download.
 * @param props - content request, file address, localized copy, and the actions this deployment offers.
 * @returns the body.
 */
export declare function NoticeBody(props: NoticeBodyProps): ReactNode;
//# sourceMappingURL=NoticeBody.d.ts.map