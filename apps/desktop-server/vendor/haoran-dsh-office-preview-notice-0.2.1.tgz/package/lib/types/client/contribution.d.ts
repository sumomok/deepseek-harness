/**
 * The browser half's Typert contribution: the consumer-side mirror of
 * `../typert.ts`. Each descriptor matches the host manifest's id, namespace,
 * and method, because the gateway matches by those names. The codecs are
 * hand-written narrowings, so no schema library rides into the page.
 *
 * @module @haoran/dsh-office-preview-notice/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import { type CommandOutcome, type EngineView } from '../types.ts';
/**
 * Narrow one state read.
 * @param value - the decoded result.
 * @returns the view.
 * @throws when a field has the wrong type.
 */
export declare function parseEngineView(value: unknown): EngineView;
/**
 * Narrow one command outcome.
 * @param value - the decoded result.
 * @returns the outcome.
 * @throws when a field has the wrong type.
 */
export declare function parseCommandOutcome(value: unknown): CommandOutcome;
/** The contribution `ctx.remote.$mount()` installs, mirroring `../typert.ts`. */
export declare const CONTRIBUTION: TypertRemoteContribution;
//# sourceMappingURL=contribution.d.ts.map