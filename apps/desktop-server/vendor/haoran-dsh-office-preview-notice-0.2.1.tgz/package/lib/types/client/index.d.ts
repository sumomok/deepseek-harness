import type { Context } from '@deepseek-ai/cordis';
import { type OfficePreviewNoticeKey } from './locales.ts';
import { type EngineStore } from './store.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The notice and download copy and the viewer-menu label. */
        'office-preview-notice': OfficePreviewNoticeKey;
    }
}
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * The timers a poller drives, injected so a test needs no clock.
 */
export interface PollTimers {
    /**
     * Schedule one callback.
     * @param callback - what to run.
     * @param ms - how long to wait.
     * @returns a handle {@link PollTimers.clear} accepts.
     */
    set: (callback: () => void, ms: number) => unknown;
    /**
     * Cancel a scheduled callback.
     * @param handle - what {@link PollTimers.set} returned.
     */
    clear: (handle: unknown) => void;
}
/**
 * Re-read the store while its phase is moving, one read in flight at a time.
 * @param store - the store to refresh.
 * @param timers - the timers to drive.
 * @returns wake, to call after anything that may have started movement, and stop.
 */
export declare function followEngine(store: EngineStore, timers: PollTimers): {
    wake: () => void;
    stop: () => void;
};
/**
 * Register the dictionary, and the preview implementation and its body unless
 * the engine is installed.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): Promise<void>;
//# sourceMappingURL=index.d.ts.map