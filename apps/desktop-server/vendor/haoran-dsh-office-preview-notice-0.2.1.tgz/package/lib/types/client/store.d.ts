/**
 * The browser half's one piece of state: the last engine view the host
 * answered, the command in flight, and the last command refusal.
 *
 * @module @haoran/dsh-office-preview-notice/client/store
 */
import type { CommandOutcome, EnginePhase, EngineView, RefusalCode } from '../types.ts';
/** The calls this store makes, bound to the mounted Remote. */
export interface EngineApi {
    /** Read where the engine stands. */
    state: () => Promise<EngineView>;
    /** Ask the application to confirm and download. */
    download: () => Promise<CommandOutcome>;
    /** Ask the application to stop the download. */
    cancel: () => Promise<CommandOutcome>;
}
/** What the body renders from. */
export interface EngineStoreState {
    /** The last view the host answered. */
    view: EngineView;
    /** The command in flight. */
    busy: 'download' | 'cancel' | undefined;
    /** The last refusal or transport failure, as a sentence; cleared when the next command starts. */
    error: string | undefined;
    /** The code of that refusal, when the shell refused with one; cleared with `error`. */
    refusal: RefusalCode | undefined;
}
/** The store the body reads and the poller drives. */
export interface EngineStore {
    /** Current state; a stable reference between changes, for `useSyncExternalStore`. */
    getSnapshot: () => EngineStoreState;
    /**
     * Observe changes.
     * @param listener - called after every change.
     * @returns unsubscribe.
     */
    subscribe: (listener: () => void) => () => void;
    /** Read the host once and publish the answer. */
    refresh: () => Promise<void>;
    /** Ask for the download, then re-read. */
    download: () => Promise<void>;
    /** Ask to stop the download, then re-read. */
    cancel: () => Promise<void>;
}
/**
 * Whether a phase keeps the poller running.
 * @param phase - the phase the last read reported.
 * @returns true while a confirmation or a download is under way.
 */
export declare function isMoving(phase: EnginePhase): boolean;
/**
 * Create the store, seeded with the view `apply` already read.
 * @param api - the bound Remote calls.
 * @param first - the view the first read answered.
 * @returns the store.
 */
export declare function createEngineStore(api: EngineApi, first: EngineView): EngineStore;
//# sourceMappingURL=store.d.ts.map