/**
 * Opening the previewed file in the computer's default application, through
 * the harness's own `session.openWorkspacePath` Remote — the call the
 * document preview's header "Open" control makes.
 *
 * The Host checks the path against its composed root filesystem, which is
 * not limited to the workspace, checks that it exists, and hands it to the
 * platform opener (`open` on macOS, `explorer.exe` on Windows, `xdg-open` on
 * Linux). `session.canOpenWorkspacePath()` says whether that opener acts on
 * the person's own screen; on a server deployment it answers false, and no
 * open control is offered.
 *
 * The Host opens whatever path it is given, and a file's `absolutePath` is
 * the target of any symbolic link on the way, so a `.docx` link could name a
 * program. {@link isOfficePath} is the one rule this module adds: only a path
 * that itself ends in a Word or PowerPoint suffix is opened.
 *
 * @module @haoran/dsh-office-preview-notice/client/open
 */
/** One RPC result, as the gateway's namespace methods return it. */
export type RemoteResult<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error?: {
        code?: string;
        message?: string;
    };
};
/** The slice of the `remote.session` namespace this module calls. */
export interface SessionOpenRemote {
    /** Whether the Host can hand a path to a desktop the person sees. */
    canOpenWorkspacePath(): Promise<RemoteResult<boolean>>;
    /** Open one Host path in its default application. */
    openWorkspacePath(request: {
        path: string;
    }): Promise<RemoteResult<unknown>>;
}
/**
 * Why an open did not happen: `key` names the line to show — the file is
 * gone, or it did not open for another reason — and `detail` carries the
 * Host's own message for the line's tooltip, when there is one.
 */
export interface OpenFailure {
    readonly key: 'openMissing' | 'openFailed';
    readonly detail?: string;
}
/**
 * Open one file in its default application.
 * @param absolutePath - the file's Host path, as its metadata reports it.
 * @returns the failure to show, or undefined once the Host opened it.
 */
export type OpenFile = (absolutePath: string) => Promise<OpenFailure | undefined>;
/**
 * Whether a Host path ends in one of the Word or PowerPoint suffixes this
 * plugin claims, ignoring case.
 * @param path - an absolute Host path, with `/` or `\` separators.
 * @returns true for `…/name.docx` and the like; false for any other suffix or none.
 */
export declare function isOfficePath(path: string): boolean;
/**
 * Bind the opener, or report that this deployment has none.
 * @param remote - the `remote.session` namespace; the plugin injects it, so it is mounted.
 * @returns the opener, or undefined when the Host answers that it cannot open
 * paths on a desktop, or that question fails.
 */
export declare function desktopOpener(remote: SessionOpenRemote): Promise<OpenFile | undefined>;
//# sourceMappingURL=open.d.ts.map