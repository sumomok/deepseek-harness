/**
 * Copy for the document tab's body and its entry in the document viewer menu.
 * Every string reaches end users, so it names the file kinds, the download,
 * and the apps a user already knows, and nothing about how the preview is
 * produced.
 *
 * `{size}` and `{percent}` / `{received}` / `{total}` are filled by
 * {@link fill}. A failed download is one plain sentence; the application's
 * own reason, which names programs and files, rides in the line's tooltip
 * for whoever is diagnosing it.
 *
 * @module @haoran/dsh-office-preview-notice/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "office-preview-notice";
/** Every key this plugin's own copy uses. */
export type OfficePreviewNoticeKey = 'title' | 'headline' | 'openElsewhere' | 'open' | 'openLabel' | 'openFailed' | 'openMissing' | 'preview' | 'previewLabel' | 'previewSize' | 'previewUnsized' | 'confirming' | 'downloading' | 'progress' | 'progressUnknownTotal' | 'cancel' | 'failed' | 'retry' | 'refusedUnsupported' | 'refusedInstalled' | 'refusedConfirming' | 'refusedInstalling' | 'refusedRecently' | 'refusedNotRunning';
/** Chinese copy. */
export declare const zh: Record<OfficePreviewNoticeKey, string>;
/** English copy. */
export declare const en: Record<OfficePreviewNoticeKey, string>;
/**
 * Fill `{name}` placeholders.
 * @param template - the localized string.
 * @param values - the values by name.
 * @returns the string with every known placeholder replaced.
 */
export declare function fill(template: string, values: Record<string, string>): string;
/**
 * Bytes as megabytes: whole MiB (1,048,576 bytes), rounded to the nearest,
 * the same figure the application's own confirmation quotes.
 * @param bytes - a byte count.
 * @returns e.g. `64 MB` for 66,711,287 bytes.
 */
export declare function megabytes(bytes: number): string;
//# sourceMappingURL=locales.d.ts.map