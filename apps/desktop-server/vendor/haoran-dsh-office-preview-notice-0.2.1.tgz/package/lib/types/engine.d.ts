/**
 * What the three Remote methods do: read the shell's engine state and pass two
 * commands through to it.
 *
 * Nothing here throws at the caller. Every failure — no shell, a shell that
 * stopped answering, a body that cannot be read — becomes a state or an
 * outcome the document tab can show as a sentence.
 *
 * @module @haoran/dsh-office-preview-notice/engine
 */
import { type ShellRoute } from './shell.ts';
import type { CommandOutcome, EngineState, EngineView } from './types.ts';
/** The shell calls this module makes, injected so the flow is testable without a shell. */
export interface ShellCalls {
    /** Ask where the engine stands. */
    state: (route: ShellRoute, abortMs: number) => Promise<EngineState>;
    /** Send one command route. */
    command: (route: ShellRoute, path: string, abortMs: number) => Promise<CommandOutcome>;
}
/** The real calls. */
export declare const SHELL_CALLS: ShellCalls;
/** What this module needs from the plugin around it. */
export interface OfficeEngineOptions {
    /** The shell's engine route, or undefined where nothing lent one. */
    route: ShellRoute | undefined;
    /** The poll interval the browser half is told to use. */
    pollMs: number;
    /** How long to wait for one answer. */
    requestTimeoutMs: number;
    /** Receives one line about a failure; never a token. */
    log: (line: string) => void;
    /** The shell calls to make; {@link SHELL_CALLS} in production. */
    calls?: ShellCalls;
}
/** The three Remote methods, with the shell behind them. */
export declare class OfficeEngine {
    private readonly options;
    private readonly calls;
    /**
     * @param options - the shell route, the cadence to publish, and the injectable calls.
     */
    constructor(options: OfficeEngineOptions);
    /**
     * Where the engine stands. A deployment with no service answers
     * `unsupported`; a shell that stops answering degrades to `failed` carrying
     * the reason.
     * @returns the view the browser half renders.
     */
    state(): Promise<EngineView>;
    /**
     * Ask the shell to confirm with the person and download.
     * @returns whether the shell put its confirmation up.
     */
    download(): Promise<CommandOutcome>;
    /**
     * Ask the shell to stop the running download.
     * @returns whether the shell stopped one.
     */
    cancel(): Promise<CommandOutcome>;
    /**
     * Pass one command to the shell.
     * @param path - the route.
     * @returns whether the shell accepted it.
     */
    private command;
}
//# sourceMappingURL=engine.d.ts.map