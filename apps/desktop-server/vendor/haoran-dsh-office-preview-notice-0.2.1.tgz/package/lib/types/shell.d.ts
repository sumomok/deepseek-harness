/**
 * The desktop shell's Office engine service, used when it offers one.
 *
 * The desktop payload carries no LibreOffice engine. The shell installs the
 * one its shipped converter requires into the data directory when the person
 * confirms it in a native window, and advertises that service by putting
 * {@link ENDPOINT_ENV} and {@link TOKEN_ENV} into the harness process
 * environment. A deployment that offers none — every `dsh web` on a server,
 * which ships its engine — sets neither.
 *
 * This module composes three requests against a loopback origin and reads
 * their answers. It downloads nothing and names no package: the shell decides
 * what is installed.
 *
 * @module @haoran/dsh-office-preview-notice/shell
 */
import { type CommandOutcome, type EngineState, type RefusalCode } from './types.ts';
/** Environment variable naming the engine service's origin. */
export declare const ENDPOINT_ENV = "DSH_DESKTOP_OFFICE_ENGINE_ENDPOINT";
/** Environment variable carrying the bearer token that service requires. */
export declare const TOKEN_ENV = "DSH_DESKTOP_OFFICE_ENGINE_TOKEN";
/** Route reporting where the engine stands. */
export declare const STATE_PATH = "/state";
/** Route asking the shell to confirm with the person and download. */
export declare const INSTALL_PATH = "/install";
/** Route stopping a running download. */
export declare const CANCEL_PATH = "/cancel";
/** Where the shell's engine service lives and how to authenticate to it. */
export interface ShellRoute {
    /** Origin of the service, without a trailing slash. */
    readonly endpoint: string;
    /** Bearer token the shell minted for this harness process. */
    readonly token: string;
}
/**
 * Read the engine route out of the environment. Both variables are required
 * together.
 * @param env - the environment to read.
 * @returns the route, or undefined when this deployment offers no such service.
 */
export declare function shellRouteFromEnv(env: NodeJS.ProcessEnv): ShellRoute | undefined;
/**
 * Narrow one state body. It arrives from another process over a socket, so
 * every field is checked and a field of an unexpected type is dropped.
 * @param body - the parsed JSON body.
 * @returns the state.
 * @throws when the body carries no readable phase.
 */
export declare function parseState(body: unknown): EngineState;
/**
 * Ask where the engine stands.
 * @param route - the shell's endpoint and token.
 * @param abortMs - how long to wait for the answer.
 * @returns the shell's state.
 * @throws when the shell refuses, answers something unreadable, or does not answer in time.
 */
export declare function readState(route: ShellRoute, abortMs: number): Promise<EngineState>;
/**
 * Read a `409` body: JSON `{ code, message }`. It arrives from another process
 * over a socket, so an unknown code or a body that is not that JSON is read as
 * a refusal without a code.
 * @param body - the response text.
 * @returns the code, when known, and the message, when present.
 */
export declare function parseRefusal(body: string): {
    code?: RefusalCode;
    message?: string;
};
/**
 * Send one command. A refusal (`409`) is the shell's answer, not a transport
 * failure, so it comes back as `ok: false` carrying the shell's code and
 * sentence.
 * @param route - the shell's endpoint and token.
 * @param path - {@link INSTALL_PATH} or {@link CANCEL_PATH}.
 * @param abortMs - how long to wait for the answer.
 * @returns whether the shell accepted it.
 * @throws when the shell does not answer in time.
 */
export declare function sendCommand(route: ShellRoute, path: string, abortMs: number): Promise<CommandOutcome>;
//# sourceMappingURL=shell.d.ts.map