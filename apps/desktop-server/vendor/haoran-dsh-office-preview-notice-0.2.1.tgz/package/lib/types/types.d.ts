/**
 * The value types both halves and the Typert manifests share.
 *
 * @module @haoran/dsh-office-preview-notice/types
 */
/**
 * Where the preview engine stands, as the desktop shell reports it.
 *
 * - `unsupported` — nothing can be downloaded here: the shell offers no engine
 *   for this machine, or this deployment has no shell service at all.
 * - `absent` — not downloaded; the download can be offered.
 * - `confirming` — the shell's confirmation window is on screen.
 * - `installing` — the download is running.
 * - `installed` — the engine is on disk and previews work.
 * - `failed` — the last download did not finish; it can be offered again.
 */
export type EnginePhase = 'unsupported' | 'absent' | 'confirming' | 'installing' | 'installed' | 'failed';
/** The shell's `/state` body, narrowed. */
export interface EngineState {
    /** Where the engine stands. */
    phase: EnginePhase;
    /** The engine version the shipped converter requires. */
    version?: string;
    /** The published download size in bytes, when the shell knows it. */
    downloadBytes?: number;
    /** Bytes received so far, while `installing`. */
    transferredBytes?: number;
    /** The download's total bytes, while `installing`, when known. */
    totalBytes?: number;
    /** The shell's own sentence for `unsupported` and `failed`. */
    reason?: string;
}
/** What the browser half reads: the shell's state plus the two facts only this plugin knows. */
export interface EngineView extends EngineState {
    /** False where this deployment lends no engine service; the browser half then offers no download. */
    available: boolean;
    /** How often the browser half re-reads the state while a confirmation or download is under way. */
    pollMs: number;
}
/**
 * Why the shell refused a command, the `code` of its `409` body.
 *
 * - `unsupported` — the shell offers no engine here.
 * - `installed` — the engine is already installed.
 * - `confirming` — the confirmation is waiting for the person.
 * - `installing` — a download is already running.
 * - `declined-recently` — the person declined the confirmation moments ago.
 * - `not-running` — a cancel arrived with no download running.
 */
export type RefusalCode = 'unsupported' | 'installed' | 'confirming' | 'installing' | 'declined-recently' | 'not-running';
/** Every {@link RefusalCode}, for narrowing a body read off the wire. */
export declare const REFUSAL_CODES: readonly RefusalCode[];
/** How one command ended. */
export interface CommandOutcome {
    /** Whether the shell accepted the command. */
    ok: boolean;
    /** Why it did not, when it did not: the shell's sentence, or the transport failure. */
    error?: string;
    /** The shell's refusal code, when the shell refused it with one. */
    code?: RefusalCode;
}
//# sourceMappingURL=types.d.ts.map