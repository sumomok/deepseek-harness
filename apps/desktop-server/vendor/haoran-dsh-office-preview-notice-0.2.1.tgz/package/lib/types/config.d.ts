/**
 * Plugin configuration. Every field is changeable from `cordis.yml` and
 * validated at load.
 *
 * The protocol is not configuration: the environment variable names, the
 * route paths, and the bearer scheme are fixed facts of the shell this plugin
 * talks to.
 *
 * @module @haoran/dsh-office-preview-notice/config
 */
import z from '@deepseek-ai/schemastery';
/** Plugin configuration. */
export interface Config {
    /**
     * How often the browser half re-reads the engine state while the shell's
     * confirmation is on screen or a download runs; the progress bar advances
     * on it. One loopback request per read.
     */
    pollMs?: number;
    /** How long the host half waits for one answer from the shell. */
    requestTimeoutMs?: number;
}
export declare const Config: z<Config>;
/** Configuration after defaults. */
export interface ResolvedConfig {
    pollMs: number;
    requestTimeoutMs: number;
}
/**
 * Settle defaults.
 * @param config - the schema-validated plugin config.
 * @returns the resolved configuration.
 */
export declare function resolveConfig(config: Config): ResolvedConfig;
//# sourceMappingURL=config.d.ts.map