/**
 * Host half of @haoran/dsh-office-preview-notice.
 *
 * The desktop payload carries no LibreOffice engine, and the shell downloads
 * one into the data directory when the person asks for it. This half is the
 * Remote the browser half asks through: it reads the shell's engine route
 * from the environment and forwards `state`, `download`, and `cancel` to it.
 * It registers no HTTP route and reads no file.
 *
 * It also removes the engine's entry from `process.env.NODE_PATH` when it
 * applies ([[stripEngineNodePath]]), so the processes the harness starts do
 * not inherit it; this process keeps resolving the engine through it.
 *
 * A deployment that is not the desktop application lends no engine service;
 * `state()` then answers `available: false`, and the browser half shows its
 * plain notice without a download button.
 *
 * @module @haoran/dsh-office-preview-notice
 */
import type { Context } from '@deepseek-ai/cordis';
import { type Config } from './config.ts';
export { Config, resolveConfig } from './config.ts';
export type { ResolvedConfig } from './config.ts';
export { OfficeEngine, SHELL_CALLS } from './engine.ts';
export type { OfficeEngineOptions, ShellCalls } from './engine.ts';
export { ENGINE_MODULES_ENV, stripEngineNodePath } from './node-path.ts';
export { OfficeEngineService } from './service.ts';
export { CANCEL_PATH, ENDPOINT_ENV, INSTALL_PATH, parseState, readState, sendCommand, shellRouteFromEnv, STATE_PATH, TOKEN_ENV, } from './shell.ts';
export type { ShellRoute } from './shell.ts';
export type { CommandOutcome, EnginePhase, EngineState, EngineView } from './types.ts';
/** Plugin name in the loader's entry roster. */
export declare const name = "office-preview-notice";
/**
 * Apply the host half.
 * @param ctx - loader context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map