/**
 * B2 of the three-layer spec (`docs/referents-three-layer-spec.md`): the
 * session truth index. Built from session events' own **structured**
 * fields only — a tool call's parsed JSON arguments, a completed mutation's
 * follow-along `locations` (the render-intent vocabulary every tool
 * presenter already declares), and a completed `web_fetch`'s final URL —
 * never a tool result's free-text output (that is the nomination layer's
 * territory, `core/detect.ts`). Absolute paths are the primary key;
 * basenames alias back to their one unambiguous absolute owner, the same
 * disambiguation rule `@deepseek-ai/dsh-client-ui-deliverables`'s
 * `producedFileMentions` already uses (a basename two paths share resolves
 * to neither, rather than guessing).
 *
 * One `MutableReferentIndex` instance is created per client apply() and
 * reset at the start of each session's replay (`start()` below, matched
 * to that session's very first `turn/start`) — "会話切换重建" (rebuilt on
 * session switch). A `ConversationNodeDefinition`'s own State channel
 * cannot carry session-wide (non-turn/step-scoped) data out to the
 * `proseReferents` service, which is a plain per-apply object, not
 * itself session-scoped — so this Definition's `start`/`update` mutate the
 * shared index as a deliberate, documented side effect, while still
 * returning a (trivial, unread) State value to satisfy the engine's own
 * per-Context bookkeeping.
 *
 * @module @haoran/dsh-clickable-refs/client/referent-index
 */
import type { ConversationMatchHandler, ConversationNodeDefinitionInput } from '@deepseek-ai/dsh-client-ui-conversation/client';
/** Default maximum number of recorded absolute paths kept in one session index. */
export declare const MAX_INDEX_PATHS = 2000;
/** Default maximum number of recorded URLs kept in one session index. */
export declare const MAX_INDEX_URLS = 500;
/** Optional capacity overrides for {@link MutableReferentIndex}. */
export interface ReferentIndexOptions {
    readonly maxPaths?: number;
    readonly maxUrls?: number;
}
/** Table-form conversation node definition returned by {@link createReferentIndexDefinition}. */
export type ReferentIndexDefinition = Omit<ConversationNodeDefinitionInput<null>, 'match'> & {
    readonly match: Readonly<Record<'turn/start' | 'tool/call', ConversationMatchHandler>>;
};
/** Read-only face `prose-referents.ts`/terminal scanning consult. */
export interface ReferentIndexReader {
    /** Whether `absolute` is a known-real path recorded from a structured session field. */
    hasPath(absolute: string): boolean;
    /** The one unambiguous absolute path a basename/relative alias resolves to, or `undefined` (unknown, or shared by more than one recorded path). */
    resolveAlias(alias: string): string | undefined;
    /** Whether `url` was actually fetched (`web_fetch`'s final URL) in this session. */
    hasUrl(url: string): boolean;
    /**
     * Subscribe to index growth (a later mention of an already-rendered path
     * may now resolve once the index records it).
     * @param listener - called with no arguments on every recorded fact.
     * @returns unsubscribe function.
     */
    subscribe(listener: () => void): () => void;
}
/** Mutable index + subscribe channel; the Definition below is its only writer. */
export declare class MutableReferentIndex implements ReferentIndexReader {
    private readonly maxPaths;
    private readonly maxUrls;
    private readonly paths;
    private readonly aliasCandidates;
    private readonly urls;
    private readonly listeners;
    private notifyScheduled;
    private disposed;
    /**
     * @param options - optional capacity bounds (defaults suit production; tests may pass smaller limits).
     */
    constructor(options?: ReferentIndexOptions);
    /** Discard every recorded fact — called once at the start of each session's replay. */
    reset(): void;
    /** Release listeners and recorded state, suppressing any already-queued notification microtask. */
    dispose(): void;
    /**
     * Record an absolute path as real, and its basename as an alias toward it.
     * @param absolute - an already-absolute path (a relative value is not this method's job to resolve).
     */
    recordPath(absolute: string): void;
    /** Record a URL as actually fetched this session. */
    recordUrl(url: string): void;
    hasPath(absolute: string): boolean;
    resolveAlias(alias: string): string | undefined;
    hasUrl(url: string): boolean;
    /**
     * Subscribe to index growth (a later mention of an already-rendered path
     * may now resolve once the index records it).
     * @param listener - called with no arguments on coalesced index updates.
     * @returns unsubscribe function.
     */
    subscribe(listener: () => void): () => void;
    private scheduleNotify;
}
/**
 * Build the table-form `ConversationNodeDefinitionInput` that populates
 * `index` as a side effect. A single session-wide Context (`id: 'session'`)
 * starts on that session's very first turn (`turn/start` with `turn === 1` —
 * always the earliest turn-scoped event in any session's log, before any tool
 * call can occur) and updates only on `tool/call`; using a match table keeps
 * this Definition out of `ConversationEventRegistry`'s unrestricted bucket on
 * streaming deltas and unrelated event types, and `publication: () => 'none'`
 * prevents state-only updates from scheduling UI publications.
 * @param index - the shared index this Definition writes into.
 * @returns the Definition to pass to `ctx.uiConversation.events.register`.
 */
export declare function createReferentIndexDefinition(index: MutableReferentIndex): ReferentIndexDefinition;
//# sourceMappingURL=referent-index.d.ts.map