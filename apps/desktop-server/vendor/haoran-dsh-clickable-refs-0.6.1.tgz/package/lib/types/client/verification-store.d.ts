import type { ReferentIndexReader } from './referent-index.ts';
/** One `host.probeTargets` result row, this store's only shape for the host stat batch — kept narrow so a test double needs no other field. */
export interface ProbeResult {
    readonly path: string;
    readonly exists: boolean;
    readonly kind?: 'file' | 'dir';
}
/** Batch prober: `ctx.workspaces.probeTargets` in production, a scripted stub in tests. */
export type ProbeTargets = (paths: readonly string[]) => Promise<readonly ProbeResult[]>;
/** Default maximum number of verified paths cached (LRU). */
export declare const MAX_VERIFIED = 2000;
/** Default maximum number of rejected paths cached (LRU). */
export declare const MAX_REJECTED = 4000;
/** Default maximum number of unresolved non-absolute aliases tracked for index growth (LRU). */
export declare const MAX_UNRESOLVED_ALIASES = 512;
/** Optional cache-capacity overrides for {@link VerificationStore}. */
export interface VerificationStoreOptions {
    readonly maxVerified?: number;
    readonly maxRejected?: number;
    readonly maxUnresolvedAliases?: number;
}
/**
 * Verification cache + host-stat batch scheduler for `file`/`dir`
 * candidates. `url` candidates never reach this store — B5 exempts them
 * from `stat` entirely (the click promise is "open a browser tab", not
 * "this host answers").
 */
export declare class VerificationStore {
    private readonly index;
    private readonly probe;
    private readonly verified;
    private readonly rejected;
    private readonly queued;
    private readonly unresolvedAliases;
    private readonly maxVerified;
    private readonly maxRejected;
    private readonly maxUnresolvedAliases;
    private dispatching;
    private dispatchTimer;
    private notifyScheduled;
    private disposed;
    private readonly listeners;
    private readonly unsubscribeIndex;
    /**
     * @param index - session truth index consulted before ever queueing a `stat`.
     * @param probe - batch prober; called with at most {@link MAX_BATCH} paths.
     * @param options - optional LRU capacity overrides.
     */
    constructor(index: ReferentIndexReader, probe: ProbeTargets, options?: VerificationStoreOptions);
    /** Cancel pending work, stop index subscription, and clear all caches and listeners (owner teardown). */
    dispose(): void;
    /**
     * Synchronous, IO-free check: verified kind, or `undefined` when not
     * (yet, or ever) verified. `stat` — a completed `host.probeTargets`
     * batch — is this store's SOLE existence verifier; the index is
     * consulted only to resolve `target` as a basename/relative alias to
     * its one unambiguous absolute owner ({@link ReferentIndexReader.resolveAlias}
     * — a no-op when `target` is not a recorded alias, which an
     * already-absolute path never is). An index-known path and a wholly
     * unknown one are then queued identically: knowing a tool touched a
     * path this session proves nothing about whether it still exists NOW,
     * so it earns no verification shortcut (deliberately not priority-queued
     * ahead of an unknown path either — a disclosed simplification, not a
     * correctness requirement). A miss that is not already queued or
     * rejected enqueues it for the next `stat` batch as a side effect —
     * callers do not need a separate "ensure" call.
     * @param target - absolute path (or a basename/relative alias text the
     * index may resolve — this store resolves nothing else itself; the
     * nomination layer resolves everything else before a candidate ever
     * reaches this method).
     * @returns the verified kind, from the `stat` batch's own authoritative
     * report — or `undefined` when not (yet, or ever) verified.
     */
    check(target: string): 'file' | 'dir' | undefined;
    /**
     * Subscribe to verification progress (verified-set additions/kind changes
     * and newly revealed alias resolutions).
     * @param listener - called with no arguments on coalesced updates.
     * @returns unsubscribe function.
     */
    subscribe(listener: () => void): () => void;
    private setVerified;
    private addRejected;
    private trackUnresolvedAlias;
    private reconcileAliases;
    private scheduleDispatch;
    private dispatch;
    private scheduleNotify;
}
//# sourceMappingURL=verification-store.d.ts.map