/**
 * The browser half's Typert contribution: the consumer-side mirror of
 * `../typert.ts`.
 *
 * The descriptor must match the host manifest's invocation exactly — same
 * id, namespace, method — because the gateway matches arguments by field
 * name. The codec is a hand-written narrowing rather than a schema library:
 * this file is bundled into the browser for one small read.
 *
 * The browser gateway never runs that narrowing. The Typert registry only
 * checks that the strict codec has a `create` function, and the client
 * gateway hands the result through unchanged unless the codec has a
 * `decode`, which this one does not; the host validates the value with the
 * zod schema in `../typert.ts`.
 *
 * @module @haoran/dsh-vision-switch/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { VisionCatalogView } from '../types.ts';
/** Narrow one catalog read. */
export declare function parseVisionCatalogView(value: unknown): VisionCatalogView;
/** The contribution `ctx.remote.$mount()` installs, mirroring `../typert.ts`. */
export declare const CONTRIBUTION: TypertRemoteContribution;
//# sourceMappingURL=contribution.d.ts.map