/**
 * The browser half's stylesheet, injected as one tagged `<style>` per client instance.
 *
 * Every colour is a harness theme variable rather than a literal, so the
 * chooser, the blocked message, and the switched note follow the light and
 * dark schemes the shell already switches between.
 *
 * The chooser rules restate `ui-user-questions`' own question-card sheet —
 * card frame, row list, footer, and the 720px narrow-viewport step — against
 * the same variables. They are a restatement rather than an import because
 * that sheet is a CSS module whose class names the host's build hashes, and
 * a plugin bundle can neither name them nor import the module.
 *
 * @module @haoran/dsh-vision-switch/client/styles
 */
/** Attribute marking this plugin's style tags. */
export declare const STYLE_TAG = "data-dsh-vision-switch";
/**
 * The `data-plugin` value on this plugin's style tags: the package name, which
 * is the id the host's client module system gives this plugin. That system
 * stamps every `<style>` without `data-plugin` with the id of the module it is
 * materializing and removes the stamped tags when that module unloads; a tag
 * that already names this plugin is left to this plugin's own disposer.
 */
export declare const STYLE_OWNER = "@haoran/dsh-vision-switch";
/**
 * Insert this call's own copy of the stylesheet. Every call appends a separate
 * tag, so overlapping client instances of this plugin each hold one and
 * disposing one instance leaves the others styled.
 * @returns a disposer removing only the tag this call inserted.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map