/**
 * Browser half of @haoran/dsh-vision-switch.
 *
 * STRATEGY: this plugin does not fight the host's own image/modality gate at
 * `session.prompt` — it satisfies it. Before a send with images leaves the
 * client, it switches the session's model selection to a vision-capable one
 * through the exact channel a manual switch uses (`session.selectModel`),
 * then lets the send proceed. `gate-registry.ts`'s module doc explains where
 * the interception itself happens and why it is not a slot shadow.
 *
 * The one host path is the Typert Remote this package's host half exports —
 * one read (`visionSwitch/catalog`), mounted here through `ctx.remote.$mount()`
 * — plus `ctx.remote.session.selectModel`, `ctx.conversation`, and
 * `ctx.modelDirectories`: the per-session model directory the composer's own
 * model seat and the /model popup both render from, which is where this
 * plugin reads the session's effective model instead of deriving one.
 *
 * Two composer entries render the chooser/blocked/switched UI, never both
 * for the same status: `conversation.composer.dock` (`GateDock.tsx`) once
 * it has mounted, and a `document.body` portal (`GatePortal.tsx`,
 * registered at `conversation.input.dock`) before it has — a brand new
 * session's very first message. Rendering the portal is also what installs
 * the gate on a session's input facade; see `GatePortal.tsx`'s module doc.
 *
 * @module @haoran/dsh-vision-switch/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type VisionSwitchKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-vision-switch` copy. */
        visionSwitch: VisionSwitchKey;
    }
}
export { applySwitch, effectiveSelection, resolveGate, standAside, type ModelDirectoriesFace, type ModelDirectoryFace, type ModelSelectionFace, } from './gate.ts';
export { GateRegistry, type ConversationFace, type DraftAttachmentFace, type GatedConversation, type GatedSessionInput, type SessionGate, type SessionInputFace, } from './gate-registry.ts';
export { createGatedSubmit, type GatedSubmit, type GateStatus, type KeyboardFace, type SubmitArgs } from './submit-gate.ts';
export { createGateDock, type GateDockDeps, type GateDockOwnProps } from './GateDock.tsx';
export { createGatePortal, type GatePortalDeps, type GatePortalOwnProps } from './GatePortal.tsx';
export { selectGateSurface, type GateSurface } from './fallback-surface.ts';
export { GateStatusView, type GateStatusViewProps } from './GateStatusView.tsx';
export { CatalogCache } from './catalog-cache.ts';
export type { SettingsSectionInjected, SettingsSectionProps } from './SettingsSection.tsx';
export type { VisionSwitchKey } from './locales.ts';
/** Required browser services. */
export declare const inject: string[];
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 */
export declare function apply(ctx: Context): Promise<void>;
//# sourceMappingURL=index.d.ts.map