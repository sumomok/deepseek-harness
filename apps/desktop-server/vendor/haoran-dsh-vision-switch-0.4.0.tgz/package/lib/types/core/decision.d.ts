/**
 * The owner's behavior tree, as one pure function: given what the browser
 * half already knows about a send attempt, decide what happens before the
 * message leaves the client. No I/O, no React, no cordis — every fact this
 * needs is resolved by the caller first, which is what keeps this testable
 * without a live session or a mounted Remote.
 *
 * @module @haoran/dsh-vision-switch/core/decision
 */
import type { ModelPin, VisionModelEntry } from '../types.ts';
/** Proceed with the send unchanged: no image attached, or the current model already accepts images. */
export interface ProceedDecision {
    readonly kind: 'proceed';
}
/** Switch to the resolved target, then proceed (case 1: the target is in the catalog and its route has a credential). */
export interface AutoSwitchDecision {
    readonly kind: 'auto-switch';
    readonly target: VisionModelEntry;
}
/** Offer every vision-capable model whose route has a credential and wait for a pick or a dismissal (case 2). */
export interface ChooseDecision {
    readonly kind: 'choose';
    readonly options: readonly VisionModelEntry[];
}
/**
 * Vision-capable models exist, but no route among them has a credential:
 * send unchanged and leave the refusal to the host (case 3).
 */
export interface DeferDecision {
    readonly kind: 'defer';
}
/** No vision-capable model exists anywhere in the catalog; refuse without switching (case 4). */
export interface BlockedDecision {
    readonly kind: 'blocked';
}
export type VisionSwitchDecision = ProceedDecision | AutoSwitchDecision | ChooseDecision | DeferDecision | BlockedDecision;
/**
 * Decide what a send attempt does, given the facts already resolved.
 * @param input.hasImageAttachment - whether the draft carries at least one image attachment. A
 * draft carrying only non-image files reaches the model through the same
 * text-and-file channel on any model, so it is not this plugin's business.
 * @param input.currentIsVision - whether the session's current model already accepts images.
 * @param input.target - the resolved switch target: `Config.target` or the built-in default.
 * @param input.visionModels - every vision-capable model the runtime catalog advertises.
 * @param input.missingCredential - routes among `visionModels` without a
 * configured credential. A switch onto one fails every request after it, so
 * their models are neither switched to nor offered; the current model is
 * still judged against every vision-capable model.
 * @returns the decision; the caller carries out whichever kind it names.
 */
export declare function decideVisionSwitch(input: {
    readonly hasImageAttachment: boolean;
    readonly currentIsVision: boolean;
    readonly target: ModelPin;
    readonly visionModels: readonly VisionModelEntry[];
    readonly missingCredential: readonly string[];
}): VisionSwitchDecision;
//# sourceMappingURL=decision.d.ts.map