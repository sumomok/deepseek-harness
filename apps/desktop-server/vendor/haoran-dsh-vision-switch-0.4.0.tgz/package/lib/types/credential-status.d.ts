/**
 * Which provider routes have no configured credential, decided without
 * reading any credential value.
 *
 * A route's settings name its API key by reference (`apiKeyEnv`, a
 * `credential-ref` field that secret redaction keeps), and the credential
 * service answers whether that reference resolves, never with what it
 * resolves to. So the check reads three public facts: the configurable-provider
 * directory (`llm.listConfigurableProviders`) for where each route's settings
 * live, the redacted settings values (`settings.describe({ redactSecrets:
 * true })`) for the reference name, and `credentials.describe(ref).configured`.
 * It never calls `credentials.resolve` or any record read.
 *
 * A route counts as having a credential when its directory entry or its
 * settings name no reference: the DeepSeek account route authenticates
 * through the account service and lists models only while signed in, and a
 * pi-ai route without `apiKeyEnv` finds its own credential (an environment
 * variable or an OAuth login), the same reading the upstream Models page
 * makes. A reference outside the credential grammar cannot resolve, so it
 * counts as missing without a lookup.
 *
 * The browser half must not import this module: it imports the credential
 * package at runtime.
 *
 * @module @haoran/dsh-vision-switch/credential-status
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * The routes among `providers` whose configured credential reference does
 * not resolve.
 * @param ctx - host context; reads `llm`, and `settings` and `credentials` through `ctx.get`.
 * @param providers - provider route ids to check; duplicates are checked once.
 * @returns the routes without a configured credential, in first-seen order.
 * @throws when `providers` is not empty and the settings or credentials
 *   service is not composed, or when a credential description fails.
 */
export declare function routesMissingCredential(ctx: Context, providers: readonly string[]): Promise<string[]>;
//# sourceMappingURL=credential-status.d.ts.map