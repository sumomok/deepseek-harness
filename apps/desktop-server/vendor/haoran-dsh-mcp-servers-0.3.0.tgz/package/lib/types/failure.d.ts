/**
 * Reading a failed connection attempt as one of the failures a person can do
 * something about.
 *
 * Only an error's own fields decide: a Node system error's `code` and
 * `syscall`, the HTTP status the MCP client's `SdkHttpError` carries in
 * `data.status`, the client's `SdkError` `code`, and the JSON-RPC
 * `ProtocolError` name. The client wraps a fetch failure twice — its own error
 * holds `data.cause`, a `TypeError('fetch failed')` whose `cause` is the socket
 * error — so the chain is walked through both links and the innermost error
 * that says something decides. Nothing reads an error's message: wording
 * changes between releases and carries no promise.
 *
 * @module @haoran/dsh-mcp-servers/failure
 */
import type { ConnectFailure, ServerTransport } from './types.ts';
/**
 * The errors one failure was caused by, outermost first.
 * @param cause - what the attempt rejected with.
 * @returns every `Error` reachable through `cause` and `data.cause`, without repeats.
 */
export declare function errorChain(cause: unknown): Error[];
/**
 * The text a person copies out when they ask someone for help.
 * @param cause - what the attempt rejected with.
 * @returns every error in the chain, one per line, outermost first; the value itself where it is no `Error`.
 */
export declare function describeFailure(cause: unknown): string;
/**
 * Which failure one attempt ran into.
 * @param cause - what the attempt rejected with.
 * @param transport - how the server was being reached.
 * @returns the innermost link's reading that names one, or `''` where none does.
 */
export declare function classifyFailure(cause: unknown, transport: ServerTransport): ConnectFailure;
//# sourceMappingURL=failure.d.ts.map