/**
 * The `settings.section` page this plugin contributes.
 *
 * Two sources feed it, and they answer different questions. The entry's config
 * form holds what is stored — which servers exist, what was confirmed about them,
 * which tools were ticked — and is what this page writes. The host read says
 * what is actually happening right now: connected or not, why not, and which
 * tools the server is offering at this moment. A tool can only be ticked once
 * the host has seen it, because the tick records the exact wording the server
 * offered.
 *
 * Saving a new server asks for nothing further: the host connects it and
 * records what it offers. The confirmation control appears only when something
 * stopped matching what was agreed to — the destination was edited, or the
 * server changed the tools it offers — and it stores both fingerprints the
 * host just reported, which is why the page never computes one. It gates the
 * ticking of the tools that changed, and only those: a ticked tool the server
 * left alone stays live, and stays the person's to un-tick.
 *
 * Changing a server happens inside its own card: the header — name, status,
 * destination, and the card's place on the page — stays as it is, and the body
 * turns into that server's fields. The tool list is not drawn meanwhile: a tick
 * is written the moment it is made, against the stored record, while the
 * fields may be about to change the destination, and saving a new destination
 * sets the recorded tool set aside — a tick made under the fields could be
 * undone by the very save they lead to.
 *
 * @module @haoran/dsh-mcp-servers/client/McpSection
 */
import { type ReactNode } from 'react';
import { type TagTone } from '@deepseek-ai/dsh-client-ui-primitives';
import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { InjectFace, PropsLocale, PropsRuntime, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { McpServersForm, McpServerView, McpToolView } from '../types.ts';
import type { McpServersKey } from './locales.ts';
/** What this section needs from the host and from storage. */
export interface McpSectionInjected {
    /** Read what the servers are doing right now. */
    list: () => Promise<McpServerView[]>;
    /** The config form over this plugin's own profile entry. */
    form: ConfigForm<McpServersForm>;
    /** How often the page re-reads the host, in milliseconds. */
    pollMs: number;
}
/** Full component props. */
export type McpSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'mcpServers'> & InjectFace<McpSectionInjected>;
/**
 * @param view - one server.
 * @returns the copy key for its status badge. A degraded server has two of
 *   them: an error came back on its own, or the deadline this side armed fired
 *   with nothing back at all, which says nothing about the connection.
 */
export declare function statusKey(view: McpServerView): McpServersKey;
/**
 * @param view - one server.
 * @returns whether its badge should read as trouble. A call nothing came back
 *   from inside the budget is not evidence of a broken server, so it reads as
 *   neither healthy nor broken.
 */
export declare function badgeTone(view: McpServerView): 'connected' | 'blocked' | 'neutral';
/**
 * @param view - one server.
 * @returns the tag palette its status badge is drawn in.
 */
export declare function statusTone(view: McpServerView): TagTone;
/**
 * @param tools - the tools one server offers right now.
 * @returns whether every one of them is ticked, which is when the server's
 *   select-all control reads as clearing them. An empty list is not all ticked.
 */
export declare function allApproved(tools: readonly McpToolView[]): boolean;
/**
 * The approvals one server's select-all control stores.
 *
 * Only the names the server offers right now change. An approval for a tool the
 * server stopped offering is left where it is: this control acts on the list on
 * screen, and removing the server is what drops the rest.
 * @param approved - the approvals the record holds.
 * @param tools - the tools the server offers right now.
 * @param tick - true to tick every one of them, false to clear every one.
 * @returns the approvals to store.
 */
export declare function approvalsForAll(approved: readonly {
    name: string;
    fingerprint: string;
}[], tools: readonly McpToolView[], tick: boolean): {
    name: string;
    fingerprint: string;
}[];
/**
 * The destination as it is shown. A dropped query is named but never printed:
 * it is a common place for a key, and two records that differ only there must
 * not read as the same destination.
 * @param view - one server.
 * @param t - the translate seat.
 * @returns the endpoint line.
 */
export declare function endpointText(view: McpServerView, t: TranslateNS<'mcpServers'>): string;
/** The confirmation panel's copy, which differs by what stopped matching. */
export interface ConfirmCopy {
    /** Heading key. */
    title: McpServersKey;
    /** Control key. */
    action: McpServersKey;
    /**
     * Whether the panel spells out where the server connects, and what running
     * something there means. A server whose tool set changed is already
     * connected, and was already connected to that same place when the person
     * agreed to it, so repeating either would answer a question nobody asked.
     */
    destination: boolean;
}
/**
 * @param view - one server waiting for a person.
 * @returns the copy its confirmation panel draws itself with.
 */
export declare function confirmCopy(view: McpServerView): ConfirmCopy;
/**
 * @param view - one blocked server.
 * @param t - the translate seat.
 * @returns the sentence explaining why, or the empty string when there is none.
 *   A failed connection is described by what it ran into, in words a person
 *   can act on; the error itself goes in the details under it
 *   ({@link failureDetail}).
 */
export declare function reasonText(view: McpServerView, t: TranslateNS<'mcpServers'>): string;
/**
 * @param view - one server.
 * @returns the error text a failed connection keeps under its sentence, or the
 *   empty string where there is none. Only a failed connection has one; every
 *   other reason's detail is already inside its sentence.
 */
export declare function failureDetail(view: McpServerView): string;
/**
 * The registered settings section.
 * @param props - the framework standard kit plus this plugin's host read and config form.
 * @returns the page.
 */
export declare function McpSection({ list, form, pollMs, t }: McpSectionProps): ReactNode;
//# sourceMappingURL=McpSection.d.ts.map