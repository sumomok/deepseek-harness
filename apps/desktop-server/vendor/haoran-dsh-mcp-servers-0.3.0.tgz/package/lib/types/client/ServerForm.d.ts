/**
 * The fields of one server, and the add card built from them. Adding draws the
 * card where the add control was; changing draws the fields inside that
 * server's own card, under its unchanged header (`McpSection`).
 *
 * Two kinds, and only two: a program already installed on this computer,
 * named by its full path, and a web address. Neither is a package name this
 * app could fetch, because it ships no package manager for one.
 *
 * @module @haoran/dsh-mcp-servers/client/ServerForm
 */
import { type ReactNode } from 'react';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { ServerRecord } from '../types.ts';
/** Props the fields read. */
export interface ServerFieldsProps {
    /** The record being edited; a blank one when adding. */
    initial: ServerRecord;
    /** Store the edited record. */
    onSave: (next: ServerRecord) => void;
    /** Leave the fields without storing; Escape anywhere inside them does the same. */
    onCancel: () => void;
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'mcpServers'>;
    /** The accessible name of the group the fields form: what is being done to which server. */
    label: string;
}
/**
 * The editable fields of one server, with its two exits.
 *
 * The first field takes the focus when they open, so the keyboard lands where
 * the change starts; Escape inside them leaves without storing.
 * @param props - the record being edited and the two exits.
 * @returns the fields, the complaint line, and the two controls.
 */
export declare function ServerFields({ initial, onSave, onCancel, t, label: groupLabel }: ServerFieldsProps): ReactNode;
/**
 * The card a new server is added in, at the foot of the page.
 * @param props - a blank record and the two exits.
 * @returns the card.
 */
export declare function ServerForm(props: Omit<ServerFieldsProps, 'label'>): ReactNode;
//# sourceMappingURL=ServerForm.d.ts.map