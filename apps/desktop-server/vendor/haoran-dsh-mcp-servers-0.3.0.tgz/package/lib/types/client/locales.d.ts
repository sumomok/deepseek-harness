/**
 * Copy for the one surface this plugin owns: its settings page.
 *
 * The protocol's own name appears once, as the page's name in the settings
 * navigation, so that someone following a third-party setup guide finds the
 * page they were sent to. Everything on the page is written for a person who
 * has never heard of it.
 *
 * @module @haoran/dsh-mcp-servers/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "mcpServers";
/** Chinese copy (the dictionary that defines the key domain). */
export declare const zh: {
    nav: string;
    unavailable: string;
    readonly: string;
    empty: string;
    add: string;
    addTitle: string;
    editTitle: string;
    edit: string;
    remove: string;
    'remove.confirm': string;
    enable: string;
    disable: string;
    save: string;
    cancel: string;
    'status.disabled': string;
    'status.needsConfirm': string;
    'status.connecting': string;
    'status.connected': string;
    'status.blocked': string;
    'status.degraded': string;
    'status.slow': string;
    'confirm.title': string;
    'confirm.body': string;
    'confirm.endpoint': string;
    'endpoint.withQuery': string;
    'confirm.action': string;
    'confirm.title.tools': string;
    'confirm.action.tools': string;
    'reason.command-missing': string;
    'reason.command-relative': string;
    'reason.env-invalid': string;
    'reason.url-invalid': string;
    'reason.url-userinfo': string;
    'reason.url-fragment': string;
    'reason.header-invalid': string;
    'reason.credential-missing': string;
    'reason.endpoint-changed': string;
    'reason.tools-changed': string;
    'reason.connect-failed': string;
    'failure.http-not-found': string;
    'failure.http-unauthorized': string;
    'failure.http-forbidden': string;
    'failure.http-server-error': string;
    'failure.refused': string;
    'failure.timeout': string;
    'failure.dns': string;
    'failure.tls': string;
    'failure.program-missing': string;
    'failure.program-not-executable': string;
    'failure.program-exited': string;
    'failure.protocol': string;
    'failure.details': string;
    'reason.connect-timeout': string;
    'reason.previous-attempt-still-closing': string;
    'reason.call-failed': string;
    'reason.call-slow': string;
    'tools.title': string;
    'tools.hint': string;
    'tools.none': string;
    'tools.offline': string;
    'tools.pending': string;
    'tools.pendingCount': string;
    'tools.error': string;
    'tools.selectAll': string;
    'tools.deselectAll': string;
    'tools.expand': string;
    'tools.collapse': string;
    'form.label': string;
    'form.transport': string;
    'form.transport.stdio': string;
    'form.transport.http': string;
    'form.command': string;
    'form.args': string;
    'form.cwd': string;
    'form.env': string;
    'form.env.name': string;
    'form.env.value': string;
    'form.env.credential': string;
    'form.env.add': string;
    'form.url': string;
    'form.headers': string;
    'form.header.name': string;
    'form.header.value': string;
    'form.header.credential': string;
    'form.header.add': string;
    'form.value.kind': string;
    'form.value.kind.literal': string;
    'form.value.kind.credential': string;
    'form.value.remove': string;
    'form.needLabel': string;
    'form.saveFailed': string;
    'form.saveRefused': string;
};
/** English copy. */
export declare const en: Record<McpServersKey, string>;
/** Dictionary key domain. */
export type McpServersKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map