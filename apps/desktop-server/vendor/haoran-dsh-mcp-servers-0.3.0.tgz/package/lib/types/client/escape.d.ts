/**
 * Escape inside a panel of the MCP page answers that panel only.
 *
 * The page sits inside the host's settings dialog, whose modal layer listens
 * for Escape on `document` and closes the whole dialog unless the event was
 * already handled (`defaultPrevented`). A panel that takes Escape therefore
 * marks the event handled and stops it before it reaches `document`. An
 * Escape that belongs to an input-method composition — pressed during it, or
 * the closing keydown some input methods deliver after `compositionend` —
 * belongs to the input method, so the panel leaves it alone, judged by the
 * same `observeComposition` guard the modal layer uses.
 *
 * @module @haoran/dsh-mcp-servers/client/escape
 */
import { type KeyboardEvent } from 'react';
/**
 * @param leave - what Escape does in the panel.
 * @returns a `keydown` handler for the panel that runs `leave` on an Escape
 *   outside an input-method composition, and keeps that Escape from the host
 *   dialog. Composition is observed on `document` while the calling component
 *   is mounted.
 */
export declare function useEscapeLeaves(leave: () => void): (event: KeyboardEvent<HTMLElement>) => void;
//# sourceMappingURL=escape.d.ts.map