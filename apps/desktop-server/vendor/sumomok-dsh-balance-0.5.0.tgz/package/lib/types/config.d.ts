/**
 * Plugin configuration. Every field is changeable from `cordis.yml` and
 * validated at load; nothing here is a constant compiled into the code.
 *
 * The per-field schema settles types, ranges, and defaults. The rules a
 * per-field schema cannot state — a schedule declaring exactly one of `rates`
 * and `multiplier`, an `HH:MM` window, a timezone this runtime knows — are
 * enforced by {@link resolveBalanceConfig}, which throws at load rather than
 * pricing something wrongly at the first request.
 *
 * @module @sumomok/dsh-balance/config
 */
import z from '@deepseek-ai/schemastery';
import { type GenericEndpointShape } from './generic-adapter.ts';
import { type PriceTable } from './prices.ts';
/** Which surfaces the browser half puts up. */
export interface Surfaces {
    /** The balance and spend chip beside Settings at the sidebar foot. */
    footer?: boolean;
    /** The per-session spend line under the composer. */
    sessionSpend?: boolean;
}
/** Plugin configuration. */
export interface Config {
    /** How long a successful balance read is served before a refresh is attempted. */
    refreshMs?: number;
    /** How long a failed balance read suppresses further attempts, so a broken endpoint is not hammered per open tab. */
    retryMs?: number;
    /** Wall-clock budget for one balance request. */
    timeoutMs?: number;
    /**
     * Currency codes in descending preference. One list serves two decisions:
     * which balance row to show when the account holds several, and which price
     * list to spend against before the account's own currency is known.
     */
    currency?: string[];
    /** Balance below which the chip is tinted as a warning. */
    lowBalance?: number;
    /** Balance below which the chip is tinted as critical. */
    criticalBalance?: number;
    /**
     * Show the footer chip's figure as dots rather than the amount. The popover
     * still carries the real numbers, so the amount is one hover away; this
     * keeps it off a screen being shared or recorded.
     */
    maskBalance?: boolean;
    /** Days of ledger rows to keep; older rows are dropped and the file rewritten at startup. */
    ledgerDays?: number;
    /**
     * IANA timezone the day and month spend boundaries are taken in. Empty means
     * the timezone the host process runs in.
     */
    timezone?: string;
    /**
     * Directory this plugin writes its ledger into. Empty means
     * `$DSH_HOME/dsh-balance`.
     */
    root?: string;
    /** Which surfaces the browser half puts up. */
    surfaces?: Surfaces;
    /**
     * The price lists spend is computed from, one per currency the provider
     * bills in. Replacing it re-prices every session; the shipped default
     * carries DeepSeek's published CNY and USD rates and the date they were
     * read. A deployment may add any currency its provider bills in.
     */
    prices?: PriceTable;
    /**
     * Candidate endpoint shapes the generic fallback adapter tries, in order,
     * for a provider with no dedicated adapter (any provider but DeepSeek). The
     * shipped default names the one-api/new-api user-quota convention and the
     * legacy OpenAI dashboard billing pair; a deployment whose gateway answers
     * neither can name its own instead.
     */
    genericEndpoints?: GenericEndpointShape[];
}
export declare const Config: z<Config>;
/** Configuration after defaults and cross-field checks, with nothing left optional. */
export interface ResolvedConfig {
    refreshMs: number;
    retryMs: number;
    timeoutMs: number;
    currency: readonly string[];
    lowBalance: number;
    criticalBalance: number;
    maskBalance: boolean;
    ledgerDays: number;
    /** The settled timezone; never empty. */
    timezone: string;
    /** The settled ledger directory; never empty. */
    root: string;
    footer: boolean;
    sessionSpend: boolean;
    prices: PriceTable;
    /** Candidate endpoint shapes the generic fallback adapter tries, in order. */
    genericEndpoints: readonly GenericEndpointShape[];
}
/**
 * Undo the schema's materialization of absent optional members.
 *
 * `@deepseek-ai/schemastery` resolves an omitted nested object to `{}` and an
 * omitted array to `[]`, so an absent value and an empty one are the same on
 * the way out. Both are read here as absent, which is the only reading that
 * works: a schedule whose `rates` is `{}` states no rates, and a window whose
 * `days` is `[]` would otherwise open on no day at all.
 * @param table - the schema-validated table.
 * @returns the same table with its empty optional members removed.
 */
export declare function compactPriceTable(table: PriceTable): PriceTable;
/**
 * Settle defaults and reject a configuration this plugin cannot honour.
 * @param config - the schema-validated plugin config.
 * @param homePath - resolves a path under the harness home, for the ledger default.
 * @returns the resolved configuration.
 * @throws {Error} naming the first unusable field.
 */
export declare function resolveBalanceConfig(config: Config, homePath: (...segments: string[]) => string): ResolvedConfig;
//# sourceMappingURL=config.d.ts.map