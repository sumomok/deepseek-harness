/**
 * The price tables this plugin ships with, transcribed from DeepSeek's own
 * pricing pages — one currency each, because DeepSeek bills two and publishes
 * a separate list for each.
 *
 * Sources, both read 2026-09-10:
 *
 * - CNY: https://api-docs.deepseek.com/zh-cn/quick_start/pricing, which states
 *   「空闲时段价格为高峰时段价格的一半。高峰时段为北京时间周一至周五 9:00 -
 *   12:00、14:00 - 18:00（其余为空闲时段）。」
 * - USD: https://api-docs.deepseek.com/quick_start/pricing, which states
 *   "Off-peak rates are half of the peak rates. Peak hours are 01:00 - 04:00
 *   and 06:00 - 10:00 UTC, Monday through Friday (all other hours are
 *   off-peak)."
 *
 * The two pages describe the same instants in their own timezones — 09:00
 * Beijing is 01:00 UTC — and each list is written in the zone its own page
 * uses rather than converted, so a reader can check either against its source.
 *
 * Both are expressed as the off-peak numbers in `base` plus a `peak` schedule
 * that doubles them, because the peak windows are two contiguous weekday spans
 * while the off-peak hours are their scattered complement. The resulting rates
 * are identical either way; `baseName: 'off-peak'` keeps the UI honest about
 * which tier the base is.
 *
 * Neither page prices cache-write tokens or reasoning tokens separately, so
 * both fields are left to their defaults: a cache write bills at the cache-miss
 * input rate and a reasoning token bills at the output rate.
 *
 * Both pages now list exactly two models, `deepseek-flash` and
 * `deepseek-v4-pro`. The two retired ids are priced here anyway, at the
 * `deepseek-flash` rates, on the pages' own instruction: 「旧模型名
 * deepseek-v4-flash、deepseek-v4-flash-vision-exp 仍可调用，但对应模型已下线，
 * 请求将由 DeepSeek-V4.1-Flash 模型提供服务，并按 Flash 价格计费。」 A stored
 * selection can still name one, and a request on it bills at this rate, so
 * dropping the rows would report those turns as unpriced tokens.
 *
 * TODO after 2026-09-14 12:00 Beijing: `deepseek-v4-pro` bills at the V4.1
 * Flash rates from then on — 「北京时间 2026 年 9 月 14 日 12:00 之后，至未来
 * V4.1 Pro 上线之前，您访问 deepseek-v4-pro 的请求将全部路由到 V4.1 Flash，并按
 * V4.1 Flash 价格计费。」 Switch that row in the next release; until the cutover
 * it carries the rates the pages print for it today.
 *
 * These numbers are the deployment's to maintain, and the currency set is
 * open — adding a third list is a third key under `tables`. Overriding
 * `prices` in `cordis.yml` replaces the whole table.
 *
 * @module @sumomok/dsh-balance/default-prices
 */
import type { PriceTable } from './prices.ts';
/** DeepSeek's published rates as of {@link DEFAULT_PRICES}.asOf, per 1M tokens. */
export declare const DEFAULT_PRICES: PriceTable;
//# sourceMappingURL=default-prices.d.ts.map