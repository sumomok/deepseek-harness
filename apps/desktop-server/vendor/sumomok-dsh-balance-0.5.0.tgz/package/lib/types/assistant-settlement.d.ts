/**
 * Reading one model attempt's settlement out of a durable session log.
 *
 * This package builds against the published `@deepseek-ai/dsh-*` packages,
 * whose `SessionEventMap` declares neither `assistant/attempt` — the event a
 * harness writes for an attempt that reached settlement without committing a
 * message — nor `llm/retry-started`, which `@deepseek-ai/dsh-llm-retry`
 * declares and this plugin does not depend on. A harness newer than those
 * published types writes both, and its log is a durable cross-version
 * boundary, so every field is read and checked here rather than asserted
 * through one cast of the whole payload. Retire this module once the published
 * `SessionEventMap` declares both events.
 *
 * @module @sumomok/dsh-balance/assistant-settlement
 */
import type { TokenUsage } from '@deepseek-ai/dsh-llm';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
/** One settled model attempt, whether or not it committed a message. */
export interface AssistantSettlement {
    /** The turn the attempt ran in. */
    turn: number;
    /** The step within that turn; with `turn`, the slot a retry reuses. */
    step: number;
    /** The route the settlement names itself; absent on an attempt, which records none. */
    subject?: {
        provider?: string;
        model: string;
    };
    /** The adapter's accounting for the attempt, when it reported any. */
    usage?: TokenUsage;
}
/**
 * Read one provider token accounting.
 *
 * The two totals are required — a sample without them prices nothing — and
 * each optional bucket is taken only when it is a count, so a provider field
 * this build does not know cannot reach the arithmetic.
 * @param value - the logged `TokenUsage`, unchecked.
 * @returns the accounting, or `undefined` when the value is not one.
 */
export declare function readUsage(value: unknown): TokenUsage | undefined;
/**
 * The last accounting an attempt's recorded stream carries.
 *
 * A provider reports usage as its own chunk, which the log keeps as a raw
 * `{ type: 'chunk' }` record rather than folding it into a packed text or
 * tool-call run; the scan therefore runs backwards over raw records and stops
 * at the first usage chunk it reaches. The last one wins because an adapter
 * that revises its accounting mid-stream sends the whole figure again.
 *
 * Stopping there is the point, not a shortcut: the shipped token pill reads
 * the same stream through `lastAssistantStreamChunk`, which also stops at the
 * last usage chunk and never looks past it. Falling back to an earlier chunk
 * when that one cannot be read would bill a figure the pill beside the amount
 * is not counting, so an unreadable last chunk is treated as no accounting at
 * all.
 * @param stream - the settlement's recorded stream, unchecked.
 * @returns the final accounting, or `undefined` when the stream carries none
 * or its last usage chunk is not one.
 */
export declare function lastStreamUsage(stream: unknown): TokenUsage | undefined;
/**
 * Read one settled model attempt.
 *
 * A committed message states its own accounting; an attempt that committed
 * none states it only inside the stream it recorded, and a message whose
 * adapter reported usage late states it in both. The declared `usage` wins
 * where it exists, since that is the figure the harness itself settled on.
 * @param event - the durable event.
 * @returns the settlement, or `null` for an event that settles no attempt.
 */
export declare function assistantSettlement(event: SessionEvent): AssistantSettlement | null;
/**
 * Read the slot a retry is about to reuse.
 * @param event - the durable event.
 * @returns the turn and step the next attempt will run in, or `null` for any
 * other event.
 */
export declare function retryStartedSlot(event: SessionEvent): {
    turn: number;
    step: number;
} | null;
//# sourceMappingURL=assistant-settlement.d.ts.map