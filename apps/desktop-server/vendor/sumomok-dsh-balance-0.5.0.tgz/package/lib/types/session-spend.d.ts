/**
 * Per-session spend as a pure fold over the session's own logged usage.
 *
 * The harness already writes what one attempt cost in tokens; this unit
 * multiplies it by the deployment's price table and adds it up. It appends
 * nothing, reads nothing outside the event it is handed, and performs no I/O —
 * the projection registry replays it over a session's durable log and caches
 * the result.
 *
 * Every settled attempt counts, not only the ones that committed a message: a
 * cancelled or failed attempt spent its tokens too, and the shipped token
 * pill — which this plugin's amount is shown beside — counts them. The two
 * numbers would otherwise disagree in one pill. A retried slot replaces rather
 * than adds, on the same rule the token pill uses, so a `(turn, step)` that
 * settled twice is billed once.
 *
 * @module @sumomok/dsh-balance/session-spend
 */
import type { TokenUsage } from '@deepseek-ai/dsh-llm';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import { type PriceEntry, type TokenCounts } from './prices.ts';
import type { SessionSpend, SessionSpendModel } from './types.ts';
/** The projection key this plugin owns. */
export declare const SESSION_SPEND_KEY = "balanceSessionSpend";
/**
 * A projection unit with a client view. The registry's client-visible overload
 * requires `wire`, which {@link ProjectionDefinition} leaves optional for
 * host-only units.
 */
export type ClientVisibleProjection = Omit<ProjectionDefinition<typeof SESSION_SPEND_KEY, SessionSpendState>, 'wire'> & {
    wire: NonNullable<ProjectionDefinition<typeof SESSION_SPEND_KEY, SessionSpendState>['wire']>;
};
/**
 * What one folded accounting contributed, kept so a replacement can take it
 * back exactly rather than recompute it at rates or a route that have since
 * moved on.
 */
export interface SpendEntry {
    /** Model row the cost landed in; `null` when nothing priced the attempt. */
    model: string | null;
    /** Price tier that priced it; `''` when nothing did. */
    schedule: string;
    /** Cost added to the total. */
    cost: number;
    /** Buckets added to the model row. */
    counts: TokenCounts;
    /** Tokens added to `unpricedTokens`. */
    unpriced: number;
}
/** Fold state; plain JSON, as the projection cache requires. */
export interface SessionSpendState {
    /** Cost of every priced attempt so far. */
    total: number;
    /** Per-model token buckets and cost. */
    byModel: Record<string, SessionSpendModel>;
    /** Cost split by the price tier that applied to each attempt. */
    bySchedule: Record<string, number>;
    /** Tokens no entry in the table prices. */
    unpricedTokens: number;
    /** Assistant steps folded, priced or not. */
    steps: number;
    /**
     * The route the next attempt bills to, from the last `request/context`.
     * `null` until this session logs one — an attempt that committed no message
     * names no route of its own, so that event is the only thing that can say
     * what a failed or cancelled attempt was billed at.
     */
    route: {
        provider: string;
        model: string;
    } | null;
    /**
     * The slot the last accounting landed in, and what it contributed. A second
     * accounting for the same `(turn, step)` replaces it; `llm/retry-started`
     * closes the slot so the retried attempt adds instead.
     */
    last: {
        turn: number;
        step: number;
        entry: SpendEntry;
    } | null;
}
declare module '@deepseek-ai/dsh-session-projection/types' {
    interface SessionProjectionStateMap {
        /** `@sumomok/dsh-balance` per-session spend fold state. */
        balanceSessionSpend: SessionSpendState;
    }
    interface SessionProjectionMap {
        /** `@sumomok/dsh-balance` per-session spend, priced from the deployment's table. */
        balanceSessionSpend: SessionSpend;
    }
}
/**
 * Split one step's provider accounting into disjoint billing buckets.
 *
 * `TokenUsage` counts are already disjoint on the input side — `inputTokens`
 * excludes cache traffic — but `reasoningTokens` is a subset of
 * `outputTokens`, so the generated bucket has it taken back out; a provider
 * pricing reasoning at the output rate then reaches the same total either way.
 * @param usage - the step's provider-reported accounting.
 * @returns the buckets {@link costOf} multiplies.
 */
export declare function billingBuckets(usage: TokenUsage): TokenCounts;
/** Every token in one step, priced or not. */
export declare function totalTokens(counts: TokenCounts): number;
/** What one priced step contributes. */
export interface PricedStep {
    /** Cost of the step, or `null` when the table prices no such model. */
    cost: number | null;
    /** The tier that priced it; absent when unpriced. */
    scheduleName?: string;
    /** The step's disjoint token buckets. */
    counts: TokenCounts;
}
/**
 * Price one step.
 * @param entries - the active currency's price list.
 * @param subject - the provider route and model the step ran on.
 * @param atMs - the step's logged time, in epoch milliseconds.
 * @param usage - the step's provider-reported accounting.
 * @returns the cost and tier, or an unpriced verdict.
 */
export declare function priceStep(entries: readonly PriceEntry[], subject: {
    provider?: string;
    model: string;
}, atMs: number, usage: TokenUsage): PricedStep;
/**
 * Build the projection unit for one currency's price list.
 *
 * `stateVersion` is derived from the list and its currency: a persisted fold
 * was computed at the rates that were configured then, so changing a rate — or
 * switching to another currency's list — must discard it rather than continue
 * adding to it. Editing the table in `cordis.yml`, or an account whose
 * currency turns out to be the other one, therefore re-prices every session on
 * next read.
 * @param entries - the active currency's price list.
 * @param currency - that currency's ISO 4217 code, restated on the wire.
 * @returns the registrable projection definition.
 */
export declare function sessionSpendProjection(entries: readonly PriceEntry[], currency: string): ClientVisibleProjection;
/**
 * A stable non-negative integer identifying one priced configuration under one
 * generation of the fold, used as the projection's cache-invalidation version.
 * @param entries - the active currency's price list.
 * @param currency - that currency's ISO 4217 code.
 * @returns a 31-bit FNV-1a hash of both plus {@link FOLD_VERSION}.
 */
export declare function priceTableVersion(entries: readonly PriceEntry[], currency: string): number;
//# sourceMappingURL=session-spend.d.ts.map