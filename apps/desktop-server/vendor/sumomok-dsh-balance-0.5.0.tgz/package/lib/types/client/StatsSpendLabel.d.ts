/**
 * This session's spend as the leading reading of the shipped token-usage pill.
 *
 * The seat replaces the pill's own token total, and the owner keeps drawing
 * what follows it — `· Cache hit 93%`. An occupant that renders nothing would
 * therefore leave the pill starting at a separator, so this one always renders
 * text: the amount when the session has a priced ledger, and the token total
 * the owner handed down when it has not, which is the reading the pill would
 * have shown on its own.
 *
 * @module @sumomok/dsh-balance/client/StatsSpendLabel
 */
import type { ReactNode } from 'react';
import type { UseProjection } from '@deepseek-ai/dsh-api-session-controller/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { StatsUsageOwnerProps } from './seat.ts';
import type { BalanceState } from './store.ts';
/** A `useSyncExternalStore`-backed selector hook, as the slot framework binds it. */
type BalanceHook = <S>(selector: (state: BalanceState) => S) => S;
/** Props the reading takes from its composed slot props. */
export interface StatsSpendLabelProps extends Pick<StatsUsageOwnerProps, 'totalTokens'> {
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'balance'>;
    /** The framework's projection reader for the current session. */
    useProjection: UseProjection;
    /** Selector over the browser half's own store, for the surface toggle. */
    useBalance: BalanceHook;
}
/**
 * The registered slot component.
 * @param props - composed slot props.
 * @returns the pill's leading reading; never empty.
 */
export declare function StatsSpendLabel(props: StatsSpendLabelProps): ReactNode;
export {};
//# sourceMappingURL=StatsSpendLabel.d.ts.map