/**
 * This session's spend, itemized in the token-usage dialog the pill opens.
 *
 * The seat is inside the owner's own definition list, after its token-bucket
 * rows, so this entry contributes bare `<dt>`/`<dd>` pairs and no skin,
 * wrapper, or positioning of its own. It restates none of those buckets: what
 * it adds is money — the session total, where it went per model, and which
 * price tier it was billed at.
 *
 * A breakdown group earns its rows only when it breaks something down. One
 * model, or one price tier, would print the session total a second time under
 * a different heading — and the ordinary session is one model at one tier, so
 * that is the common case, not the corner. Each group therefore appears at two
 * entries or more, on the same rule.
 *
 * @module @sumomok/dsh-balance/client/StatsSpendRows
 */
import { type ReactNode } from 'react';
import type { UseProjection } from '@deepseek-ai/dsh-api-session-controller/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { BalanceState } from './store.ts';
/** A `useSyncExternalStore`-backed selector hook, as the slot framework binds it. */
type BalanceHook = <S>(selector: (state: BalanceState) => S) => S;
/** Props the rows take from their composed slot props. */
export interface StatsSpendRowsProps {
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'balance'>;
    /** The framework's projection reader for the current session. */
    useProjection: UseProjection;
    /** Selector over the browser half's own store, for the surface toggle. */
    useBalance: BalanceHook;
}
/**
 * The registered slot component.
 * @param props - composed slot props.
 * @returns the rows, or nothing while this session has no priced usage.
 */
export declare function StatsSpendRows(props: StatsSpendRowsProps): ReactNode;
export {};
//# sourceMappingURL=StatsSpendRows.d.ts.map