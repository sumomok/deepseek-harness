/**
 * The sidebar-footer chip: the followed provider's remaining balance, and a
 * popover breaking down that balance, an explicit provider picker, and this
 * installation's spend.
 *
 * Nothing renders while the followed provider is unconfigured — no key, or an
 * endpoint this plugin may not talk to. An unconfigured deployment should see
 * the sidebar it had before installing this plugin, not a placeholder
 * explaining that a feature it did not ask for is not working. The picker
 * inside the popover is a separate, explicit choice: selecting an
 * unsupported provider there shows why, rather than hiding, because the user
 * asked to see it.
 *
 * The chip is one ordinary item in `sidebar.footer.action`, a slot other
 * plugins may also occupy: no absolute positioning, no assumption that it
 * owns the row's edge, and a measured degrade — the full "Provider ¥12.34"
 * form drops the provider name to "¥12.34" once the row is too crowded for
 * it, rather than wrapping or overflowing a sibling's box.
 *
 * A deployment that masks the balance (`spend.ui.maskBalance`) puts dots
 * where the chip's figure would be, in every string the chip renders — the
 * visible label, the tooltip, and the off-screen span the narrow-rail
 * measurement reads — so a shared or recorded screen carries no amount. The
 * popover is deliberately left alone: opening it is the deliberate act that
 * asks for the number.
 *
 * @module @sumomok/dsh-balance/client/FooterChip
 */
import { type ReactNode } from 'react';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { BalanceState } from './store.ts';
/** A `useSyncExternalStore`-backed selector hook, as the slot framework binds it. */
type BalanceHook = <S>(selector: (state: BalanceState) => S) => S;
/** Props the chip reads from its composed slot props. */
export interface FooterChipProps {
    /** Whether the sidebar renders wide content; `false` is the 56px rail. */
    wide: boolean;
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'balance'>;
    /** Selector over the browser half's own store. */
    useBalance: BalanceHook;
    /** Read both faces again for the followed provider, bypassing the host's refresh window. */
    refresh: (force: boolean) => void;
    /** Change the popover's own provider selection; `undefined` reverts to following the session. */
    selectProvider: (provider: string | undefined) => void;
}
/**
 * The registered slot component.
 * @param props - composed slot props.
 * @returns the chip, or nothing while the followed provider is unconfigured.
 */
export declare function FooterChip(props: FooterChipProps): ReactNode;
export {};
//# sourceMappingURL=FooterChip.d.ts.map