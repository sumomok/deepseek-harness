/**
 * The `settings.section` page this plugin contributes: the price table, the
 * low/critical-balance thresholds, and whether the footer chip masks its
 * figure, read and written through the settings-namespace scope every
 * settings row binds through (`ctx.settingsScope.bind`,
 * `@deepseek-ai/dsh-client-ui-settings`).
 *
 * A saved masking switch is pushed onto the chip by this page, through the
 * injected `refresh`: the chip renders the flag the last spend read carried,
 * not this settings document, so nothing else would move it before the next
 * poll tick. The thresholds and the price table reach the chip on that tick
 * instead — they change a tint and an arithmetic result, not what is on a
 * screen someone is about to share.
 *
 * Adding a currency, and editing a model's time-of-day tiers, are not
 * exposed here — only an existing currency's per-model base rates are
 * editable as rows, add/remove included. A row's own schedules and timezone
 * (when it already has them) are carried through unedited on save, never
 * dropped, and summarized as read-only text: the plugin configuration
 * (`cordis.yml`, or a direct settings-document edit) is still where a tier
 * itself is authored.
 *
 * @module @sumomok/dsh-balance/client/PriceTableSection
 */
import { type ReactNode } from 'react';
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { Config } from '../config.ts';
import type { PriceEntry } from '../prices.ts';
import type { BalanceKey } from './locales.ts';
/** Props the section reads from its composed slot props. */
export interface PriceTableSectionProps {
    /** Close the settings panel; unused here — this page has no flow that leaves settings. */
    close: () => void;
    /** The bound settings scope over this plugin's own namespace. */
    scope: SettingsScope<Config>;
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'balance'>;
    /**
     * Read the followed provider's balance and spend again. The masking switch
     * calls it with `force` after its own save so the chip stops showing the
     * amount without waiting for a poll tick: the flag rides on the spend read,
     * which the host answers straight off the ledger with no cache window, and
     * `force` is what keeps this read from being joined to an ordinary refresh
     * already in flight (`client/store.ts`). Its cost is the balance read
     * alongside it, which then bypasses the host's refresh window — one extra
     * provider call per flip of the switch.
     */
    refresh: (force: boolean) => void;
}
/** One save action's inline status, shown beside its own control. */
type SaveState = 'idle' | 'saving' | 'saved' | 'error';
/** @param state - one save action's status. @returns its copy key, or `undefined` while idle. */
export declare function saveStatusKey(state: SaveState): BalanceKey | undefined;
/** One price-table row being edited, as plain strings so an empty field stays representable. */
export interface DraftRow {
    model: string;
    provider: string;
    per: string;
    input: string;
    inputCacheHit: string;
    output: string;
    cacheWrite: string;
    reasoning: string;
    /** Carried through unedited; this form draws no control for it. */
    schedules: PriceEntry['schedules'];
    timezone: string;
}
/** @param entry - a price-table entry. @returns its editable draft. */
export declare function draftOf(entry: PriceEntry): DraftRow;
/** @returns a fresh row for "add model", with no schedules and the usual per-1M unit. */
export declare function blankDraft(): DraftRow;
/**
 * @param text - a form field's raw text.
 * @param fallback - value when the text is empty or not a number.
 * @returns the parsed number.
 */
export declare function numberOr(text: string, fallback: number): number;
/** @param draft - one edited row. @returns the {@link PriceEntry} it saves as. */
export declare function entryOf(draft: DraftRow): PriceEntry;
/**
 * The registered `settings.section` component.
 * @param props - composed slot props.
 * @returns the page, or a loading/unavailable placeholder before the first accepted section.
 */
export declare function PriceTableSection({ scope, t, refresh }: PriceTableSectionProps): ReactNode;
export {};
//# sourceMappingURL=PriceTableSection.d.ts.map