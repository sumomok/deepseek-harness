/**
 * One money figure that rolls to its new value instead of jumping.
 *
 * The session amount changes while the reader is looking at something else —
 * a step settles, the number is suddenly different, and nothing says it moved.
 * Half a second of counting is what makes the change legible, so this
 * interpolates the value and re-renders the same {@link formatSpend} output
 * each frame rather than animating a style: there is no CSS transition, no
 * colour flash, and the amount is the only thing that moves.
 *
 * Interruption restarts from what is currently on screen, not from the value
 * the last roll was heading for, so two settlements in quick succession read
 * as one continuous count rather than a jump backwards.
 *
 * @module @sumomok/dsh-balance/client/AnimatedAmount
 */
import { type ReactNode } from 'react';
/** What the figure shows, and in which currency. */
export interface AnimatedAmountProps {
    /** ISO 4217 code the amount is quoted in. */
    currency: string;
    /** The amount to show. A change from the figure on screen starts a roll. */
    value: number;
}
/**
 * The rolling figure.
 * @param props - the currency and the amount.
 * @returns the amount as {@link formatSpend} renders it this frame.
 */
export declare function AnimatedAmount({ currency, value }: AnimatedAmountProps): ReactNode;
//# sourceMappingURL=AnimatedAmount.d.ts.map