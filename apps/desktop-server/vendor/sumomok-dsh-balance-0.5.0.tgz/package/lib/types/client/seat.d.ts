/**
 * Where this session's spend is shown, and how that is decided at runtime.
 *
 * Two placements exist, and which one a build offers depends on the build:
 *
 * - `conversation.chat.stats.usageLabel` / `conversation.chat.stats.usageRows`
 *   — seats inside the shipped token-usage pill under the composer: the label
 *   seat replaces the pill's leading reading, the rows seat appends to the
 *   dialog that pill opens. Both are added by a core patch, so they exist in
 *   the fork's desktop builds and in nothing else.
 * - `conversation.composer.dock` — the stock ambient row under the composer,
 *   declared by `@deepseek-ai/dsh-client-ui-conversation`, which every
 *   composition with a conversation view has. This is where the spend goes as
 *   its own line when the patch is not there.
 *
 * **The choice is made from the live declaration ledger, not from a version
 * check.** `ctx.slots.inject(key, …)` runs its callback once per declaration
 * lifetime of `key` and never runs it at all while the key is undeclared, so
 * injecting on the patched key IS the detection: the callback firing means the
 * seat exists.
 *
 * The two pill seats are `children` of `ui-chat`'s own `stats` entry in
 * `conversation.composer.dock`, so they enter the ledger when that entry is
 * registered and stay there for as long as it is — whether or not the pill
 * itself renders, which it does not while a session has no token activity. On
 * a patched build the label seat is therefore declared from startup and the
 * dock line is never registered at all; on a stock build it is never declared
 * and the line is registered instead. Neither placement waits on a session.
 *
 * Losing the patched declaration means `ui-chat` itself was unregistered, and
 * the line comes back. That is not a running build's normal traffic: it is
 * what keeps a composition that swaps its chat view, or a plugin reload during
 * development, from leaving the spend nowhere.
 *
 * @module @sumomok/dsh-balance/client/seat
 */
/**
 * The patched seats' types, declared here because this package is the only one
 * that can: the core patch that declares them at runtime lives in the harness
 * checkout, and this plugin builds against the published packages, which do
 * not carry them. Retire this block if a published
 * `@deepseek-ai/dsh-client-ui-*` ever declares the keys itself — two
 * augmentations of one interface member must agree exactly, and the other one
 * would then be the authority.
 */
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /**
         * The leading reading of the token-usage pill, replacing the owner's own
         * token total. Added by a core patch; absent from the stock chat view.
         */
        'conversation.chat.stats.usageLabel': {
            kind: 'single';
            scope: 'session';
            owner: StatsUsageOwnerProps;
        };
        /**
         * Extra rows in the token-usage dialog's definition list, after the
         * owner's own bucket rows. Added by the same core patch.
         */
        'conversation.chat.stats.usageRows': {
            kind: 'list';
            scope: 'session';
            owner: StatsUsageOwnerProps;
        };
    }
}
/** Owner share of both token-usage seats. */
export interface StatsUsageOwnerProps {
    /** Every prompt-side billing bucket plus output over the whole durable log, exact. */
    totalTokens: number;
    /** Cache-hit share of billed input as the pill prints it (the bare number, e.g. "93"), or null when nothing was billed yet. */
    cacheHitPercent: string | null;
}
/** The seat a core patch adds for the pill's leading reading. */
export declare const STATS_LABEL_SLOT = "conversation.chat.stats.usageLabel";
/** The seat the same patch adds inside the pill's dialog. */
export declare const STATS_ROWS_SLOT = "conversation.chat.stats.usageRows";
/** The stock ambient row under the composer. */
export declare const COMPOSER_DOCK_SLOT = "conversation.composer.dock";
/** The three seats this plugin can take. */
export type SeatKey = typeof STATS_LABEL_SLOT | typeof STATS_ROWS_SLOT | typeof COMPOSER_DOCK_SLOT;
/** The one slot-service method this coordinator uses. */
export interface SeatSlots {
    /**
     * Install an effect for each declaration lifetime of a slot.
     * @param key - the seat to depend on.
     * @param callback - creates the disposer for one declaration lifetime.
     * @returns idempotent disposer for the wait and the active effect.
     */
    inject: (key: SeatKey, callback: () => () => void) => () => void;
}
/**
 * Register this session's spend in whichever seats this build declares.
 *
 * The pill seats win whenever the label seat is declared: showing the amount
 * twice — once in the pill, once on a line of its own under it — is the one
 * outcome neither placement wants. The rows seat is injected under the label
 * seat rather than beside it, so a build declaring only one of the two still
 * gets the half it declared, in either arrival order.
 * @param slots - the slot service.
 * @param register - registers the spend in one seat and returns its disposer.
 * @returns a disposer removing every injection and registration.
 */
export declare function installSpendSeats(slots: SeatSlots, register: (key: SeatKey) => () => void): () => void;
//# sourceMappingURL=seat.d.ts.map