/**
 * The browser half's stylesheet, injected as a tagged `<style>` per client instance.
 *
 * Every colour is a harness theme variable rather than a literal, so the chip
 * follows the light and dark schemes the shell already switches between.
 *
 * @module @sumomok/dsh-balance/client/styles
 */
/** Attribute marking this plugin's style tags. */
export declare const STYLE_TAG = "data-dsh-balance";
/**
 * The web client's module id for this plugin, which is its package name
 * (`BootModuleRow.id`, "Entry name == package name", in the client module
 * system's `manifest.ts`). The tag carries it as `data-plugin` from the
 * start: the module system stamps every `style` without `data-plugin` with
 * the id of whichever module materializes next, and removes a module's
 * stamped tags when that module unloads, which would take this stylesheet
 * down with an unrelated plugin.
 */
export declare const STYLE_OWNER = "@sumomok/dsh-balance";
/**
 * Put a copy of the stylesheet in the document. Each call adds its own tag
 * and its disposer removes only that tag, so a client instance that overlaps
 * another (a reload, a second mount) keeps its styles when the other one is
 * disposed; two identical copies apply exactly as one does.
 * @returns a disposer removing this call's tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map