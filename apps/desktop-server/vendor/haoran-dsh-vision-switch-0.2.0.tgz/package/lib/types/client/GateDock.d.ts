/**
 * The `conversation.composer.dock` entry: installs this session's submit
 * gate (via {@link GateRegistry.gateFor}, idempotent — see its own module
 * doc for why this is the interception point instead of a slot shadow) and
 * renders whatever the gate's status currently calls for.
 *
 * Also the source of truth for `gate.dockMounts`: the host only renders
 * `conversation.composer.dock` once a session has a turn in its history
 * (`ConversationRoot.tsx`'s `hero`/`zone` computation upstream — see
 * `GatePortal.tsx`'s module doc), so this component's own mount lifecycle
 * IS "is the dock available for this session". The effect below
 * increments/decrements that count so `GatePortal` (mounted from an
 * always-available seat) can tell whether it or this component is
 * responsible for the current status — the two route through the same
 * `selectGateSurface` so they never both render it.
 *
 * @module @haoran/dsh-vision-switch/client/GateDock
 */
import { type ReactNode } from 'react';
import type { SessionId } from '@deepseek-ai/dsh-api-remotes/client';
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { GateRegistry } from './gate-registry.ts';
import type { VisionSwitchKey } from './locales.ts';
/** Owner-supplied props this entry reads; everything else about the dock's own layout is the host's. */
export interface GateDockOwnProps {
    /** Current session id; the dock entry is session-scoped, so this is always live where it renders. */
    readonly sessionId?: SessionId | undefined;
}
/** What the component needs from the plugin install. */
export interface GateDockDeps {
    /** The registry that installs and tracks each session's gate. */
    readonly registry: GateRegistry;
    /** Translate bound to this plugin's own namespace. */
    readonly t: Translate<VisionSwitchKey>;
}
/**
 * Build the dock entry.
 * @param deps - the gate registry and this plugin's own translate.
 * @returns the component to register at `conversation.composer.dock`.
 */
export declare function createGateDock(deps: GateDockDeps): (props: GateDockOwnProps) => ReactNode;
//# sourceMappingURL=GateDock.d.ts.map