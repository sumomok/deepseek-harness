/**
 * Where the actual interception happens.
 *
 * `conversation.composer.bar`'s `keyboard` prop is package-private: the
 * slot's own `inject` callback computes it from `ui-conversation`'s internal
 * `InputHub`, and a third-party registrant at that slot cannot reproduce it
 * (confirmed by trying — `tsc` rejects a registration whose props require
 * `keyboard` without supplying an equivalent `inject`, and the only equivalent
 * needs the private hub). So this plugin does not shadow that slot at all.
 *
 * Instead: `ctx.conversation` (`IConversation`, a public service) exposes
 * `input: SessionInputResolver`, and `SessionInputResolver.for(actx)` returns
 * the *same* per-session `SessionInput` singleton `InputBar`'s own `keyboard`
 * prop wraps (`ui-conversation/apply.ts`'s `inject` returns `keyboard: shell`,
 * where `shell` is that same cached-by-session-id object). `SessionInput`
 * documents `submit` as "THE complexity sink" — the one path every send takes
 * — so replacing that one method on the object this plugin legitimately
 * obtained through the public service is the gate: `InputBar` still reads
 * `keyboard.submit` off the same object on every render, and property lookup
 * happens at call time, so it sees whatever this plugin last assigned there.
 *
 * @module @haoran/dsh-vision-switch/client/gate-registry
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionId } from '@deepseek-ai/dsh-api-remotes/client';
import type { VisionModelEntry } from '../types.ts';
import type { CatalogCache } from './catalog-cache.ts';
import type { SessionsFace } from './gate.ts';
import { type StatusStore } from './status-store.ts';
import { type GateStatus } from './submit-gate.ts';
/** The one field and the one method this plugin reads or replaces on the real `SessionInput`. */
export interface SessionInputFace {
    readonly state: {
        getSnapshot(): {
            readonly imageIds: readonly unknown[];
        };
    };
    submit(mode?: unknown): void;
}
/** The one field this plugin reads off the real `IConversation` service. */
export interface ConversationFace {
    readonly input: {
        for(actx: Context): SessionInputFace;
    };
}
/** One session's installed gate: its status store and the chooser actions bound to it. */
export interface SessionGate {
    /** The status this session's chooser/blocked/note UI renders from. */
    readonly store: StatusStore<GateStatus>;
    /**
     * How many live `GateDock` instances currently have this session's docked
     * seat mounted — incremented/decremented by `GateDock`'s own mount effect.
     * `GatePortal` reads this (`> 0`) as `selectGateSurface`'s `dockMounted`
     * argument: while it is `0`, `conversation.composer.dock` has not
     * rendered this session's entry yet (a brand new session's first
     * message — the host does not mount that slot until the session has a
     * turn in its history), so the portal fallback is responsible instead.
     */
    readonly dockMounts: StatusStore<number>;
    /** A chooser option was picked. */
    readonly pick: (entry: VisionModelEntry) => void;
    /** The chooser was dismissed. */
    readonly cancel: () => void;
}
/**
 * Lazily installs the submit gate for each session it is asked about, once,
 * and hands back the status store and chooser actions to render from.
 */
export declare class GateRegistry {
    private readonly conversation;
    private readonly scope;
    private readonly sessions;
    private readonly catalog;
    private readonly gates;
    /**
     * @param conversation - the `ctx.conversation` service.
     * @param scope - resolves a session id to its scoped context (`ctx.sessions.scope`).
     * @param sessions - the stock session calls.
     * @param catalog - this plugin's own catalog cache.
     */
    constructor(conversation: ConversationFace, scope: (sessionId: SessionId) => Context | undefined, sessions: SessionsFace, catalog: CatalogCache);
    /**
     * Ensure the gate is installed for one session, and return it.
     *
     * Idempotent per session id: the `gates` map is the sole install guard,
     * so calling this from a render body on every render costs one map lookup
     * after the first call.
     * @param sessionId - the session to gate.
     * @returns the session's gate, or undefined when the session's real input
     * facade could not be reached (no `ui-conversation`, or a scope that is not yet live).
     */
    gateFor(sessionId: SessionId): SessionGate | undefined;
}
//# sourceMappingURL=gate-registry.d.ts.map