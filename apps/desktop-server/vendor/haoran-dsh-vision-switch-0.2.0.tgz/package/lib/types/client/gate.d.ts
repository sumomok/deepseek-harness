/**
 * Send-attempt gating: resolve what a submit with images should do, using
 * the exact channel a manual model switch uses (the session's durable
 * `modelSelection` projection to read, `session.selectModel` to write — the
 * same calls the composer's own model seat makes, `ui-model-selection`'s
 * `ModelDirectory`) plus this plugin's own vision-capable catalog.
 *
 * `IApiClient` (the old flat RPC-wrapper `sessions.models()` /
 * `sessions.selectModel()` pair this file used before) is retired upstream
 * with no direct replacement: reading "the session's current model" is no
 * longer one RPC, it is the session's own durable projection, live in the
 * client without a round trip. `SessionsFace.projectedSelection` reads it
 * synchronously; only the write (`selectModel`) is still a Remote call.
 *
 * @module @haoran/dsh-vision-switch/client/gate
 */
import type { ModelSelection, SessionId } from '@deepseek-ai/dsh-api-remotes/client';
import type { SessionSelectModelRequest, SessionSelectModelValue } from '@deepseek-ai/dsh-api-session-controller/types';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import { type VisionSwitchDecision } from '../core/decision.ts';
import type { ModelPin } from '../types.ts';
import type { CatalogCache } from './catalog-cache.ts';
/** The two stock session calls this plugin drives — the identical pair the model-selection UI uses. */
export interface SessionsFace {
    /**
     * The session's current effective model selection, read from its durable
     * `modelSelection` projection — never a network round trip. Undefined
     * when the session has recorded no selection yet (a session that has
     * never sent a first message) or has no live scope.
     * @param sessionId - the session to read.
     * @returns the current selection, or undefined when not yet resolvable.
     */
    projectedSelection(sessionId: SessionId): ModelSelection | undefined;
    /**
     * Apply a model switch through the same Remote call a manual pick in the
     * model popup or the composer's model seat makes.
     * @param request - session identity and requested selection.
     * @returns the Remote result.
     */
    selectModel(request: SessionSelectModelRequest): Promise<RemoteResult<SessionSelectModelValue>>;
}
/**
 * Resolve a send-attempt decision, or `'degraded'` when either read fails,
 * or the session has no current selection to compare against yet — a broken
 * catalog RPC or an unreachable/brand-new session must never block sending
 * text, so the caller treats `'degraded'` as "proceed, exactly as the host's
 * own gate would have handled it without this plugin".
 * @param sessions - the stock session calls.
 * @param catalog - this plugin's own catalog cache.
 * @param sessionId - the session the draft belongs to.
 * @param hasImages - whether the draft carries at least one image attachment.
 * @returns the decision, or `'degraded'` on read failure.
 */
export declare function resolveGate(sessions: SessionsFace, catalog: CatalogCache, sessionId: SessionId, hasImages: boolean): Promise<VisionSwitchDecision | 'degraded'>;
/**
 * Read the session's current model selection — the same durable projection
 * the model popup and the composer's model seat both render from.
 * @param sessions - the stock session calls.
 * @param sessionId - the session to read.
 * @returns the current selection, or undefined when not yet resolvable.
 */
export declare function currentSelection(sessions: SessionsFace, sessionId: SessionId): ModelSelection | undefined;
/**
 * Perform the switch — the identical call a manual pick in the model popup
 * or the composer's model seat makes, so the result is session-sticky with
 * no separate persistence path of this plugin's own.
 * @param sessions - the stock session calls.
 * @param sessionId - the session to switch.
 * @param target - the provider/model to select.
 * @throws when the host rejects the switch.
 */
export declare function applySwitch(sessions: SessionsFace, sessionId: SessionId, target: ModelPin): Promise<void>;
//# sourceMappingURL=gate.d.ts.map