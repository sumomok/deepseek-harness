/**
 * A minimal `SnapshotStore`-shaped observable (`getSnapshot`/`subscribe`/
 * `set`) for one session's gate status.
 *
 * `@deepseek-ai/dsh-client-store` ships the real `SnapshotStore` engine, but
 * importing its *value* export (`createSnapshotStore`, not just the type)
 * runs that package's whole pre-built browser bundle at module load, which
 * touches `window` at the top level and throws in a plain Node/vitest run —
 * every real consumer only ever imports it from inside an actual browser
 * bundle. This plugin's status is one small tagged union set wholesale on
 * every transition (never a partial mutation), so the engine's
 * immer/zustand/persist machinery buys nothing here; this is the whole
 * store, not a trimmed copy of a larger one.
 *
 * @module @haoran/dsh-vision-switch/client/status-store
 */
/** The subset of `SnapshotStore<T>` this plugin actually uses. */
export interface StatusStore<T> {
    getSnapshot(): T;
    subscribe(listener: () => void): () => void;
    set(next: T): void;
}
/**
 * Create a status store.
 * @param initial - the initial value.
 * @returns the store.
 */
export declare function createStatusStore<T>(initial: T): StatusStore<T>;
//# sourceMappingURL=status-store.d.ts.map