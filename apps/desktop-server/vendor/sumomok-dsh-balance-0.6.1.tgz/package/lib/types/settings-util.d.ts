/**
 * Small settings-reading helpers shared by every adapter that resolves a
 * provider's connection facts from another plugin's untyped settings.
 *
 * @module @sumomok/dsh-balance/settings-util
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Where a resolver reads another plugin's profile entry values from: the
 * adapter registry passes one {@link SettingsSnapshot} to every resolver it
 * builds, so the resolvers of one read share one `describe()` call.
 */
export interface SettingsSource {
    /**
     * @param entryId - the profile entry id (a configurable provider's `settingsNs`).
     * @returns the entry's volatile values, with {@link entryValue}'s absence cases.
     */
    entryValue(entryId: string | undefined): unknown;
}
/**
 * The {@link SettingsSource} that calls `describe()` on every read, used by a
 * resolver built without the registry's shared snapshot.
 * @param ctx - the plugin context.
 * @returns the per-call source.
 */
export declare function liveSettingsSource(ctx: Context): SettingsSource;
/**
 * One held `ctx.settings.describe()` result shared by every read until it is
 * invalidated or reaches its maximum age.
 *
 * On dsh 0.1.7 `describe()` is synchronous and recomposes every profile
 * layer, tens of milliseconds per call on a desktop profile, and a provider
 * picker read resolves every candidate provider; calling it per resolver
 * blocked the Host event loop for more than a second per read.
 *
 * The plugin calls {@link invalidate} on `settings/document-updated` and
 * `llm/adapters-updated`. The settings service emits
 * `settings/document-updated` from inside `describe()` when it sees a changed
 * entry, and every settings write ends with a `describe()` call, so an edit
 * made through the settings service invalidates the snapshot as it commits. A
 * profile change that no `describe()` call has observed yet emits nothing;
 * the maximum age bounds how long such a change can go unread.
 */
export declare class SettingsSnapshot {
    private readonly ctx;
    private readonly maxAgeMs;
    private readonly now;
    private rows;
    private takenAt;
    private takenGeneration;
    private generation;
    /**
     * @param ctx - the plugin context.
     * @param maxAgeMs - how long one `describe()` result is served; the plugin's `refreshMs`.
     * @param now - epoch milliseconds.
     */
    constructor(ctx: Context, maxAgeMs: number, now: () => number);
    /**
     * Drop the held result, so the next read calls `describe()` again. The rows
     * carry unredacted entry values, so they are released here rather than
     * kept until that next read.
     */
    invalidate(): void;
    /**
     * @param entryId - the profile entry id (a configurable provider's `settingsNs`).
     * @returns the entry's volatile values, with {@link entryValue}'s absence cases.
     */
    entryValue(entryId: string | undefined): unknown;
    /** The held rows, or a fresh `describe()` result when none is valid; `undefined` without a settings service. */
    private current;
}
/**
 * The live settings of another plugin's profile entry: the entry's volatile
 * fields as `ctx.settings.describe()` lists them, unredacted.
 *
 * Every call runs `describe()`; reads that resolve several providers share a
 * {@link SettingsSnapshot} instead.
 * @param ctx - the plugin context.
 * @param entryId - the profile entry id (a configurable provider's `settingsNs`).
 * @returns the entry's volatile values, or `undefined` without a settings
 *   service, without an id, or while that entry is not listed (not active, or
 *   carrying no volatile field).
 */
export declare function entryValue(ctx: Context, entryId: string | undefined): unknown;
/** Read one optional string from an untyped settings section. */
export declare function optionalString(value: unknown): string | undefined;
/**
 * Walk a settings section down to one provider's profile object.
 * @param section - the entry's live values ({@link entryValue}), or `undefined` while unlisted.
 * @param path - path from the section root to the profile; empty means the whole section.
 * @returns the profile object, or `undefined` when the path does not resolve to one.
 */
export declare function profileAtPath(section: unknown, path: readonly string[]): Record<string, unknown> | undefined;
/**
 * Derive the conventional credential reference for a provider route, matching
 * the Models settings page's own derivation exactly (`ui-settings-models`):
 * a typed key with no explicit `apiKeyEnv` stores under this reference, so a
 * profile naming none must resolve to the same name here.
 * @param provider - provider route id (e.g. `anthropic`, `minimax-cn`).
 * @returns the derived reference name (e.g. `MINIMAX_CN_API_KEY`).
 */
export declare function deriveKeyRef(provider: string): string;
//# sourceMappingURL=settings-util.d.ts.map