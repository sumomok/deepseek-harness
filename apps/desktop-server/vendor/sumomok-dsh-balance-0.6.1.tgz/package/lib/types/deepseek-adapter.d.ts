/**
 * The DeepSeek member of the adapter registry: resolves the connection facts
 * `readBalance` needs, reading settings through the settings source it is
 * given and the launch environment and the credential seam on every call, so
 * a rotated key or an edited endpoint reaches the next poll without a restart.
 *
 * @module @sumomok/dsh-balance/deepseek-adapter
 */
import type { Context } from '@deepseek-ai/cordis';
import { type BalanceRequest } from './balance.ts';
import type { ResolvedConfig } from './config.ts';
import { DEEPSEEK_PROVIDER_ID } from './provider-id.ts';
import { type SettingsSource } from './settings-util.ts';
/**
 * Build the resolver the balance reader calls before every read.
 *
 * The key is resolved per call and settings are read through `settings` per
 * call, both on purpose: a key rotated through the Models page, or an endpoint
 * changed in settings, reaches the next read without restarting anything (the
 * registry's shared {@link file://./settings-util.ts} snapshot is invalidated
 * by the settings service's change event).
 *
 * The provider's settings are found the way every other adapter finds them:
 * `ctx.llm`'s configurable-provider directory names the profile entry that
 * configures `deepseek-official` (`llm-deepseek` in the shipped composition,
 * mounted by `@deepseek-ai/dsh-llm-deepseek-api-key`), and that entry's live
 * `apiKeyEnv` and `baseURL` are read from `ctx.settings.describe()`'s rows. Without a
 * directory entry the launch environment and the public endpoint decide.
 * @param ctx - the plugin context.
 * @param config - the resolved plugin config.
 * @param settings - where the entry's values are read; per-call `describe()` when omitted.
 * @returns a resolver yielding the next read's facts, or `null` while unconfigured.
 */
export declare function providerResolver(ctx: Context, config: ResolvedConfig, settings?: SettingsSource): () => Promise<BalanceRequest | null>;
export { DEEPSEEK_PROVIDER_ID };
//# sourceMappingURL=deepseek-adapter.d.ts.map