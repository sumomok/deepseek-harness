# @haoran/dsh-vision-switch

[English](README.md) | 中文

桌面内部使用，不发布。当会话当前模型不支持图片时发送一条带图片的消息，harness 自身在 `session.prompt` 处的闸门会直接拒绝发送——这是一个死路，发送者没有任何后续可走。本插件用一次切换替代这个死路：在发送离开浏览器之前，通过与手动切换模型完全相同的通道，把会话切到一个支持图片的模型，再放行发送。它从不触碰 host 的闸门——它存在的意义就是让带图片的发送根本不会触发那道闸门。

## 发送时发生什么

1. **默认目标模型在目录中** —— 切换到它并发送。默认目标是 `deepseek-official` 上的 `deepseek-v4-flash-vision-exp`，与 `@haoran/dsh-default-model` 让每个新会话起步所用的模型相同。部署可以用 `Config.target` 指定另一个 `{provider, model}`。
2. **默认目标不存在，但目录中还有其他支持图片的模型** —— 弹出一个小选择器：「当前模型不支持图片，选择一个支持图片的模型继续」，按显示名列出其余模型。选中一个即切换并发送；关闭选择器则中止发送，草稿保持不变。
3. **目录中根本没有支持图片的模型** —— 「当前没有可用的支持图片的模型」，草稿保持不变，不做任何切换尝试。

切换发生后，composer 附近会出现一条几秒钟的淡提示：「已切换到支持图片的模型：\<名称\>」。这次切换是会话级持久的——用的正是模型选择弹窗里手动选择所调用的同一个 `sessions.selectModel`——且没有任何自动还原到之前模型的机制。

**在常见路径上零干扰。** 草稿里没有图片，或当前模型本来就支持图片：什么都不会运行，什么都不会查询，发送行为和没装这个插件时完全一样。

## 为什么需要 host 半——不同于部分兄弟插件

浏览器端本来无法得知哪些模型支持图片。客户端已经能访问的两个 RPC——`session.models` 和 `llm.models`——在传输时都丢弃了 `inputModalities`；只有 host 自己的 `ctx.llm.resolveModelInfo` 才带着这个字段。所以本插件带了一个很小的 host 半，它唯一的工作就是一次读取：一个 Typert Remote（`visionSwitch/catalog`），构建方式与那两个 RPC 构建目录的方式相同，只是保留了它们省略的那一个字段。这个 host 半同时携带真正的 `Config`（`enabled`、`target`），浏览器半通过同一个 Remote 读取它——本插件不需要走 `@sumomok/dsh-text-drop` 那种「客户端插件收不到配置，退回导出常量」的变通方案，因为带 Config 的 host 半让浏览器能够读到一份真实的、随 cordis.yml 变化的配置。

## 发送拦截点

`conversation.composer.bar` 虽是单一种类（single-kind）槽位，却无法像 `@sumomok/dsh-text-drop` 遮罩 `conversation.input.attachments` 那样被遮罩：这个槽位的 `keyboard` prop 是包内私有的，由 `ui-conversation` 自己的 `inject` 从其私有的 `InputHub` 计算得出，第三方注册者无法复现它——声明这个槽位的 props 却拿不出这个私有面时，`tsc` 会直接拒绝编译。

本插件转而从一扇公开的门进入同一个对象。`ctx.conversation.input`（`IConversation.input`，一个 `SessionInputResolver`）是文档化的公开服务，`SessionInputResolver.for(actx)` 返回的正是 `InputBar` 自己的 `keyboard` prop 所包装的那个同一份、按会话缓存的 `SessionInput` 单例——两条路径都会走到 `InputHub` 内部同一个按会话 id 缓存的表，因此它是同一个对象，不是副本。`SessionInput.submit` 是 harness 自己所说的「复杂度汇点」：从回车键、发送按钮，到其它插件已经在用的公开 `inputActions.submit()`，每一次发送最终都会在这同一个对象上调用 `submit`。本插件替换的正是这一个方法，而且是替换在通过公开服务合法拿到的这个对象上（`client/gate-registry.ts` 里的 `gateFor`）：在转发给原始 `submit` 之前，先读草稿的附件 id，若草稿带着附件且当前模型不支持图片，就先解决切换（或弹出选择器，或阻止发送）。composer 的其余部分——布局、文本框、每一个其他控件、这个对象上的每一个其他方法——都未被触碰。

闸门装在 facade 实例上，而不是会话 id 上，并且每个实例最多装一次。`InputHub` 会随作用域一起丢弃该会话的 `SessionInputShell`，会话重新物化时再建一个新的，因此 `gateFor` 会把自己改写过的那个实例与解析器此刻交回的实例作比较：新实例会被改写，已经带着本闸门的实例绝不会被再包一层（在控制器剪掉作用域记录、而 fiber 自己尚未 dispose 的那一瞬，facade 可以比作用域记录活得更久；闸门套闸门会让一次发送把整套切换跑两遍）。它在那里读的字段，其类型取自 `@deepseek-ai/dsh-client-ui-conversation` 的 `InputState['attachmentIds']`，所以宿主一旦改名该字段，本包的 `tsc` 就会失败，而不是在运行中的输入框里抛错；并且替身可能遇到的每一种失败——读状态、目录判定、状态回调——都会把这次发送转交给原始的 `submit`，而不是抛出：`submit` 一抛错，发送按钮、Enter 与 Cmd+Enter 就全都没有反应。原始 `submit` 每次尝试最多只被调用一次：它在把发送交出去之后还会继续做事（收起命令弹层、重新跟踪输入触发器，两者都可被其它插件接管），因此从它那里抛回来的错误只会打到浏览器控制台，绝不会用第二次发送去回应。急切安装还会等到宿主真正列出该会话之后（`phase: 'ready'`，且 `byId` 中有对应行）：仅凭 `current` 去解析作用域，会凭空铸出一个控制器从未上台的作用域，下一次列表发布就会把它连同闸门刚改写过的那个 shell 一起剪除。

**算数的是任意附件，不只是图片。**输入状态只发布草稿的附件 id，别的什么都没有；而本插件持有的服务面（`IConversation`）没有任何把 id 解析成种类的方法——解析住在 `ConversationController` 类上，而 `ctx.conversation` 的类型并不是它，本插件也不越过自己的服务面去够。所以在不支持图片的模型上挂一个 PDF 或 `.zip`，走的是和图片完全相同的那条路：自动切到目标模型，或弹出选择器，或阻止发送。宿主本来就把两种附件放进同一份 `attachmentIds` 列表，因此这里判断得过宽的代价是一次没人需要的模型切换，而不是一次被拒的发送。

## 第一条消息的降级方案

选择器、阻止提示、切换提示渲染所在的 `conversation.composer.dock`，只有在会话已经有过一轮真实对话之后才会挂载——一个全新会话的第一条消息因此没有 dock 可画。情形 1（自动切换）不受影响：发送本身照常进行，dock 稍后挂载出来后切换提示会正常渲染。情形 2 和情形 3 会在任何一轮对话存在之前就把发送按住不放，如果没有降级方案，这次点击就会什么都看不见。

`GatePortal.tsx` 注册在始终会挂载的 `conversation.input.dock` 位置，补上了这个缺口：只要当前会话的 dock 还没挂载，它就会通过 `react-dom` 的 `createPortal` 把同样的选择器/阻止提示/切换提示渲染到 `document.body` 上。`fallback-surface.ts` 里的 `selectGateSurface` 负责判断某个状态该由 dock 还是 portal 这两个渲染面中的哪一个负责，因此二者永远不会同时渲染同一个状态。portal 选择器可以用 Escape 键或点击外部关闭，效果与它自己的取消按钮相同——中止发送，草稿保持不变；portal 的阻止提示没有可点的关闭控件，出现几秒后会自动消失。这个手法借鉴了 `@sumomok/dsh-text-drop` 的 `DragHintStrip`：一个嵌套在 composer 自身 DOM 子树深处的 `position: fixed` 元素，能画出背景色，却无法在 host 的 `backdrop-filter` 图层之上画出自己的文字——这正是 portal 要直接指向 `document.body`、而不是原地叠一个高 z-index 的原因。

## 配置

```yaml
- id: vision-switch
  name: '@haoran/dsh-vision-switch'
  config:
    enabled: true
    # target:
    #   provider: deepseek-official
    #   model: some-other-vision-model
```

| 字段 | 默认值 | 含义 |
| --- | --- | --- |
| `enabled` | `true` | `false` 时只保留 host 自身的闸门行为——本插件什么都不做。 |
| `target` | 未设置 | 指定 case 1 自动切换的目标。未设置时解析为 `deepseek-official` / `deepseek-v4-flash-vision-exp`。若指定的目标不在目录中，会退回选择器（case 2），并在 host 端记一条警告日志。 |

profile 自身 `cordis.patch.yml` 中按 id 定位的补丁会**整体替换 `config` 块**——如果追加了 `target`，记得把 `enabled` 一并写上。

## 设置页

设置区是只读的（以 screenshot 插件自身的设置区为先例），展示插件是否启用、解析出的目标模型及其当前是否在目录中、以及目录里共有多少个支持图片的模型。它没有开关：`enabled`/`target` 是从 `cordis.yml` 一次性解析出来的 `Config` 字段，不是一份实时的 `settings` 文档，为它们搭一条写入通道需要一整套本插件其他地方都用不到的机制。要更改它们，请编辑 `cordis.yml`。

## 本插件不做什么

**回合中途的 `read_image` 仍然需要先处于一个支持图片的模型。** 本插件只把关客户端自身的发送尝试，不触碰 agent 的工具调用路径。如果 agent 在回合中途、在纯文本模型上调用 `read_image`，那次调用依旧会像今天一样失败。

**没有自动还原。** 一旦切换，会话会一直停留在支持图片的模型上，直到别的东西改变它——本插件从不主动切回去。

**没有闸门的非桌面 host 行为完全一致。** 本插件的判断只依据草稿本身携带的图片附件和模型目录，从不依据某个 host 是否强制那道拒绝——它在任何闸门存在之前就已经动作了。

## 安装

```sh
pnpm run build
cd packages/vision-switch && pnpm pack --pack-destination /tmp
dsh plugin --profile <name> add /tmp/haoran-dsh-vision-switch-0.1.0.tgz
```

关于基于 tarball 的 profile 安装方式，以及为什么不能使用 `link:` 依赖，见 workspace 根 README。

## 开发

```sh
pnpm run build
pnpm run typecheck
pnpm run test
```
