/**
 * Where the actual interception happens.
 *
 * `conversation.composer.bar`'s `keyboard` prop is package-private: the
 * slot's own `inject` callback computes it from `ui-conversation`'s internal
 * `InputHub`, and a third-party registrant at that slot cannot reproduce it
 * (confirmed by trying — `tsc` rejects a registration whose props require
 * `keyboard` without supplying an equivalent `inject`, and the only equivalent
 * needs the private hub). So this plugin does not shadow that slot at all.
 *
 * Instead: `ctx.conversation` (`IConversation`, a public service) exposes
 * `input: SessionInputResolver`, and `SessionInputResolver.for(actx)` returns
 * the *same* per-session `SessionInput` singleton `InputBar`'s own `keyboard`
 * prop wraps (`ui-conversation/apply.ts`'s `inject` returns `keyboard: shell`,
 * where `shell` is that same cached-by-session-id object). `SessionInput`
 * documents `submit` as "THE complexity sink" — the one path every send takes
 * — so replacing that one method on the object this plugin legitimately
 * obtained through the public service is the gate: `InputBar` still reads
 * `keyboard.submit` off the same object on every render, and property lookup
 * happens at call time, so it sees whatever this plugin last assigned there.
 *
 * @module @haoran/dsh-vision-switch/client/gate-registry
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionId } from '@deepseek-ai/dsh-api-remotes/client';
import type { InputState, SessionInput } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { VisionModelEntry } from '../types.ts';
import type { CatalogCache } from './catalog-cache.ts';
import type { SessionsFace } from './gate.ts';
import { type StatusStore } from './status-store.ts';
import { type GateStatus } from './submit-gate.ts';
/** The one field and the one method this plugin reads or replaces on the real `SessionInput`. */
export interface SessionInputFace {
    readonly state: {
        getSnapshot(): Pick<InputState, 'attachmentIds'>;
    };
    submit(mode?: unknown): void;
}
/** Constrains a real facade type to the face above. */
type Conforms<T extends SessionInputFace> = T;
/**
 * The real facade this plugin patches, constrained to `SessionInputFace`: a
 * rename or retype of `state.getSnapshot().attachmentIds` or of `submit` in
 * `@deepseek-ai/dsh-client-ui-conversation` fails `tsc` here rather than
 * throwing inside a live composer, where the throw would sit on the first
 * line of the replaced `submit` and take every send with it.
 */
export type GatedSessionInput = Conforms<SessionInput>;
/** The one field this plugin reads off the real `IConversation` service. */
export interface ConversationFace {
    readonly input: {
        for(actx: Context): SessionInputFace;
    };
}
/** One session's installed gate: its status store and the chooser actions bound to it. */
export interface SessionGate {
    /** The status this session's chooser/blocked/note UI renders from. */
    readonly store: StatusStore<GateStatus>;
    /**
     * How many live `GateDock` instances currently have this session's docked
     * seat mounted — incremented/decremented by `GateDock`'s own mount effect.
     * `GatePortal` reads this (`> 0`) as `selectGateSurface`'s `dockMounted`
     * argument: while it is `0`, `conversation.composer.dock` has not
     * rendered this session's entry yet (a brand new session's first
     * message — the host does not mount that slot until the session has a
     * turn in its history), so the portal fallback is responsible instead.
     */
    readonly dockMounts: StatusStore<number>;
    /** A chooser option was picked. */
    readonly pick: (entry: VisionModelEntry) => void;
    /** The chooser was dismissed. */
    readonly cancel: () => void;
}
/**
 * Lazily installs the submit gate on each session's current input facade and
 * hands back the status store and chooser actions to render from.
 */
export declare class GateRegistry {
    private readonly conversation;
    private readonly scope;
    private readonly sessions;
    private readonly catalog;
    private readonly gates;
    /**
     * Every facade this registry has patched, with the gate installed on it.
     * A facade is patched at most once for as long as it lives: the id-keyed
     * map above is dropped whenever a scope stops resolving, which the
     * controller can do for a facade that is still live and still wrapped
     * (the window between `pruneScopes` deleting the scope record and the
     * fiber's own dispose), and wrapping a gate around a gate there would run
     * the whole switch twice for one send. Weakly held, so a facade that dies
     * with its scope takes its entry with it.
     */
    private readonly installed;
    /**
     * @param conversation - the `ctx.conversation` service.
     * @param scope - resolves a session id to its scoped context (`ctx.sessions.scope`).
     * @param sessions - the stock session calls.
     * @param catalog - this plugin's own catalog cache.
     */
    constructor(conversation: ConversationFace, scope: (sessionId: SessionId) => Context | undefined, sessions: SessionsFace, catalog: CatalogCache);
    /**
     * Ensure the gate is installed on the session's *current* input facade, and
     * return it.
     *
     * Idempotent per facade instance, not per session id: `SessionInputShell`
     * rides the session scope (`ui-conversation`'s `InputHub` drops it in the
     * scope disposer and builds a new one when the session is rematerialized),
     * so the cache entry carries the instance it patched and a fresh instance
     * is patched again — while a facade already carrying this registry's gate
     * keeps it and is never wrapped a second time. Calling this from a render
     * body on every render costs the hub's own session-keyed lookup plus one
     * map lookup.
     * @param sessionId - the session to gate.
     * @returns the session's gate, or undefined when the session's real input
     * facade could not be reached (no `ui-conversation`, or a scope that is not yet live).
     */
    gateFor(sessionId: SessionId): SessionGate | undefined;
    /**
     * Replace one facade's `submit` with the gated one and build the gate that
     * renders from it.
     * @param sessionId - the session the facade belongs to.
     * @param sessionInput - the facade to patch; never one already patched here.
     * @returns the installed gate.
     */
    private install;
}
export {};
//# sourceMappingURL=gate-registry.d.ts.map