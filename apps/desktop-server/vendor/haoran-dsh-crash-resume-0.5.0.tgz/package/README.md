# @haoran/dsh-crash-resume

English | [中文](README.zh.md)

When the app exits unexpectedly in the middle of a turn, the next launch continues that turn once. When continuing could do harm, the conversation keeps one grey line instead, 「已中断 · <reason>」 / "Interrupted · <reason>", with a 「继续」 / "Continue" text button at its end that continues the turn when you press it; sending a message works too. In the chat, the work of the interrupted turn and of the turn that continued it is shown unfolded, the interrupted turn's header reads 「已中断」 / "Interrupted", and under a turn the plugin held or continued the chat's own 「任务已停止」 / "Task stopped" line is left out, so a held turn reports its stop in one line, the plugin's.

Display name: 崩溃恢复 / Crash recovery (working name, pending approval).

## What happens at the next launch

An interrupted turn is a turn the server's exit cut short, in one of two forms. Either the log stops inside the turn, because the server died before the turn's closing events reached storage, or the log's last turn ended `aborted` with cause `disposed`, which the host logs when its shutdown cancels a running turn, and no turn follows it. A turn you stopped yourself ends `aborted` with cause `user` and is never interrupted; neither is a turn an agent-loop reload ended while the server kept running (see [How it knows](#how-it-knows)).

| The interrupted turn… | Result |
| --- | --- |
| was an ordinary turn a person started | continued once, after the app reports it is ready |
| had asked for an approval nobody answered | held: `awaiting-approval` |
| had a question tool waiting for an answer (`ask_user_question`, `exit_plan_mode`, configurable) | held: `awaiting-answer` |
| was itself a continuation, automatic or one you asked for, or carries no message at all and follows an interrupted turn | held: `already-resumed` |
| was started by a person in a session whose goal is active | held: `goal-active` |
| was cut short by a stop request (the app was quit or restarted) | held: `stopped` |
| belongs to a subagent or an archived session, or was opened by a goal round, a schedule, or a job notice | left exactly as it is |

Continuing a turn that waited on a person would turn the wait into a refusal or an unanswerable question. Continuing a continuation again without asking could repeat the crash forever: restart, continue, crash. `turn/start` is logged before the turn's message, so a continuation that died between the two leaves a turn with no message; such a turn after an interrupted one is held for the same reason. A scheduled turn that died at the same point gets the same line, and nothing runs.

The goal service disarms every goal when an agent is created for its session, so after a restart no driver continues a goal until a person resumes it. An automatic continuation of a turn in such a session would work toward the goal without that consent, so the turn is held. A goal round's own turn is not a person's and is left as it is.

When more than one reason applies, the line names the first in the table's order.

## The Continue button

Every held line has the button, whatever its reason. Pressing it sends the same kind of continuation message the automatic path sends, with its own text: it says the turn was cut short when the app exited or restarted, that you chose to continue, that in-flight tool calls were closed with unknown results, and that an approval or question the turn was waiting for no longer applies. It names no tool. A tool call the model makes after that is a new call and is approved like any other.

The button asks the host, through the `crashResume/continueHeld` Remote, and the host decides. It sends the message only when the session is still exactly where the interruption left it: no turn running, nothing waiting in its inbox, and its log ending with the end of the interrupted turn. It checks this when it opens the session and again after flushing it, with no wait between that last check and the send, so a message you sent first always wins.

| The host answers | The line shows |
| --- | --- |
| `sent` | the button stays disabled and reads 「正在继续…」 / "Continuing…" until the new turn appears |
| `busy` or `settled`: a turn is running, a message is queued, or the session is already past the interrupted turn | after the button, in red: 「会话已经有了新的进展，没有从这里继续」 / "The session has moved on, so it was not continued" |
| `unopened`: the session could not be opened | after the button, in red: 「会话暂时打不开，没有继续，请稍后再试」 / "The session could not be opened, so it was not continued; try again later" |
| `archived`: the session is archived, and an archived session runs no model step | after the button, in red: 「这个会话已归档，没有继续」 / "This session is archived, so it was not continued" |
| the call did not reach the host, was refused, or the answer was unknown | after the button, in red: 「没能继续，请稍后再试」 / "Could not continue; try again later" |

After a refusal the button can be pressed again. The button is also disabled while the session runs or holds a message you sent that the host has not taken yet. Once any later turn exists, whether the button or your own message started it, the line stays without the button. The row reads this from the conversation itself, so it shows the same after a reload.

- **Active goal.** Continue picks up only the interrupted turn; the goal stays paused until you resume it. The line's reason says that the session's goal is paused.
- **A continuation that crashes again.** It carries this plugin's message, so the next launch holds it as `already-resumed`, and it is continued again only if you press the button again.
- **During startup.** The host provides the Remote only once this plugin's startup pass has finished. A press before that reads "Could not continue"; pressing again a moment later works.

## How it knows

**Which sessions to look at.** While it runs, each server process keeps its own registry, `$DSH_HOME/crash-resume/in-flight/<pid>.json`: the ids of top-level sessions whose turn started and has not ended. It adds an id on `turn/start`, observed on the host's `session/event` stream. On `turn/end` it first flushes the session, because storage batches appends and a crash inside that window would leave an open turn no registry lists; it removes the id once the flush completes, unless a new turn started meanwhile. A turn end logged as `aborted` with cause `disposed` is handled apart: while the server shuts down, the id stays, so the next launch examines the turn; while the server keeps running, an agent-loop reload ended the turn, and the id is removed at once, because the reload has already closed the session's handle. Each write replaces the file atomically (uniquely named temporary file, fsync, rename, directory fsync); writes from a plugin reloaded from the same module instance are queued after the previous load's, and a disposed load writes nothing more. At startup the plugin reads the registries whose writers are gone and the one named by its own pid, and reads only the listed sessions, completely, through the persistence service. The session store is never scanned, older-format sessions are never opened, and the backend's directory layout is never used. A damaged registry means the sessions it listed are not recovered; the plugin says so in the log.

**Two servers on one home.** One registry per process, rather than one shared file under a lock file, means neither server overwrites the other's entries and a crashed server's lock is never left behind. A registry whose writer still runs is left alone. Two servers that start at the same moment can both read the same dead registry; the session store's single-writer ownership decides which one continues or marks each session.

**When a registry's writer is gone.** A pid alone is not enough: after a reboot, or after the pid wraps around, an unrelated live process can hold the same number. Each registry therefore records the machine's boot time (`Date.now()` minus Node's `os.uptime()`, which on macOS matches `sysctl kern.boottime`) and a heartbeat the server rewrites every quarter of `staleRegistryMs`. A registry counts as dead when no process has its pid, when its boot time differs from the current one by more than a minute, or when its heartbeat is older than `staleRegistryMs`. The last rule covers a pid reused within one boot; it can also take over the registry of a live server that did not run for that long, such as one on a machine that slept, and the session store's single-writer ownership then keeps the two from writing the same session.

**A turn the host's shutdown ended.** Its log's last turn ended `aborted` with cause `disposed`, and no turn follows it. It is taken up as interrupted only when a registry of a process that is gone listed the session. The registry named by this process's own pid can also be one that an earlier load of the plugin in this same process wrote; a session only that registry listed is left as it is, because an agent-loop reload inside this running process ended its turn, and reloading the plugin afterwards must not hold or continue it. The loads of the plugin that run from one module instance share the record of which registry files the process has written; a module instance loaded anew starts with an empty record (see [Known limitations](#known-limitations)). A turn a startup has already held is neither held a second time nor continued at a later launch, because the held marker naming the turn follows its end.

**Order at startup.** This process's registry, listing every candidate, is written before any log is read. Held markers are written next. The registries read at startup and the sentinel are deleted last. A session to continue stays listed until its continuation's own turn ends, and one that could not be opened stays listed for the next launch. A crash at any point therefore leaves the next launch the same candidates and the same stop fact.

**Whether it was a crash.** The log does not say whether a quit or a crash cut a turn short. On Windows the desktop shell force-kills the server, and the turn stays open in the log, as after a crash. On macOS the server shuts down, and from DeepSeek Harness 0.2.1-alpha.3 on the result depends on what the turn was doing: a turn waiting for the model, or running a tool that returns as soon as it is cancelled, ends `aborted` with cause `disposed`, the same end a fatal error leaves; a turn whose tool takes longer to stop loses its closing events and stays open. So a deliberate stop is recorded outside the log, in `$DSH_HOME/crash-resume/intentional-stop.json`. This plugin writes it synchronously from its own `SIGTERM`, `SIGINT` and `SIGHUP` listeners (`SIGHUP` is what a closing terminal sends to `dsh web`), which run in the same signal emit as the launcher's before any teardown starts. Nothing else in the server writes it: a fatal error (an uncaught exception or unhandled rejection, which the launcher turns into a disposal and exit code 1), a disposal without a stop request, and a plugin reload leave none, so a turn cut short by a fatal error is continued. The three listeners change no exit behavior: the launcher's own listeners still decide the exit code, and when no other listener handles the signal the plugin removes its listeners and raises the signal again, so the process still ends by it. The desktop shell writes the same file, in the same format, before it force-kills the server on Windows (reason `quit`, `update` or `shutdown`). The next launch holds every interrupted turn it finds while the sentinel is present, and deletes the sentinel after it has written the held markers.

**Whether it was already continued once.** The continuation is an ordinary logged `user/message` whose `source.kind` is `plugin:crash-resume`. The model reads it, and the log keeps it, so the next launch can see it. The rule counts on the log alone, never on memory that dies with the process.

## What it writes into a session

- **The continuation message.** Model-visible, in the language chosen in Settings, read from the same place the desktop shell's boot page reads it, at the moment the message is sent. The text says that the app exited mid-turn, that in-flight tools were closed with unknown results, and that a partial action must be checked before it is repeated. It names no tool. The chat shows it as a collapsed row titled "Continued after an unexpected exit" rather than as something you typed.
- **The continuation you asked for.** The same kind of message, with the `continue*` texts. Its source also carries `trigger: 'person'`, and the chat titles its row 「你确认后继续了上一轮」 / "Continued the previous turn at your request". A message without `trigger`, which includes every message a version before 0.4.0 wrote, reads as automatic; a version before 0.4.0 shows a continuation you asked for with the automatic title.
- **The held marker.** A `plugin:crash-resume/held` event carrying only `interruptedTurn` and `reason` (plus `turn: null`, which the browser's conversation index reads as "between turns"), placed after the interrupted turn's closing events. It is written through a persistence write handle while no agent owns the session, before the app reports it is ready, and always with `ignorable: true`. A build without this plugin skips it; the session stays readable after the plugin is removed. The line's text comes from the browser's dictionaries, so it reads in the viewer's language.

`Session.append` cannot write `ignorable`, and an unknown event without it makes a session unreadable to every build. On an unpatched upstream base such an event also makes session search fail for all sessions. That is why the marker is never appended through a live session.

## In the chat

In the Compact, Standard and Detailed work-details modes the chat folds a finished turn's work under a "Completed in …" row. From 0.2.1-alpha.3 the chat keeps a turn the app's exit cut short open and labels its row 「已停止」 / "Stopped", the label of a turn you stopped yourself; a chat before that release folds it under "Completed in …", so the turn looks finished and its work looks lost. The plugin labels that row 「已中断」 / "Interrupted" and opens two kinds of turns, once each:

| Turn | Opens | Recognized by |
| --- | --- | --- |
| a turn the app's exit cut short: it ended `interrupted`, or `aborted` with cause `disposed` | when it is first shown | the turn's `turn/end` reason |
| the turn the continuation message started | once that turn has ended; while it runs the chat shows it open anyway | the source of the message that opened it, `plugin:crash-resume` |

The host ends a turn `interrupted` when it next opens or reads a session whose log stops inside that turn, and its shutdown ends a running turn `aborted` with cause `disposed` (see [How it knows](#how-it-knows)). Either way a crash or a quit cut the turn short, so the first row also covers turns this plugin held, `stopped` included, turns it leaves as they are (a subagent's or an archived session's turn, a turn no person started), turns cut short before the plugin was installed, and a turn an agent-loop reload ended, which the plugin neither continues nor holds. The 「意外退出后自动继续」 / "Continued after an unexpected exit" row itself stays collapsed: it holds the message the model read, not the turn's work.

The plugin draws no control of its own. It calls the same `setOpen` the "Completed in …" button calls, from a layout effect, which React runs before the browser paints, and records the turn, keyed by the turn number and its answer step, in a store it declares beside the chat's own. A turn it has recorded is never opened again, so collapsing it with that button sticks. It also records every other closed turn it finds open, so a continued turn the reader opened and collapsed by hand stays collapsed when its continuation row appears later. Like the chat's own open state, the record is kept only in memory, so after a reload every interrupted turn and every continued turn opens again. Verbose folds nothing, so there nothing changes visibly; turns opened there stay open after switching to a mode that folds.

On such a turn the row reads 「已中断」 / "Interrupted", and a screen reader announces 「已中断」 / "Interrupted" instead of 「已停止」 / "Stopped". A chat before 0.2.1-alpha.3 shows the turn's duration there, and the row reads 「已中断，运行了 9秒」 / "Interrupted after 9s". The row stays the chat's own component: the plugin hands it a translator that answers the chat's stopped and completed labels from this plugin's dictionary and every other text, the duration included, from the chat's, so the row follows a language switch in Settings without a reload. Every other turn keeps the chat's label, including a turn you stopped, which reads 「已停止」 / "Stopped", and the turn the continuation message started, which ends like any other turn.

From 0.2.1-alpha.3 the chat also closes an interrupted turn with a line of its own: 「任务已停止」 / "Task stopped", then that the DSH process exited before the turn finished. Under a turn this plugin held, that line stands beside the held line and says the same thing again; under a turn it continued, it reports a stop the continuation already took up. The plugin leaves the line out when the chat holds a held line naming the turn, or a message carrying this plugin's continuation of it, whether that message shows as the continuation row or, when its turn is the earliest one loaded, as context. Every other line of the kind stays the chat's: an interrupted turn this plugin left alone keeps 「任务已停止」 / "Task stopped", and a failure or a sign-out stop keeps its line under any turn. A turn whose end the host's shutdown logged gets no such line from the chat, so there is nothing to leave out under it. The plugin places its renderer in front of the chat's `turn-error` renderer and draws the chat's own component for every line it keeps.

## Configuration

Every field is written out in `cordis.patch.yml`.

| Field | Default | Meaning |
| --- | --- | --- |
| `stateDir` | `$DSH_HOME/crash-resume` | Where the registry and the sentinel live. The desktop shell writes to the default path; move both or neither. |
| `awaitUserTools` | `ask_user_question`, `exit_plan_mode` | Tools whose open call means the turn was waiting for an answer. |
| `resumeTextZh` / `resumeTextEn` | see the patch | The continuation message the model reads. |
| `resumeSummaryZh` / `resumeSummaryEn` | see the patch | The one-line summary stored with it. |
| `continueTextZh` / `continueTextEn` | see the patch | The continuation message the model reads when you press Continue. |
| `continueSummaryZh` / `continueSummaryEn` | see the patch | The one-line summary stored with it. |
| `maxLogBytes` | 67108864 (64 MiB) | Largest log the startup pass reads; a larger one is skipped with a warning. Applies where the backend reports a size (JSONL does). |
| `readTimeoutMs` | 15000 | Longest the startup pass waits for one log; a slower one is skipped with a warning. The read itself is not cancelled. |
| `staleRegistryMs` | 3600000 (one hour) | Heartbeat age after which another server's registry counts as dead although its pid is in use. |

## Known limitations

- **On Windows this plugin requires a desktop shell that writes the sentinel (DSH desktop from rc.35).** The shell stops the server with `taskkill /T /F`, which no listener sees; without the shell's sentinel every quit reads as a crash and every interrupted turn is continued.
- **Running out of memory cannot be caught.** A log that makes the startup pass run out of memory kills the process before any handler runs. The plugin records the id it is about to read in its registry and waits for that write before reading; a launch that finds a dead registry still naming an id it was reading skips that session with a warning. One bad log therefore costs one failed launch, not a crash loop. `maxLogBytes` refuses the largest logs before they are read.
- **A crash while the auto-review gateway judges a walled-mode sandbox escalation is held, not continued.** That escalation's `approval/asked` is written before the gateway answers. The log does not say whether a reviewer or a person holds the question, so the plugin treats it as a person's.
- **Questions are recognized by tool name.** A question asked from inside a `run_code` program, or by a plugin calling `ctx.userQuestions` directly, is not recognized, and such a turn is continued.
- **A turn no person started is never continued.** This covers the first turn after an interrupted one when a job notice or a goal round opened it.
- **One sentinel per home.** With two servers on one home, a stop of one can make the other's crash read as a stop. That holds turns that could have been continued and never continues one that should be held.
- **A launch that fails before this plugin loads leaves the sentinel in place.** A crash after that launch is then held as `stopped`.
- **Only the turn's top level opens.** Tool calls and reasoning inside an opened turn stay collapsed group headers; the chat offers plugins no way to open them.
- **A continued turn at the top of the loaded history is not opened.** When the turn the continuation message started is the earliest turn loaded, the event that queued the message lies before the loaded page, so the chat shows the message as context rather than as the continuation row, and the plugin does not recognize the turn. Once 「加载更早」 / "Load earlier" brings in the events before it, the continuation row appears and opens the turn, unless the reader has already opened it.
- **A collapse is not remembered across a reload.** After a reload every interrupted turn and every continued turn opens again, as described in [In the chat](#in-the-chat).
- **Turning the plugin off and on opens them again.** Disabling and re-enabling this plugin without reloading the page starts its record empty, so interrupted and continued turns open again, including ones the reader collapsed.
- **The interrupted label depends on three of the chat's dictionary keys.** The plugin replaces the texts the chat looks up as `message.stopped`, `message.turnProcess.took` and `message.turnProcess.worked`, and only for a turn the app's exit cut short. If a later 0.2.x chat renames any of them, an interrupted turn reads 「已停止」 / "Stopped" or 「已完成，用时 …」 / "Completed in …" again; this repository's typecheck fails on such a rename.
- **Leaving out the chat's stop line depends on its `turn-error` row.** The plugin recognizes the line by the row's slot key `turn-error`, its code `INTERRUPTED` and its `turn`. If a later 0.2.x chat changes any of them, the line shows again beside the held line; `tests/interrupted-turn.spec.tsx`, which draws the chat's published renderers, fails on such a change once the workspace moves to that chat.
- **The Remote checks the session, not the held line.** `crashResume/continueHeld` continues any session whose log ends with the end of the turn it names, `interrupted` or `aborted` with cause `disposed`, whether or not a held marker follows it. The button exists only on a held line, so in the app this means a held turn; a client that calls the Remote directly can continue a turn the plugin left alone, such as one a goal round started or one an agent-loop reload ended.
- **A turn an agent-loop reload ended can still be taken up.** The plugin tells a reload from the server's exit by whether the root context is being disposed when the turn ends, and by which registry listed the session. Three narrow windows remain: the server dies before the registry write that drops the session lands; the plugin is unloaded together with the agent loop and the server exits before the plugin loads again; or the plugin's module is instantiated anew in the same process, as hot module replacement does, so its record of the registry files this process has written starts empty, and a turn with a disposed end that this process's own registry listed before that moment reads as interrupted. In the first two the next launch holds the turn, or continues it once when no sentinel was written; in the third the new instance's startup pass does the same.
- **A partial answer keeps the chat's 「已停止」 / "Stopped".** When the server shuts down while the model is writing its answer, the host logs the partial answer as interrupted, and the chat ends it with its own 「已停止」 / "Stopped" mark, which this plugin does not relabel; the turn's header reads 「已中断」 / "Interrupted".

## Requirements

DeepSeek Harness 0.2.0-rc.2 or a later 0.2.x release (every dsh peer is `>=0.2.0-rc.2 <0.3.0-0`), with the session controller, the Typert loader and gateway, and the web client's Remote service (the desktop app and `dsh web` have all of them). On Windows, a desktop shell that writes the sentinel (DSH desktop from rc.35).
