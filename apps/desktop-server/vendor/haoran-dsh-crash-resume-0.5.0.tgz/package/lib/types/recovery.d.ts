/**
 * The two startup steps: the pass that runs inside `apply`, before the
 * gateway admits any client, and the continuation that runs once the
 * application reports it is ready.
 *
 * @module @haoran/dsh-crash-resume/recovery
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { ResolvedConfig } from './config.ts';
import { type Verdict } from './judge.ts';
import { type ContinueHeldResult, type PERSON_TRIGGER } from './shared.ts';
/** A session the startup pass decided to continue, with the turn it continues. */
export interface ResumeCandidate {
    readonly id: string;
    readonly turn: number;
}
/** Why a candidate could not be judged; it is left as it is. */
export interface Unreadable {
    readonly kind: 'unreadable';
    readonly detail: string;
}
/** What the startup pass did, for the caller's registry update and for tests. */
export interface StartupOutcome {
    /** Sessions to continue once the application is ready. */
    readonly resume: readonly ResumeCandidate[];
    /** Candidates that stay in the in-flight registry: sessions already live in this process. */
    readonly keep: readonly string[];
    /** Every other candidate's verdict, or why none could be reached. */
    readonly verdicts: ReadonlyMap<string, Verdict | Unreadable>;
}
/** Inputs of the startup pass that come from this launch. */
export interface StartupInputs {
    readonly candidates: readonly string[];
    /**
     * The candidates that only this process's own registry listed, written by
     * an earlier load of the plugin in this process (see `JudgedSession`).
     */
    readonly listedByThisProcess: ReadonlySet<string>;
    readonly stopped: boolean;
    readonly config: ResolvedConfig;
    /**
     * Called with a candidate's id before its log is read and with undefined
     * after; the pass awaits it. The caller records the id durably, so a
     * process that dies while reading a log (out of memory, for one) tells the
     * next startup which log to skip.
     */
    readonly examining?: (id: string | undefined) => Promise<void>;
}
/**
 * The sessions the workspace registry lists as archived, read at the time of
 * the call.
 * @param ctx - the plugin context.
 * @returns the archived session ids; empty where no workspace registry is mounted.
 */
export declare function archivedIds(ctx: Context): readonly string[];
/**
 * The startup pass. Reads each candidate's complete stored log, decides, and
 * writes the held marker where the decision is to hold. Runs inside the
 * plugin's `apply`, which the launcher awaits before it reports the
 * application ready, so no client can open a session while a write handle
 * taken here is open. A candidate whose log is missing, larger than
 * `maxLogBytes`, slower than `readTimeoutMs`, or fails to read is left as it
 * is with a warning.
 * @param ctx - the plugin context.
 * @param inputs - candidates from the in-flight registries, the stop flag, and the policy.
 * @returns what to continue, what to keep listed, and every other verdict.
 */
export declare function runStartupPass(ctx: Context, inputs: StartupInputs): Promise<StartupOutcome>;
/**
 * Whether the live log still ends with the end of `turn`, written by the
 * host when it closed the interrupted turn or logged by the host's disposal,
 * and nothing after it started a new turn. Anything else means the session
 * moved on (a person sent a message first) and must not be continued.
 * @param events - the live session's events.
 * @param turn - the interrupted turn.
 * @returns true when the session is still exactly where the interruption left it.
 */
export declare function stillInterrupted(events: readonly SessionEvent[], turn: number): boolean;
/**
 * What {@link continueOne} did.
 *
 * - `sent`: the continuation message was handed to the agent.
 * - `busy`: the agent is running or has queued input; that turn's own end
 *   settles the session.
 * - `settled`: the session is idle and moved past the interrupted turn.
 * - `unopened`: the session could not be opened; the interrupted turn is
 *   still where it was.
 */
export type ContinueResult = Exclude<ContinueHeldResult, 'archived'>;
/** The continuation message {@link continueOne} sends. */
export interface ContinuationMessage {
    /** The text the model reads. */
    readonly text: string;
    /** The one-line summary stored with it. */
    readonly summary: string;
    /** Present when a person asked for the continuation; the automatic one has none. */
    readonly trigger?: typeof PERSON_TRIGGER;
}
/**
 * Continue one interrupted turn by sending a continuation message. The
 * message is an ordinary logged `user/message`, so the model request it
 * produces is reconstructable from the log, and its source kind is what the
 * next startup reads to refuse a second continuation, whether it was sent
 * automatically or at a person's request. The agent's state is checked
 * again after the flush and immediately before the send, with no await in
 * between, so a message a person sent meanwhile wins.
 * @param ctx - the plugin context.
 * @param candidate - the session and its interrupted turn.
 * @param message - the text, the summary, and the trigger to record.
 * @returns what happened.
 */
export declare function continueOne(ctx: Context, candidate: ResumeCandidate, message: ContinuationMessage): Promise<ContinueResult>;
//# sourceMappingURL=recovery.d.ts.map