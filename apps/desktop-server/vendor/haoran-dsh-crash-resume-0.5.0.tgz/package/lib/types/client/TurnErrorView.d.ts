/**
 * The `turn-error` row under a turn this plugin held or continued.
 *
 * From 0.2.1-alpha.3 the chat closes a turn the app's exit cut short with a
 * row of its own, 「任务已停止」 / "Task stopped" and the reason that the DSH
 * process exited before the turn finished. Its `turn-error` node carries the
 * code `INTERRUPTED`. Under a turn this plugin held, that row stands next to
 * the held row and says the same thing a second time; under a turn this plugin
 * continued, it reports a stop the continuation already took up.
 *
 * This view shadows the host's `turn-error` renderer at priority -1. It
 * renders nothing for an `INTERRUPTED` row whose turn this plugin handled:
 * the chat holds a held row naming that turn, or a message whose source is
 * this plugin's continuation of that turn. The continuation message is a
 * `turn-trigger` row, or a `context` row when its turn is the earliest
 * loaded one; the view matches it by source in either. Every other row,
 * including the `INTERRUPTED` row of a turn this plugin left alone, goes to
 * the host's own component, read from the slot ledger, with the props the
 * slot runtime handed this view.
 *
 * The held row and the continuation message are both logged after the
 * interrupted turn's `turn/end`, so once the chat has loaded the stop row it
 * has loaded them as well.
 *
 * A turn whose end the host's disposal logged (`aborted`, cause `disposed`)
 * gets no such row: the chat's `turn-error` Definition builds one for an
 * `aborted` end only when a sign-out cancelled the turn, so this view has
 * nothing to leave out under it.
 *
 * @module @haoran/dsh-crash-resume/client/TurnErrorView
 */
import type { ReactNode } from 'react';
import type { StoredEntry } from '@deepseek-ai/dsh-client-ui-slots';
/** The code the chat's `turn-error` Definition gives a turn closed after the process exited mid-turn. */
export declare const INTERRUPTED_CODE = "INTERRUPTED";
/** One chat node as this view reads it: its kind and its payload. */
export interface TurnErrorChatNode {
    readonly kind: string;
    readonly data?: unknown;
}
/** The chat snapshot fields this view reads. */
export interface TurnErrorChatFields {
    /** Every node the chat has built for the loaded history. */
    readonly nodes: {
        values(): readonly TurnErrorChatNode[];
    };
}
/** The props a keyed `turn-error` entry receives; only the parts this view reads are named. */
export interface TurnErrorViewProps {
    readonly node: {
        readonly data: {
            readonly turn: number;
            readonly code?: string | undefined;
        };
    };
    readonly useChat: <S>(selector: (chat: TurnErrorChatFields) => S) => S;
}
/** What the view needs from the plugin context, resolved per render. */
export interface TurnErrorViewDeps {
    /** Live ledger of `conversation.chat.node` entries. */
    readonly entries: () => readonly StoredEntry[];
}
/**
 * Whether this plugin held or continued a turn.
 * @param nodes - the chat's nodes.
 * @param turn - the interrupted turn.
 * @returns true when a held row names the turn, or a message carries this plugin's continuation source for it.
 */
export declare function handledByPlugin(nodes: readonly TurnErrorChatNode[], turn: number): boolean;
/**
 * Build the shadowing renderer for the `turn-error` cell.
 * @param deps - ledger access.
 * @returns the component to register at `priority: -1` with locale `chat`.
 */
export declare function createTurnErrorView(deps: TurnErrorViewDeps): (props: TurnErrorViewProps) => ReactNode;
//# sourceMappingURL=TurnErrorView.d.ts.map