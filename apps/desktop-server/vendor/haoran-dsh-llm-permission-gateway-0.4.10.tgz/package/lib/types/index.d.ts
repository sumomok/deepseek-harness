/**
 * A permission gate that asks a model about the calls nothing else stops.
 *
 * DeepSeek Harness routes every tool call through the `tools/pre-execute`
 * waterfall, the one extension point that can see a call's arguments. Two
 * things reach a human without this plugin, and neither covers an ordinary
 * tool: a listener that returns `ask` from this waterfall, which only the two
 * hook bridges and the jobs tool do; and the sandbox-escape path, where a
 * confined `bash`, `pwsh`, `write`, or `edit` call that was refused asks for
 * its wall to be lowered. This plugin registers on the waterfall, prepended,
 * and it registers on the escalation path too.
 *
 * What it reviews is what has no wall around it. Under `read-only` or
 * `workspace-write` the operating system already confines the shell and the
 * file tools, so those are passed through un-reviewed and the review model is
 * spent on what the sandbox cannot see: a `run_code` program body, which runs
 * on a worker thread inside the harness process with `node:fs` and
 * `node:child_process` in reach; calls that leave the machine; and calls that
 * act with a login the person owns. Turning the sandbox off removes every wall,
 * and every call is reviewed again.
 *
 * Whether it acts at all is decided by the two knobs the harness already has,
 * folded into one of three tiers by `./policy.ts`:
 *
 * - **walled** — a wall stands and a person can be asked. Review covers what
 *   the wall does not, and only while this plugin's own switch is on; the
 *   switch ships off, because under a wall the harness is already refusing the
 *   file effects a review would object to.
 * - **auto-review** — no wall, and a person can still be asked. Review is what
 *   this state IS, so the switch does not reach it.
 * - **full-access** — no wall, and the approval policy resolves every request
 *   to a refusal before any answerer sees it. This gate steps aside entirely:
 *   no red line, no `alwaysAsk`, no review. Asking there does not put a
 *   question to anyone; it converts this gate's questions into silent refusals
 *   of calls nobody objected to.
 *
 * A delegated session is governed by the session it was delegated from, because
 * its own approval policy is pinned to `never` at the delegation boundary and
 * says nothing about which mode the person chose. The tier comes from the root
 * of the lineage; whether anyone can answer comes from the calling session, and
 * where nobody can, every question this gate would raise becomes a refusal it
 * signs itself — after the rest of the chain has had the call, whose own
 * refusal or own question still wins.
 *
 * It gates what the MODEL asks for, not what a plugin does. Work a plugin
 * performs in its own route handlers, timers, or event listeners produces no
 * tool call and is invisible here; the package README states that limit in full.
 *
 * Three structural commitments are worth reading before the code:
 *
 * - Failure never opens the gate. {@link Config.onFailure} ranges over `ask`
 *   and `deny` only, so a timeout, an unreachable model, or an unparsable
 *   answer cannot become an allow — there is no such value to configure. An
 *   attacker who can only make the reviewer slow gains nothing.
 * - Every answer but a refusal delegates. An allow returns `next()` and an ask
 *   is put to `next()` before it is raised, so every other listener on the
 *   waterfall still decides. The chain's own answer wins over this gate's ask:
 *   a listener further along may be the one that books the approval its tool
 *   body later checks for, and a short-circuited ask leaves it holding a call
 *   the person approved and it never saw. This gate can add denials but never
 *   removes another plugin's.
 * - The model cannot refuse. A `deny` from the review model becomes an `ask`,
 *   so a wrong judgment costs a prompt rather than a blocked call. Where nobody
 *   can answer that ask it becomes this gate's own refusal, which is the same
 *   decision the harness would have reached — an unanswerable request resolves
 *   to `rejected` — said in a sentence the person can read afterwards. Apart
 *   from those and from {@link Config.onFailure} set to `deny`, the two red
 *   lines are the only denials this gate makes on its own, and wherever it
 *   decides a call they consult neither the model nor the configuration.
 *
 * Every decision, allow included, is recorded where the session log cannot
 * carry it; `./probe.ts` states why that record is a file and not an event.
 *
 * Configuration reference and known limits live in the package README.
 * @module @haoran/dsh-llm-permission-gateway
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ReviewMode } from './mode.ts';
export { detectRedLine, resolveProtectedTargets } from './redline.ts';
export type { ProtectedTargets, RedLine, RedLineHit } from './redline.ts';
export { parseJudgeResponse } from './judge.ts';
export type { EscalationReview, JudgeFailure, JudgeOutcome, JudgeResult, JudgeRoute, JudgeVerdict } from './judge.ts';
export { applyEscalationAnswerer, parseEscalationReason } from './escalation.ts';
export type { EscalationAnswererOptions, EscalationFacts } from './escalation.ts';
export { applyReviewCommand, createGatewayStore, REVIEW_COMMAND } from './mode.ts';
export type { GatewayDefaults, GatewaySettings, GatewayStore, ReviewMode } from './mode.ts';
export { accessTier, effectiveApprovalPolicy, readTier } from './policy.ts';
export type { AccessTier, AgentLookup, ApprovalPolicy, ApprovalPolicyReader, PermissionStateReader, TierLineage, TierState, } from './policy.ts';
export { GATEWAY_SETTINGS_NAMESPACE } from './settings-namespace.ts';
export { CallNotes, DEFAULT_WALLED_TOOLS, OWN_ASK_LIMIT, readWalls, sandboxConfines, skipStep } from './walls.ts';
export type { RememberedCall, SkipStep, WallState } from './walls.ts';
export { createVerdictProbe, defaultVerdictLogPath, judgeDiagnostics, reviewSpend, verdictRecord, verdictSummary } from './probe.ts';
export type { DownstreamAnswer, ProbeCall, ProbeDecision, ProbeLog, ProbeOutcome, RecordFormat, VerdictProbe, VerdictProbeOptions, VerdictRecord, VerdictSource, } from './probe.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "llm-permission-gateway";
/**
 * The review model (`llm`) and the registry whose calls are gated (`tools`),
 * which is also where each tool's own description is read from.
 */
export declare const inject: string[];
/**
 * What this gate does when it cannot obtain a verdict.
 *
 * `allow` is absent on purpose and must stay absent: a fail-open permission
 * gate is defeated by making the reviewer slow rather than by convincing it,
 * which is a far lower bar than the review itself. Keeping the value
 * unrepresentable puts that guarantee in the type system instead of in a
 * default that a later edit could flip.
 */
export type FailureDecision = 'ask' | 'deny';
/**
 * Tools whose effects are confined to reading local state, to drawing
 * something in the conversation, or to asking the person already at the
 * keyboard, skipped to keep review cost proportional.
 *
 * `ask_user_question` is on the list for the second reason. Its whole effect is
 * to put a question in front of the user and wait for the answer: it touches
 * nothing on the machine, and every argument it carries is text that person is
 * about to read. A review can only add a model call and, on an `ask` verdict, a
 * second prompt in front of the one the tool exists to show.
 *
 * `show_chart` and `content_show` render into the conversation the user is
 * already looking at; `job_output` reads a job's own recorded output;
 * `web_search` sends a query to a search engine and returns results, without
 * carrying a login or fetching a page the search did not name.
 */
export declare const DEFAULT_READ_ONLY_TOOLS: readonly string[];
/** Plugin configuration; every field is changeable from cordis.yml and validated at load. */
export interface Config {
    /**
     * Registered LLM provider route the review model is reached on wherever the
     * user has picked none. The settings page offers every route an adapter
     * serves; this field is what a fresh installation, and a machine whose stored
     * choice no longer resolves, is reviewed on.
     */
    provider: string;
    /**
     * Model id for reviews wherever the user has picked none, chosen
     * independently of the agent's own model. A separate model is not a defence
     * against a compromised provider, but it does keep one model's blind spots
     * from being both the attack surface and the check on it, and a small model
     * keeps review inside the latency budget.
     */
    model: string;
    /**
     * Whether the two walled access modes are reviewed as well, for a fresh
     * installation and wherever no settings provider stores the user's own
     * choice. The settings page and `/review` change the stored value.
     *
     * It defaults to `false` because under a wall the harness already stops the
     * file effects a review would object to, and what is left there is work the
     * person chose a confined mode to be able to do without being interrupted.
     * The tier whose stated behaviour is the review does not read this field.
     */
    walledReview?: boolean;
    /**
     * The 0.3.x name for that switch, accepted so a profile that still sets it
     * loads, and read by nothing.
     * @deprecated Since 0.4.4. Superseded by {@link Config.walledReview}.
     */
    mode?: ReviewMode;
    /**
     * Provider-owned reasoning-effort id for the judge, or `''` to take the
     * route's own default. Reviewing one call is a single classification, and the
     * default `off` keeps thinking tokens from crowding out the answer inside
     * {@link Config.maxOutputTokens} — which fails closed, so a wrong value here
     * costs approval prompts rather than silent allows. Legal ids belong to the
     * provider, so an unsupported one surfaces on the first review rather than at
     * load; the id is sent to a settings-picked route on another provider too,
     * because omitting it there means that route's own default, which is thinking
     * wherever the provider thinks by default.
     */
    reasoningEffort?: string;
    /**
     * Sampling temperature every review request states, `0` to `2`.
     *
     * It ships `0` because a review is one classification of one call rather than
     * a piece of writing: the same arguments put to the same model should reach
     * the same verdict, and sampling is a reason for two identical calls to be
     * decided differently. The value reaches the provider verbatim; DeepSeek's
     * reasoning-model interface ignores it on a request that thinks, so raising
     * it there changes nothing.
     */
    temperature?: number;
    /**
     * Wall-clock budget for one review; exceeding it applies {@link Config.onFailure}.
     * The default covers a call at the full {@link Config.maxArgumentsChars}
     * size: measured on 2026-08-21, `deepseek-v4-flash` returns a verdict on a
     * 200K-character call in roughly 5-8 seconds.
     */
    timeoutMs?: number;
    /** Output cap for the review answer, which is one small JSON object. */
    maxOutputTokens?: number;
    /**
     * Extra output tokens one retry adds when a review answer reached
     * {@link Config.maxOutputTokens} having spent thinking tokens; `0` never
     * retries.
     *
     * The provider counts thinking inside the output cap, so a review model that
     * thinks first can spend the cap before it writes the verdict — a fail-closed
     * failure, whose symptom is an approval prompt on every call. A cap is a
     * ceiling rather than a spend, so room a review does not use costs nothing;
     * the package README carries the measurement the default is sized from.
     */
    reasoningBudgetTokens?: number;
    /**
     * Serialized-argument size above which the call is not reviewed at all.
     * Oversized arguments apply {@link Config.onFailure} rather than being
     * truncated: a truncated review reads a different call than the one that
     * would run, and the part left out is exactly where a payload would sit.
     *
     * The default is high because a low one turns the calls most worth reviewing
     * into manual approval prompts: measured on 2026-08-21, the `code` preset's
     * `run_code` calls routinely carry 9-10K characters of arguments, so an 8000
     * cap sent exactly those past the model and straight to a human. 200K
     * characters is reviewed whole inside {@link Config.timeoutMs}.
     */
    maxArgumentsChars?: number;
    /** What to do when no verdict is obtained. */
    onFailure?: FailureDecision;
    /** Tools passed straight through to the rest of the chain without review. */
    readOnlyTools?: string[];
    /**
     * Tools the operating-system sandbox already confines, passed through
     * un-reviewed while it does. They are reviewed again in the `auto-review`
     * tier — no wall, and a person still reachable — which is where
     * `danger-full-access` lands while approvals are still answered, and where a
     * composition with no sandbox policy at all lands too.
     */
    walledTools?: string[];
    /** Tool name to the cost sentence shown when it is asked about; asked without consulting the model. */
    alwaysAsk?: Record<string, string>;
    /**
     * Per-agent cap on remembered verdicts, and on the confined calls remembered
     * so an escalation review can read what they asked for. `0` disables both:
     * every call is reviewed afresh, and every escalation goes to a person
     * because no call is remembered to review it against.
     *
     * An entry is keyed by tool name and argument digest, and by nothing else.
     * The tool's description is part of what a review reads and no part of that
     * key, so a description edited, shadowed, or unregistered after a verdict was
     * reached does not invalidate it: the entry answers for the rest of that
     * agent's run. Setting this to `0` is what makes every call read the registry
     * again.
     *
     * It does not bound the record of this gate's own asks — that one is a fixed
     * {@link OWN_ASK_LIMIT}, so no configuration can switch off the guard that
     * keeps the escalation answerer from granting this gate's own question.
     */
    cacheEntries?: number;
    /** Language for the human-facing reason the review model writes. */
    reasonLanguage?: string;
    /**
     * Absolute path of the JSONL file every decision is appended to, or `false`
     * to write no file. Defaults to `$DSH_HOME/llm-permission-gateway/verdicts.jsonl`,
     * resolved at load rather than written into the schema because the harness
     * home is a property of the installation. The one-line summary on the host
     * log is written either way, so `false` narrows the trace rather than
     * removing it.
     */
    verdictLog?: string | false;
    /**
     * Characters of the serialized call kept in each record, whitespace
     * collapsed; `0` keeps none, which is the default.
     *
     * A record otherwise identifies a call by its argument digest, which says
     * that two calls were identical without saying what either one asked for.
     * The preview closes that gap and is the user's own argument text while it
     * does so — as sensitive as the session log, and written with the process
     * umask into `$DSH_HOME`, so it is protected by whatever protects that
     * directory and by nothing this plugin adds.
     */
    verdictLogArgsPreview?: number;
}
export declare const Config: z<Config>;
/**
 * Register the gate.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map