/**
 * The settings document this plugin owns: its durable-boundary parse, and the
 * one write the host itself makes into it.
 *
 * Two layers on the read, deliberately: the schemastery schema handed to
 * `SettingsProvider.installSection` accepts any array of records, because a
 * schema failure there refuses the whole registration and would strand every
 * server over one bad row; the zod parse below then judges each record on its
 * own and drops only the ones it cannot read, warning about each.
 *
 * @module @haoran/dsh-mcp-servers/settings-document
 */
import type { Context } from '@deepseek-ai/cordis';
import s from '@deepseek-ai/schemastery';
import type { McpServersDocument } from './types.ts';
/**
 * A server id: the tool-name namespace, so it is limited to what the
 * harness's own `serverName` grammar accepts (`[A-Za-z0-9_-]{1,32}`),
 * narrowed further to lowercase so two records cannot differ by case alone.
 */
export declare const SERVER_ID_PATTERN: RegExp;
/** The section as the settings seam stores it, before per-record judgement. */
export interface McpServersSection {
    /** Stored server records; each one is judged by {@link parseDocument}. */
    servers?: unknown[];
}
/**
 * The namespace schema. It describes the section's outer form only — see this
 * module's own note on why the records stay `any` here.
 */
export declare const Settings: s<McpServersSection>;
/** The section value a composition without a stored document resolves to. */
export declare const EMPTY_SECTION: McpServersSection;
/**
 * Read the stored section into records this plugin can act on.
 *
 * A record it cannot read is dropped with a warning rather than failing the
 * document: one hand-edited row must not take every other server offline.
 * @param section - the resolved settings section, as the seam produced it.
 * @param warn - receives one message per dropped record.
 * @returns the readable records, in document order, ids unique.
 */
export declare function parseDocument(section: unknown, warn: (message: string) => void): McpServersDocument;
/**
 * Stores what one server is trusted at, in the same document the settings page
 * writes.
 *
 * The host writes this document for exactly one reason: the tool set a server
 * turns out to offer is only knowable after connecting, and a person who
 * stored the record already consented to it, so nothing is gained by asking
 * them to click again for a fingerprint they cannot compute. Every other
 * change to this document still comes from the settings page.
 */
export interface ConfirmationWriter {
    /**
     * Record one server's confirmation.
     * @param id - the record's id; an id the document no longer holds is ignored.
     * @param endpoint - the destination fingerprint now trusted.
     * @param tools - the tool-set fingerprint now trusted.
     * @returns settlement once the document holds it.
     * @throws {Error} whatever the settings seam raises for a refused write.
     */
    write(id: string, endpoint: string, tools: string): Promise<void>;
}
/**
 * The writer this plugin runs on: it edits the raw stored entry rather than a
 * parsed record, so a field this version fills a default for is not written
 * back as an override, and every other entry — including one this plugin
 * cannot read — is carried through unchanged, exactly as the settings page
 * carries it.
 *
 * A whole-array write rather than one path-addressed edit per field: the page
 * writes the array wholesale for every change it makes, so an index-addressed
 * write from here would be the only thing in this plugin that could land on a
 * different record than the one it read.
 * @param ctx - the plugin context; without a settings provider this writes nothing.
 * @param source - the currently authoritative section, as `installSection` hands it over.
 * @returns the writer.
 */
export declare function settingsConfirmationWriter(ctx: Context, source: () => McpServersSection): ConfirmationWriter;
//# sourceMappingURL=settings-document.d.ts.map