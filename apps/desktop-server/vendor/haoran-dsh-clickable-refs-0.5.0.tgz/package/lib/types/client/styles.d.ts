/**
 * This plugin's whole stylesheet, injected once as a tagged `<style>`.
 *
 * A CSS module would be the shell's own idiom, but (same as every other
 * out-of-repo plugin here) this package's build hands `tsc` output straight
 * to esbuild, which emits no stylesheet for a `.module.css` next to source
 * that no longer exists at that point — so the rules live here as text.
 *
 * The one surface this plugin draws is the prose UNC copy toast. Its class
 * uses the plugin's own `dshcr-` prefix so it cannot collide with a host
 * class, and its colors are `--dsw-*` harness theme tokens, so it follows the
 * same light/dark scheme as the host.
 *
 * @module @haoran/dsh-clickable-refs/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-clickable-refs";
/**
 * Put the stylesheet in the document, once.
 * @returns a disposer removing the tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map