/**
 * The `referent/open` waterfall listener that claims a chat-prose UNC click
 * before `dsh-render`'s own default (`workspaces.openPath`) would run.
 * Extracted from `client/index.ts`'s `apply()` (where it is registered via
 * `ctx.on('referent/open', …)`) so it has its own directly-callable,
 * directly-testable export.
 *
 * A UNC target (`\\server\share\…`) from assistant prose is never opened:
 * opening it would make the host touch an SMB share the model named. Prose
 * has no per-span notice slot (`prose-unc-toast.ts`'s own header), so this
 * listener refuses the open, copies the path, and confirms via the
 * frame-wide toast.
 *
 * @module @haoran/dsh-clickable-refs/client/prose-unc-claim
 */
import type { ReferentRef } from '@deepseek-ai/dsh-api-session-controller/client';
/** The clipboard/label plumbing this listener needs, bound by the caller. */
export interface ProseUncClaimDeps {
    /** Writes text to the clipboard; resolves the write's own success. */
    writeClipboard: (text: string) => Promise<boolean>;
    /** The localized "copied" confirmation text for the toast. */
    copiedLabel: () => string;
}
/**
 * Claim a chat-prose UNC reference before the dispatch's own default runs.
 * A reference from any other source, or a non-UNC target, always falls
 * through to `next()` unchanged — this listener never re-enters the seam or
 * calls a workspace/window opener itself.
 * @param ref - the dispatched reference.
 * @param next - the waterfall's next listener, or its default action.
 * @param deps - clipboard write and the copied-confirmation toast text.
 */
export declare function claimProseUnc(ref: ReferentRef, next: () => Promise<void>, deps: ProseUncClaimDeps): Promise<void>;
//# sourceMappingURL=prose-unc-claim.d.ts.map