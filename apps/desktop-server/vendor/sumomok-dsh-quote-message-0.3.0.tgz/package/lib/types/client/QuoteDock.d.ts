import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import { type QuotePayload } from '../core/quote.ts';
import type { QuoteIdentity } from './identity.ts';
import type { QuoteKey } from './locales.ts';
/** What the dock reads off its owner share and its own inject. */
export interface QuoteDockProps {
    /** Owner share: the live input state; the draft names the insert position and the revision guards it. */
    readonly input: {
        readonly draft: string;
        readonly draftRev: number;
    };
    /** Framework prop: the session this entry is mounted for. */
    readonly sessionId: SessionId;
    /** Framework prop: translate bound to this plugin's namespace. */
    readonly t: Translate<QuoteKey>;
    /**
     * Injected: message identity of the chat row a given node key anchors,
     * read from the session's live "chat" Conversation View target — see
     * `identity.ts`. Undefined when the row is not a message (or is not
     * resolvable yet).
     */
    readonly identityAt: (sessionId: SessionId, nodeKey: string) => QuoteIdentity | undefined;
    /** Injected: seat one quote in this session's composer. */
    readonly quote: (sessionId: SessionId, payload: QuotePayload, input: {
        readonly draft: string;
        readonly draftRev: number;
    }) => boolean;
}
/**
 * Render the selection pill for one session.
 * @param props - owner share, framework props, and the injected insert path.
 * @returns the portaled pill, or null while no chat selection stands.
 */
export declare function QuoteDock({ input, sessionId, t, quote, identityAt }: QuoteDockProps): import("react").ReactPortal | null;
//# sourceMappingURL=QuoteDock.d.ts.map