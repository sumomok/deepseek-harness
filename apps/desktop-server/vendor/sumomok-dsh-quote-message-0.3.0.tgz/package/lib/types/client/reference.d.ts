/**
 * The chip: how one quote becomes a `ReferenceInsert` the host's own
 * reference path can seat, and how it reaches a session's composer from
 * outside the trigger pipeline.
 *
 * @module @sumomok/dsh-quote-message/client/reference
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { ReferenceInsert } from '@deepseek-ai/dsh-client-ui-input-trigger/client';
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import { type QuotePayload } from '../core/quote.ts';
import type { QuoteKey } from './locales.ts';
/**
 * Source name of the `@message` picker. It is also the serializer routing key
 * the host stores on every occurrence, so it must stay stable: a chip in a
 * draft is expanded by looking this name up in the source roster.
 */
export declare const QUOTE_SOURCE_NAME = "message";
/**
 * Inline label cached on the occurrence, e.g. `引用 #12 助手`. The draft shows
 * it after the `@` glyph.
 * @param payload - the quote payload.
 * @param t - bound translate for this plugin's namespace.
 * @returns the chip label.
 */
export declare function chipLabel(payload: QuotePayload, t: Translate<QuoteKey>): string;
/**
 * Build the reference insert for one quote.
 *
 * `appearance` is `session` — the closest of the three the host's chip
 * renderer knows (session / file / folder), and a quote does point at a
 * message in the current session. It is not decoration: an entry without an
 * appearance renders a bare `@` where every first-party chip renders a domain
 * glyph, so the quote chip would be the one reference in the composer that
 * does not look like a reference.
 * @param payload - the quote payload (the chip carries the text itself).
 * @param label - inline label from {@link chipLabel}.
 * @param clipboardText - the block a copy of the draft carries.
 * @returns the insert the input machine seats as one occurrence.
 */
export declare function quoteReference(payload: QuotePayload, label: string, clipboardText: string): ReferenceInsert;
/**
 * Seat one chip in a session's composer without going through the trigger
 * pipeline (the selection pill's path). The position comes from
 * {@link quoteInsertRange}; `draftRev` rides along as the machine's CAS guard,
 * so a draft that changed between the click and the dispatch is left alone.
 * @param ctx - the plugin's client root context.
 * @param sessionId - session whose composer receives the chip.
 * @param reference - the insert from {@link quoteReference}.
 * @param input - published input state read at click time.
 * @returns whether the input machine applied it (false = stale draft, or no live scope).
 */
export declare function insertQuoteReference(ctx: Context, sessionId: SessionId, reference: ReferenceInsert, input: {
    readonly draft: string;
    readonly draftRev: number;
}): boolean;
//# sourceMappingURL=reference.d.ts.map