# @haoran/dsh-data-location

English | [中文](README.zh.md)

See where the DeepSeek Harness desktop application keeps its data, and move it to another folder. A **Data & Storage** page appears in Settings showing the data folder, what terminals use, and how the last move went, with a **Change Location…** button.

## What you see

| Step | What the page shows |
| --- | --- |
| Always | The data folder, and whether terminals use it too — when this launch wrote the terminal's data location, or, on the first launch from a move's new location, when the move wrote it |
| Choosing | "Waiting for you to choose a folder…" while the system folder picker is open |
| Checking | "Checking …" while the desktop shell checks the folder |
| Refused | Every reason the folder cannot take the data, one sentence each |
| Confirm | Where the data goes, how much is copied (or that it is a rename on the same drive), what happens to the window, and a reminder to close DSH in a terminal; **Move** and **Cancel** |
| Requested | That the move is starting; the application replaces its window with the move's progress and reopens from the new location |
| Requested, no answer | That the request was sent and no answer came back — the shell may be stopping this server for the move, which cuts the answer off — and to open the page again if the window does not change; **Change Location…** stays available |
| Declined | Why the application did not open a second folder picker or carry the removal on again, as a plain sentence rather than a failure |
| Afterwards | The last move's result — for a failed move, its cause and what to do next; for a new location kept after it failed its check, what the check found — what it left where, and why the last requested move did not start, if it did not |

The page refuses to start while any conversation has work running — a turn, a subagent, or a background job. A scheduled follow-up does not count: it is stored on disk, survives the server stopping, and fires from the new location afterwards.

## Where it works, and where it does nothing

This plugin needs the loopback data-location service the desktop shell lends the server it starts — `DSH_DESKTOP_DATA_ENDPOINT` and `DSH_DESKTOP_DATA_TOKEN` in that child process's environment. A `dsh web` on a server sets neither; there `state()` answers `available: false`, the browser half registers no page, and nothing appears in Settings.

The move itself is not here. The shell owns the folder picker, the check of the folder, the move in its own window, and the relaunch. This plugin adds the two facts only the server knows: every workspace folder (sent with each check and each move, since the data may not go inside one and the shell's check after the move counts them), and which conversations are running.

Built and tested against DeepSeek Harness 0.2.1-alpha.1; it uses nothing that 0.2.0-rc.2 lacks. Every `@deepseek-ai/dsh-*` peer is `>=0.2.0-rc.2 <0.3.0-0`, so a 0.1.x host skips the whole bundle and the page does not appear there either.

## The contract with the shell

| Route | Body | Answer |
| --- | --- | --- |
| `GET /state` | — | `{ home, moving, cleanupRunning?, cleanupWaiting?, lastResult?, lastRefusal?, terminal?, cleanup? }` |
| `POST /choose` | — | `{ path }`, or `{}` when the picker was cancelled; `409` while a picker is already open |
| `POST /preflight` | `{ target, workspaces }` | the folder check's verdict |
| `POST /start` | `{ target, workspaces }` | `202` once the move is recorded; `409` with the reason it was refused |
| `POST /retry-cleanup` | — | `202` when the removal runs again; `409` with `{ reason }` — `none-waiting`, `running`, or `no-window` |

On both `/preflight` and `/start`, `target` is the folder the person picked. The shell works out the folder the data goes into from it each time — the picked folder when it is empty and not the top of a drive, otherwise a new `DSH-Data` folder inside it — and the verdict's target names that folder; the confirmation shows it, and `/start` sends the picked folder again.

All five require `Authorization: Bearer <token>`. Answers carry kinds and paths, never sentences; this page words them, and a kind this build does not know is shown as a general sentence rather than failing the page. `/choose` has no deadline, because the picker stays open as long as the person browses.

`cleanup` (`{ leftoverBytes }`) drives the "could not be removed from the old location … Try Again" card; the shell sends it once three removals in a row left files behind. `cleanupRunning` and `cleanupWaiting` can be true only in the move's cleanup phase: running, the page says "Removing…" and disables Try Again; waiting, it says the removal carries on the next time DSH opens. With a move recorded and both false (a move asked for and not yet carried, or one switched and not yet checked), it says the move is getting ready. A shell that sends neither is read as removing.

`lastResult.failure` (`{ kind, also? }`) names why a move failed, on every failed result and on a moved one whose new location failed its check after the person kept it. A failed move caused by `source-changed`, `target-occupied`, `copy-mismatch`, `copy-gone`, `no-space`, or `no-permission` gets one sentence with that cause and a next step; the `source-changed` sentence says nothing about where the data is, because the data folder may be gone from its old path. What the check of the new location found (`not-started`, `unreadable`, `fewer-sessions`, `plugin-quarantined`, `workspaces-differ`, as `kind` or in `also`) is one sentence per problem, under a line saying the data was put back in its original location, or, for a kept new location, that it stays in use, followed by what to check and do next: see whether conversations, plugins, and workspaces are all there, install a plugin that could not be loaded again, or move the data from this page. `lock-lost`, `other`, a kind this build does not know, and a result without `failure` get the general sentence, and the shell's English `detail` is never shown. `lastResult.terminalNotRestored` (`{ path }`) names a new location the terminal may still use after a rollback could not put the terminal's data location back; on a failed result the page says so after the cause, with the step to change or delete that setting and open a new terminal. A failed move's sentences say the data is in its original location; only the cancelled one says nothing has changed. `terminal` is this launch's own write of the terminal's data location, or else a move's write, on a launch that checks that move's switch or carries on its cleanup, and on the first launch after the move finished on a new location the person kept though it failed its check. Nothing in it says which of the two it is, so every outcome other than `synced` and `unconfirmed` says that DSH in the terminal may not see the conversations. The person's own setting, and DSH's lines in a file the shell could not change, also come with a step: change that setting or those lines to the location shown, or delete them, then open a new terminal; the page names the file, and the line, when the shell gives them.

## Permissions / security

- **The browser never sees the endpoint or the token.** Both are read once on the host side; the browser reaches the host only through the harness's own `/api` Typert gateway, and this plugin registers no HTTP route.
- **A caller can name a folder, and nothing else.** The shell checks the folder again when the move is asked for and decides whether the data may go there.
- **Nothing here fails a launch or throws across the gateway.** No service, a service that stopped answering, or a body it cannot read becomes a sentence on the page.

## Configuration

| Key | Default | What it does |
| --- | --- | --- |
| `activePollMs` | `3000` | How often the page re-reads the state while it is open and the old copy is being removed |
| `requestTimeoutMs` | `30000` | How long the host half waits for a state read or a removal request |
| `checkTimeoutMs` | `300000` | How long the host half waits for a folder check or a move request, which read the whole data folder first |

## Known limitations

- The page shows no size for the current data folder; the size appears in the confirmation, from the folder check.
- The page has no "Show in Finder" / "Show in File Explorer" buttons: the shell's service has no route to reveal a folder, so paths are shown as text.
- The confirmation gives no time estimate.
- Running conversations are counted only here, once, just before the move is asked for. A turn that starts after that count and before the shell stops the server — most likely a scheduled follow-up firing in that window — is cut off: one interrupted turn, with no data lost. Closing the gap needs the server to hold back new turns until the stop, which neither this plugin nor the shell does.
- If the picked folder changes between the check and **Move** (an empty folder gets a file, say), the shell works the target out again at `/start` and can move the data into a different folder than the confirmation named, such as a new `DSH-Data` folder inside it; nothing says so before the move, and the result names the folder afterwards. Closing the gap needs the shell to answer `/start` with the folder it worked out, or to refuse when it differs from the one the confirmation showed.
