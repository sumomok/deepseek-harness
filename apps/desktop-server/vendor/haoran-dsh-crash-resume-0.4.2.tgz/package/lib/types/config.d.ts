/**
 * Deployment policy for crash recovery.
 *
 * Every field is written out in this package's `cordis.patch.yml` at the
 * value declared here, so a profile that changes one can see what it is
 * replacing.
 *
 * @module @haoran/dsh-crash-resume/config
 */
import z from '@deepseek-ai/schemastery';
/** Tool names whose open call means the turn is waiting for the user's answer. */
export declare const DEFAULT_AWAIT_USER_TOOLS: readonly string[];
/** Model-facing text of the continuation message, in Chinese. */
export declare const DEFAULT_RESUME_TEXT_ZH = "\u5E94\u7528\u5728\u4E0A\u4E00\u8F6E\u8FDB\u884C\u4E2D\u610F\u5916\u9000\u51FA\u3002\u5F53\u65F6\u5728\u6267\u884C\u7684\u5DE5\u5177\u8C03\u7528\u5DF2\u6309\u201C\u7ED3\u679C\u672A\u77E5\u201D\u5173\u95ED\u3002\u91CD\u590D\u4EFB\u4F55\u53EF\u80FD\u53EA\u505A\u4E86\u4E00\u534A\u7684\u64CD\u4F5C\uFF08\u5199\u6587\u4EF6\u3001\u6267\u884C\u547D\u4EE4\u7B49\uFF09\u4E4B\u524D\uFF0C\u5148\u68C0\u67E5\u5B83\u73B0\u5728\u7684\u72B6\u6001\uFF0C\u518D\u7EE7\u7EED\u4EFB\u52A1\u3002";
/** Model-facing text of the continuation message, in English. */
export declare const DEFAULT_RESUME_TEXT_EN = "The app exited unexpectedly in the middle of the previous turn. Tool calls that were in flight were closed with unknown results. Before repeating any partial action such as a file write or a command, check its current state. Then continue the task.";
/** One-line account shown on the continuation row before it is expanded, in Chinese. */
export declare const DEFAULT_RESUME_SUMMARY_ZH = "\u5E94\u7528\u610F\u5916\u9000\u51FA\u540E\u81EA\u52A8\u7EE7\u7EED\u4E0A\u4E00\u8F6E";
/** One-line account shown on the continuation row before it is expanded, in English. */
export declare const DEFAULT_RESUME_SUMMARY_EN = "Continued the previous turn after the app exited unexpectedly";
/** Model-facing text of the continuation a person asks for with the held row's button, in Chinese. */
export declare const DEFAULT_CONTINUE_TEXT_ZH = "\u4E0A\u4E00\u8F6E\u5728\u8FDB\u884C\u4E2D\u88AB\u4E2D\u65AD\uFF08\u5E94\u7528\u9000\u51FA\u6216\u91CD\u542F\uFF09\uFF0C\u7528\u6237\u9009\u62E9\u4ECE\u4E2D\u65AD\u5904\u7EE7\u7EED\u3002\u5F53\u65F6\u5728\u6267\u884C\u7684\u5DE5\u5177\u8C03\u7528\u5DF2\u6309\u201C\u7ED3\u679C\u672A\u77E5\u201D\u5173\u95ED\uFF1B\u5982\u679C\u5F53\u65F6\u5728\u7B49\u6279\u51C6\u6216\u56DE\u7B54\uFF0C\u90A3\u6B21\u8BF7\u6C42\u5DF2\u5931\u6548\u3002\u91CD\u590D\u4EFB\u4F55\u53EF\u80FD\u53EA\u505A\u4E86\u4E00\u534A\u7684\u64CD\u4F5C\uFF08\u5199\u6587\u4EF6\u3001\u6267\u884C\u547D\u4EE4\u7B49\uFF09\u4E4B\u524D\uFF0C\u5148\u68C0\u67E5\u5B83\u73B0\u5728\u7684\u72B6\u6001\uFF0C\u518D\u7EE7\u7EED\u4EFB\u52A1\u3002";
/** Model-facing text of the continuation a person asks for with the held row's button, in English. */
export declare const DEFAULT_CONTINUE_TEXT_EN = "The previous turn was cut short when the app exited or restarted, and the user chose to continue from where it stopped. Tool calls that were in flight were closed with unknown results; if the turn was waiting for an approval or an answer, that request no longer applies. Before repeating any partial action such as a file write or a command, check its current state. Then continue the task.";
/** One-line account stored with the continuation a person asked for, in Chinese. */
export declare const DEFAULT_CONTINUE_SUMMARY_ZH = "\u6309\u7528\u6237\u8981\u6C42\u7EE7\u7EED\u4E0A\u4E00\u8F6E";
/** One-line account stored with the continuation a person asked for, in English. */
export declare const DEFAULT_CONTINUE_SUMMARY_EN = "Continued the previous turn at the user's request";
/** Largest stored log, in bytes, the startup pass reads (64 MiB). */
export declare const DEFAULT_MAX_LOG_BYTES: number;
/** Longest the startup pass waits for one session's log, in milliseconds. */
export declare const DEFAULT_READ_TIMEOUT_MS = 15000;
/** Heartbeat age after which another process's registry counts as dead (one hour). */
export declare const DEFAULT_STALE_REGISTRY_MS: number;
/** Validated deployment policy. */
export interface Config {
    /**
     * Directory for the in-flight registry and the intentional-stop sentinel;
     * absent means `$DSH_HOME/crash-resume`. The desktop shell writes its
     * sentinel to `$DSH_HOME/crash-resume/intentional-stop.json`, so moving
     * this directory without moving the shell's path makes a Windows quit look
     * like a crash.
     */
    stateDir?: string;
    /** Tool names whose open call means the turn is waiting for the user's answer. */
    awaitUserTools?: string[];
    /** Continuation message text, Chinese. */
    resumeTextZh?: string;
    /** Continuation message text, English. */
    resumeTextEn?: string;
    /** Continuation row summary, Chinese. */
    resumeSummaryZh?: string;
    /** Continuation row summary, English. */
    resumeSummaryEn?: string;
    /** Text of the continuation a person asks for with the held row's button, Chinese. */
    continueTextZh?: string;
    /** Text of the continuation a person asks for with the held row's button, English. */
    continueTextEn?: string;
    /** Summary stored with the continuation a person asked for, Chinese. */
    continueSummaryZh?: string;
    /** Summary stored with the continuation a person asked for, English. */
    continueSummaryEn?: string;
    /**
     * Largest stored log, in bytes, the startup pass reads. A larger candidate
     * is skipped with a warning and dropped from the registry. Applies only
     * where the storage backend reports a size (the JSONL backend does).
     */
    maxLogBytes?: number;
    /**
     * Longest the startup pass waits to open and read one candidate's log, in
     * milliseconds. A candidate that takes longer is skipped with a warning and
     * dropped from the registry. The storage read itself is not cancelled; the
     * pass only stops waiting for it.
     */
    readTimeoutMs?: number;
    /**
     * Heartbeat age, in milliseconds, after which another process's in-flight
     * registry counts as dead even though a process with its pid is running.
     * Each server rewrites its registry every quarter of this interval. It
     * covers a pid reused within one boot; a pid from an earlier boot is
     * recognized by the recorded boot time.
     */
    staleRegistryMs?: number;
}
export declare const Config: z<Config>;
/** {@link Config} with every default applied. */
export interface ResolvedConfig {
    readonly stateDir: string;
    readonly awaitUserTools: readonly string[];
    readonly resumeText: {
        readonly zh: string;
        readonly en: string;
    };
    readonly resumeSummary: {
        readonly zh: string;
        readonly en: string;
    };
    readonly continueText: {
        readonly zh: string;
        readonly en: string;
    };
    readonly continueSummary: {
        readonly zh: string;
        readonly en: string;
    };
    readonly maxLogBytes: number;
    readonly readTimeoutMs: number;
    readonly staleRegistryMs: number;
}
/** Name of the state directory under the harness home. */
export declare const STATE_DIR_NAME = "crash-resume";
/**
 * Apply defaults to a validated config.
 * @param config - the schema-validated config.
 * @param home - the harness home the default state directory lives under.
 * @returns the complete policy.
 */
export declare function resolveConfig(config: Config, home?: string): ResolvedConfig;
//# sourceMappingURL=config.d.ts.map