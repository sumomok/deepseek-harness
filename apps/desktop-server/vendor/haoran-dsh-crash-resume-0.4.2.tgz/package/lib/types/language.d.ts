/**
 * The language the user chose in Settings, read the way the desktop shell's
 * boot page reads it (`storedLanguagePreference` in
 * `apps/desktop-shell/src/theme-preference.ts`): the last row with id
 * `locale` in the profile's own patch layer, whose `config.preference` the
 * Settings page writes, and otherwise `locale.preference` in the home's
 * `settings.yaml`. A Chinese or English locale id maps to its language; no
 * choice, or any other id, follows the system locale.
 *
 * @module @haoran/dsh-crash-resume/language
 */
/** A language this plugin writes its model-facing text in. */
export type Language = 'zh' | 'en';
/** Where to look for the stored choice. */
export interface LanguageSources {
    /** The running profile's own `cordis.patch.yml`. */
    readonly patchPath?: string | undefined;
    /** The harness home, holding `settings.yaml`. */
    readonly home?: string | undefined;
    /** The system locale id used when nothing was chosen. */
    readonly systemLocale: string;
}
/**
 * The language to write the continuation message in.
 * @param sources - the profile patch path, the home, and the system locale.
 * @returns `zh` or `en`; English when neither the choice nor the system locale is Chinese or English.
 */
export declare function settingsLanguage(sources: LanguageSources): Language;
//# sourceMappingURL=language.d.ts.map