/**
 * Durable names and payloads this plugin writes into session logs, and the
 * answers its Remote sends, shared by both halves and by the Typert manifest.
 * Pure data: the browser half and the manifest import this module, so it must
 * not reach Node or any host service, and it imports nothing.
 *
 * @module @haoran/dsh-crash-resume/shared
 */
/**
 * Event type of the held marker. The `plugin:` prefix is the namespace V4
 * session logs use for extension-owned names, so a later first-party event
 * cannot collide with it.
 */
export declare const HELD_EVENT_TYPE = "plugin:crash-resume/held";
/** `source.kind` of the message that continues an interrupted turn. */
export declare const RESUME_SOURCE_KIND = "plugin:crash-resume";
/**
 * `source.trigger` of a continuation message a person asked for with the held
 * row's button. An automatic continuation carries no `trigger`.
 */
export declare const PERSON_TRIGGER = "person";
/**
 * Every answer of the `crashResume/continueHeld` Remote, the held row's
 * Continue button.
 *
 * - `sent`: the continuation message was handed to the agent.
 * - `busy`: the agent is running or has queued input.
 * - `settled`: the session is idle and its log no longer ends with the
 *   closers of the named interrupted turn.
 * - `unopened`: the session could not be opened.
 * - `archived`: the session is archived, and an archived session runs no
 *   model step.
 */
export declare const CONTINUE_HELD_RESULTS: readonly ["sent", "busy", "settled", "unopened", "archived"];
/** One of {@link CONTINUE_HELD_RESULTS}. */
export type ContinueHeldResult = typeof CONTINUE_HELD_RESULTS[number];
/**
 * Why an interrupted turn was not continued automatically.
 *
 * - `awaiting-approval`: the turn had asked for an approval nobody answered.
 * - `awaiting-answer`: a question tool was waiting for the user's answer.
 * - `already-resumed`: the turn was itself a continuation, automatic or
 *   confirmed with the held row's button, so continuing it again without
 *   asking could repeat the same crash.
 * - `goal-active`: the session has an active goal. After a restart the goal
 *   service leaves every goal disarmed until a person resumes it, and an
 *   automatic continuation would act on that goal without that consent.
 * - `stopped`: the app was quit or restarted on purpose.
 */
export type HeldReason = 'awaiting-approval' | 'awaiting-answer' | 'already-resumed' | 'goal-active' | 'stopped';
/** Every {@link HeldReason}, for validating a payload read back from a log. */
export declare const HELD_REASONS: readonly HeldReason[];
/**
 * Payload of the held marker. Facts only: the browser half renders the row's
 * text in the viewer's language from these fields.
 */
export interface HeldEventData {
    /**
     * Always null. The browser's conversation index places an event by its
     * payload's `turn` field, and null is its explicit "session level" value
     * (`payloadCoordinates` in dsh-client-ui-conversation's location index), so
     * the row stands between turns instead of inside the turn it follows.
     */
    readonly turn: null;
    /** The interrupted turn the marker follows. */
    readonly interruptedTurn: number;
    /** Why the turn was held. */
    readonly reason: HeldReason;
}
/**
 * Narrow an untyped event payload to {@link HeldEventData}.
 * @param data - the payload read back from a session log or the wire.
 * @returns the payload when it is a well-formed held marker, else undefined.
 */
export declare function heldEventData(data: unknown): HeldEventData | undefined;
//# sourceMappingURL=shared.d.ts.map