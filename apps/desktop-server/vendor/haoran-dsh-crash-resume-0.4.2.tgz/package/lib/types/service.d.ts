/**
 * The `crashResume` Typert Remote: the host side of the held row's Continue
 * button.
 *
 * The browser reaches it only through the harness's `/api` gateway, which
 * dispatches by the strict descriptor in `./typert.ts`: the descriptor names
 * the method, so the class carries no `@Remote` decorator. It has no
 * decorator and no parameter property because the crash specs load
 * `src/index.ts` under plain Node, whose type stripping rejects both.
 *
 * @module @haoran/dsh-crash-resume/service
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { ContinueHeldResult } from './shared.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /**
         * The held row's Continue action (provided by `@haoran/dsh-crash-resume`
         * once its startup pass has finished; absent before).
         */
        crashResume: CrashResumeService;
    }
}
/**
 * Continue one held turn at a person's request.
 * @param sessionId - the session the held row belongs to.
 * @param interruptedTurn - the turn the row's marker names.
 * @returns what happened.
 */
export type ContinueHeld = (sessionId: string, interruptedTurn: number) => Promise<ContinueHeldResult>;
/** The `crashResume` service and Remote namespace. */
export declare class CrashResumeService extends TypertRemoteService {
    private readonly run;
    /**
     * Register the service under `crashResume` and bind the same key as its
     * Remote namespace.
     * @param ctx - owning plugin context; the service is withdrawn with it.
     * @param run - the host action the Remote method delegates to.
     */
    constructor(ctx: Context, run: ContinueHeld);
    /**
     * Continue the interrupted turn a held row names, by sending the
     * continuation message, when the session is still exactly where the
     * interruption left it: idle, nothing queued, and its log ending with the
     * closers of that turn.
     * @param sessionId - the session the held row belongs to.
     * @param interruptedTurn - the turn the row's marker names.
     * @returns `sent`, or why nothing was sent.
     */
    continueHeld(sessionId: string, interruptedTurn: number): Promise<ContinueHeldResult>;
}
//# sourceMappingURL=service.d.ts.map