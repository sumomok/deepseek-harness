/**
 * The browser half's Typert contribution, which `ctx.remote.$mount()`
 * installs as the `remote.crashResume` namespace.
 *
 * It is the host manifest's own invocation list. The gateway matches a call
 * by the descriptor's id, namespace, method and wire names, and the
 * manifest's codecs are plain parse functions with no schema library, so one
 * list serves both sides and the two cannot disagree. The browser never runs
 * the parameter codecs, and the result codec has no `decode`; `./continue.ts`
 * narrows the answer itself.
 *
 * @module @haoran/dsh-crash-resume/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
/** The contribution the browser half mounts. */
export declare const CONTRIBUTION: TypertRemoteContribution;
//# sourceMappingURL=contribution.d.ts.map