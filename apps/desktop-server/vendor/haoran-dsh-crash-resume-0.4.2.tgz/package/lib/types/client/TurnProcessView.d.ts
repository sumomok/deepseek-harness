/**
 * The `turn-process` row: the button above a closed turn's work that folds
 * it, labelled "Completed in …".
 *
 * This view shadows the host's `turn-process` renderer at priority -1 and
 * always renders the host's own component, read from the slot ledger; the
 * button, its duration and its accessibility attributes stay the host's. It
 * changes two things.
 *
 * A turn that ended `interrupted` is opened once. The host writes that end
 * reason when it next opens or reads a session whose log stops inside a
 * turn, whether a crash or a quit cut the turn short and whether this plugin
 * continued it, held it, or left it alone (a turn no person started, a
 * subagent's or an archived session's turn, or a turn cut short before the
 * plugin was installed).
 *
 * The same turn is labelled 「已中断，运行了 …」 / "Interrupted after …"
 * instead of 「已完成，用时 …」 / "Completed in …". The registration declares
 * the chat's `chat` locale namespace, so the slot runtime hands this view the
 * chat's own translator, a new function on every locale switch. For an
 * interrupted turn the view passes the host component a translator that
 * answers the two completion labels from this plugin's dictionary and every
 * other key from the chat's; for any other turn it passes the chat's
 * translator itself. Either way the translator changes identity with the
 * locale, so the memoized host component re-renders in the new language.
 *
 * The same effect records every other closed turn it finds open, without
 * opening anything. When the continuation turn is the earliest turn in the
 * loaded history, the chat shows its opening message as a context row, not a
 * `turn-trigger` row, so the continuation row mounts only after earlier
 * history loads; a turn the reader opened and collapsed before that is then
 * already recorded, and the continuation row leaves it collapsed.
 *
 * @module @haoran/dsh-crash-resume/client/TurnProcessView
 */
import { type ReactNode } from 'react';
import type { TurnProcessOwnerProps } from '@deepseek-ai/dsh-client-ui-chat/client';
import type { ConversationLocation } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { StoredEntry, Translate, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import { type ExpandedStoreProps } from './expand-once.ts';
import type { CrashResumeKey } from './locales.ts';
/** The props a keyed `turn-process` entry receives; only the parts this view reads are named. */
export type TurnProcessViewProps = {
    readonly node?: {
        readonly location?: ConversationLocation;
    };
    readonly turnProcess?: TurnProcessOwnerProps | undefined;
    /** The chat's translator: the `chat` locale seat, a new function per locale revision. */
    readonly t: TranslateNS<'chat'>;
} & ExpandedStoreProps;
/** What the view needs from the plugin context, resolved per render. */
export interface TurnProcessViewDeps {
    /** Live ledger of `conversation.chat.node` entries. */
    readonly entries: () => readonly StoredEntry[];
    /** Translate bound to this plugin's namespace. */
    readonly t: () => Translate<CrashResumeKey>;
}
/**
 * Whether a node belongs to a turn that ended because the app exited in the middle of it.
 * @param node - a chat node; only its location is read.
 * @returns true when the node's turn is closed with end reason `interrupted`.
 */
export declare function isInterruptedTurn(node: {
    readonly location?: ConversationLocation;
} | undefined): boolean;
/**
 * Build the shadowing renderer for the `turn-process` cell.
 * @param deps - ledger access and this plugin's translator.
 * @returns the component to register at `priority: -1`, with locale `chat` and the record's store.
 */
export declare function createTurnProcessView(deps: TurnProcessViewDeps): (props: TurnProcessViewProps) => ReactNode;
//# sourceMappingURL=TurnProcessView.d.ts.map