/**
 * Why a press did not continue the turn, one alert line each.
 *
 * - `moved-on`: the session is running, has queued input, or is past the
 *   interrupted turn (host answers `busy` and `settled`).
 * - `unopened`: the host could not open the session.
 * - `archived`: the session is archived.
 * - `failed`: the call did not reach the host, the host refused it, or the
 *   answer was none of the known ones.
 */
export type Refusal = 'moved-on' | 'unopened' | 'archived' | 'failed';
/** What a press led to: the message was sent, or one {@link Refusal}. */
export type ContinueOutcome = 'sent' | Refusal;
/** One RPC result, as the gateway's namespace methods return it. */
export type RemoteResult<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error?: {
        code?: string;
        message?: string;
    };
};
/** The slice of the `remote.crashResume` namespace the row calls. */
export interface CrashResumeRemote {
    /**
     * Ask the host to continue a held turn.
     * @param sessionId - the session the row belongs to.
     * @param interruptedTurn - the turn the row's marker names.
     * @returns the gateway's result; the value is unchecked wire data.
     */
    continueHeld(sessionId: string, interruptedTurn: number): Promise<RemoteResult<unknown>>;
}
/**
 * Continue a held turn and say what happened.
 * @param sessionId - the session the row belongs to.
 * @param interruptedTurn - the turn the row's marker names.
 * @returns the outcome to show; never rejects.
 */
export type ContinueHeldAction = (sessionId: string, interruptedTurn: number) => Promise<ContinueOutcome>;
/**
 * Map one gateway result to the outcome the row shows.
 * @param result - the result of a `continueHeld` call.
 * @returns `sent`, or the refusal line to show.
 */
export declare function outcomeOf(result: RemoteResult<unknown>): ContinueOutcome;
/**
 * Bind the Continue action to the mounted namespace.
 * @param remote - settles to the namespace once it is mounted, or to
 * undefined when the mount failed; awaited on every press, so a press made
 * while the mount is still running waits for it.
 * @returns the action the held row calls.
 */
export declare function continueAction(remote: Promise<CrashResumeRemote | undefined>): ContinueHeldAction;
//# sourceMappingURL=continue.d.ts.map