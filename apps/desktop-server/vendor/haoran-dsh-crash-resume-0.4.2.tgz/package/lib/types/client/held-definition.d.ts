/**
 * The conversation Definition that turns a held marker into a chat row of
 * its own.
 *
 * The marker is written after the interrupted turn's `turn/end` with
 * `turn: null`, the payload value the engine's location index reads as
 * "session level", so the engine places it outside every turn. The chat's grouping
 * emits a node with no turn as its own root entry rather than folding it into
 * a turn's process group, which is why this row needs no change to the
 * chat's fixed list of turn-independent kinds.
 *
 * @module @haoran/dsh-crash-resume/client/held-definition
 */
import type { ConversationNodeDefinition, ConversationViewNode } from '@deepseek-ai/dsh-client-ui-conversation/client';
import { type HeldReason } from '../shared.ts';
/** Chat node kind, and the keyed-slot entry that renders it. */
export declare const HELD_NODE_KIND = "crash-resume-held";
/** Renderer payload of the held row. */
export interface HeldNodeData {
    readonly seq: number;
    readonly time: number;
    readonly interruptedTurn: number;
    readonly reason: HeldReason;
}
/** The Chat node shape the chat target reads; fields beyond `ConversationViewNode` are the chat's own. */
export interface HeldChatNode extends ConversationViewNode {
    readonly kind: typeof HELD_NODE_KIND;
    readonly anchorSeq: number;
    readonly location: {
        readonly kind: 'session';
    };
    readonly visibility: 'visible';
    readonly data: HeldNodeData;
}
/** One held marker, one row. */
export declare const heldDefinition: ConversationNodeDefinition<HeldNodeData>;
//# sourceMappingURL=held-definition.d.ts.map