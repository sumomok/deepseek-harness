/**
 * The held row: the turn above stopped and was not continued automatically.
 *
 * What the row says comes from the marker's two fields and the session's
 * own state, so it reads the same on every reload and in the viewer's own
 * language. It is one line of grey text, "<title> · <reason>", in the
 * typography of the chat's own turn header (「已停止」 / "Stopped"):
 *
 * - **Open**: the line and a borderless Continue text button at its end.
 * - **Pending**: the button is disabled and reads "Continuing…" from the
 *   press until the session moves past the interrupted turn.
 * - **Refused**: an alert after the button saying why nothing was sent; the
 *   button is enabled again.
 * - **Settled**: once any turn after the interrupted one exists, whoever
 *   started it, the row keeps only the line.
 *
 * The button is disabled while the session runs or holds a message not yet
 * admitted. The host checks again on every press and is the one that
 * decides.
 *
 * @module @haoran/dsh-crash-resume/client/HeldCard
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { ContinueHeldAction } from './continue.ts';
import type { HeldNodeData } from './held-definition.ts';
/** The session snapshot fields the row reads. */
export interface HeldSessionFields {
    /** Whether the session's agent is running. */
    readonly running: boolean;
    /** Messages sent from this page that the host has not admitted yet. */
    readonly pendingSubmissions: readonly unknown[];
}
/** The chat snapshot fields the row reads. */
export interface HeldChatFields {
    /** The turn numbers the chat has seen, in log order. */
    readonly timeline: {
        readonly turnOrder: readonly number[];
    };
}
/**
 * Props of the held row: the node the chat hands the keyed slot, the session
 * standard props it reads, and this plugin's translator.
 */
export type HeldCardProps = {
    readonly node: {
        readonly data: HeldNodeData;
    };
    readonly sessionId: SessionId;
    readonly useSession: <S>(selector: (session: HeldSessionFields) => S) => S;
    readonly useChat: <S>(selector: (chat: HeldChatFields) => S) => S;
} & PropsLocale<'crash-resume'>;
/** What the row needs from the plugin context. */
export interface HeldCardDeps {
    /** The Continue action. */
    readonly continueHeld: ContinueHeldAction;
}
/**
 * Build the held row. Called once per load of the plugin, so the component
 * keeps one identity across registrations.
 * @param deps - the Continue action.
 * @returns the component to register on the held node's keyed cell.
 */
export declare function createHeldCard(deps: HeldCardDeps): (props: HeldCardProps) => ReactNode;
//# sourceMappingURL=HeldCard.d.ts.map