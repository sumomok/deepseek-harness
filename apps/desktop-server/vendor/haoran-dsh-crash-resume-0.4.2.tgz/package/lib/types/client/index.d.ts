/**
 * Browser half of @haoran/dsh-crash-resume: the held row with its Continue
 * button, the continuation message's row, the 「已中断」 / "Interrupted"
 * label on the header of a turn that ended `interrupted`, and the work
 * details of the turns that ended `interrupted` or that the continuation
 * message started, opened once per session scope.
 *
 * Both rows are built from events the chat already folds — the held marker
 * and the continuation `user/message` — and from the session's own state, so
 * they read the same on every reload, in the viewer's own language. Which
 * turns to open is read from the same events: a turn's `turn/end` reason and
 * the source of the message that opened it.
 *
 * The one host path is the `crashResume` Remote this package's host half
 * provides, mounted through `ctx.remote.$mount()`; only the Continue button
 * calls it.
 *
 * @module @haoran/dsh-crash-resume/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type HeldNodeData } from './held-definition.ts';
import { type CrashResumeKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-crash-resume` copy. */
        'crash-resume': CrashResumeKey;
    }
}
declare module '@deepseek-ai/dsh-client-ui-chat/client' {
    interface ChatNodeDataMap {
        /** A turn interrupted by a crash or a quit that was not continued automatically. */
        'crash-resume-held': HeldNodeData;
    }
}
export { CONTRIBUTION } from './contribution.ts';
export { continueAction, outcomeOf } from './continue.ts';
export type { ContinueHeldAction, ContinueOutcome, CrashResumeRemote, Refusal, RemoteResult } from './continue.ts';
export { closedTurn, createExpandedStore, expandedKey, useExpandOnce } from './expand-once.ts';
export type { ExpandedActions, ExpandedState, ExpandedStore, ExpandedStoreProps } from './expand-once.ts';
export { createHeldCard } from './HeldCard.tsx';
export type { HeldCardDeps, HeldCardProps, HeldChatFields, HeldSessionFields } from './HeldCard.tsx';
export { HELD_NODE_KIND, heldDefinition } from './held-definition.ts';
export type { HeldChatNode, HeldNodeData } from './held-definition.ts';
export { en, NS, zh } from './locales.ts';
export type { CrashResumeKey } from './locales.ts';
export { createResumeTriggerView, isPersonTrigger, isResumeSource, pickIncumbent } from './ResumeTriggerView.tsx';
export type { ResumeTriggerDeps, TriggerProps } from './ResumeTriggerView.tsx';
export { insertStyles, STYLE_TAG } from './styles.ts';
export { createTurnProcessView, isInterruptedTurn } from './TurnProcessView.tsx';
export type { TurnProcessViewDeps, TurnProcessViewProps } from './TurnProcessView.tsx';
/** Required browser services; every `ctx.<name>` read below is listed. */
export declare const inject: string[];
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 * @returns once the Remote mount has settled, after every row is registered.
 */
export declare function apply(ctx: Context): Promise<void>;
//# sourceMappingURL=index.d.ts.map