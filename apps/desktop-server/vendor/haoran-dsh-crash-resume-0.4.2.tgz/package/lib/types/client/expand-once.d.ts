import { type PropsStore, type StoreHandle } from '@deepseek-ai/dsh-client-store';
import type { TurnProcessOwnerProps, TurnProcessSpec } from '@deepseek-ai/dsh-client-ui-chat/client';
import type { ConversationLocation, TurnLocation } from '@deepseek-ai/dsh-client-ui-conversation/client';
/** The record of turn generations opened or found open within one session scope. */
export interface ExpandedState {
    /** One {@link expandedKey} per recorded turn generation. */
    expanded: string[];
}
/** The record's write set. */
export type ExpandedActions = {
    /** Record one turn generation; recording it again changes nothing. */
    markExpanded: (draft: ExpandedState, key: string) => void;
};
/** Handle of the record's store. */
export type ExpandedStore = StoreHandle<ExpandedState, ExpandedActions>;
/** What a registration declaring the record's store receives: its selector hook and its write set. */
export type ExpandedStoreProps = PropsStore<ExpandedStore>;
/**
 * Declare the record's store. Called inside `apply`, so each load of the
 * plugin gets its own handle; the handle's identity is what makes the two
 * registrations share one instance per session scope.
 * @returns the handle both chat-node registrations pass as `store`.
 */
export declare function createExpandedStore(): ExpandedStore;
/**
 * The record key of one turn generation: the turn and its answer step (0 for
 * a turn with no answer), the pair the chat keys its own open state by. A
 * turn whose answer step changes is a new generation, which the chat shows
 * folded again.
 * @param spec - the turn's process spec.
 * @returns the key.
 */
export declare function expandedKey(spec: Pick<TurnProcessSpec, 'turn' | 'answerStep'>): string;
/**
 * The turn a node belongs to, once that turn has ended.
 * @param node - a chat node; only its location is read.
 * @returns the turn's location when its status is `closed`; undefined for a
 * running turn, a turn of unknown status, or a node outside every turn.
 */
export declare function closedTurn(node: {
    readonly location?: ConversationLocation;
} | undefined): TurnLocation | undefined;
/**
 * Open a turn's work details once. Runs in a layout effect, which React
 * runs after the commit and before the browser paints: the earliest point at
 * which the chat's setter may be called.
 *
 * The first time `eligible` holds for a turn generation, its key is recorded
 * and, unless the chat already shows the turn open, `setOpen(true)` is
 * called. A recorded generation is never opened again within the same
 * session scope, so a collapse stays collapsed; a turn found already open is
 * recorded the same way, so collapsing it later stays as well.
 * @param turnProcess - the chat's turn-process owner props for this row; absent outside a projected turn.
 * @param eligible - whether this row's turn is one to open.
 * @param store - the record's selector hook and write set.
 */
export declare function useExpandOnce(turnProcess: TurnProcessOwnerProps | undefined, eligible: boolean, store: ExpandedStoreProps): void;
//# sourceMappingURL=expand-once.d.ts.map