/**
 * Copy for the browser half, in the two locales the harness ships.
 *
 * The `held.reason.*` lines state facts only, so they still read true once
 * the session has moved on and the held row shows no button. Every `held.*`
 * string sits inside one line of the chat and ends without a full stop.
 *
 * The `interrupted.*` strings label the header of a turn the app's exit cut
 * short. `interrupted.took` is a prefix: the chat appends the turn's duration
 * after it, so it keeps its trailing space, as the chat's own
 * 「已完成，用时 」 / "Completed in " does.
 *
 * @module @haoran/dsh-crash-resume/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "crash-resume";
/** Every key the browser half looks up. */
export type CrashResumeKey = 'held.title' | 'held.reason.awaiting-approval' | 'held.reason.awaiting-answer' | 'held.reason.already-resumed' | 'held.reason.goal-active' | 'held.reason.stopped' | 'held.continue' | 'held.continuing' | 'held.refused.moved-on' | 'held.refused.unopened' | 'held.refused.archived' | 'held.refused.failed' | 'resumed.title' | 'resumed.explanation' | 'resumed.title.person' | 'resumed.explanation.person' | 'interrupted.took' | 'interrupted.worked';
/** Chinese copy. */
export declare const zh: Record<CrashResumeKey, string>;
/** English copy. */
export declare const en: Record<CrashResumeKey, string>;
//# sourceMappingURL=locales.d.ts.map