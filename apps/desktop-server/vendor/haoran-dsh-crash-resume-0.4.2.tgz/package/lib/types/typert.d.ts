/**
 * Host-face Typert manifest, discovered by `@deepseek-ai/dsh-typert-loader`
 * through `exports["./typert"]` and registered under this package's name.
 * Hand-written, because the Typert generator runs over the harness workspace,
 * not over out-of-repo packages.
 *
 * The gateway decodes every wire argument with its codec's `create().parse`
 * before the service runs, so a call with an empty session id or a turn that
 * is not a non-negative integer never reaches `continueHeld`. Neither side
 * runs the result codec's `parse`; it documents the answers, and the browser
 * half narrows the value itself.
 *
 * The loader imports the built `lib/typert.js` by file path, outside the
 * plugin's module graph, so this module imports only `./shared.ts`, which
 * the build inlines.
 *
 * @module @haoran/dsh-crash-resume/typert
 */
import { type ContinueHeldResult } from './shared.ts';
/**
 * Narrow the `sessionId` wire argument.
 * @param value - the wire value.
 * @returns the id.
 * @throws when it is not a non-empty string.
 */
export declare function parseSessionIdArgument(value: unknown): string;
/**
 * Narrow the `interruptedTurn` wire argument.
 * @param value - the wire value.
 * @returns the turn number.
 * @throws when it is not a non-negative safe integer.
 */
export declare function parseTurnArgument(value: unknown): number;
/**
 * Narrow a `continueHeld` answer.
 * @param value - the answer.
 * @returns the answer as one of {@link CONTINUE_HELD_RESULTS}.
 * @throws when it is not one of them.
 */
export declare function parseContinueHeldResult(value: unknown): ContinueHeldResult;
/** Type symbols of the three codecs; the browser contribution repeats them. */
export declare const TYPE_SYMBOLS: {
    readonly sessionId: "@haoran/dsh-crash-resume#SessionIdText";
    readonly interruptedTurn: "@haoran/dsh-crash-resume#InterruptedTurn";
    readonly result: "@haoran/dsh-crash-resume#ContinueHeldResult";
};
/** The contribution `dsh-typert-loader` registers for this package. */
export declare const TYPERT: {
    readonly package: "@haoran/dsh-crash-resume";
    readonly face: "host";
    readonly schemas: readonly [];
    readonly invocations: readonly [{
        readonly id: "@haoran/dsh-crash-resume#crashResume/continueHeld";
        readonly service: "crashResume";
        readonly namespace: "crashResume";
        readonly method: "continueHeld";
        readonly invocation: {
            readonly kind: "direct";
        };
        readonly parameters: readonly [{
            readonly name: "sessionId";
            readonly wire: "sessionId";
            readonly source: "json";
            readonly codec: {
                readonly mode: "strict";
                readonly typeSymbol: "@haoran/dsh-crash-resume#SessionIdText";
                readonly create: () => {
                    parse: typeof parseSessionIdArgument;
                };
            };
        }, {
            readonly name: "interruptedTurn";
            readonly wire: "interruptedTurn";
            readonly source: "json";
            readonly codec: {
                readonly mode: "strict";
                readonly typeSymbol: "@haoran/dsh-crash-resume#InterruptedTurn";
                readonly create: () => {
                    parse: typeof parseTurnArgument;
                };
            };
        }];
        readonly result: {
            readonly mode: "strict";
            readonly typeSymbol: "@haoran/dsh-crash-resume#ContinueHeldResult";
            readonly create: () => {
                parse: typeof parseContinueHeldResult;
            };
        };
    }];
    readonly model: {
        readonly services: readonly [{
            readonly description: "Continue a turn that crash recovery held instead of continuing it automatically, at a person's request (ctx.crashResume).";
            readonly summary: "Continue a held turn at a person's request.";
            readonly tags: readonly [];
            readonly jsDoc: "/** Continue a held turn at a person's request. */";
            readonly key: "crashResume";
            readonly exportName: "CrashResumeService";
            readonly members: readonly [{
                readonly kind: "method";
                readonly name: "continueHeld";
                readonly signature: "continueHeld(sessionId: string, interruptedTurn: number): Promise<ContinueHeldResult>";
                readonly summary: "Continue the held turn when the session is still where the interruption left it.";
                readonly jsDoc: "/** Continue the held turn when the session is still where the interruption left it. */";
            }];
            readonly types: readonly [];
        }];
        readonly events: readonly [];
        readonly objects: readonly [];
    };
};
export default TYPERT;
//# sourceMappingURL=typert.d.ts.map