/**
 * The files this plugin keeps under its state directory
 * (`$DSH_HOME/crash-resume` by default).
 *
 * - `in-flight/<pid>.json`: one registry per server process. It holds the ids
 *   of top-level sessions whose turn has started and not yet ended in that
 *   process, the id the startup pass is reading, if any, the machine's boot
 *   time, and a heartbeat the process refreshes while it runs. A startup
 *   reads the registries of dead processes, plus the one named by its own
 *   pid (see {@link registryDead} for when a registry counts as dead). Those sessions are the only candidates, so startup
 *   never scans the session store. Each process writes only its own file, so
 *   two servers sharing one home never overwrite each other's entries and
 *   need no lock file. Two servers that start at the same moment can both
 *   read one dead registry; the session store's single-writer ownership
 *   decides which of them acts on each session.
 * - `intentional-stop.json`: written when the server receives SIGTERM or
 *   SIGINT. Its presence at the next startup means the interrupted turns were
 *   cut short by a stop request, not a crash. The desktop shell writes the
 *   same file, in the same format, before it force-kills the server on
 *   Windows. There is one sentinel per home: with two servers on one home, a
 *   stop of one can make the other's crash read as a stop, which holds turns
 *   that could have been continued and never continues one that should be
 *   held.
 *
 * Every write is atomic: a uniquely named temporary file in the same
 * directory is written and fsynced, renamed over the target, and the
 * directory is fsynced where the platform allows it. A crash leaves the old
 * content or the new content, never a torn file.
 *
 * @module @haoran/dsh-crash-resume/state-files
 */
/** Directory of the per-process registries inside the state directory. */
export declare const IN_FLIGHT_DIR = "in-flight";
/** File name of the intentional-stop sentinel inside the state directory. */
export declare const SENTINEL_FILE = "intentional-stop.json";
/** Format version of every file here. */
export declare const STATE_FILE_VERSION = 1;
/** Contents of one `in-flight/<pid>.json`. */
export interface InFlightFile {
    readonly version: 1;
    /** The writing process. */
    readonly pid: number;
    /** Epoch milliseconds the machine booted, as {@link bootTime} read it. */
    readonly boot: number;
    /** Epoch milliseconds of the last write; rewritten periodically while the process runs. */
    readonly heartbeat: number;
    /** Session ids, each at most once. */
    readonly sessions: readonly string[];
    /**
     * The ids the startup pass was reading when this file was written. A
     * process that died while this is non-empty died reading those logs,
     * possibly out of memory, so the next startup skips them instead of
     * reading them again.
     */
    readonly examining: readonly string[];
}
/** Who wrote the sentinel. */
export type SentinelWriter = 'shell' | 'server';
/** Contents of `intentional-stop.json`. */
export interface SentinelFile {
    readonly version: 1;
    /** Epoch milliseconds of the write. */
    readonly at: number;
    readonly by: SentinelWriter;
    /** Free-form cause, for diagnostics only; never interpreted. */
    readonly reason: string;
}
/** Result of parsing one registry. */
export type InFlightRead = {
    readonly kind: 'ok';
    readonly file: InFlightFile;
} | {
    readonly kind: 'corrupt';
    readonly detail: string;
};
/**
 * The path of one process's registry.
 * @param directory - the state directory.
 * @param pid - the process id.
 * @returns the file path.
 */
export declare function registryPath(directory: string, pid: number): string;
/**
 * Write `text` to `target` atomically.
 * @param directory - the directory holding `target`; created when absent.
 * @param target - the destination path, directly inside `directory`.
 * @param text - the complete new content.
 */
export declare function writeAtomic(directory: string, target: string, text: string): Promise<void>;
/**
 * Synchronous form of {@link writeAtomic}, for a signal listener that must
 * finish before the process starts tearing down.
 * @param directory - the directory holding `target`; created when absent.
 * @param target - the destination path, directly inside `directory`.
 * @param text - the complete new content.
 */
export declare function writeAtomicSync(directory: string, target: string, text: string): void;
/**
 * Largest difference, in milliseconds, between two boot-time readings of the
 * same boot. The reading is wall clock minus uptime, so a wall-clock
 * correction shifts it; a reboot moves it by at least the reboot's duration.
 */
export declare const BOOT_TOLERANCE_MS = 60000;
/**
 * The machine's boot time: `Date.now()` minus `os.uptime()`. Node's
 * `os.uptime()` is libuv's `uv_uptime`, which counts from boot including
 * sleep; on macOS the result matches `sysctl kern.boottime`.
 * @returns epoch milliseconds, rounded to the millisecond.
 */
export declare function bootTime(): number;
/** Fields of one registry besides its format version. */
export interface InFlightState {
    readonly pid: number;
    readonly boot: number;
    readonly heartbeat: number;
    readonly sessions: Iterable<string>;
    readonly examining?: Iterable<string>;
}
/**
 * Serialize one registry.
 * @param state - the registry's fields.
 * @returns the file text.
 */
export declare function formatInFlight(state: InFlightState): string;
/**
 * Parse registry text. Anything that is not exactly this module's own format
 * is `corrupt`, so a damaged file never becomes a list of sessions to act on.
 * @param text - the file content.
 * @returns the parsed file, or the reason the content cannot be used.
 */
export declare function parseInFlight(text: string): InFlightRead;
/**
 * Whether a process id belongs to a running process. A pid reused by an
 * unrelated process reads as running; {@link registryDead} covers that case.
 * @param pid - the process id.
 * @returns true unless the system reports no such process.
 */
export declare function processRunning(pid: number): boolean;
/** One registry found on disk. */
export interface FoundRegistry {
    readonly path: string;
    /** The pid named by the file name. */
    readonly pid: number;
    readonly read: InFlightRead;
    /** Epoch milliseconds of the file's last modification. */
    readonly modified: number;
}
/** What {@link registryDead} compares a registry against. */
export interface Liveness {
    /** This process's id. */
    readonly pid: number;
    /** {@link bootTime} now. */
    readonly boot: number;
    /** Epoch milliseconds now. */
    readonly now: number;
    /** Heartbeat age after which a registry counts as dead. */
    readonly staleAfterMs: number;
}
/**
 * Whether a registry's writer is gone, so a startup may take over its
 * sessions. It is gone when:
 * - the file is named by this process's own pid (a previous holder of the
 *   pid, or this process's own earlier load of the plugin);
 * - no process has its pid;
 * - it was written in an earlier boot, so its pid is from another process
 *   table even when a live process now holds the same number;
 * - its heartbeat is older than `staleAfterMs`, which covers a pid reused
 *   within one boot. A damaged file's modification time stands in for the
 *   heartbeat.
 * @param found - the registry.
 * @param live - this process and the clock.
 * @returns true when the registry's sessions may be taken over.
 */
export declare function registryDead(found: FoundRegistry, live: Liveness): boolean;
/**
 * Read every registry in the state directory.
 * @param directory - the state directory.
 * @returns each file with its parse result; an absent directory yields none.
 */
export declare function readRegistries(directory: string): Promise<FoundRegistry[]>;
/**
 * Queue an atomic write of `text` to `target` after every write already
 * queued for that path in this process.
 * @param directory - the directory holding `target`.
 * @param target - the destination path.
 * @param text - the complete new content.
 * @returns settlement of this write; it rejects when the write fails.
 */
export declare function queueWrite(directory: string, target: string, text: string): Promise<void>;
/**
 * Wait for every write queued for `target` so far.
 * @param target - the destination path.
 * @returns once they have settled.
 */
export declare function writesSettled(target: string): Promise<void>;
/**
 * Serialize a sentinel.
 * @param by - the writer.
 * @param reason - diagnostic cause.
 * @param at - epoch milliseconds of the write.
 * @returns the file text.
 */
export declare function formatSentinel(by: SentinelWriter, reason: string, at: number): string;
/**
 * Write the sentinel synchronously.
 * @param directory - the state directory.
 * @param reason - diagnostic cause.
 */
export declare function writeSentinelSync(directory: string, reason: string): void;
/**
 * Read the sentinel without removing it. Its presence is the whole signal:
 * content that does not parse still means somebody stopped the app on
 * purpose, and is reported so the damage is visible.
 * @param directory - the state directory.
 * @returns whether a sentinel is present, and a parse problem when there is one.
 */
export declare function peekSentinel(directory: string): {
    present: boolean;
    problem?: string;
};
/**
 * Remove the sentinel once the startup pass has acted on it.
 * @param directory - the state directory.
 */
export declare function removeSentinel(directory: string): Promise<void>;
//# sourceMappingURL=state-files.d.ts.map