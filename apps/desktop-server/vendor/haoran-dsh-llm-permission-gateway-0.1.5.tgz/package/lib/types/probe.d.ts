/**
 * The trace this gate leaves behind, so a decision can be inspected after the
 * fact instead of inferred from a latency bump.
 *
 * Only two of the gate's answers are visible anywhere else: a denial surfaces
 * to the model as a tool error, and an `ask` reaches the session log as an
 * `approval/asked` pair. An allow is silent — indistinguishable in the log from
 * a call this plugin never saw — which leaves the most common outcome, and the
 * one the review model actually spends money on, unaccounted for.
 *
 * A session event would be the natural home for it and is not available: a
 * `SessionEventMap` member is required-on-read, the harness registers event
 * types in its own tree, and an unknown non-ignorable event makes the host
 * refuse to replay the whole session log. So the record goes to a file this
 * package owns and to the host log, neither of which the harness reads back.
 *
 * Nothing here is part of a decision. Every write is contained, a failing write
 * is reported once and then ignored, and no path returns a value the caller's
 * verdict depends on.
 * @module @haoran/dsh-llm-permission-gateway/probe
 */
import type { TokenUsage } from '@deepseek-ai/dsh-llm';
import type { JudgeVerdict } from './judge.ts';
import type { RedLine } from './redline.ts';
/**
 * Which step of the decision order answered. The names match the README's
 * numbered order, so a record says not just what was decided but which layer
 * decided it — a `cache` allow and a `model` allow cost very different things.
 */
export type VerdictSource = 'redline' | 'alwaysAsk' | 'readOnly' | 'oversize' | 'cache' | 'model' | 'failure';
/** Identity, size, and content of the call a record describes. */
export interface ProbeCall {
    /** The tool the model asked to run. */
    readonly tool: string;
    /** Registry call id, the same one the approval seam and the session log carry. */
    readonly callId: string;
    /** Root model-requested call owning this execution tree; omitted when it is the call itself. */
    readonly rootCallId?: string;
    /** Session id of the agent the call belongs to; omitted for a call made outside an agent. */
    readonly agent?: string;
    /**
     * Canonical JSON of the whole call. Its length is the number
     * `maxArgumentsChars` is compared against, and its opening characters are
     * what an enabled preview keeps.
     */
    readonly serialized: string;
    /**
     * Full hex digest of the call's arguments — the argument half of the cache
     * key, so two records sharing it were offered the same arguments. The record
     * keeps its first {@link DIGEST_CHARS} characters.
     */
    readonly argsDigest: string;
}
/** What the gate decided and what reaching that decision cost. */
export interface ProbeOutcome {
    /** The step that answered. */
    readonly source: VerdictSource;
    /** The answer; `readOnly` records `allow`, because delegating admits the call. */
    readonly decision: JudgeVerdict;
    /** Wall-clock time this gate held the call, including any review round trip. */
    readonly latencyMs: number;
    /** Which red line matched; present only when `source` is `redline`. */
    readonly redLine?: RedLine;
    /** Why no verdict was obtained; present only when `source` is `failure`. */
    readonly failureCause?: string;
    /** The reason sentence attached to the decision, before truncation. */
    readonly reason?: string;
    /**
     * What the review request spent. Present only when a review was actually
     * issued — a `model` decision and a `failure` whose stream reported usage
     * before it broke — so summing these numbers over a file counts every token
     * this gate bought and nothing else.
     */
    readonly usage?: TokenUsage;
}
/**
 * One decision, as written to the probe file. Field order is the write order,
 * so the JSONL is readable without a parser.
 *
 * The token counts are the harness's disjoint ones: `inputTokens` excludes the
 * cached prefix, so one review's billed prompt is `inputTokens +
 * cacheReadTokens`.
 */
export interface VerdictRecord {
    /** When the decision was reached, ISO-8601. */
    readonly at: string;
    /** The tool the model asked to run. */
    readonly tool: string;
    /** Registry call id, the same one the approval seam and the session log carry. */
    readonly callId: string;
    /** Root model-requested call owning this execution tree; absent when it is the call itself. */
    readonly rootCallId?: string;
    /** Session id of the agent the call belongs to; absent for a call made outside an agent. */
    readonly agent?: string;
    /** Serialized size of the call, the number `maxArgumentsChars` is compared against. */
    readonly argsChars: number;
    /** First {@link DIGEST_CHARS} characters of the argument digest; equal digests mean equal arguments. */
    readonly argsDigest: string;
    /** The step that answered. */
    readonly source: VerdictSource;
    /** The answer. */
    readonly decision: JudgeVerdict;
    /** Wall-clock time this gate held the call, rounded to whole milliseconds. */
    readonly latencyMs: number;
    /** The judge route's model id, so a record names the reviewer that produced it. */
    readonly model: string;
    /** Uncached prompt tokens the review spent; absent when no review was issued. */
    readonly inputTokens?: number;
    /** Answer tokens the review spent; absent when no review was issued. */
    readonly outputTokens?: number;
    /** Prompt tokens served from the provider's cache; absent when the provider reported none. */
    readonly cacheReadTokens?: number;
    /** Thinking tokens inside the answer; absent when the provider reported none. */
    readonly reasoningTokens?: number;
    /** Which red line matched; absent unless `source` is `redline`. */
    readonly redLine?: RedLine;
    /** Why no verdict was obtained; absent unless `source` is `failure`. */
    readonly failureCause?: string;
    /** The reason sentence, truncated to {@link MAX_REASON_CHARS}; absent when the step produced none. */
    readonly reason?: string;
    /**
     * Opening characters of the serialized call, whitespace collapsed; absent
     * unless {@link RecordFormat.argsPreviewChars} is above zero. This is the
     * user's own argument text, so it is off by default.
     */
    readonly argsPreview?: string;
}
/**
 * The two host-log methods this module uses, stated locally so the probe stays
 * a plain Node module rather than importing the plugin context.
 */
export interface ProbeLog {
    /** One-line decision summary. */
    info(message: string): void;
    /** Reported once, when the record file cannot be written. */
    warn(message: string): void;
}
/** What every record carries beyond the call itself, and how much of the call it keeps. */
export interface RecordFormat {
    /** Judge route's model id, stamped on every record. */
    readonly model: string;
    /** Characters of serialized argument text kept in each record; `0` keeps none. */
    readonly argsPreviewChars: number;
}
/** How a probe writes. */
export interface VerdictProbeOptions extends RecordFormat {
    /** Absolute path of the JSONL record, or `false` to write no file. */
    readonly logPath: string | false;
    /** Host log receiving the one-line summary, and the single unwritable-file warning. */
    readonly log: ProbeLog;
}
/** Records decisions; every method returns nothing and throws nothing. */
export interface VerdictProbe {
    /**
     * Record one decision.
     * @param call - identity, size, and content of the call that was decided.
     * @param outcome - what was decided, by which step, and at what cost.
     */
    record(call: ProbeCall, outcome: ProbeOutcome): void;
}
/**
 * Where decisions are recorded when the profile names no path.
 *
 * Under the harness home rather than beside the package, because the package
 * directory is reinstalled on every version bump and is also inside this
 * plugin's own self-modification red line.
 * @returns the absolute default record path.
 */
export declare function defaultVerdictLogPath(): string;
/**
 * Build the record for one decision.
 * @param call - identity, size, and content of the call that was decided.
 * @param outcome - what was decided, by which step, and at what cost.
 * @param format - the reviewer stamped on the record and how much of the call it keeps.
 * @returns the record to serialize, with absent optional fields left out entirely.
 */
export declare function verdictRecord(call: ProbeCall, outcome: ProbeOutcome, format: RecordFormat): VerdictRecord;
/**
 * Render a record as the one line that goes to the host log.
 *
 * Neither the reason nor the argument preview is included: both are text about
 * the user's own arguments, and the host log is a coarser-grained place than
 * the record file. Read the file for them.
 * @param record - the record to summarize.
 * @returns a single line, no trailing newline.
 */
export declare function verdictSummary(record: VerdictRecord): string;
/**
 * Create the probe used for the lifetime of one plugin instance.
 * @param options - where to write, what to stamp and keep, and the host log.
 * @returns a probe whose `record` never throws and never blocks on the host log.
 */
export declare function createVerdictProbe(options: VerdictProbeOptions): VerdictProbe;
//# sourceMappingURL=probe.d.ts.map