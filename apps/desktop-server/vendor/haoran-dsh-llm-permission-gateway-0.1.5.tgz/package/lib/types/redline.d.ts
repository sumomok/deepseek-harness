/**
 * The two denials this gateway makes without consulting the review model and
 * without consulting its own configuration.
 *
 * They exist because a gate whose every decision is delegated has a single
 * point of failure: persuade or degrade the reviewer and the gate opens. These
 * two run first, on every tool call, and no `Config` field can reach them —
 * that is their whole purpose, so nothing here may become configurable.
 *
 * Detection is deliberately narrow. A red line reports only argument text that
 * has no plausible benign reading; everything subtler is left to the review
 * model, which is separately instructed that these two categories are never
 * allowable. Both layers deny; neither can override the other into an allow.
 * @module @haoran/dsh-llm-permission-gateway/redline
 */
/** The two categories. A third would need a new release, not a new config key. */
export type RedLine = 'credential-exfiltration' | 'permission-self-modification';
/** One red-line match, carrying the user-facing cost statement for the denial. */
export interface RedLineHit {
    /** Which category matched. */
    readonly line: RedLine;
    /** What running the call would cost, in the words the user sees. */
    readonly reason: string;
}
/**
 * The filesystem locations whose modification would disable or reconfigure this
 * gateway, resolved once at plugin load from the running installation rather
 * than written down as literals.
 */
export interface ProtectedTargets {
    /** Directories and files whose subtree is off limits. */
    readonly paths: readonly string[];
    /** Additional text forms of those locations (`~/.dsh/profiles`, `$DSH_HOME/...`, the package name). */
    readonly literals: readonly string[];
}
/**
 * Resolve the protected locations for the running installation.
 * @returns the paths and literal text forms the self-modification red line guards.
 */
export declare function resolveProtectedTargets(): ProtectedTargets;
/**
 * Classify one pending call against both red lines.
 *
 * Ordering is significant: this runs before the read-only skip list, before
 * `alwaysAsk`, and before the review model, so no configuration choice and no
 * model answer can route a call around it.
 * @param toolName - the tool about to run, quoted into the denial reason.
 * @param args - the parsed, deep-frozen call arguments.
 * @param targets - the protected locations from {@link resolveProtectedTargets}.
 * @returns the matching red line, or `undefined` when neither applies.
 */
export declare function detectRedLine(toolName: string, args: unknown, targets: ProtectedTargets): RedLineHit | undefined;
//# sourceMappingURL=redline.d.ts.map