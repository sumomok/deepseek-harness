/**
 * The review call itself: one prompt, one model turn, one parsed verdict.
 *
 * Every way this can go wrong returns {@link JudgeFailure} rather than a
 * verdict, and the failure type carries no verdict of its own — the caller
 * decides, and its only choices are the fail-closed ones. Nothing in this
 * module can produce `allow` except a model answer that parsed as `allow`.
 * @module @haoran/dsh-llm-permission-gateway/judge
 */
import type { Context } from '@deepseek-ai/cordis';
import type { TokenUsage } from '@deepseek-ai/dsh-llm';
/** The closed answer set. The parser accepts these three strings and nothing else. */
export type JudgeVerdict = 'allow' | 'ask' | 'deny';
/** A parsed model answer. */
export interface JudgeResult {
    /** The verdict the model returned. */
    readonly verdict: JudgeVerdict;
    /** The model's one-sentence statement of what running the call would cost. */
    readonly reason: string;
}
/** Why no verdict was obtained. Carries no verdict, so no failure path can allow. */
export interface JudgeFailure {
    /** Short machine-ish label for the failure mode, quoted into the fail-closed reason. */
    readonly cause: 'timeout' | 'cancelled' | 'model-error' | 'unparsable-answer';
    /** Detail for the fail-closed reason shown to the user. */
    readonly detail: string;
}
/**
 * The judge's outcome: either a parsed verdict or a failure.
 *
 * `usage` rides both members because a review that produced no verdict can
 * still have been paid for — a truncated answer is billed like any other — and
 * a cost record that counted only the successful reviews would understate what
 * the gate spends. It is absent when the stream reported no usage chunk.
 */
export type JudgeOutcome = {
    readonly kind: 'verdict';
    readonly result: JudgeResult;
    readonly usage?: TokenUsage;
} | {
    readonly kind: 'failure';
    readonly failure: JudgeFailure;
    readonly usage?: TokenUsage;
};
/** Where the judge model lives and how long it may take. */
export interface JudgeRoute {
    /** Registered LLM provider route (`ctx.llm` adapter selector). */
    readonly provider: string;
    /** Model id, chosen independently of the agent's own model. */
    readonly model: string;
    /** Provider-owned reasoning effort id, or `undefined` to take the provider default. */
    readonly reasoningEffort: string | undefined;
    /** Output cap; the answer is one small JSON object. */
    readonly maxOutputTokens: number;
    /** Wall-clock budget for the whole review call. */
    readonly timeoutMs: number;
    /** Language for the human-facing reason. */
    readonly reasonLanguage: string;
}
/**
 * Parse a model answer into a verdict.
 *
 * The whole answer must be one JSON object: no prose around it, and no search
 * for a decision word anywhere in the text. An answer that does not parse, or
 * whose `decision` is not exactly one of the three enum members, or whose
 * `reason` is not a non-empty string, yields `undefined` and therefore the
 * caller's fail-closed outcome.
 * @param text - the model's raw output.
 * @returns the parsed result, or `undefined` when the answer is not usable.
 */
export declare function parseJudgeResponse(text: string): JudgeResult | undefined;
/**
 * Review one pending call.
 * @param ctx - context exposing the `llm` service.
 * @param route - the independently configured judge model and its budget.
 * @param toolName - the tool about to run.
 * @param args - the parsed call arguments.
 * @param callerSignal - the tool call's own cancellation.
 * @returns the parsed verdict, or the failure the caller must fail closed on, with the tokens the request reported.
 */
export declare function judgeCall(ctx: Context, route: JudgeRoute, toolName: string, args: unknown, callerSignal: AbortSignal): Promise<JudgeOutcome>;
//# sourceMappingURL=judge.d.ts.map