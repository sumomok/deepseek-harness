/**
 * A permission gate that asks a model instead of consulting a rule table.
 *
 * DeepSeek Harness routes every tool call through the `tools/pre-execute`
 * waterfall, the one extension point that can see a call's arguments — the
 * approval seam downstream of it is deliberately blind to them. Two things
 * reach a human without this plugin, and neither covers an ordinary tool: a
 * listener that returns `ask` from this waterfall, which only the two hook
 * bridges and the jobs tool do; and the sandbox-escape path, where `tool-bash`
 * and `tool-fs` hand an approver to the sandbox and a human sees the call only
 * when it tries to leave the sandbox. A capability plugin that does neither has
 * no gate at all. This plugin registers on the waterfall, prepended, and gives
 * every side-effecting call to a separately configured review model.
 *
 * It gates what the MODEL asks for, not what a plugin does. Work a plugin
 * performs in its own route handlers, timers, or event listeners produces no
 * tool call and is invisible here; the package README states that limit in full.
 *
 * Two structural commitments are worth reading before the code:
 *
 * - Failure never opens the gate. {@link Config.onFailure} ranges over `ask`
 *   and `deny` only, so a timeout, an unreachable model, or an unparsable
 *   answer cannot become an allow — there is no such value to configure. An
 *   attacker who can only make the reviewer slow gains nothing.
 * - Allowing delegates. An allow returns `next()`, so every other listener on
 *   the waterfall still decides; this gate can add denials but never removes
 *   another plugin's.
 *
 * Every decision, allow included, is recorded where the session log cannot
 * carry it; `./probe.ts` states why that record is a file and not an event.
 *
 * Configuration reference and known limits live in the package README.
 * @module @haoran/dsh-llm-permission-gateway
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { detectRedLine, resolveProtectedTargets } from './redline.ts';
export type { ProtectedTargets, RedLine, RedLineHit } from './redline.ts';
export { parseJudgeResponse } from './judge.ts';
export type { JudgeFailure, JudgeOutcome, JudgeResult, JudgeRoute, JudgeVerdict } from './judge.ts';
export { createVerdictProbe, defaultVerdictLogPath, verdictRecord, verdictSummary } from './probe.ts';
export type { ProbeCall, ProbeLog, ProbeOutcome, RecordFormat, VerdictProbe, VerdictProbeOptions, VerdictRecord, VerdictSource, } from './probe.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "llm-permission-gateway";
/** The review model (`llm`) and the registry whose calls are gated (`tools`). */
export declare const inject: string[];
/**
 * What this gate does when it cannot obtain a verdict.
 *
 * `allow` is absent on purpose and must stay absent: a fail-open permission
 * gate is defeated by making the reviewer slow rather than by convincing it,
 * which is a far lower bar than the review itself. Keeping the value
 * unrepresentable puts that guarantee in the type system instead of in a
 * default that a later edit could flip.
 */
export type FailureDecision = 'ask' | 'deny';
/** Plugin configuration; every field is changeable from cordis.yml and validated at load. */
export interface Config {
    /** Registered LLM provider route for the review model. */
    provider: string;
    /**
     * Model id for reviews, chosen independently of the agent's own model. A
     * separate model is not a defence against a compromised provider, but it does
     * keep one model's blind spots from being both the attack surface and the
     * check on it, and a small model keeps review inside the latency budget.
     */
    model: string;
    /**
     * Provider-owned reasoning-effort id for the judge, or `''` to take the
     * provider default. Reviewing one call is a single classification, and the
     * default `off` keeps thinking tokens from crowding out the answer inside
     * {@link Config.maxOutputTokens} — which fails closed, so a wrong value here
     * costs approval prompts rather than silent allows. Legal ids belong to the
     * provider, so an unsupported one surfaces on the first review rather than at load.
     */
    reasoningEffort?: string;
    /**
     * Wall-clock budget for one review; exceeding it applies {@link Config.onFailure}.
     * The default covers a call at the full {@link Config.maxArgumentsChars}
     * size: measured on 2026-08-21, `deepseek-v4-flash` returns a verdict on a
     * 200K-character call in roughly 5-8 seconds.
     */
    timeoutMs?: number;
    /** Output cap for the review answer, which is one small JSON object. */
    maxOutputTokens?: number;
    /**
     * Serialized-argument size above which the call is not reviewed at all.
     * Oversized arguments apply {@link Config.onFailure} rather than being
     * truncated: a truncated review reads a different call than the one that
     * would run, and the part left out is exactly where a payload would sit.
     *
     * The default is high because a low one turns the calls most worth reviewing
     * into manual approval prompts: measured on 2026-08-21, the `code` preset's
     * `run_code` calls routinely carry 9-10K characters of arguments, so an 8000
     * cap sent exactly those past the model and straight to a human. 200K
     * characters is reviewed whole inside {@link Config.timeoutMs}.
     */
    maxArgumentsChars?: number;
    /** What to do when no verdict is obtained. */
    onFailure?: FailureDecision;
    /** Tools passed straight through to the rest of the chain without review. */
    readOnlyTools?: string[];
    /** Tool name to the cost sentence shown when it is asked about; asked without consulting the model. */
    alwaysAsk?: Record<string, string>;
    /** Per-agent cap on remembered verdicts; `0` disables reuse. */
    cacheEntries?: number;
    /** Language for the human-facing reason the review model writes. */
    reasonLanguage?: string;
    /**
     * Absolute path of the JSONL file every decision is appended to, or `false`
     * to write no file. Defaults to `$DSH_HOME/llm-permission-gateway/verdicts.jsonl`,
     * resolved at load rather than written into the schema because the harness
     * home is a property of the installation. The one-line summary on the host
     * log is written either way, so `false` narrows the trace rather than
     * removing it.
     */
    verdictLog?: string | false;
    /**
     * Characters of the serialized call kept in each record, whitespace
     * collapsed; `0` keeps none, which is the default.
     *
     * A record otherwise identifies a call by its argument digest, which says
     * that two calls were identical without saying what either one asked for.
     * The preview closes that gap and is the user's own argument text while it
     * does so — as sensitive as the session log, and written with the process
     * umask into `$DSH_HOME`, so it is protected by whatever protects that
     * directory and by nothing this plugin adds.
     */
    verdictLogArgsPreview?: number;
}
export declare const Config: z<Config>;
/**
 * Register the gate.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map