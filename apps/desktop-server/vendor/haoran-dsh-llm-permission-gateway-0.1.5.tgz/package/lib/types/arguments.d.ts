/**
 * Argument inspection helpers shared by the red-line scanner, the review
 * prompt, and the decision cache. Tool arguments arrive as losslessly
 * JSON-serializable values that the registry has already deep-frozen, so every
 * function here is a pure reader.
 * @module @haoran/dsh-llm-permission-gateway/arguments
 */
/**
 * Serialize a value with object keys in sorted order, so two calls that differ
 * only in key order produce one cache entry rather than two review requests.
 * Non-serializable leaves (`undefined`, functions) are dropped exactly as
 * `JSON.stringify` drops them.
 * @param value - the value to serialize.
 * @returns the canonical JSON text.
 */
export declare function canonicalJson(value: unknown): string;
/**
 * Stable digest of one call's arguments, used as the cache key component.
 * @param value - the parsed tool arguments.
 * @returns a hex SHA-256 of the canonical serialization.
 */
export declare function argumentsDigest(value: unknown): string;
/**
 * Every string leaf reachable from `value`, including object keys. Keys are
 * collected because a path can hide in a key as easily as in a value (a
 * file-map argument keyed by path, for example).
 * @param value - the parsed tool arguments.
 * @returns the collected strings in traversal order.
 */
export declare function stringLeaves(value: unknown): string[];
//# sourceMappingURL=arguments.d.ts.map