/**
 * The review request put to the judge model.
 *
 * Two properties of this text are load-bearing. The pending call is injected as
 * a fenced JSON document and framed as data on both sides of the fence, because
 * the arguments under review are attacker-reachable and would otherwise read as
 * further instructions. And the answer contract is a single JSON object with a
 * closed `decision` enum, because {@link parseJudgeResponse} refuses anything
 * else rather than guessing.
 * @module @haoran/dsh-llm-permission-gateway/prompt
 */
/**
 * Build the reviewer's system prompt.
 * @param reasonLanguage - the language the human-facing reason must be written in.
 * @returns the system prompt text.
 */
export declare function judgeSystemPrompt(reasonLanguage: string): string;
/**
 * Build the user message carrying the pending call.
 * @param toolName - the tool about to run.
 * @param args - the parsed call arguments.
 * @returns the user message text.
 */
export declare function judgeUserPrompt(toolName: string, args: unknown): string;
//# sourceMappingURL=prompt.d.ts.map