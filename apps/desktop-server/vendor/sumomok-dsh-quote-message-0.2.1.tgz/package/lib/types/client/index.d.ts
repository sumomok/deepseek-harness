import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type QuoteKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Selection pill and chip copy. */
        'quote-message': QuoteKey;
    }
}
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * Register the selection pill and the codec that expands its chips.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map