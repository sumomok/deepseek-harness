/**
 * The two decisions the shadowing user-bubble renderer makes, kept out of the
 * component so both are testable without a DOM: what to hand the incumbent
 * bubble, and which entry the incumbent is.
 *
 * @module @sumomok/dsh-quote-message/client/quoted-node
 */
import type { StoredEntry } from '@deepseek-ai/dsh-client-ui-slots';
import { type QuoteBlockLines } from '../core/split-quotes.ts';
/** What to render for one message that carries quote blocks. */
export interface QuotedPlan {
    /** Blocks to render as cards, in document order. */
    readonly quotes: readonly QuoteBlockLines[];
    /** Content for the incumbent bubble, with the quote region removed. */
    readonly content: readonly unknown[];
}
/**
 * Decide what the bubble should show.
 *
 * `null` means "change nothing": the message carries no quote block, or its
 * shape is not one this plugin rewrites. A prompt the composer sent carries
 * exactly one text block; a message with none, or with several, is left to
 * the incumbent untouched rather than guessed at.
 * @param content - the node's content blocks.
 * @returns the cards and the reduced content, or null to render the incumbent unchanged.
 */
export declare function planQuotedContent(content: readonly unknown[]): QuotedPlan | null;
/**
 * Find the entry this renderer shadows: the host's own component for one node
 * kind.
 *
 * Shadowing keeps every entry of a cell registered and renders the lowest
 * priority, so the incumbent is still in the ledger and is read from there
 * rather than imported — a value import across plugin bundles would be a
 * second copy of the module, and there is no import to make anyway.
 * @param entries - the slot's registered entries (`ctx.slots.entries`).
 * @param key - the keyed cell, `user` or `steering`.
 * @param own - this plugin's own component, excluded from the search.
 * @returns the incumbent component, or undefined when this plugin is alone in the cell.
 */
export declare function pickIncumbent(entries: readonly StoredEntry[], key: string, own: unknown): unknown;
//# sourceMappingURL=quoted-node.d.ts.map