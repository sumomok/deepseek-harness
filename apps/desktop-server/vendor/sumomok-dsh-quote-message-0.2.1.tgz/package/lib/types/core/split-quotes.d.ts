/**
 * Find the quote blocks in one user message so they can be rendered as cards
 * instead of as raw `>` lines inside the bubble.
 *
 * Only the blocks at the edges of the message are cards. A message is
 * normally a question plus the passage it cites, and the passage sits at one
 * end or the other depending on where the chip was inserted; a `>` run in the
 * middle of what someone wrote is their own prose and stays where they put it.
 *
 * @module @sumomok/dsh-quote-message/core/split-quotes
 */
/** One quote block: its lines with the `>` marker removed. */
export type QuoteBlockLines = readonly string[];
/** The cards found in a message and the text left for the bubble. */
export interface QuoteSplit {
    /** Blocks in document order; empty when the message carries none. */
    readonly quotes: readonly QuoteBlockLines[];
    /** The message without them. Identical to the input when no block was found. */
    readonly rest: string;
}
/**
 * Split a message into its edge quote blocks and the rest.
 *
 * The text is returned unchanged when it carries no block at either edge, so
 * a caller can treat an unchanged `rest` as "nothing to do" by identity.
 * @param text - the message's text part.
 * @returns the blocks in document order and the remaining text.
 */
export declare function splitQuoteBlocks(text: string): QuoteSplit;
/**
 * Drop the block's own heading line when it is one this plugin wrote.
 *
 * The serialized block opens with the localized header (`引用：` / `Quote:`);
 * the card shows that word as its head instead, so keeping the line would
 * print it twice. A blockquote someone wrote by hand has no such line and
 * keeps every line as body.
 * @param lines - one block's lines.
 * @param headings - the header lines this plugin emits, in every locale.
 * @returns the body lines.
 */
export declare function stripQuoteHeading(lines: QuoteBlockLines, headings: readonly string[]): QuoteBlockLines;
//# sourceMappingURL=split-quotes.d.ts.map