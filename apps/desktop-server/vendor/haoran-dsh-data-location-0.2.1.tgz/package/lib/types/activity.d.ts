/**
 * Which conversations are still running, asked the way archiving asks.
 *
 * A move stops the server, and on Windows it stops it hard, so a turn still
 * running would not end cleanly. The page therefore refuses to start while any
 * conversation has work running, and says how many do. Each live session is put
 * to the `workspace/session-activity` waterfall, whose providers report turns,
 * subagents, and background jobs.
 *
 * **A scheduled follow-up does not count.** The schedule provider reports a
 * session's active schedules through the same waterfall, but a schedule is a
 * stored plan, not running work: it is on disk, it survives the server stopping,
 * and it fires from the new location after the move. Counting it would refuse
 * every move for as long as any conversation has one.
 *
 * @module @haoran/dsh-data-location/activity
 */
/** The activity family that is stored rather than running. */
export declare const STORED_FAMILY = "schedule";
/** One activity entry, as far as counting needs it. */
export interface ActivityEntry {
    readonly kind: string;
}
/**
 * Count the sessions with running work.
 * @param sessionIds - the live sessions.
 * @param ask - asks the providers what still runs for one session.
 * @returns how many sessions report anything other than a stored schedule.
 */
export declare function countRunning<Id>(sessionIds: readonly Id[], ask: (sessionId: Id) => Promise<readonly ActivityEntry[]>): Promise<number>;
//# sourceMappingURL=activity.d.ts.map