/**
 * The desktop shell's data-location service, used when it offers one.
 *
 * Only the desktop shell can move the data folder: the move stops the server
 * this plugin runs in, carries on in the shell's own window, and relaunches
 * the application. The shell advertises the service by putting
 * `DSH_DESKTOP_DATA_ENDPOINT` and `DSH_DESKTOP_DATA_TOKEN` into the server's
 * environment; a deployment that offers none — every `dsh web` on a server —
 * sets neither, and this plugin then reports the capability unavailable and
 * puts up no page.
 *
 * This module composes five requests against a loopback origin and reads their
 * answers. It picks no folder, checks nothing on disk, and moves nothing.
 *
 * Every answer is read at this process boundary: a field spelled with a type
 * this build does not expect is dropped, and a kind it does not know becomes
 * `other`.
 *
 * @module @haoran/dsh-data-location/shell
 */
import { type MoveFailureView, type MoveOutcomeView, type PreflightView, type Reason, type RetryRefusal, type TerminalView } from './types.ts';
/** Environment variable naming the data-location service's origin. */
export declare const ENDPOINT_ENV = "DSH_DESKTOP_DATA_ENDPOINT";
/** Environment variable carrying the bearer token that service requires. */
export declare const TOKEN_ENV = "DSH_DESKTOP_DATA_TOKEN";
/** Route reporting where the data is and how the last move went. */
export declare const STATE_PATH = "/state";
/** Route opening the native folder picker. */
export declare const CHOOSE_PATH = "/choose";
/** Route checking a folder without moving anything. */
export declare const PREFLIGHT_PATH = "/preflight";
/** Route starting a move. */
export declare const START_PATH = "/start";
/** Route carrying the old copy's removal on again. */
export declare const RETRY_CLEANUP_PATH = "/retry-cleanup";
/** Where the shell's data-location service lives and how to authenticate to it. */
export interface ShellRoute {
    /** Origin of the service, without a trailing slash. */
    readonly endpoint: string;
    /** Bearer token the shell minted for this server process. */
    readonly token: string;
}
/** The shell's `/state` answer, as this plugin reads it. */
export interface ShellState {
    home: string;
    moving: boolean;
    /** Absent from a shell that does not send it. */
    cleanupRunning?: boolean;
    /** Absent from a shell that does not send it. */
    cleanupWaiting?: boolean;
    cleanup?: {
        leftoverBytes: number;
    };
    lastResult?: MoveOutcomeView;
    lastRefusal?: Reason[];
    terminal?: TerminalView;
}
/** What a move request sends: the folder, and every workspace folder the server knows. */
export interface MoveRequestBody {
    /**
     * The folder the person picked, on both the check and the start. The shell
     * works out the folder the data goes into from it each time: the picked
     * folder when it is empty and not the top of a drive, otherwise a new
     * folder inside it.
     */
    target: string;
    workspaces: string[];
}
/** How `/start` ended. */
export type ShellStart = {
    started: true;
} | {
    started: false;
    reasons: Reason[];
};
/** How `/choose` ended: the folder picked, nothing when cancelled, or `busy` when a picker was already open. */
export type ShellChoose = {
    kind: 'picked';
    path: string;
} | {
    kind: 'cancelled';
} | {
    kind: 'busy';
};
/** How `/retry-cleanup` ended. */
export type ShellRetry = {
    started: true;
} | {
    started: false;
    reason: RetryRefusal;
};
/**
 * Read the data-location route out of the environment.
 *
 * Both variables are required together: an endpoint without a token would be
 * refused on every call, and a token without an endpoint names nothing.
 * @param env - the environment to read.
 * @returns the route, or undefined when this deployment offers no such service.
 */
export declare function shellRouteFromEnv(env: NodeJS.ProcessEnv): ShellRoute | undefined;
/**
 * Read one refusal from the shell's folder check.
 * @param value - one entry of the check's `refusals`.
 * @returns the reason; `other` for a kind or a field this build cannot read.
 */
export declare function parseRefusal(value: unknown): Reason;
/**
 * Read why the shell would not start a move, or took one back.
 * @param value - the `409` body of `/start`, or `/state`'s `lastRefusal`.
 * @returns the reasons; a single `other` for a kind this build does not know.
 */
export declare function parseMoveRefusal(value: unknown): Reason[];
/**
 * Read the folder check's verdict.
 * @param value - the `/preflight` body.
 * @returns the verdict, before running conversations are counted in.
 * @throws when the body carries no readable target.
 */
export declare function parsePreflight(value: unknown): PreflightView;
/**
 * Read why a move failed.
 * @param value - the result's `failure`.
 * @returns the kinds; undefined when it is not an object with a text `kind`, as in a result an older shell wrote.
 * Entries of `also` that are not text are dropped.
 */
export declare function parseFailure(value: unknown): MoveFailureView | undefined;
/**
 * Read a finished move's result.
 * @param value - `/state`'s `lastResult`.
 * @returns the result, or undefined when it names no source and target.
 */
export declare function parseMoveResult(value: unknown): MoveOutcomeView | undefined;
/**
 * Read what a write of the terminal's data location came to, from the write
 * {@link TerminalView} names.
 *
 * An `overridden` write with no value read back means terminals get no data
 * location at all; DSH in a terminal then uses its default folder, which the
 * shell usually links to the data but not always, and this plugin cannot see
 * which, so it reads as `unconfirmed`. A `not-written` write is the person's
 * own setting only when the shell found their assignment in the profile
 * (`foreign-assignment`); every other refusal, and a write that threw
 * (`failed`), is `not-written`.
 * @param value - `/state`'s `terminal`.
 * @returns the view, or undefined for a kind this build does not know.
 */
export declare function parseTerminal(value: unknown): TerminalView | undefined;
/**
 * Read one `/state` body.
 * @param value - the parsed body.
 * @returns the state.
 * @throws when the body carries no readable data folder.
 */
export declare function parseState(value: unknown): ShellState;
/**
 * Ask where the data is and how the last move went.
 * @param route - the shell's endpoint and token.
 * @param abortMs - how long to wait.
 * @returns the state.
 * @throws when the shell refuses, cannot be read, or does not answer in time.
 */
export declare function readState(route: ShellRoute, abortMs: number): Promise<ShellState>;
/**
 * Open the native folder picker and wait for the person.
 *
 * There is no deadline: the picker stays open as long as the person browses,
 * and a deadline would report a failure while it is still on screen.
 * @param route - the shell's endpoint and token.
 * @returns the folder picked, cancelled, or busy when the shell answered `409` because a picker is already open.
 * @throws when the shell answers anything else or cannot be reached.
 */
export declare function requestChoose(route: ShellRoute): Promise<ShellChoose>;
/**
 * Check a folder without moving anything.
 * @param route - the shell's endpoint and token.
 * @param body - the folder picked and the workspace folders.
 * @param abortMs - how long to wait; the check reads the whole data folder.
 * @returns the verdict.
 * @throws when the shell refuses, cannot be read, or does not answer in time.
 */
export declare function requestPreflight(route: ShellRoute, body: MoveRequestBody, abortMs: number): Promise<PreflightView>;
/**
 * Ask the shell to start the move. On `202` the shell stops this server next,
 * so the answer is the last thing this process hears about the move.
 * @param route - the shell's endpoint and token.
 * @param body - the folder picked, the same folder the check was given, and the workspace folders.
 * @param abortMs - how long to wait; the shell checks the folder again first.
 * @returns started, or the reasons the shell refused.
 * @throws {@link StartUnanswered} when the request may have reached the shell and no answer came; an `Error` when the
 * shell answers anything else or nothing accepted the connection.
 */
export declare function requestStart(route: ShellRoute, body: MoveRequestBody, abortMs: number): Promise<ShellStart>;
/**
 * A `/start` request that may have reached the shell and got no answer: it
 * timed out, or the connection broke after it was opened. The shell may still
 * be starting the move, so this is not a refusal.
 */
export declare class StartUnanswered extends Error {
    readonly name = "StartUnanswered";
}
/**
 * Ask the shell to carry the old copy's removal on again.
 * @param route - the shell's endpoint and token.
 * @param abortMs - how long to wait.
 * @returns started, or why not from the `409` body; a reason this build does not know reads as `other`.
 * @throws when the shell answers anything else or does not answer in time.
 */
export declare function requestRetryCleanup(route: ShellRoute, abortMs: number): Promise<ShellRetry>;
//# sourceMappingURL=shell.d.ts.map