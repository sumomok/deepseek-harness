/**
 * The Settings page: where the data is, what terminals use, how the last move
 * went, and the button that starts a new one.
 *
 * Choosing a new place goes one way — the folder picker, the check, a
 * confirmation, the request — and a refusal at the check or at the request
 * lists every reason the shell gave, in words. Once the shell accepts a move it
 * stops the server that draws this page, so the last thing the page says is
 * that the move is starting; a request whose answer never arrived says it was
 * sent, not that it failed.
 *
 * @module @haoran/dsh-data-location/client/DataLocationSection
 */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type DataLocationView, type MoveOutcomeView, type Reason, type TerminalView } from '../types.ts';
import type { DataLocationKey } from './locales.ts';
import { type LocationStoreState, type Notice } from './store.ts';
/** Registration-side dependencies of {@link DataLocationSection}. */
export interface DataLocationSectionInjected {
    hooks: {
        /** The browser half's own store. */
        location: HostObservable<LocationStoreState>;
    };
    /** Read the host again. */
    refresh: () => void;
    /** Open the folder picker, then check the folder picked. */
    choose: () => void;
    /** Ask for the move the confirmation shows. */
    confirm: () => void;
    /** Leave the confirmation, the refusal, or an unconfirmed request. */
    cancel: () => void;
    /** Ask for the old copy's removal again. */
    retryCleanup: () => void;
}
/** Full component props. */
export type DataLocationSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'dataLocation'> & InjectFace<DataLocationSectionInjected>;
/** The page's translate seat. */
type T = (key: DataLocationKey, params?: Record<string, unknown>) => string;
/**
 * One reason in words.
 * @param t - the translate seat.
 * @param reason - the reason.
 * @returns its sentence.
 */
export declare function reasonText(t: T, reason: Reason): string;
/**
 * What the application said when it declined the last command.
 * @param t - the translate seat.
 * @param notice - the notice.
 * @returns its sentence.
 */
export declare function noticeText(t: T, notice: Notice): string;
/**
 * What a recorded move is doing, when no leftover card is shown.
 * @param t - the translate seat.
 * @param view - the current view, with `moving` true.
 * @returns removing now, removing at the next launch, or getting the move ready (a move asked for and not yet
 * carried, or one switched and not yet checked); a shell that sends neither cleanup field reads as removing.
 */
export declare function movingText(t: T, view: DataLocationView): string;
/**
 * The terminal line.
 * @param t - the translate seat.
 * @param terminal - what a write of the terminal's data location came to.
 * @returns its sentence.
 */
export declare function terminalText(t: T, terminal: TerminalView): string;
/**
 * The sentences a finished move is reported with, in reading order.
 *
 * A `moved` result with a failure, or with a kept original from a shell that
 * sends no failure, is a new location the person kept after it failed its
 * check: the page says the data is there, what the check found, what to look
 * at and do next, and where the original is when one was kept. A failed result names, after its cause, a
 * new location a terminal may still use, then the copies it left.
 * @param t - the translate seat.
 * @param result - the move's result.
 * @returns the sentences.
 */
export declare function resultLines(t: T, result: MoveOutcomeView): string[];
/**
 * The registered settings section.
 * @param props - the framework standard kit plus this plugin's store and commands.
 * @returns the page.
 */
export declare function DataLocationSection(props: DataLocationSectionProps): ReactNode;
export {};
//# sourceMappingURL=DataLocationSection.d.ts.map