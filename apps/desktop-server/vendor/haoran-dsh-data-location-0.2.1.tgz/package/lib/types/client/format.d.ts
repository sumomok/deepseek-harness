/**
 * The two things this page turns into text besides copy: a byte count and a
 * date.
 *
 * `GB`, `MB`, and `KB` are unit symbols, not copy — the same in both
 * dictionaries — so they stay here rather than in `locales.ts`.
 *
 * @module @haoran/dsh-data-location/client/format
 */
/**
 * A byte count in the largest unit that keeps it at one or more.
 * @param bytes - the count.
 * @returns gigabytes with one decimal, whole megabytes, or whole kilobytes (at least 1), with the unit symbol.
 */
export declare function formatSize(bytes: number): string;
/**
 * A timestamp in the reader's own locale and time zone.
 * @param iso - the timestamp the shell wrote.
 * @returns the local rendering, or the raw text when it is not a date.
 */
export declare function formatWhen(iso: string): string;
//# sourceMappingURL=format.d.ts.map