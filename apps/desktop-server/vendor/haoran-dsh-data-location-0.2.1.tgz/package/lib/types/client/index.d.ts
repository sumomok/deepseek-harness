/**
 * Browser half: the Data & Storage page in Settings.
 *
 * The only host path is the Typert Remote this package's host half exports,
 * mounted here through `ctx.remote.$mount()`. This plugin fetches nothing
 * itself and knows no token, no endpoint, and no route.
 *
 * **Nothing is registered where the data cannot be moved.** A `dsh web` on a
 * server lends no data-location service, so the first thing this does is read
 * the host once, and an `available: false` answer ends the registration before
 * it starts.
 *
 * @module @haoran/dsh-data-location/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type DataLocationKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-data-location` copy. */
        dataLocation: DataLocationKey;
    }
}
export { CONTRIBUTION } from './contribution.ts';
export { DataLocationSection, reasonText, resultLines, terminalText } from './DataLocationSection.tsx';
export type { DataLocationSectionInjected, DataLocationSectionProps } from './DataLocationSection.tsx';
export { formatSize, formatWhen } from './format.ts';
export { en, NS, zh } from './locales.ts';
export type { DataLocationKey } from './locales.ts';
export { createLocationStore, pendingCleanup } from './store.ts';
export type { LocationApi, LocationStore, LocationStoreState, Step } from './store.ts';
export { insertStyles, STYLE_OWNER, STYLE_TAG } from './styles.ts';
/** Required browser services. */
export declare const inject: string[];
/** This plugin's settings page id. */
export declare const SECTION_ID = "data-location";
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 */
export declare function apply(ctx: Context): Promise<void>;
//# sourceMappingURL=index.d.ts.map