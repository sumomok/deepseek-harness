/**
 * The browser half's one piece of state: the last view the host answered,
 * where the person is in choosing a new place, and the last thing that failed.
 *
 * The steps of a change go one way: pick a folder, have it checked, confirm,
 * ask for the move. A refusal at the check or at the request lands on
 * `refused` with the reasons; `requested` is final, because the shell stops
 * this server next and the page goes away with it. A request whose answer
 * never arrived lands on `unconfirmed`, which may still be followed by that
 * stop, so it is not shown as a failure.
 *
 * @module @haoran/dsh-data-location/client/store
 */
import type { ChooseAnswer, DataLocationView, PreflightAnswer, PreflightView, Reason, RetryAnswer, RetryRefusal, StartAnswer } from '../types.ts';
/** The five calls this store makes, bound to the mounted Remote. */
export interface LocationApi {
    /** Read where the data is. */
    state: () => Promise<DataLocationView>;
    /** Open the folder picker. */
    choose: () => Promise<ChooseAnswer>;
    /** Check the folder picked. */
    preflight: (target: string) => Promise<PreflightAnswer>;
    /** Ask for the move into the folder picked; the shell works out the folder the data goes into again. */
    start: (target: string) => Promise<StartAnswer>;
    /** Ask for the old copy's removal again. */
    retryCleanup: () => Promise<RetryAnswer>;
}
/** Where the person is in choosing a new place. */
export type Step = {
    kind: 'idle';
}
/** The folder picker is open. */
 | {
    kind: 'choosing';
}
/** The folder picked is being checked. */
 | {
    kind: 'checking';
    chosen: string;
}
/** The folder picked cannot take the data, or the move was refused when asked for. */
 | {
    kind: 'refused';
    chosen: string;
    reasons: Reason[];
}
/** The check passed; the page asks for confirmation, naming the folder the data goes into (`verdict.target`). */
 | {
    kind: 'confirm';
    chosen: string;
    verdict: PreflightView;
}
/** The move is being asked for. */
 | {
    kind: 'starting';
    chosen: string;
    verdict: PreflightView;
}
/** The shell accepted the move; it stops this server next. */
 | {
    kind: 'requested';
    target: string;
}
/**
 * The request was sent and no answer came back. The shell may have
 * accepted it and be stopping this server, which also cuts the answer off,
 * so the page does not call it a failure.
 */
 | {
    kind: 'unconfirmed';
    target: string;
};
/** A line the page shows after a command the application declined, until the next command. */
export type Notice = 
/** A folder picker was already open. */
{
    kind: 'chooser-open';
}
/** The old copy's removal was not carried on again, and why. */
 | {
    kind: 'retry';
    reason: RetryRefusal;
};
/** What the page renders from. */
export interface LocationStoreState {
    /** The last view the host answered. */
    view: DataLocationView;
    /** Where the person is in choosing a new place. */
    step: Step;
    /** Whether a removal retry is being asked for. */
    retrying: boolean;
    /** Whether the last command failed to reach the application; cleared when the next one starts. */
    failed: boolean;
    /** What the application said when it declined the last command; cleared when the next one starts. */
    notice: Notice | undefined;
}
/** The store the page reads. */
export interface LocationStore {
    /** Current state; a stable reference between changes, so it pairs with `useSyncExternalStore`. */
    getSnapshot: () => LocationStoreState;
    /**
     * Observe changes.
     * @param listener - called after every change.
     * @returns unsubscribe.
     */
    subscribe: (listener: () => void) => () => void;
    /** Read the host once and publish the answer; a failed read keeps the last view. */
    refresh: () => Promise<void>;
    /** Open the folder picker, then check the folder picked. */
    choose: () => Promise<void>;
    /**
     * Ask for the move to the folder picked. The shell works the target out
     * from it again, as its check did, so the target the confirmation shows is
     * not sent: inside a folder that is not empty it is a new `DSH-Data` folder,
     * and sending that would have the shell add a second one.
     */
    confirm: () => Promise<void>;
    /** Leave the confirmation, the refusal, or an unconfirmed request without asking for anything more. */
    cancel: () => void;
    /** Ask for the old copy's removal again, then re-read. */
    retryCleanup: () => Promise<void>;
}
/**
 * Create the store, seeded with the view `apply` already read.
 * @param api - the bound Remote calls.
 * @param first - the view the first read answered.
 * @param log - receives what a failed call said, which the page does not show.
 * @returns the store.
 */
export declare function createLocationStore(api: LocationApi, first: DataLocationView, log: (line: string) => void): LocationStore;
/**
 * Whether the old copy's removal left something behind and can be asked for again.
 * @param view - the current view.
 * @returns the bytes left, or undefined when nothing is waiting.
 */
export declare function pendingCleanup(view: DataLocationView): number | undefined;
//# sourceMappingURL=store.d.ts.map