/**
 * The browser half's Typert contribution: the consumer-side mirror of
 * `../typert.ts`.
 *
 * Each descriptor matches the host manifest's invocation exactly — same id,
 * namespace, method, and parameter wire names — because the gateway matches by
 * those names. The browser gateway at `0.2.0-rc.2` and `0.2.1-alpha.1` never
 * runs a result codec without a `decode`, so the result codecs here only
 * satisfy the registry's requirement that every strict codec have a
 * `create()`; the host parses the one argument with its own schema.
 *
 * @module @haoran/dsh-data-location/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
/** The contribution `ctx.remote.$mount()` installs, mirroring `../typert.ts`. */
export declare const CONTRIBUTION: TypertRemoteContribution;
//# sourceMappingURL=contribution.d.ts.map