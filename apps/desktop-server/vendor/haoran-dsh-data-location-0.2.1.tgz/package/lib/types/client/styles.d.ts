/**
 * The browser half's stylesheet, injected as one tagged `<style>` per client instance.
 *
 * Every colour is a harness theme variable, so the page follows the light and
 * dark schemes the shell already switches between. Paths break anywhere, since
 * a folder path has no spaces to wrap at and the page must fit a narrow panel.
 *
 * @module @haoran/dsh-data-location/client/styles
 */
/** Attribute marking this plugin's style tags. */
export declare const STYLE_TAG = "data-dsh-data-location";
/**
 * The `data-plugin` value on this plugin's style tags: the package name, which
 * is the id the host's client module system gives this plugin. That system
 * stamps every `<style>` without `data-plugin` with the id of the module it is
 * materializing and removes the stamped tags when that module unloads; a tag
 * that already names this plugin is left to this plugin's own disposer.
 */
export declare const STYLE_OWNER = "@haoran/dsh-data-location";
/**
 * Insert this call's own copy of the stylesheet. Every call appends a separate
 * tag, so overlapping client instances of this plugin each hold one and
 * disposing one instance leaves the others styled.
 * @returns a disposer removing only the tag this call inserted.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map