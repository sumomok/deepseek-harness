/**
 * Copy for the browser half, in the two locales the harness ships.
 *
 * The Chinese is the original and the English is its translation. No line
 * says "pointer", "journal", "marker", "volume", or a variable name: the person
 * reading it wants their data somewhere else, and the page tells them where it
 * is, whether it can go where they picked, and what happened.
 *
 * Paths are quoted with 「」 in Chinese and with straight double quotes in
 * English, and every other value is a `{name}` placeholder the locale plugin
 * fills.
 *
 * @module @haoran/dsh-data-location/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "dataLocation";
/** Chinese copy (the dictionary that defines the key domain). */
export declare const zh: {
    nav: string;
    title: string;
    home: string;
    change: string;
    choosing: string;
    checking: string;
    refused: string;
    'confirm.title': string;
    'confirm.size': string;
    'confirm.contents': string;
    'confirm.copy': string;
    'confirm.rename': string;
    'confirm.terminal': string;
    'confirm.longPaths': string;
    'confirm.start': string;
    'confirm.starting': string;
    cancel: string;
    requested: string;
    requestedUnconfirmed: string;
    chooserOpen: string;
    'retry.running': string;
    'retry.none-waiting': string;
    'retry.no-window': string;
    'retry.other': string;
    cleaning: string;
    cleaningLater: string;
    preparing: string;
    unavailable: string;
    failed: string;
    'terminal.synced': string;
    'terminal.overridden': string;
    'terminal.ownSetting': string;
    'terminal.ownSettingAt': string;
    'terminal.notWritten': string;
    'terminal.notWrittenIn': string;
    'terminal.unconfirmed': string;
    'result.when': string;
    'result.moved': string;
    'result.failed': string;
    'result.failed.source-changed': string;
    'result.failed.target-occupied': string;
    'result.failed.copy-mismatch': string;
    'result.failed.copy-gone': string;
    'result.failed.no-space': string;
    'result.failed.no-permission': string;
    'result.failedCheck': string;
    'result.failedCheckNext': string;
    'check.not-started': string;
    'check.unreadable': string;
    'check.fewer-sessions': string;
    'check.plugin-quarantined': string;
    'check.workspaces-differ': string;
    'result.cancelled': string;
    'result.other': string;
    'result.unusedCopy': string;
    'result.unusedInPlace': string;
    'result.abandonedCopy': string;
    'result.terminalNotRestored': string;
    'result.keptFailed': string;
    'result.keptFailedNext': string;
    'result.originalKept': string;
    'result.originalAway': string;
    'result.leftover': string;
    leftovers: string;
    'leftovers.retry': string;
    lastRefusal: string;
    'reason.parent-missing': string;
    'reason.folder-unreadable': string;
    'reason.inside-source': string;
    'reason.contains-source': string;
    'reason.inside-install': string;
    'reason.inside-user-data': string;
    'reason.inside-update-cache': string;
    'reason.inside-workspace': string;
    'reason.cloud-synced': string;
    'reason.inside-temp': string;
    'reason.not-empty': string;
    'reason.harness-data': string;
    'reason.not-a-folder': string;
    'reason.unsupported-file-system': string;
    'reason.network-location': string;
    'reason.no-permission': string;
    'reason.capability-missing': string;
    'reason.not-enough-space': string;
    'reason.name-collision': string;
    'reason.abandoned-unreadable': string;
    'reason.terminal-unreadable': string;
    'reason.in-progress': string;
    'reason.no-identity': string;
    'reason.locked': string;
    'reason.server-still-running': string;
    'reason.conversations-running': string;
    'reason.conversations-running.one': string;
    'reason.other': string;
};
/** Dictionary key domain. */
export type DataLocationKey = keyof typeof zh;
/** English copy. */
export declare const en: Record<DataLocationKey, string>;
//# sourceMappingURL=locales.d.ts.map