/**
 * Host-face Typert manifest, discovered by `@deepseek-ai/dsh-typert-loader`.
 *
 * The loader resolves `<package>/package.json` from the config tree, reads
 * `exports["./typert"]`, imports this module, and registers the `TYPERT`
 * export, so the plugin appearing as a Loader entry under its own package name
 * is the whole registration. The manifest is hand-written because the Typert
 * generator runs over the harness workspace rather than over out-of-repo
 * packages; it is structurally what that generator emits.
 *
 * The gateway parses each argument with its codec's `create()` schema, so the
 * `target` codec is what refuses a non-string folder. Results pass through
 * unvalidated; their schemas describe what the host half returns.
 *
 * Keep this file free of imports other than `zod`: the loader imports it
 * directly by file path, outside the plugin's own module graph.
 *
 * @module @haoran/dsh-data-location/typert
 */
import { z } from 'zod';
/** The contribution `dsh-typert-loader` registers for this package. */
export declare const TYPERT: {
    package: string;
    face: string;
    schemas: never[];
    invocations: {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: string;
            codec: {
                mode: "strict";
                typeSymbol: string;
                create: () => z.ZodType;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            create: () => z.ZodType;
        };
    }[];
    model: {
        services: {
            description: string;
            summary: string;
            tags: never[];
            jsDoc: string;
            key: string;
            exportName: string;
            members: {
                kind: string;
                name: string;
                signature: string;
                summary: string;
                jsDoc: string;
            }[];
            types: never[];
        }[];
        events: never[];
        objects: never[];
    };
};
export default TYPERT;
//# sourceMappingURL=typert.d.ts.map