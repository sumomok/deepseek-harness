/**
 * What the five Remote methods do: read the shell's state, pass the picker and
 * the folder check through, count running conversations, and ask for the move.
 *
 * **Nothing here throws at the caller.** The whole surface is one Settings page,
 * and every failure it can meet — no shell, a shell that stopped answering, a
 * body it cannot read — becomes a sentence on that page rather than an
 * exception crossing the gateway.
 *
 * Every move request carries every workspace folder the server knows. The
 * shell refuses a folder inside one, and it counts them as the baseline its
 * check after the move compares against, so the list is always the registry's
 * whole list and never a stand-in.
 *
 * @module @haoran/dsh-data-location/location
 */
import { type MoveRequestBody, type ShellChoose, type ShellRetry, type ShellRoute, type ShellStart, type ShellState } from './shell.ts';
import type { ChooseAnswer, DataLocationView, PollCadence, PreflightAnswer, PreflightView, RetryAnswer, StartAnswer } from './types.ts';
/** The shell calls this module makes, injected so the whole flow is testable without a shell. */
export interface ShellCalls {
    /** Ask where the data is. */
    state: (route: ShellRoute, abortMs: number) => Promise<ShellState>;
    /** Open the folder picker. */
    choose: (route: ShellRoute) => Promise<ShellChoose>;
    /** Check a folder. */
    preflight: (route: ShellRoute, body: MoveRequestBody, abortMs: number) => Promise<PreflightView>;
    /** Ask for the move. */
    start: (route: ShellRoute, body: MoveRequestBody, abortMs: number) => Promise<ShellStart>;
    /** Ask for the old copy's removal again. */
    retryCleanup: (route: ShellRoute, abortMs: number) => Promise<ShellRetry>;
}
/** The real calls. */
export declare const SHELL_CALLS: ShellCalls;
/** What this module needs from the plugin around it. */
export interface DataLocationOptions {
    /** The shell's route, or undefined where nothing lent this deployment the service. */
    route: ShellRoute | undefined;
    /** The polling cadence the browser half is told to use. */
    poll: PollCadence;
    /** How long to wait for a state read or a removal request. */
    requestTimeoutMs: number;
    /** How long to wait for a folder check or a move request, which read the whole data folder. */
    checkTimeoutMs: number;
    /** Every workspace folder the server knows. */
    workspaces: () => string[];
    /** How many conversations have work running. */
    running: () => Promise<number>;
    /** Receives one line about a failure; never a token. */
    log: (line: string) => void;
    /** The shell calls to make; {@link SHELL_CALLS} in production. */
    calls?: ShellCalls;
}
/** The five Remote methods, with the shell behind them. */
export declare class DataLocation {
    private readonly route;
    private readonly options;
    private readonly calls;
    /**
     * @param options - the shell route, the timeouts, what the server knows, and the injectable calls.
     */
    constructor(options: DataLocationOptions);
    /**
     * Where the data is and how the last move went.
     * @returns the view; `available: false` without the service, `reachable: false` when the shell did not answer.
     */
    state(): Promise<DataLocationView>;
    /**
     * Open the native folder picker over the application window.
     * @returns the folder picked, nothing when cancelled, `busy` when a picker was already open, or why the picker
     * could not be used.
     */
    choose(): Promise<ChooseAnswer>;
    /**
     * Check a folder without moving anything, and count running conversations.
     * @param target - the folder picked; the verdict names the folder the data would go into.
     * @returns the verdict, or why the check could not be made.
     */
    preflight(target: string): Promise<PreflightAnswer>;
    /**
     * Ask the shell to move the data. Running conversations are counted again
     * first, since the check the page showed; any running refuses the move here
     * and the shell is not asked.
     * @param target - the folder picked, the same folder the check was given; the shell works out the folder the data
     * goes into from it again.
     * @returns started, the reasons it was refused, or why it could not be asked, marked `unanswered` when the request
     * may have reached the shell and no answer came.
     */
    start(target: string): Promise<StartAnswer>;
    /**
     * Ask the shell to carry the old copy's removal on again.
     * @returns started, why the application did not, or why it could not be asked.
     */
    retryCleanup(): Promise<RetryAnswer>;
    /**
     * The body of a move request.
     * @param target - the folder.
     * @returns the folder with every workspace folder the server knows.
     */
    private body;
    /**
     * Log one failed call.
     * @param name - the method.
     * @param error - what it threw.
     * @returns the message, for the answer.
     */
    private failed;
}
//# sourceMappingURL=location.d.ts.map