/**
 * The `dataLocation` Service Definition and its Typert Remote face.
 *
 * The browser reaches this service only through the harness's own `/api` Typert
 * gateway. This plugin registers no HTTP route of its own, and **the browser
 * never sees the shell's endpoint or its token**: both are read once from the
 * process environment on the host side and never leave it.
 *
 * The authority to move the data is not here. `start` forwards to the desktop
 * shell, which checks the folder again, owns the move, and stops this server to
 * carry it. A caller admitted to `/api` can name a folder; the shell decides
 * whether the data may go there.
 *
 * @module @haoran/dsh-data-location/service
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { ChooseAnswer, DataLocationView, PreflightAnswer, RetryAnswer, StartAnswer } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Where the data is kept, and moving it (provided by `@haoran/dsh-data-location`). */
        dataLocation: DataLocationService;
    }
}
/** Where the data is kept, and moving it. */
export declare abstract class DataLocationService extends TypertRemoteService {
    /**
     * @param ctx - owning plugin context.
     */
    constructor(ctx: Context);
    /**
     * Where the data is and how the last move went.
     * @returns the view; `available: false` where nothing lent this deployment the service.
     */
    abstract state(): Promise<DataLocationView>;
    /**
     * Open the native folder picker over the application window and wait for the person.
     * @returns the folder picked, nothing when cancelled, or why the picker could not be used.
     */
    abstract choose(): Promise<ChooseAnswer>;
    /**
     * Check a folder without moving anything.
     * @param target - the folder picked.
     * @returns the verdict, or why the check could not be made.
     */
    abstract preflight(target: string): Promise<PreflightAnswer>;
    /**
     * Ask the application to move the data into a folder. On success the
     * application stops this server next and carries the move in its own window.
     * @param target - the folder the person confirmed.
     * @returns started, the reasons it was refused, or why it could not be asked.
     */
    abstract start(target: string): Promise<StartAnswer>;
    /**
     * Ask the application to remove what a finished move left at the old location again.
     * @returns whether a removal was waiting, or why it could not be asked.
     */
    abstract retryCleanup(): Promise<RetryAnswer>;
    /**
     * Remote face of {@link DataLocationService.state}; the decorator cannot mark
     * the abstract member, so this concrete adapter carries the identical contract.
     * @returns the view.
     */
    remoteExportState(): Promise<DataLocationView>;
    /**
     * Remote face of {@link DataLocationService.choose}.
     * @returns the folder picked, or why not.
     */
    remoteExportChoose(): Promise<ChooseAnswer>;
    /**
     * Remote face of {@link DataLocationService.preflight}.
     * @param target - the folder picked.
     * @returns the verdict, or why not.
     */
    remoteExportPreflight(target: string): Promise<PreflightAnswer>;
    /**
     * Remote face of {@link DataLocationService.start}.
     * @param target - the folder confirmed.
     * @returns started, or why not.
     */
    remoteExportStart(target: string): Promise<StartAnswer>;
    /**
     * Remote face of {@link DataLocationService.retryCleanup}.
     * @returns whether a removal was waiting, or why not.
     */
    remoteExportRetryCleanup(): Promise<RetryAnswer>;
}
export default DataLocationService;
//# sourceMappingURL=service.d.ts.map