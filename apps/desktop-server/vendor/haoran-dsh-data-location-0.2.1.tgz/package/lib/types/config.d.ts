/**
 * Plugin configuration. Every field is changeable from `cordis.yml` and
 * validated at load.
 *
 * The protocol is not configuration and is not here: the environment variable
 * names, the five route paths, and the bearer scheme are fixed facts of the
 * shell this plugin talks to.
 *
 * @module @haoran/dsh-data-location/config
 */
import z from '@deepseek-ai/schemastery';
/** Plugin configuration. */
export interface Config {
    /**
     * How often the page re-reads the state while it is open and a move is on
     * disk, which is while the old copy is being removed after a move.
     */
    activePollMs?: number;
    /** How long the host half waits for a state read or a removal request. */
    requestTimeoutMs?: number;
    /**
     * How long the host half waits for a folder check or a move request. Both
     * read the whole data folder first, so this sits well above the other.
     */
    checkTimeoutMs?: number;
}
export declare const Config: z<Config>;
/** Configuration after defaults, with nothing left optional. */
export interface ResolvedConfig {
    activePollMs: number;
    requestTimeoutMs: number;
    checkTimeoutMs: number;
}
/**
 * Settle defaults.
 * @param config - the schema-validated plugin config.
 * @returns the resolved configuration.
 */
export declare function resolveDataLocationConfig(config: Config): ResolvedConfig;
//# sourceMappingURL=config.d.ts.map