/**
 * Show where the desktop application keeps its data, and move it.
 *
 * The data folder holds every conversation, uploaded file, and installed
 * plugin, and moving it means stopping the server this plugin runs in. So none
 * of the move is here: the desktop shell owns the folder picker, the check of
 * the folder, the move itself in its own window, and the relaunch from the new
 * location. This plugin is the part a person sees — one Settings page saying
 * where the data is, what the last move came to, and a button to choose a new
 * place — plus the two facts only the server knows: which workspace folders
 * exist, and which conversations are still running.
 *
 * What this plugin touches: the shell's data-location service on the loopback
 * address, the workspace registry (read), and the session activity waterfall
 * (asked). It registers no HTTP route, reads no file, and knows no URL — the
 * browser half reaches it only through the harness's `/api` Typert gateway, and
 * the endpoint and token stay on this side of it.
 *
 * A deployment that is not the desktop application lends no such service, and
 * then `state()` answers `available: false` and the browser half registers no
 * page.
 *
 * @module @haoran/dsh-data-location
 */
import type { Context } from '@deepseek-ai/cordis';
import { type Config } from './config.ts';
export { countRunning, STORED_FAMILY } from './activity.ts';
export type { ActivityEntry } from './activity.ts';
export { Config, resolveDataLocationConfig } from './config.ts';
export type { ResolvedConfig } from './config.ts';
export { DataLocation, SHELL_CALLS } from './location.ts';
export type { DataLocationOptions, ShellCalls } from './location.ts';
export { DataLocationService } from './service.ts';
export { CHOOSE_PATH, ENDPOINT_ENV, parseFailure, parseMoveRefusal, parseMoveResult, parsePreflight, parseRefusal, parseState, parseTerminal, PREFLIGHT_PATH, readState, requestChoose, requestPreflight, requestRetryCleanup, requestStart, RETRY_CLEANUP_PATH, shellRouteFromEnv, START_PATH, StartUnanswered, STATE_PATH, TOKEN_ENV, } from './shell.ts';
export type { MoveRequestBody, ShellChoose, ShellRetry, ShellRoute, ShellStart, ShellState } from './shell.ts';
export { CARRY_FAILURE_KINDS, HEALTH_FAILURE_KINDS, MOVE_FAILURE_KINDS, REASON_KINDS } from './types.ts';
export type { CarryFailureKind, ChooseAnswer, DataLocationView, HealthFailureKind, MoveFailureKind, MoveFailureView, MoveOutcomeView, PollCadence, PreflightAnswer, PreflightView, Reason, RetryAnswer, RetryRefusal, StartAnswer, TerminalView, } from './types.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "data-location";
/**
 * Required services: the live sessions whose activity is asked, and the
 * workspace registry whose folders every move request carries. Both are
 * required so that their absence leaves the plugin unapplied and the page
 * absent, rather than a move request carrying an empty workspace list.
 */
export declare const inject: string[];
/**
 * Mount the data-location capability.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map