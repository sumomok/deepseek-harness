/**
 * The value types both halves and the Typert manifests share.
 *
 * These are this plugin's own reading of the desktop shell's answers, not the
 * shell's types: each carries only what the Settings page words, so a field the
 * shell adds later changes nothing here, and a kind this build does not know
 * arrives as `other` rather than failing the page.
 *
 * @module @haoran/dsh-data-location/types
 */
/**
 * One reason a move cannot start, or did not.
 *
 * The kinds up to `name-collision` come from the shell's folder check; the
 * next six from its start; `conversations-running` is this plugin's own, because only the server
 * knows which conversations are running; `other` is a kind this build does not
 * know.
 */
export type Reason = {
    kind: 'parent-missing';
} | {
    kind: 'folder-unreadable';
} | {
    kind: 'inside-source';
} | {
    kind: 'contains-source';
} | {
    kind: 'inside-install';
} | {
    kind: 'inside-user-data';
} | {
    kind: 'inside-update-cache';
} | {
    kind: 'inside-workspace';
    workspace: string;
} | {
    kind: 'cloud-synced';
    root: string;
}
/** Inside one of the system's temporary folders, which the system empties on its own. */
 | {
    kind: 'inside-temp';
    root: string;
} | {
    kind: 'not-empty';
} | {
    kind: 'harness-data';
} | {
    kind: 'not-a-folder';
} | {
    kind: 'unsupported-file-system';
} | {
    kind: 'network-location';
} | {
    kind: 'no-permission';
} | {
    kind: 'capability-missing';
} | {
    kind: 'not-enough-space';
    needed: number;
    free: number;
}
/** Two names in the data would become one name at the new location (letter case, or Unicode normalization). */
 | {
    kind: 'name-collision';
} | {
    kind: 'abandoned-unreadable';
    path: string;
} | {
    kind: 'terminal-unreadable';
} | {
    kind: 'in-progress';
} | {
    kind: 'no-identity';
} | {
    kind: 'locked';
} | {
    kind: 'server-still-running';
} | {
    kind: 'conversations-running';
    count: number;
} | {
    kind: 'other';
};
/** Every {@link Reason} kind, in the order the page lists them. */
export declare const REASON_KINDS: readonly ["parent-missing", "folder-unreadable", "inside-source", "contains-source", "inside-install", "inside-user-data", "inside-update-cache", "inside-workspace", "cloud-synced", "inside-temp", "not-empty", "harness-data", "not-a-folder", "unsupported-file-system", "network-location", "no-permission", "capability-missing", "not-enough-space", "name-collision", "abandoned-unreadable", "terminal-unreadable", "in-progress", "no-identity", "locked", "server-still-running", "conversations-running", "other"];
/**
 * Every kind the shell names a failed move's cause with.
 *
 * - `source-changed`: the data folder was no longer where it was, or no longer held this data.
 * - `target-occupied`: something that is not the move's copy is at the new location.
 * - `copy-mismatch`: the copy read back different from the original.
 * - `copy-gone`: the copy at the new location disappeared, or no longer holds this data.
 * - `no-space`: a drive ran out of space.
 * - `no-permission`: a file or folder could not be written, or the drive is read-only.
 * - `lock-lost`: the move lost hold of the data, and the person gave it up or took it back.
 * - the {@link HEALTH_FAILURE_KINDS}: the first launch on the new location failed its check.
 * - `other`: anything else, including a kind this build does not know.
 */
export declare const MOVE_FAILURE_KINDS: readonly ["source-changed", "target-occupied", "copy-mismatch", "copy-gone", "no-space", "no-permission", "lock-lost", "not-started", "unreadable", "fewer-sessions", "plugin-quarantined", "workspaces-differ", "other"];
/** One {@link MOVE_FAILURE_KINDS} entry. */
export type MoveFailureKind = typeof MOVE_FAILURE_KINDS[number];
/**
 * What the check of the first launch on the new location found: DSH did not
 * start there, the data there could not be read, fewer conversations than
 * before the move, a plugin that could not be loaded, or another number of
 * workspaces. Only these reach a `moved` result, and only these appear in
 * {@link MoveFailureView.also}.
 */
export declare const HEALTH_FAILURE_KINDS: readonly ["not-started", "unreadable", "fewer-sessions", "plugin-quarantined", "workspaces-differ"];
/** One {@link HEALTH_FAILURE_KINDS} entry. */
export type HealthFailureKind = typeof HEALTH_FAILURE_KINDS[number];
/**
 * The failures while the data was being moved, before any check of the new
 * location, that the page words with a cause and a next step of their own;
 * `lock-lost` and `other` get the general sentence. The `source-changed`
 * sentence says nothing about where the data is, since the data folder may
 * be gone from its old path.
 */
export declare const CARRY_FAILURE_KINDS: readonly ["source-changed", "target-occupied", "copy-mismatch", "copy-gone", "no-space", "no-permission"];
/** One {@link CARRY_FAILURE_KINDS} entry. */
export type CarryFailureKind = typeof CARRY_FAILURE_KINDS[number];
/** Why a move failed. */
export interface MoveFailureView {
    /** The first problem. */
    kind: MoveFailureKind;
    /** Further problems the same check of the new location found, in its order; empty when there are none. */
    also: MoveFailureKind[];
}
/** How the last move the page can report ended. */
export interface MoveOutcomeView {
    /** `other` is an outcome this build does not know. */
    outcome: 'moved' | 'cancelled' | 'failed' | 'other';
    /** Where the data was. */
    source: string;
    /** Where it was going. */
    target: string;
    /** When it ended, as the shell wrote it (ISO 8601). */
    finishedAt: string;
    /** Folders a rollback could not remove at the new location, with the bytes each still holds. */
    leftovers: {
        path: string;
        bytes: number;
    }[];
    /** A rollback renamed the copy at the new location to this folder and left it there. */
    unusedCopy?: string;
    /** A rollback went on without the copy at the new location, on a drive that was away; it is still there. */
    abandonedCopy?: string;
    /** The person kept the new location while the original could not be found; it is still on its drive. */
    abandonedOriginal?: string;
    /** The new location failed its check after the person kept it; the original is kept in this folder. */
    keptOriginal?: string;
    /**
     * A rollback could not put the terminal's data location setting back as it
     * was, so DSH in a terminal may still use this new location, which the
     * application no longer uses. Only a `failed` result carries it.
     */
    terminalNotRestored?: string;
    /**
     * Why the move failed: on a `failed` result, and on a `moved` one whose new
     * location failed its check after the person chose to keep it. Absent from a
     * result an older shell wrote, and from one this build cannot read.
     */
    failure?: MoveFailureView;
}
/**
 * What a write of the terminal's data location came to: this launch's own
 * write, or else a data move's write, on a launch that checks that move's
 * switch or carries on its cleanup, and on the first launch after the move
 * finished on a new location that failed its check after the person chose to
 * keep it.
 */
export type TerminalView = 
/** Terminals opened from now on use this location. */
{
    kind: 'synced';
}
/** Terminals read a different location, `value`, which the shell read back after its write. */
 | {
    kind: 'overridden';
    value: string;
}
/** A setting the person wrote themselves stays in effect; `file` and `line` say where, when the shell found it. */
 | {
    kind: 'own-setting';
    file?: string;
    line?: number;
}
/**
 * The shell could not change the terminal's setting, so terminals may still
 * use the location they used before; `file` names the file it could not
 * change, when it names one.
 */
 | {
    kind: 'not-written';
    file?: string;
}
/** The shell could not confirm what terminals will read. */
 | {
    kind: 'unconfirmed';
};
/** How often the page re-reads the state while a move's cleanup runs. */
export interface PollCadence {
    /** Interval while the page is open and a move is on disk. */
    activeMs: number;
}
/** What the page renders from. */
export interface DataLocationView {
    /**
     * False exactly where the deployment lends no data-location service. The
     * browser half registers nothing in that case.
     */
    available: boolean;
    /** Whether the shell answered the last read; false leaves every field below empty. */
    reachable: boolean;
    /** The data folder in use. */
    home: string;
    /** Whether a move is on disk: requested, in progress, or removing the old copy. */
    moving: boolean;
    /**
     * Whether the shell is removing a finished move's old copy right now; true
     * only in the move's cleanup phase. Absent when the shell does not say.
     */
    cleanupRunning?: boolean;
    /**
     * Whether the move is in its cleanup phase and no removal runs now, so the
     * removal carries on at the next launch or a retry. Absent when the shell
     * does not say; with both absent the page reads a recorded move as removing.
     */
    cleanupWaiting?: boolean;
    /**
     * The old copy's removal after a move left files behind, and the shell wants
     * the page to say so and offer to try again.
     */
    cleanup?: {
        leftoverBytes: number;
    };
    /** The last finished move. */
    lastResult?: MoveOutcomeView;
    /** Why the last move asked for from Settings was taken back after it had been accepted. */
    lastRefusal?: Reason[];
    /**
     * What a write of the terminal's data location came to, from the write
     * {@link TerminalView} names; absent when the shell reports no write.
     */
    terminal?: TerminalView;
    /** The polling cadence, resolved from this plugin's config. */
    poll: PollCadence;
}
/** The folder check's verdict, with the running conversations counted in. */
export interface PreflightView {
    /** Whether the move may start: no reason from the shell and no running conversation. */
    ok: boolean;
    /** The folder the data would be moved into (the picked folder, or a new folder inside it). */
    target: string;
    /** Whether the move is a rename on one drive rather than a copy. */
    sameVolume: boolean;
    /** Bytes the copy writes; zero for a rename. */
    copyBytes: number;
    /** Why the move may not start. */
    reasons: Reason[];
    /** Whether some paths get long enough at the new location that some Windows programs cannot open them. */
    longPaths: boolean;
}
/** What opening the folder picker came to. */
export interface ChooseAnswer {
    /** The folder picked; absent when the picker was cancelled or failed. */
    picked?: string;
    /** True when a folder picker was already open, so no second one was opened. */
    busy?: boolean;
    /** Why the picker could not be used, when it could not. */
    error?: string;
}
/** What checking a folder came to. */
export interface PreflightAnswer {
    /** The verdict; absent when the check could not be made. */
    verdict?: PreflightView;
    /** Why the check could not be made. */
    error?: string;
}
/** What asking for a move came to. */
export interface StartAnswer {
    /** Whether the shell accepted the move and is about to carry it. */
    started: boolean;
    /** Why it did not, when it refused. */
    reasons?: Reason[];
    /** Why it could not be asked, when the request itself failed. */
    error?: string;
    /**
     * Set with `error` when the request may have reached the shell and no answer
     * came: the shell may still be starting the move, so the page does not call
     * it a failure.
     */
    unanswered?: boolean;
}
/**
 * Why the old copy's removal was not carried on again: none is waiting, one
 * is running already, the application window it needs is not open, or a
 * reason this build does not know.
 */
export type RetryRefusal = 'none-waiting' | 'running' | 'no-window' | 'other';
/** What asking for the old copy's removal again came to. */
export interface RetryAnswer {
    /** Whether a removal was waiting and was carried on again. */
    started: boolean;
    /** Why it was not, when the application answered. */
    reason?: RetryRefusal;
    /** Why it could not be asked, when the request itself failed. */
    error?: string;
}
//# sourceMappingURL=types.d.ts.map