/**
 * The browser half's stylesheet, injected as one tagged `<style>` per client instance.
 *
 * Every colour is a harness theme variable rather than a literal, so the page
 * and the button follow the light and dark schemes the shell already switches
 * between. The button is an ordinary flex item wherever it lands: no absolute
 * positioning, and no assumption that it owns either edge of its row, because
 * both seats it can take are shared with other plugins. Which of the two it
 * took decides whether it paints a surface at all. In the settings-row seat
 * (`dshdu-action-inrow`) it paints none — no border, no background, none on
 * hover either — because that row owns the hover surface and a second painted
 * box inside it reads as a separate control; there, hover moves only the label
 * colour and the focus ring is the one outline the button draws. In the
 * sidebar-foot fallback the button is a row of its own with nothing painting
 * underneath it, so it keeps its own pill and its own hover fill.
 *
 * @module @haoran/dsh-desktop-update/client/styles
 */
/** Attribute marking this plugin's style tags. */
export declare const STYLE_TAG = "data-dsh-desktop-update";
/**
 * The `data-plugin` value on this plugin's style tags: the package name, which
 * is the id the host's client module system gives this plugin. That system
 * stamps every `<style>` without `data-plugin` with the id of the module it is
 * materializing and removes the stamped tags when that module unloads; a tag
 * that already names this plugin is left to this plugin's own disposer.
 */
export declare const STYLE_OWNER = "@haoran/dsh-desktop-update";
/**
 * Insert this call's own copy of the stylesheet. Every call appends a separate
 * tag, so overlapping client instances of this plugin each hold one and
 * disposing one instance leaves the others styled.
 * @returns a disposer removing only the tag this call inserted.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map