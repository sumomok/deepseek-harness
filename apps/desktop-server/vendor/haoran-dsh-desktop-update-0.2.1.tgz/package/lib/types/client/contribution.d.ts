/**
 * The browser half's Typert contribution: the consumer-side mirror of
 * `../typert.ts`.
 *
 * Each descriptor must match the host manifest's invocation exactly — same id,
 * namespace, and method — because the gateway matches by those names. The
 * codecs are hand-written narrowings rather than a schema library: this file is
 * bundled into the browser and a validator's bytes would ride into every page
 * load for four small calls.
 *
 * Each codec carries the `create()` factory the registry requires of every
 * strict codec. The browser gateway at `0.1.7-rc.2` never calls it — it reads a
 * result through `decode` only, and these codecs have none — so the browser does
 * not run these narrowings on what the host returns.
 *
 * @module @haoran/dsh-desktop-update/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { CommandOutcome, UpdateView } from '../types.ts';
/** Narrow one state read. */
export declare function parseUpdateView(value: unknown): UpdateView;
/** Narrow one command outcome. */
export declare function parseCommandOutcome(value: unknown): CommandOutcome;
/** The contribution `ctx.remote.$mount()` installs, mirroring `../typert.ts`. */
export declare const CONTRIBUTION: TypertRemoteContribution;
//# sourceMappingURL=contribution.d.ts.map