/**
 * The profile entry id this plugin's bundle inserts.
 *
 * Its own module because both halves need it and only one of them can import
 * `./mode.ts`: that module reads the Loader's volatile references and the
 * commands registry, neither of which belongs in a browser bundle.
 * @module @haoran/dsh-llm-permission-gateway/settings-namespace
 */
/**
 * Id of the profile entry the bundle inserts, which is also the settings
 * namespace the browser half asks `configForms` for. The host half writes
 * through its own `ctx.fiber.entry` id instead, so a composition that renames
 * the entry still stores the choice where it belongs; only the settings page
 * reads this constant, and it does not appear for an entry under another id.
 */
export declare const GATEWAY_ENTRY_ID = "llm-permission-gateway";
//# sourceMappingURL=settings-namespace.d.ts.map