/**
 * The review call itself: one prompt, one model turn, one verdict call read.
 * Two questions share it — a pending tool call and a sandbox escalation.
 *
 * Every review offers exactly one tool, {@link SUBMIT_VERDICT}, and forces the
 * model to call it; the verdict is read from that call and from nothing else.
 *
 * Every way this can go wrong returns {@link JudgeFailure} rather than a
 * verdict, and the failure type carries no verdict of its own — the caller
 * decides, and its only choices are the fail-closed ones. Nothing in this
 * module can produce `allow` except a verdict call whose `decision` is `allow`.
 * @module @haoran/dsh-llm-permission-gateway/judge
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ContentBlock, TokenUsage, ToolSchema } from '@deepseek-ai/dsh-llm';
declare module '@deepseek-ai/dsh-llm' {
    interface GenerateOptions {
        /**
         * Requires the answer to call one of the offered `tools`.
         *
         * Declared here because this package's installed peer predates the field;
         * it corresponds to the core patch `llm-tool-choice`, whose DeepSeek
         * adapter maps it onto the wire's `tool_choice` and whose pi-ai adapter
         * refuses it with `UNSUPPORTED_OPTION`. A host without that patch drops the
         * field silently and still sends the tools. Delete this block once the peer
         * carries the field — the property type is the patch's own, so the merge
         * needs nothing here.
         */
        toolChoice?: {
            type: 'any';
        };
    }
}
/**
 * The one tool every review offers, and the only place a verdict is read from.
 *
 * Its description names only itself; the prompt tells the model what the
 * decision means.
 */
export declare const SUBMIT_VERDICT: ToolSchema;
/**
 * The answer set the verdict reader accepts. `deny` is still read because a
 * model told to answer with two values may answer with three; the gate downgrades it
 * rather than letting an unrecognized word become a fail-closed failure.
 */
export type JudgeVerdict = 'allow' | 'ask' | 'deny';
/** A verdict read from one model answer. */
export interface JudgeResult {
    /** The verdict the model returned. */
    readonly verdict: JudgeVerdict;
    /** The model's one-sentence statement of what running the call would cost. */
    readonly reason: string;
}
/** Why no verdict was obtained. Carries no verdict, so no failure path can allow. */
export interface JudgeFailure {
    /** Short machine-ish label for the failure mode, recorded and quoted into the fail-closed reason. */
    readonly cause: 'timeout' | 'cancelled' | 'model-error' | 'unparsable-answer';
    /** Detail for the fail-closed reason shown to the user, in the user's own language. */
    readonly detail: string;
    /**
     * Opening characters of the raw answer, whitespace collapsed: the verdict
     * call's arguments where the answer held exactly one call, and its text
     * otherwise. Present on every failure reached after the stream ended —
     * including an empty answer,
     * which is recorded as the empty string rather than omitted, because "the
     * model said nothing" is the diagnosis. It is model text about the user's own
     * call, so the record writer drops it unless `verdictLogArgsPreview` is
     * above zero, the same switch that admits the argument preview.
     */
    readonly answerPreview?: string;
    /**
     * The finish kind the stream reported, for failures reached after it ended.
     * A stream that ended without a finish chunk reads as `stop` here, because
     * that is how the assembler reports it, and an abort carries no finish at
     * all.
     */
    readonly finish?: string;
}
/**
 * The judge's outcome: either a parsed verdict or a failure.
 *
 * `usage` rides both members because a review that produced no verdict can
 * still have been paid for — a truncated answer is billed like any other — and
 * a cost record that counted only the successful reviews would understate what
 * the gate spends. It is absent when the stream reported no usage chunk, and it
 * covers both turns of a widened review rather than only the one that answered.
 *
 * `budgetRetried` marks an outcome reached after {@link JudgeRoute.reasoningBudgetTokens}
 * bought a second turn; see {@link JudgeRoute.reasoningBudgetTokens} for when
 * that happens. `answerRetried` marks one reached after the same question was
 * put again because the first answer could not be read. The two never appear
 * together: a truncated answer is widened, a finished one is re-asked.
 */
export type JudgeOutcome = {
    readonly kind: 'verdict';
    readonly result: JudgeResult;
    readonly toolChoice: ToolChoiceMode;
    readonly usage?: TokenUsage;
    readonly budgetRetried?: true;
    readonly answerRetried?: true;
} | {
    readonly kind: 'failure';
    readonly failure: JudgeFailure;
    readonly toolChoice: ToolChoiceMode;
    readonly usage?: TokenUsage;
    readonly budgetRetried?: true;
    readonly answerRetried?: true;
};
/**
 * How one review offered {@link SUBMIT_VERDICT}: `forced` with
 * `toolChoice: { type: 'any' }`, or `offered` alone on a route that refused the
 * forced call.
 */
export type ToolChoiceMode = 'forced' | 'offered';
/** Where the judge model lives and how long it may take. */
export interface JudgeRoute {
    /** Registered LLM provider route (`ctx.llm` adapter selector). */
    readonly provider: string;
    /** Model id, chosen independently of the agent's own model. */
    readonly model: string;
    /** Provider-owned reasoning effort id, or `undefined` to take the provider default. */
    readonly reasoningEffort: string | undefined;
    /** Sampling temperature every review request states, forwarded verbatim from `Config.temperature`. */
    readonly temperature: number;
    /** Output cap; the answer is one small verdict call, plus any text a model writes before it. */
    readonly maxOutputTokens: number;
    /**
     * Extra output tokens one retry adds after an answer that hit
     * {@link JudgeRoute.maxOutputTokens}; `0` never retries. On a forced route
     * every such answer is retried; on an offered one, only an answer that
     * reported spending thinking tokens ({@link widensToAnswer} states why).
     *
     * The provider counts thinking inside the output cap, so a reviewer that
     * thinks first can exhaust the cap before it writes the verdict — which is a
     * fail-closed failure, and therefore an approval prompt on every call. The
     * retry is issued inside the same {@link JudgeRoute.timeoutMs} budget and
     * happens at most once.
     */
    readonly reasoningBudgetTokens: number;
    /**
     * Whether the first turn is issued at {@link JudgeRoute.maxOutputTokens} plus
     * {@link JudgeRoute.reasoningBudgetTokens} rather than at the cap alone.
     *
     * Set for a route whose effort was chosen from the settings page: the person
     * picked how hard the reviewer thinks, the provider counts thinking inside
     * the cap, and starting narrow would buy a truncated first answer and a
     * second turn on every call. A cap is a ceiling and not a spend, so the room
     * a choice of the route's own no-thinking effort does not use costs nothing.
     * The retry is then not issued: the wider cap is where it would have gone.
     */
    readonly budgetFirstTurn: boolean;
    /**
     * Whether reviews on this route force the verdict call. False once the route
     * has refused one at this effort: not every adapter accepts `toolChoice`, and
     * the in-tree pi-ai adapter answers a request carrying it with
     * `UNSUPPORTED_OPTION`. The tool is offered either way.
     */
    readonly forcesTool: boolean;
    /**
     * Report that this route refused a forced call, so the reviews after it at
     * the same effort only offer the tool. The memory belongs to the route and is
     * dropped when the route changes or an adapter registers or retires one.
     */
    readonly refuseForcedTool: () => void;
    /** Wall-clock budget for the whole review call. */
    readonly timeoutMs: number;
    /** Language for the human-facing reason. */
    readonly reasonLanguage: string;
}
/**
 * One sandbox escalation put to the review model: the operating system has
 * already refused a command, and the agent is asking for the refusal to be
 * lifted for this one call.
 */
export interface EscalationReview {
    /** The tool whose call was refused (`bash`, `pwsh`, `write`, `edit`). */
    readonly tool: string;
    /** The wider sandbox mode being asked for. */
    readonly requestedMode: string;
    /** The agent's own stated reason, verbatim; a claim about itself, not evidence. */
    readonly justification: string;
    /**
     * Arguments of the refused call, as this gate saw them on `tools/pre-execute`.
     * Required, because the prompt tells the model the refused call is in front of
     * it: an escalation whose call was not remembered goes to a person instead of
     * reaching this function.
     */
    readonly arguments: unknown;
}
/**
 * Validate one set of verdict-call arguments.
 *
 * `decision` must be exactly one of the three enum members — `deny` is still
 * read, and the gate downgrades it — and `reason` a non-empty string. Anything
 * else yields `undefined` and therefore the caller's fail-closed outcome.
 * @param record - the parsed arguments object.
 * @returns the verdict, or `undefined` when the arguments do not state one.
 */
export declare function verdictOf(record: Readonly<Record<string, unknown>>): JudgeResult | undefined;
/** What one answer's content blocks say, as {@link readVerdictCall} reads them. */
export type VerdictCall = {
    readonly kind: 'verdict';
    readonly result: JudgeResult;
    /** The call's raw arguments, whitespace collapsed and cut to the preview length. */
    readonly answerPreview: string;
} | {
    readonly kind: 'unreadable';
    /** Why no verdict was read, in the words the person sees; it names no tool. */
    readonly detail: string;
    /** The one call's raw arguments where there was exactly one call, the answer's text otherwise. */
    readonly answerPreview: string;
};
/**
 * Read the verdict from one answer's content blocks.
 *
 * The verdict is read from exactly one tool call named `submit_verdict` and
 * from nothing else: text and reasoning blocks never take part, because a
 * model that writes a sentence before its call writes whatever it likes there.
 * Two calls are unreadable rather than a choice between them — choosing would
 * be searching the answer for a decision, which this reader must never do —
 * and so is a call under another name, arguments that are not one JSON object,
 * arguments {@link verdictOf} rejects, and no call at all.
 * @param blocks - the assembled answer.
 * @returns the verdict, or why none was read, with the answer text to preview.
 */
export declare function readVerdictCall(blocks: readonly ContentBlock[]): VerdictCall;
/**
 * Review one pending call.
 *
 * The description is passed explicitly, and explicitly as `undefined` where the
 * registry resolves none, so that whether the judge sees one is decided by the
 * caller that read the registry rather than defaulted here.
 * @param ctx - context exposing the `llm` service.
 * @param route - the independently configured judge model and its budget.
 * @param toolName - the tool about to run.
 * @param args - the parsed call arguments.
 * @param description - the tool's own registered description, or `undefined` when none is available.
 * @param confined - whether the operating system confines this call's file effects, which is the premise the prompt states.
 * @param callerSignal - the tool call's own cancellation.
 * @returns the parsed verdict, or the failure the caller must fail closed on, with the tokens the request reported.
 */
export declare function judgeCall(ctx: Context, route: JudgeRoute, toolName: string, args: unknown, description: string | undefined, confined: boolean, callerSignal: AbortSignal): Promise<JudgeOutcome>;
/**
 * Review one sandbox escalation on the user's behalf.
 * @param ctx - context exposing the `llm` service.
 * @param route - the independently configured judge model and its budget.
 * @param request - the refused call, the wider access asked for, and the agent's justification.
 * @param callerSignal - the approval request's own cancellation, when it carries one.
 * @returns the parsed verdict, or the failure the caller must fail closed on, with the tokens the request reported.
 */
export declare function judgeEscalation(ctx: Context, route: JudgeRoute, request: EscalationReview, callerSignal: AbortSignal): Promise<JudgeOutcome>;
//# sourceMappingURL=judge.d.ts.map