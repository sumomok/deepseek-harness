/**
 * The `compactionPolicy` service: the two answers the harness's compaction
 * engine asks for.
 *
 * **`isEnabled()` turns the harness's own between-steps listener off.** That
 * listener retries a failed compaction at every following step with nothing
 * held between attempts. This plugin compacts at the same moment from its own
 * `agent/pre-step` listener (`./step-compaction.ts`), which backs off per agent
 * and per turn. The switch a person sets is read there, not here.
 *
 * It answers `false` only once the step path has reached a compaction engine.
 * Before the first agent exists, and in a composition whose engine this plugin
 * can address for no agent at all, it answers `true` — the harness's own
 * behaviour, unchanged. The seat takes no agent, so one answer governs every
 * agent in the process; the step path covers every agent in turn, delegated
 * ones included.
 *
 * **`thresholdRatio()` is the share the engine compares against.** The engine
 * reads it each time the step path calls `compactIfNeeded`, and it reads the
 * volatile Config on every call, so it answers the share in force right now.
 *
 * @module @haoran/dsh-auto-compact/policy
 */
import type { AutoCompactSettings } from './section.ts';
/** Live automatic-compaction policy a host-plane plugin provides from its own Config. */
export interface CompactionPolicy {
    /**
     * Whether pressure-triggered compaction runs at all; overflow recovery is unaffected.
     * @returns false once this plugin's own step compaction can run, true while it cannot.
     */
    isEnabled(): boolean;
    /**
     * Share of the model's context window (0–1) at which the next step compacts first.
     * @returns the live threshold ratio; a value outside (0, 1], or one the retained tail
     *   would not clear, is refused and the configured ratio governs instead.
     */
    thresholdRatio(): number;
}
/**
 * The service key, declared here because this package is the only one that
 * can: the agent loop that reads it at runtime lives in the harness checkout,
 * and this plugin builds against the published packages, which do not carry
 * the declaration. Retire this block if a published `@deepseek-ai/dsh-*` ever
 * declares the key itself — two augmentations of one interface member must
 * agree exactly, and the other one would then be the authority.
 */
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Automatic-compaction policy, provided by `@haoran/dsh-auto-compact`. */
        compactionPolicy: CompactionPolicy;
    }
}
/**
 * Build the policy over a settings source and the step path's own coverage.
 * @param source - thunk returning the switch and the share in force right now.
 * @param covers - whether the step path has reached an engine it can compact with.
 * @returns the policy to provide under `compactionPolicy`.
 */
export declare function createCompactionPolicy(source: () => AutoCompactSettings, covers: () => boolean): CompactionPolicy;
//# sourceMappingURL=policy.d.ts.map