/**
 * The card's stylesheet, injected as one tagged `<style>` per client instance.
 *
 * Every colour is a harness theme variable rather than a literal, so the row
 * follows the light and dark schemes the shell already switches between. The
 * row is laid out like the harness's own General rows — no frame of its own, a
 * vertical padding and a hairline separator underneath — because the General
 * column stacks feature-owned rows and removes the last row's separator itself.
 *
 * The switch is a real checkbox with the box moved off-screen rather than
 * hidden: `display:none` would take it out of the tab order and out of reach of
 * a screen reader, and the track beside it is decoration that the label
 * forwards clicks to.
 *
 * @module @haoran/dsh-auto-compact/client/styles
 */
/** Attribute marking this plugin's style tags. */
export declare const STYLE_TAG = "data-dsh-auto-compact";
/**
 * The `data-plugin` value on this plugin's style tags: the package name, which
 * is the id the host's client module system gives this plugin. That system
 * stamps every `<style>` without `data-plugin` with the id of the module it is
 * materializing and removes the stamped tags when that module unloads; a tag
 * that already names this plugin is left to this plugin's own disposer.
 */
export declare const STYLE_OWNER = "@haoran/dsh-auto-compact";
/**
 * Insert this call's own copy of the stylesheet. Every call appends a separate
 * tag, so overlapping client instances of this plugin each hold one and
 * disposing one instance leaves the others styled.
 * @returns a disposer removing only the tag this call inserted.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map