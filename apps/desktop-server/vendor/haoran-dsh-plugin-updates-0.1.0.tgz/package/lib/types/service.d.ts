/**
 * The `pluginUpdates` Service Definition and its Typert Remote face.
 *
 * The browser reaches this service only through the harness's own `/api` Typert
 * gateway, which inherits the host's trust fence. This plugin registers no HTTP
 * route of its own.
 *
 * Three of the five methods change something, which makes this the one seam in
 * this repository that is not read-only, so where the authority sits matters.
 * It is not here. Every mutating method forwards to the desktop shell, which
 * fixes the profiles that may be acted in, checks the package against that
 * profile's own installed dependencies, refuses anything but one exact
 * published version, and puts a native confirmation in front of the person
 * before it installs. A caller admitted to `/api` behind a reverse proxy can
 * therefore ask for an update and gets a dialog on the machine's own screen; it
 * cannot install anything, cannot name a package the profile never installed,
 * and cannot name a specifier at all.
 *
 * @module @haoran/dsh-plugin-updates/service
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { RelaunchOutcome, UpdateOutcome, UpdatesView } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Installed-plugin updates (provided by `@haoran/dsh-plugin-updates`). */
        pluginUpdates: PluginUpdatesService;
    }
}
/** Updating the plugins the user installed. */
export declare abstract class PluginUpdatesService extends TypertRemoteService {
    /**
     * @param ctx - owning plugin context.
     */
    constructor(ctx: Context);
    /**
     * What is installed, and what the last check said about it.
     *
     * Reads disk and nothing else, so it answers immediately and works on a
     * machine with no network.
     * @returns the current view, or an unavailable one where nothing lent this
     * deployment a package manager.
     */
    abstract list(): Promise<UpdatesView>;
    /**
     * Look for newer published versions.
     * @returns the view including whatever the check found, or why it found nothing.
     */
    abstract check(): Promise<UpdatesView>;
    /**
     * Install the newest published version of one installed plugin, after the
     * person confirms it on the machine's own screen.
     * @param name - the package name, which must be one {@link PluginUpdatesService.list} returned.
     * @returns how it ended, including the compatibility sentence the dialog carried.
     */
    abstract update(name: string): Promise<UpdateOutcome>;
    /**
     * Put the last update back, after the person confirms it.
     * @returns how it ended.
     */
    abstract rollback(): Promise<UpdateOutcome>;
    /**
     * Ask the person to restart the application, which is what makes an installed
     * update take effect.
     * @returns what the person answered.
     */
    abstract relaunch(): Promise<RelaunchOutcome>;
    /**
     * Remote face of {@link PluginUpdatesService.list}; the decorator cannot mark
     * the abstract member, so this concrete adapter carries the identical contract.
     * @returns the current view.
     */
    remoteExportList(): Promise<UpdatesView>;
    /**
     * Remote face of {@link PluginUpdatesService.check}.
     * @returns the view including whatever the check found.
     */
    remoteExportCheck(): Promise<UpdatesView>;
    /**
     * Remote face of {@link PluginUpdatesService.update}.
     * @param name - the package name.
     * @returns how it ended.
     */
    remoteExportUpdate(name: string): Promise<UpdateOutcome>;
    /**
     * Remote face of {@link PluginUpdatesService.rollback}.
     * @returns how it ended.
     */
    remoteExportRollback(): Promise<UpdateOutcome>;
    /**
     * Remote face of {@link PluginUpdatesService.relaunch}.
     * @returns what the person answered.
     */
    remoteExportRelaunch(): Promise<RelaunchOutcome>;
}
export default PluginUpdatesService;
//# sourceMappingURL=service.d.ts.map