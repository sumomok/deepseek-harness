/**
 * Wire types shared by the host half, the browser half, and the Typert
 * manifest. Nothing here carries a token, a path, or a package-manager
 * transcript: every value in this module is something the browser is allowed to
 * render, and the two that are not — which profile a package lives in, and the
 * text pnpm printed — are named as such where they appear.
 *
 * @module @haoran/dsh-plugin-updates/types
 */
/**
 * Which profile one package is installed in.
 *
 * Internal routing only. It decides which directory an update runs in and is
 * never rendered: "profile" is a word from the command line, and the person
 * this feature is for installed a plugin, not a profile.
 */
export type OwningProfile = 'desktop' | 'web';
/** Where one row stands. */
export type RowState = 
/** No check has reported on this row yet. */
'unknown'
/** Checked, and nothing newer is published. */
 | 'current'
/** Checked, and a newer version is published. */
 | 'outdated'
/** Updated in this session; the new version takes effect after a restart. */
 | 'updated';
/** One installed plugin, as the Updates tab renders it. */
export interface PluginRow {
    /** The package name, which is also the name shown. */
    name: string;
    /** The profile this package is installed in; routing only, never rendered. */
    profile: OwningProfile;
    /** The version running now. */
    installed: string;
    /** The newest published version, once a check has reported one. */
    latest?: string;
    /** Where this row stands. */
    state: RowState;
}
/** The one update that can still be undone. */
export interface RollbackOffer {
    /** The package that was updated. */
    name: string;
    /** The version it was on before, which rolling back returns it to. */
    from: string;
    /** The version it was updated to. */
    to: string;
    /** Epoch milliseconds of the update. */
    at: number;
}
/** Why the updater can do nothing at all here. */
export type UnavailableReason = 
/** This deployment is not the desktop application, so nothing lent it a package manager. */
'no-package-manager';
/**
 * Why one update, rollback, or restart did not happen.
 *
 * A code rather than a sentence, because the sentence belongs to whichever
 * language the person reads and this half serves both. The one message this
 * package does compose in Chinese is the compatibility warning, which goes into
 * a native dialog the application draws in Chinese whatever the browser is set
 * to.
 */
export type FailureCode = 
/** This deployment lends no package manager, so nothing can be installed. */
'unavailable'
/** The named plugin is not installed any more. */
 | 'not-installed'
/** Nothing newer than what is installed has been published. */
 | 'already-current'
/** There is no update to undo. */
 | 'nothing-to-undo'
/** The application did not answer the request. */
 | 'unreachable'
/** The install ran and did not finish. */
 | 'install-failed';
/** Everything the Updates tab renders from. */
export interface UpdatesView {
    /**
     * Whether updating is possible in this deployment at all. When false the tab
     * is not rendered, and every other field is empty.
     */
    available: boolean;
    /** Why, when it is not available. */
    reason?: UnavailableReason;
    /** The plugins the user installed, by name; never the ones the application ships. */
    rows: PluginRow[];
    /** Epoch milliseconds of the last completed check; null when none has completed. */
    checkedAt: number | null;
    /** Whether a check is running right now. */
    checking: boolean;
    /** Whether the last check could not reach the registry. */
    checkFailed: boolean;
    /** The one update that can still be undone. */
    rollback: RollbackOffer | null;
}
/** How one update or rollback ended. */
export interface UpdateOutcome {
    /** Whether the package now on disk is the one that was asked for. */
    ok: boolean;
    /** Whether the person confirmed the application's own dialog. */
    confirmed: boolean;
    /** The package that was acted on. */
    name: string;
    /** The version asked for. */
    version: string;
    /** Why it did not happen, when it did not. */
    failure?: FailureCode;
    /** Whether the dialog carried a compatibility warning about this version. */
    warned: boolean;
    /** Whether the application has to restart before this takes effect. */
    restartRequired: boolean;
}
/** How the restart request ended. */
export interface RelaunchOutcome {
    /** Whether the person chose to restart now. */
    confirmed: boolean;
    /** Why the request could not be made, when it could not. */
    failure?: FailureCode;
}
//# sourceMappingURL=types.d.ts.map