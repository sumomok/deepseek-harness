/**
 * The desktop shell's plugin-admin service, used when it offers one.
 *
 * The desktop application ships a package manager the machine it runs on does
 * not have. It advertises it by putting
 * `DSH_DESKTOP_PLUGIN_ADMIN_ENDPOINT` and `DSH_DESKTOP_PLUGIN_ADMIN_TOKEN` in
 * the harness process environment; a deployment that offers no such service —
 * every `dsh web` on a server — sets neither, and this plugin then reports the
 * capability unavailable and puts up no user interface at all. There is no
 * second path: this module never looks for pnpm, never resolves a package
 * manager off PATH, and never fetches a registry URL of its own, so a customer
 * mirror, proxy, or private registry configured on the machine is the one every
 * request goes through.
 *
 * The shell owns every decision that matters. It fixes which profiles may be
 * acted in, checks the package name against the profile's own installed
 * dependencies, refuses anything but one exact published version, and puts a
 * native confirmation in front of the user before it installs. This module
 * composes requests and reads answers; a request it composes wrongly is one the
 * shell refuses.
 *
 * The wire protocol is stated in full in `apps/desktop/README.md` of the
 * desktop repository, which is what a shell implements against.
 * @module @haoran/dsh-plugin-updates/shell
 */
import type { OwningProfile } from './types.ts';
/** Environment variable naming the plugin-admin service's origin. */
export declare const ENDPOINT_ENV = "DSH_DESKTOP_PLUGIN_ADMIN_ENDPOINT";
/** Environment variable carrying the bearer token that service requires. */
export declare const TOKEN_ENV = "DSH_DESKTOP_PLUGIN_ADMIN_TOKEN";
/** Route reporting which of a profile's packages have a newer version. */
export declare const OUTDATED_PATH = "/outdated";
/** Route reporting one published version's peer requirements. */
export declare const PEERS_PATH = "/peers";
/** Route that confirms with the user and installs. */
export declare const UPDATE_PATH = "/update";
/** Route that confirms with the user and restarts the application. */
export declare const RELAUNCH_PATH = "/relaunch";
/** Where the shell's plugin-admin service lives and how to authenticate to it. */
export interface ShellRoute {
    /** Origin of the service, without a trailing slash. */
    readonly endpoint: string;
    /** Bearer token the shell minted for this harness process. */
    readonly token: string;
}
/**
 * Read the plugin-admin route out of the environment.
 *
 * Both variables are required together: an endpoint without a token would be
 * refused by the shell on every call, and a token without an endpoint names
 * nothing.
 * @param env - the environment to read.
 * @returns the route, or undefined when this deployment offers no such service.
 */
export declare function shellRouteFromEnv(env: NodeJS.ProcessEnv): ShellRoute | undefined;
/**
 * How much longer than the shell's own budget this client waits.
 *
 * The shell measures its deadline from the moment it accepts a request, behind
 * the connection and the body read, so a client abort at the same number would
 * fire on a shell that is answering exactly as asked.
 */
export declare const ABORT_MARGIN_MS = 5000;
/** How long this client waits for a read the shell answers without asking anyone. */
export declare const READ_ABORT_MS: number;
/**
 * How long this client waits for a call that opens a dialog and then installs.
 *
 * A person has to notice the dialog, read it, and answer it, and pnpm then has
 * to fetch a package over whatever link the machine has. The shell owns the
 * real deadline and answers when it passes; this budget only has to sit above
 * it.
 */
export declare const UPDATE_ABORT_MS: number;
/** How the shell said one pnpm run ended. */
export interface RunEnding {
    /** Exit status, or null when a signal or a failure ended it. */
    exitCode: number | null;
    /** The signal that ended it, when one did. */
    signal: string | null;
    /** Why the run produced no exit status, when spawning or the deadline is what ended it. */
    failure?: string;
    /** What pnpm wrote to standard error, capped by the shell. */
    stderr?: string;
}
/** What `pnpm outdated --json` reported for one package, as pnpm spells it. */
export interface OutdatedEntry {
    /** The version installed now. */
    current?: string;
    /** The newest published version. */
    latest?: string;
    /** The newest version the declared range admits. */
    wanted?: string;
}
/** The shell's answer on {@link OUTDATED_PATH}. */
export interface OutdatedAnswer extends RunEnding {
    /** The profile the run happened in. */
    profile: OwningProfile;
    /** pnpm's own object, keyed by package name; null when the run printed no JSON. */
    packages: Record<string, OutdatedEntry> | null;
    /** What pnpm printed instead of JSON, when it printed something else. */
    output?: string;
}
/** The shell's answer on {@link PEERS_PATH}. */
export interface PeersAnswer extends RunEnding {
    /** The peer ranges the published version declares; null when it declares none. */
    peers: Record<string, string> | null;
}
/** The shell's answer on {@link UPDATE_PATH}. */
export interface UpdateAnswer extends RunEnding {
    /** Whether the person confirmed the dialog; false means nothing ran. */
    confirmed: boolean;
    /**
     * The version now in the profile's own `node_modules`, read after the run;
     * null when nothing readable is there.
     *
     * **This is what says the install worked, not {@link RunEnding.exitCode}.**
     * `pnpm add` exits 1 with `ERR_PNPM_IGNORED_BUILDS` while installing
     * correctly, on every profile that has not answered its build-approval
     * question — which is every profile the desktop shell seeds, for any plugin
     * whose tree carries a package with an install script.
     */
    installedVersion?: string | null;
    /** Whether the installed package still declares itself a plugin; null when unknown. */
    stillBundle?: boolean | null;
    /** Bundle-list entries the shell removed because the package stopped being one. */
    droppedFromBundles?: string[];
    /** What pnpm printed, capped by the shell. */
    output?: string;
}
/** The shell's answer on {@link RELAUNCH_PATH}. */
export interface RelaunchAnswer {
    /** Whether the person chose to restart now. */
    confirmed: boolean;
}
/**
 * Ask which of one profile's packages have a newer version published.
 * @param route - the shell's endpoint and token.
 * @param profile - the profile to look in.
 * @returns what pnpm reported, and how its run ended.
 * @throws when the shell refuses or does not answer in time.
 */
export declare function readOutdated(route: ShellRoute, profile: OwningProfile): Promise<OutdatedAnswer>;
/**
 * Ask what one published version requires of the application around it.
 * @param route - the shell's endpoint and token.
 * @param profile - the profile the package is installed in.
 * @param name - the package name.
 * @param version - the exact published version to ask about.
 * @returns the declared peer ranges, and how the run ended.
 * @throws when the shell refuses or does not answer in time.
 */
export declare function readPeers(route: ShellRoute, profile: OwningProfile, name: string, version: string): Promise<PeersAnswer>;
/**
 * Ask the person to confirm, then install one exact version.
 * @param route - the shell's endpoint and token.
 * @param profile - the profile to install into.
 * @param name - the package name.
 * @param version - the exact published version to install.
 * @param warning - one plain sentence shown under the question, when there is something to warn about.
 * @returns what the person answered and how the install ended.
 * @throws when the shell refuses or does not answer in time.
 */
export declare function requestUpdate(route: ShellRoute, profile: OwningProfile, name: string, version: string, warning?: string): Promise<UpdateAnswer>;
/**
 * Ask the person to confirm, then restart the application.
 * @param route - the shell's endpoint and token.
 * @returns what the person answered.
 * @throws when the shell refuses or does not answer in time.
 */
export declare function requestRelaunch(route: ShellRoute): Promise<RelaunchAnswer>;
//# sourceMappingURL=shell.d.ts.map