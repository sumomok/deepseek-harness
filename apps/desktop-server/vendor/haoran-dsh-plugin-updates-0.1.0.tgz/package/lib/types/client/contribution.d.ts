/**
 * The browser half's Typert contribution: the consumer-side mirror of
 * `../typert.ts`.
 *
 * Each descriptor must match the host manifest's invocation exactly — same id,
 * namespace, method, and parameter wire names — because the gateway matches
 * arguments by field name. The codecs are hand-written narrowings rather than a
 * schema library: this file is bundled into the browser and a validator's bytes
 * would ride into every page load for five small calls.
 *
 * @module @haoran/dsh-plugin-updates/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { RelaunchOutcome, UpdateOutcome, UpdatesView } from '../types.ts';
/** Narrow one view read. */
export declare function parseUpdatesView(value: unknown): UpdatesView;
/** Narrow one update or rollback outcome. */
export declare function parseUpdateOutcome(value: unknown): UpdateOutcome;
/** Narrow one restart answer. */
export declare function parseRelaunchOutcome(value: unknown): RelaunchOutcome;
/** The contribution `ctx.remote.$mount()` installs, mirroring `../typert.ts`. */
export declare const CONTRIBUTION: TypertRemoteContribution;
//# sourceMappingURL=contribution.d.ts.map