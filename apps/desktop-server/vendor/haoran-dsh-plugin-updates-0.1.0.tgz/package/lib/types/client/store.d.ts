/**
 * The browser half's own small store: the last view the host answered, which
 * row is busy, and the last thing that happened.
 *
 * It lives outside React because two things read it — the tab, and the tab
 * label that carries the count — and because the tab is re-registered whenever
 * that count changes, which remounts its component. State kept here survives
 * that; state kept in the component would not.
 *
 * @module @haoran/dsh-plugin-updates/client/store
 */
import type { FailureCode, RelaunchOutcome, UpdateOutcome, UpdatesView } from '../types.ts';
/** What one row is in the middle of. */
export type Busy = 
/** Nothing. */
{
    kind: 'idle';
}
/** Checking every row at once. */
 | {
    kind: 'checking';
}
/** Installing one row's new version. */
 | {
    kind: 'updating';
    name: string;
}
/** Putting the last update back. */
 | {
    kind: 'undoing';
};
/** The last thing that happened, shown once and replaced by the next action. */
export type Notice = {
    kind: 'none';
}
/** The person closed the application's dialog without confirming. */
 | {
    kind: 'cancelled';
}
/** Something did not happen, and this is why. */
 | {
    kind: 'failed';
    failure: FailureCode;
};
/** What the tab renders from. */
export interface UpdatesState {
    /** The last view the host answered; undefined until the first read returns. */
    view: UpdatesView | undefined;
    /** What is in flight. */
    busy: Busy;
    /** The last thing that happened. */
    notice: Notice;
}
/** The five calls the browser half makes. */
export interface UpdatesApi {
    /**
     * Read what is installed and what the last check said.
     * @returns the view.
     */
    list(): Promise<UpdatesView>;
    /**
     * Look for newer published versions.
     * @returns the view including whatever the check found.
     */
    check(): Promise<UpdatesView>;
    /**
     * Install one plugin's newest published version.
     * @param name - the package name.
     * @returns how it ended.
     */
    update(name: string): Promise<UpdateOutcome>;
    /**
     * Put the last update back.
     * @returns how it ended.
     */
    rollback(): Promise<UpdateOutcome>;
    /**
     * Ask the person to restart the application.
     * @returns what they answered.
     */
    relaunch(): Promise<RelaunchOutcome>;
}
/** A store of one value with `useSyncExternalStore`'s subscribe/snapshot pair. */
export interface UpdatesStore {
    /**
     * Subscribe to changes.
     * @param listener - called after every state replacement.
     * @returns the unsubscriber.
     */
    subscribe(listener: () => void): () => void;
    /**
     * The current state.
     * @returns a stable reference between changes.
     */
    getSnapshot(): UpdatesState;
    /** Read the list once. */
    refresh(): Promise<void>;
    /** Run a check. */
    check(): Promise<void>;
    /**
     * Update one plugin.
     * @param name - the package name.
     */
    update(name: string): Promise<void>;
    /** Put the last update back. */
    rollback(): Promise<void>;
    /** Ask the person to restart. */
    relaunch(): Promise<void>;
}
/** How many rows have a newer version published — the number the tab label carries. */
export declare function outdatedCount(view: UpdatesView | undefined): number;
/**
 * Build the store over one RPC face.
 * @param api - the mounted Remote namespace.
 * @param onError - receives a failed call; the store keeps its last good view.
 * @returns the store.
 */
export declare function createUpdatesStore(api: UpdatesApi, onError: (error: unknown) => void): UpdatesStore;
//# sourceMappingURL=store.d.ts.map