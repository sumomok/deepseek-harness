/**
 * Copy for the browser half, in the two locales the harness ships.
 *
 * The Chinese is the original and the English is its translation, which is the
 * order this product is written in. Neither says "profile", "registry",
 * "package manager", or "dependency": the person reading it installed a plugin,
 * and every one of those words would be asking them to learn how the thing is
 * built before they can press a button.
 *
 * @module @haoran/dsh-plugin-updates/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "pluginUpdates";
/** Every key the browser half looks up. */
export type UpdatesKey = 'tab' | 'tabWithCount' | 'title' | 'intro' | 'loading' | 'empty' | 'check' | 'checking' | 'checkedAt' | 'neverChecked' | 'checkFailed' | 'update' | 'updating' | 'currentGroup' | 'currentGroupCount' | 'unknownState' | 'restartPending' | 'restartNow' | 'cancelled' | 'undoTitle' | 'undoLine' | 'undo' | 'undoing' | 'warned' | 'failure.unavailable' | 'failure.not-installed' | 'failure.already-current' | 'failure.nothing-to-undo' | 'failure.unreachable' | 'failure.install-failed';
/** Chinese copy, which is the original. */
export declare const zh: Record<UpdatesKey, string>;
/** English copy. */
export declare const en: Record<UpdatesKey, string>;
/**
 * Fill `{name}` placeholders in one copy string.
 * @param text - the copy, with placeholders.
 * @param values - the values to substitute.
 * @returns the filled text; a placeholder with no value is left as it is.
 */
export declare function fill(text: string, values: Record<string, string>): string;
//# sourceMappingURL=locales.d.ts.map