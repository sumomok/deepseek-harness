/**
 * Plugin configuration: the switch and the share one person sets, stored on
 * this plugin's own profile entry.
 *
 * Both fields are volatile. The harness's settings layer edits exactly the
 * volatile fields of an entry and writes the result into the profile patch;
 * the Loader commits the new value into the references `apply` received
 * without remounting the plugin, and the policy reads them on every call.
 *
 * Every field this Config has must stay volatile. The first launch on a
 * `0.1.7` base imports the `auto-compact` section of an older `settings.yaml`
 * into this entry, and one key in that section that is not a volatile field
 * fails the whole section. An ordinary field would also be written into the
 * profile patch with every save, freezing the bundle layer's value for that
 * person.
 *
 * @module @haoran/dsh-auto-compact/config
 */
import type { Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type AutoCompactSettings } from './section.ts';
/** Plugin configuration, as `apply` receives it. */
export interface Config {
    /** Whether automatic compaction runs at all. */
    enabled: Volatile<boolean>;
    /** The share of the context window that triggers it, in percent: a whole number from 20 to 95. */
    thresholdPercent: Volatile<number>;
}
/** The schema the Loader resolves this entry's `config` with. */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    enabled: z<boolean, boolean, "volatile-defined">;
    thresholdPercent: z<number, number, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    enabled: z<boolean, boolean, "volatile-defined">;
    thresholdPercent: z<number, number, "volatile-defined">;
}>>, "plain">;
/**
 * Read the switch and the share in force right now.
 * @param config - the Config `apply` received; the Loader updates its references in place.
 * @returns the current values.
 */
export declare function readAutoCompact(config: Config): AutoCompactSettings;
//# sourceMappingURL=config.d.ts.map