/**
 * Browser half: one row in Settings → General.
 *
 * **No new navigation entry.** The General page of the harness's settings
 * shell already stacks one row per preference, contributed by whichever
 * plugin owns it, into `settings.general.item`. This row goes there, and only
 * while the Host's settings service serves this plugin's entry
 * (`ctx.configForms.whileServed`): an entry that failed to mount, was turned
 * off, or runs where nothing serves settings leaves no empty row behind. A
 * build without a General page never declares the slot, `ctx.slots.inject`
 * never fires, and this plugin puts nothing on screen.
 *
 * Everything here reads and writes one entry through `ctx.configForms`. This
 * half makes no call of its own, holds no copy of the policy, and never talks
 * to its own host half: the two meet at the profile entry.
 *
 * @module @haoran/dsh-auto-compact/client
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type AutoCompactKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-auto-compact` copy. */
        autoCompact: AutoCompactKey;
    }
}
export { AutoCompactCard } from './AutoCompactCard.tsx';
export type { AutoCompactCardProps } from './AutoCompactCard.tsx';
export { AutoCompactCardController, snapThresholdPercent } from './card-controller.ts';
export type { AutoCompactCardFace, AutoCompactCardState } from './card-controller.ts';
export { en, fill, NS, zh } from './locales.ts';
export type { AutoCompactKey } from './locales.ts';
export { insertStyles, STYLE_TAG } from './styles.ts';
/** Where the row sits among the General rows: after the conversation preferences, before the version row. */
export declare const GENERAL_ROW_ORDER = 21;
/** Required browser services. */
export declare const inject: string[];
/**
 * Mount the row.
 * @param ctx - the browser plugin context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map