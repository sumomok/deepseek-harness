/**
 * Copy for the card, in the two locales the harness ships.
 *
 * The Chinese is the original and the English is its translation, which is the
 * order this product is written in. No line says "token", "window",
 * "threshold", or "compaction ratio": the person reading it is deciding how
 * full a conversation should get before it is summarised, and every one of
 * those words would ask them to learn how the model is fed first.
 *
 * The percentage line names the usage ring beside the message box on purpose.
 * That ring is the one figure a person has already watched climb, and saying
 * the two are read the same way is what makes the slider mean anything.
 *
 * It says when and how deep, because both changed and both are the person's to
 * know. The compaction is not a thing that happens to a reply in progress, and
 * a line that left the timing out would leave someone wondering why an answer
 * stopped halfway. It keeps the last message and summarises the rest, which at
 * the slider's low end is most of the conversation — a person setting 20% is
 * entitled to read that before they drag it there, and the two repository
 * READMEs are not where they will. "Sometimes a few more" is not hedging: the
 * range walks back to a balanced tool boundary, so the exact number is a
 * property of the conversation and promising one message would be a promise
 * the engine does not make.
 *
 * One name for one thing: the card's title, this line and `hintOff` all say
 * compact, never a second word for the same act.
 *
 * @module @haoran/dsh-auto-compact/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "autoCompact";
/** Chinese copy (the dictionary that defines the key domain). */
export declare const zh: {
    title: string;
    switchAria: string;
    hint: string;
    hintOff: string;
    thresholdLabel: string;
    thresholdValue: string;
    readOnly: string;
    failed: string;
};
/** English copy. */
export declare const en: Record<AutoCompactKey, string>;
/** Dictionary key domain. */
export type AutoCompactKey = keyof typeof zh;
/**
 * Substitute `{name}` placeholders in one line of copy.
 * @param text - the dictionary line.
 * @param values - the values to put in, by placeholder name.
 * @returns the filled line; a placeholder with no value is left as written.
 */
export declare function fill(text: string, values: Record<string, string>): string;
//# sourceMappingURL=locales.d.ts.map