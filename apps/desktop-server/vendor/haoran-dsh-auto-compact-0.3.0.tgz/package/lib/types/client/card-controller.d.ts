/**
 * What the card renders from, and the two writes it makes.
 *
 * The slider is the reason this is a controller rather than component state. A
 * range input reports every position it passes through, and writing each one
 * would put a document commit on every frame of a drag. So a moving slider
 * stages a draft here and nothing leaves the page; the release is the write.
 * The draft is dropped only once the Host has settled the write, because
 * dropping it earlier would show the old figure for as long as the round trip
 * takes.
 *
 * A write the Host refuses resolves `false` and the form reloads the Host's own
 * state; a write that never reached the Host rejects. Either way this
 * controller drops its draft and says so, rather than keeping a figure the
 * profile does not have. The form belongs to `ctx.configForms`, which releases
 * it; this controller only unsubscribes.
 *
 * @module @haoran/dsh-auto-compact/client/card-controller
 */
import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import { type AutoCompactSettings } from '../section.ts';
/** What the card draws. */
export interface AutoCompactCardState {
    /** Whether the Host's form for this entry has loaded; the row renders nothing before. */
    available: boolean;
    /** Whether the profile accepts writes. */
    writable: boolean;
    /** The switch position. */
    enabled: boolean;
    /** The share to draw, which is the staged draft while one is being dragged. */
    thresholdPercent: number;
    /** Whether the last write did not take. */
    failed: boolean;
}
/** The registration-side face the card's slot entry injects. */
export interface AutoCompactCardFace {
    hooks: {
        /** Card snapshot, bound by the renderer as useAutoCompactCard. */
        autoCompactCard: HostObservable<AutoCompactCardState>;
    };
    /** Write the switch. */
    setEnabled: (next: boolean) => void;
    /** Stage a slider position without writing it. */
    previewPercent: (next: number) => void;
    /** Write the position the slider was released on. */
    commitPercent: (next: number) => void;
}
/**
 * Put one share on the nearest slider position inside the offered range.
 * @param value - the share a control reported.
 * @returns the share the slider can actually stand on.
 */
export declare function snapThresholdPercent(value: number): number;
/** Derives the row's state from this entry's settings form and writes its two fields. */
export declare class AutoCompactCardController {
    private readonly form;
    private readonly listeners;
    private readonly unsubscribe;
    private draft;
    private failed;
    private disposed;
    private state;
    /**
     * @param form - this entry's settings form; its snapshot is the only read
     * and its `set` the only write.
     */
    constructor(form: ConfigForm<AutoCompactSettings>);
    /** Stop deriving and stop publishing. */
    dispose(): void;
    /**
     * Build the face the card's slot registration injects.
     * @returns the card's snapshot source and its two writes.
     */
    inject(): AutoCompactCardFace;
    /** Stage a slider position; nothing is written and nothing leaves the page. */
    private preview;
    /** Write the released position, unless it is the one the document already holds. */
    private commit;
    /** Write one field, then drop the draft the write was made from. */
    private write;
    private subscribe;
    private derive;
    /**
     * Republish, keeping the snapshot reference while nothing this card shows
     * has moved.
     */
    private publish;
}
//# sourceMappingURL=card-controller.d.ts.map