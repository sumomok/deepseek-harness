/**
 * The card's stylesheet, injected once as a tagged `<style>`.
 *
 * Every colour is a harness theme variable rather than a literal, so the row
 * follows the light and dark schemes the shell already switches between. The
 * row is laid out like the harness's own General rows — no frame of its own, a
 * vertical padding and a hairline separator underneath — because the General
 * column stacks feature-owned rows and removes the last row's separator itself.
 *
 * The switch is a real checkbox with the box moved off-screen rather than
 * hidden: `display:none` would take it out of the tab order and out of reach of
 * a screen reader, and the track beside it is decoration that the label
 * forwards clicks to.
 *
 * @module @haoran/dsh-auto-compact/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-auto-compact";
/**
 * Put the stylesheet in the document, once.
 * @returns a disposer removing the tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map