/**
 * When the compaction actually happens: after a turn the user let finish, and
 * never inside one.
 *
 * The harness's own automatic path runs `agent/pre-step`, so a conversation
 * over the threshold compacts between the steps of a turn the user is watching
 * — and a compaction that fails there is only warned about and retried at the
 * very next step, with nothing carried across steps to slow it down. A
 * summarizer that is down therefore produces one failed attempt per step for
 * as long as the turn runs.
 *
 * This module moves the decision to the driver's own exit: the agent has just
 * gone from running to idle. The conversation is settled, the turn is closed,
 * the user is not waiting on a step, and there is one attempt per exit — the
 * next reading happens after the next one, so a failure waits for new work
 * instead of repeating immediately.
 *
 * Two situations are deliberately not acted on, and one signal identifies both:
 * **a turn the user stopped and a conversation being closed** close with
 * `turn/end` carrying `reason.kind === 'aborted'` and then publish an idle
 * status. Pressing Stop must not be followed by an unrequested compaction the
 * composer offers no way to stop (the maintenance phase reports itself as
 * `idle`, so the Stop control is already gone by then); and disposal is
 * `cancel({kind:'disposed'})` followed by `whenIdle()`, which would then wait
 * on a summarization started after the cancellation.
 *
 * **A delegated agent is also skipped, and its cost is real.** A delegated run
 * reaches its idle transition in one of two ways, and neither is worth a
 * summary. A foreground run — `run_in_background: false` — is awaited by the
 * parent's tool call, which settles on `await child.whenIdle()`; a compaction
 * started from that transition claims the maintenance phase synchronously, so
 * the parent's tool call waits out the whole summarization in the middle of
 * the reply being written, and the child is disposed straight after with the
 * summary unread (measured 3ms against 803/804/804ms over three runs, with an
 * 800ms stand-in summarizer). A background run — the shipped default, since
 * both in-process delegation tools are configured `backgroundMode:
 * continuable` and `run_in_background` then defaults to true — blocks nobody,
 * but its result still surfaces only once the summary finishes, later messages
 * to that child queue behind it, and a child never messaged again keeps a
 * summary no one reads. The seat has no agent parameter, so `isEnabled():
 * false` closes the harness's between-steps path for delegated agents too and
 * nothing replaces it: either way a delegated conversation has the harness's
 * overflow recovery and nothing else. That is the accepted cost, stated in
 * both READMEs and the release notes.
 *
 * The reading starts from the same fields the usage ring divides —
 * `projectedTokens`, then `pressureTokens`, over the routed `contextWindow` of
 * the `contextPressure` projection — and departs from the ring in two places.
 * Where the token meter is reachable, a measurement that is not anchored on
 * provider usage takes its `totalTokens` instead — the engine's own numerator
 * for that state, and the only reading that prices a routed adapter's images.
 * And where the projection has a window but neither numerator yet, the meter's
 * `totalTokens` is the last fallback; the ring shows nothing in that state.
 *
 * @module @haoran/dsh-auto-compact/idle-compaction
 */
import type { Context } from '@deepseek-ai/cordis';
import type { TokenMeasurement } from '@deepseek-ai/dsh-token-meter';
import type { ContextPressureProjection } from '@deepseek-ai/dsh-token-meter/client';
import type { AutoCompactSettings } from './section.ts';
/** What this module gives the policy seat: whether it is covering any agent. */
export interface IdleCompaction {
    /**
     * Whether a compaction engine has been reached for at least one agent.
     * @returns true once this module has resolved an engine it can compact with.
     */
    covers(): boolean;
}
/**
 * The share of the window the next request would occupy.
 *
 * Read from the fields the usage ring beside the message box divides whenever
 * the measurement is anchored on provider usage: `projectedTokens` is that last
 * prompt-side sample carried forward by the surface's movement since, and
 * `pressureTokens` is the sample alone, which is what the projection publishes
 * before any movement has been folded.
 *
 * A measurement that is NOT usage-anchored takes the meter's own
 * `totalTokens`, which is what the engine's `occupancyTokens` takes in that
 * state and for the same reason: the projection prices everything after its
 * last sample with the route-independent heuristic, so it cannot see a routed
 * adapter's declared image pricing for history no provider has billed. Without
 * a reachable meter that branch has no reading and nothing triggers, which is
 * what the ring renders there too.
 *
 * One fallback the ring does not have: a projection with a window and neither
 * numerator yet reads the meter's `totalTokens`, where the ring shows nothing.
 *
 * The denominator is always the projection's recorded route capacity.
 * @param pressure - the session's published `contextPressure` value.
 * @param measurement - the token meter's measurement of the same session, when one is reachable.
 * @returns the occupied share of the window, or null while it is unknown.
 */
export declare function occupiedShare(pressure: ContextPressureProjection | undefined, measurement: TokenMeasurement | undefined): number | null;
/**
 * Compact once a driver exits, when the conversation is full enough.
 *
 * Only the running-to-idle transition acts, and only when the turn it closes
 * was not aborted. The previous status is tracked rather than inferred from the
 * event, because "the conversation just produced something" is this plugin's
 * own rule: an agent observed idle without having been seen running — a session
 * opened, this plugin loaded mid-life — has produced nothing to compact.
 *
 * One attempt per exit, one attempt at a time per agent. A run that leaves the
 * conversation still above the share does not try again here: the next exit is
 * the next decision point. Failures are logged and dropped; the harness's own
 * compaction records already carry them into the conversation.
 *
 * @param ctx - a context with `sessionProjections` composed; its unload removes the listeners.
 * @param section - thunk returning the switch and the share in force right now.
 * @returns the coverage question the policy seat answers from.
 */
export declare function installIdleCompaction(ctx: Context, section: () => AutoCompactSettings): IdleCompaction;
//# sourceMappingURL=idle-compaction.d.ts.map