/**
 * What one person's automatic-compaction choice is, and the range it lives in.
 *
 * This module is the one home for those facts and imports nothing, because
 * both halves need them: the host half validates the entry's Config over the
 * range, and the browser half edits the same entry and draws the slider over
 * the same range. A client bundle may not reach the host half (it would pull
 * the schema library into the page), so the shared facts live below both.
 *
 * The three bounds are not configuration. They are the shape of the control —
 * below the floor compaction would fire on a conversation that has barely
 * started, and above the ceiling it would fire too late to leave room for the
 * step it is making room for. What a deployment does choose is the pair of
 * values this range is entered at, which are this plugin's `Config` fields.
 *
 * @module @haoran/dsh-auto-compact/section
 */
/**
 * This plugin's profile entry id. Three things must equal it: the `id` of the
 * bundle row in `cordis.patch.yml`, the entry the browser half's settings form
 * edits, and the section name rc.33 and earlier wrote into `settings.yaml`,
 * which the harness's one-time import uses as the entry id.
 */
export declare const AUTO_COMPACT_ENTRY_ID = "auto-compact";
/** One person's automatic-compaction choice. */
export interface AutoCompactSettings {
    /** Whether compaction runs on context pressure at all. */
    enabled: boolean;
    /** Share of the context window, in percent, that triggers it. */
    thresholdPercent: number;
}
/** Lowest share the slider offers. */
export declare const THRESHOLD_MIN_PERCENT = 20;
/** Highest share the slider offers. */
export declare const THRESHOLD_MAX_PERCENT = 95;
/** Distance between two slider positions; the slider's rounding only, not a limit on the stored value. */
export declare const THRESHOLD_STEP_PERCENT = 5;
/** Default for the switch, which the Config schema applies while the entry stores none. */
export declare const DEFAULT_ENABLED = true;
/** Default for the share, which the Config schema applies while the entry stores none. */
export declare const DEFAULT_THRESHOLD_PERCENT = 60;
//# sourceMappingURL=section.d.ts.map