# @haoran/dsh-auto-compact

English | [中文](README.zh.md)

Compact the conversation before it runs out of room, at a point you choose. A row appears in Settings under **General** with a switch and a slider: turn it on, drag it to the share of the context window you want, and whenever a reply finishes with the conversation that full, it is condensed before you send the next one.

## What you set, and what it does

| Control | Range | What it means |
| --- | --- | --- |
| The switch | on / off | Whether the conversation is condensed on its own at all |
| The slider | 20%–95%, in steps of 5 | The share of the context window that, once a turn ends above it, condenses the conversation. Steps of 5 are the slider's; the entry accepts any whole number from 20 to 95 |

The percentage is read the same way as the usage ring beside the message box. That ring is the one figure you have already watched climb, and the slider is where you say how far you are willing to let it climb.

One value, for everything. There is no per-conversation override and no per-model one: it is a preference about how you like to work, not a property of any one conversation.

**Turning the switch off does not turn off compaction.** It turns off compacting *early*. When a conversation will not fit at all, the harness still recovers on its own — that is its floor, and this plugin can neither raise nor lower it. What the switch decides is whether anything happens before that point.

## When it happens

After a reply finishes, and never inside one. *This plugin's* compaction, that is — the harness's own overflow recovery still runs mid-reply when a request will not fit at all, and nothing here can move that.

The harness's own automatic compaction runs between the steps of a turn, and this plugin switches that off. Two things are wrong with the earlier moment. A reply you are watching stops while its history is summarised. And a summarisation that fails there is simply logged, with the very next step trying again — nothing is carried between the attempts — so a summarising model that is down produces one failed attempt per step for as long as the turn runs.

The moment the driver goes idle has neither problem. Nothing is in flight, so nothing is interrupted; and there is one attempt, because the next reading is not taken until the next time it goes idle. A run that fails, or that leaves the conversation still above your share, waits rather than trying again immediately.

Strictly it is once per *driver exit*, not once per turn: several messages queued while a reply runs are drained as consecutive turns inside one running stretch, and they share one compaction at the end of it.

Two situations are deliberately skipped, and one signal identifies both: **a reply you stopped**, and a conversation being closed, which is a stop followed by a wait for quiet. Being answered with an unrequested full-conversation summary is not what Stop means — and while that summary runs the composer shows no Stop button, since the session reports itself as idle throughout.

**A sub-conversation a task delegated is skipped too, and that costs something.** There are two ways such a sub-conversation goes quiet, and a compaction is worth having in neither. When the task is waiting for it — delegation the model asked to run in the foreground — the task waits out the entire summary before it can report back, in the middle of the reply you are reading: 3ms against 803/804/804ms over three runs, measured against a real agent with an 800ms stand-in. The sub-conversation is then closed with that summary unread. When the task is not waiting — the usual case, because delegated work runs in the background unless the model asks otherwise — nothing is held up, but the sub-conversation's answer still arrives only after the summary, anything sent to it afterwards queues behind, and one that is never spoken to again keeps a summary no one reads.

So sub-conversations are left alone, **and nothing else compacts them either**: the policy this plugin publishes takes no conversation, so switching the harness's between-steps path off switched it off for them as well. A sub-conversation therefore has the harness's overflow recovery and nothing before it. That is the accepted trade — a long delegated task can reach the window's edge and be rescued there rather than kept clear of it.

**Nothing shows on screen while it runs.** The session reports itself as idle, so there is no progress row and no way to interrupt; a message sent during it is held and sent when the summary lands, and it does not appear in the transcript until then. A full-conversation summary can take tens of seconds.

## What it condenses

Everything it safely can. The compaction is the same operation the `/compact` command performs: the last message is kept word for word — sometimes a few more, because the range walks back to a boundary where every tool call still has its result — and everything before it becomes one summary. The harness's between-steps compaction kept a longer tail, sized by the compaction backend's own `retainRatio` and `retainTokens`, because it was making room for a request that was about to go out. This one is not, so it takes the whole reduction at once and the next reply starts from the summary.

## What you give up by not compacting mid-reply

One long reply can outgrow the context window on its own — a chain of tool calls, each returning a large result. The harness's between-steps path existed for that, and this plugin closes it. What is left for that case is overflow recovery: the provider refuses the request, the harness compacts and retries, and by default it does that **once** before the failure reaches you (`maxOverflowRetries`, default 1, raised per deployment in the compaction backend's own config). A deployment that expects very long tool-heavy replies should raise it.

## What it is not

It does not measure the context window and it does not write the summary. The reading comes from the projection the usage ring reads, and the compaction is the harness's own, performed through its published seam. What this plugin owns is the switch, the percentage, and the moment.

The reading has a second source for one case the ring cannot show. A conversation no provider has billed yet — image-heavy history above all — publishes no usage figure, so the ring reads nothing and, on that alone, nothing would ever be compacted. Where the token meter is reachable, that state falls back to the meter's own total, which is the number the harness's own trigger used there and the only one that prices a routed model's images.

It does not report a compaction that went wrong, either: a failed compaction is shown by the failure card in the chat (host builds from rc.33 on), because the harness records the failure itself and the conversation view already renders it.

## Where it works, and where it does nothing

The row takes `settings.general.item`, the seat the Settings **General** page stacks one preference per row in, at order 21: after the conversation preferences, before the version row. It is registered only while the Host's settings service serves this plugin's entry (`ctx.configForms.whileServed`), so an entry that failed to mount, was turned off, or runs where nothing serves settings leaves no empty row. A build whose settings page has no General page never declares the slot, and then this plugin registers no interface at all. Nothing is version-checked: the declaration is the detection.

The host half reads its own volatile Config on every use. It tells the settings service it draws its own row (`configure({ auto: false })`), so no generated page duplicates it; without a settings service it simply answers the profile's own values and nothing in the page can change them.

**The engine is found per conversation, not once at load.** A preset publishes `compaction` behind an `isolate` realm, which is invisible to the host plane this plugin is mounted on — the shipped desktop profile disables the compaction backend on the host and mounts it inside every preset. So the engine is resolved through `agentPresets.serviceFor(agent, 'compaction')` when a conversation opens, falling back to a plain host-plane read for a composition that mounts it there. Where neither answers, this plugin says so in the host log once for that conversation and compacts nothing in it.

The policy itself is coarser than that, and deliberately: it takes no conversation, so it reports one answer for the whole process. It keeps reporting the harness's own behaviour until an engine is reached for *some* conversation, and reports `false` from then on. So a composition where every conversation has an engine is fully covered, and a conversation that has none inside a composition that mostly does gets neither path — the host log line is the only notice, and there is no engine there to have compacted it anyway.

## The service it publishes

Under the Cordis service key `compactionPolicy`:

| Method | Answer |
| --- | --- |
| `isEnabled()` | `false` once this plugin has found an engine to compact with for some conversation; `true` — the harness's own behaviour — while it has found none |
| `thresholdRatio()` | The share of the context window, 0–1, this plugin triggers at, read live from the entry's Config |

The switch in Settings is *not* what `isEnabled()` returns. It decides whether this plugin's compaction runs, and it is read there. `isEnabled()` answers one question only: whether the harness should stop compacting between steps because something else now will. The two are coupled on purpose — a `false` returned before any engine was found would be a composition that never compacts at all.

No shipped backend reads `thresholdRatio()` while `isEnabled()` answers false — the one path that consulted it is the one being switched off — and it stays because it is half of a published key another backend may read.

## Profile entry and the one-time import

The entry id is `auto-compact`, and both fields are volatile: the settings service edits them in place, writes the changed fields into the profile's own `cordis.patch.yml`, and the Loader hands the new value to the running plugin without a remount.

| Field | Type | Default |
| --- | --- | --- |
| `enabled` | boolean | `true` |
| `thresholdPercent` | whole number, 20–95 | `60` |

A value outside those bounds is refused at the save that produced it, and the value in force stays. The first launch on a `0.1.7` base imports the `auto-compact` section that versions up to 0.2.4 wrote into `$DSH_HOME/settings.yaml` into this entry once — the entry id is that section name — and renames the file to `settings.yaml.imported`. From then on, a field that was imported or saved is fixed in the profile for that person, and a new default shipped in this package reaches only people who never changed that field.

## Configuration

The bundle row carries no `config`: both defaults live in the plugin's schema, so a save writes only the fields a person actually changed. A profile that wants different starting values writes them on its own id-targeted row:

```yaml
- id: auto-compact
  config:
    enabled: true
    thresholdPercent: 60
```

## Compatibility

Built against the `0.1.7-rc.2` harness base; every `@deepseek-ai/dsh-*` peer range is `>=0.1.7-rc.1 <0.2.0-0`, which the harness's plugin compatibility check admits on `0.1.7-rc.x`, `0.1.7`, and later `0.1.x` releases. It needs the settings layer of that base (`ctx.configForms`, volatile Config fields) and reads the preset roster through `@deepseek-ai/dsh-agent-preset-registry`, which replaced `@deepseek-ai/dsh-agent-presets`.

## Install

```sh
dsh plugin --profile <name> add <path-or-tarball>
```
