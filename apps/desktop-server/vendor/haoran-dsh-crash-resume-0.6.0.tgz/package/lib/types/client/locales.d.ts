/**
 * Copy for the browser half, in the two locales the harness ships.
 *
 * The `held.reason.*` lines state facts only, so they still read true once
 * the session has moved on and the held row shows no button. Every `held.*`
 * and `retry.*` string sits inside one line of the chat and ends without a
 * full stop.
 *
 * The `retry.*` strings are the Retry button under the chat's row of a turn
 * that ended in an error, its disabled-state hint, and the alert after it.
 * `retried.*` title and explain the row of the message the button sends.
 *
 * The `interrupted.*` strings label the header of a turn the app's exit cut
 * short, whether its end was lost and written as `interrupted` at the next
 * launch or logged by the host's disposal as `aborted` with cause
 * `disposed`. `interrupted.worked` stands in for the chat's 「已停止」 /
 * "Stopped" and 「已完成」 / "Completed". `interrupted.took` is a prefix: a
 * chat before 0.2.1-alpha.3 appends the turn's duration after it, so it
 * keeps its trailing space, as the chat's own 「已完成，用时 」 /
 * "Completed in " does.
 *
 * @module @haoran/dsh-crash-resume/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "crash-resume";
/** Every key the browser half looks up. */
export type CrashResumeKey = 'held.title' | 'held.reason.awaiting-approval' | 'held.reason.awaiting-answer' | 'held.reason.already-resumed' | 'held.reason.goal-active' | 'held.reason.stopped' | 'held.continue' | 'held.continuing' | 'held.refused.moved-on' | 'held.refused.unopened' | 'held.refused.archived' | 'held.refused.failed' | 'resumed.title' | 'resumed.explanation' | 'resumed.title.person' | 'resumed.explanation.person' | 'retry.button' | 'retry.retrying' | 'retry.busy' | 'retry.refused.moved-on' | 'retry.refused.unopened' | 'retry.refused.archived' | 'retry.refused.failed' | 'retried.title' | 'retried.explanation' | 'interrupted.took' | 'interrupted.worked';
/** Chinese copy. */
export declare const zh: Record<CrashResumeKey, string>;
/** English copy. */
export declare const en: Record<CrashResumeKey, string>;
//# sourceMappingURL=locales.d.ts.map