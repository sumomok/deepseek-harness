/**
 * Browser half of @haoran/dsh-crash-resume: the held row with its Continue
 * button, the row of this plugin's continuation and retry messages, the
 * 「已中断」 / "Interrupted" label on the header of a turn the app's exit cut
 * short (ended `interrupted`, or `aborted` with cause `disposed`), the chat's
 * own stop row left out under a turn this plugin held or continued, a Retry
 * button under the chat's failure row of the session's last turn when that
 * turn ended in an error, and the work details of the turns the app's exit
 * cut short or that the continuation message started, opened once per
 * session scope.
 *
 * Every row is built from events the chat already folds — the held marker,
 * this plugin's `user/message`s and each turn's `turn/end` — and from the
 * session's own state, so it reads the same on every reload, in the viewer's
 * own language. Which turns to open is read from the same events: a turn's
 * `turn/end` reason and the source of the message that opened it.
 *
 * The one host path is the `crashResume` Remote this package's host half
 * provides, mounted through `ctx.remote.$mount()`; only the Continue and
 * Retry buttons call it.
 *
 * @module @haoran/dsh-crash-resume/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type HeldNodeData } from './held-definition.ts';
import { type CrashResumeKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-crash-resume` copy. */
        'crash-resume': CrashResumeKey;
    }
}
declare module '@deepseek-ai/dsh-client-ui-chat/client' {
    interface ChatNodeDataMap {
        /** A turn interrupted by a crash or a quit that was not continued automatically. */
        'crash-resume-held': HeldNodeData;
    }
}
export { CONTRIBUTION } from './contribution.ts';
export { continueAction, outcomeOf, retryAction } from './continue.ts';
export type { ContinueHeldAction, ContinueOutcome, CrashResumeRemote, Refusal, RemoteResult, RetryFailedAction } from './continue.ts';
export { closedTurn, createExpandedStore, expandedKey, useExpandOnce } from './expand-once.ts';
export type { ExpandedActions, ExpandedState, ExpandedStore, ExpandedStoreProps } from './expand-once.ts';
export { createHeldCard } from './HeldCard.tsx';
export type { HeldCardDeps, HeldCardProps, HeldChatFields, HeldSessionFields } from './HeldCard.tsx';
export { HELD_NODE_KIND, heldDefinition } from './held-definition.ts';
export type { HeldChatNode, HeldNodeData } from './held-definition.ts';
export { en, NS, zh } from './locales.ts';
export type { CrashResumeKey } from './locales.ts';
export { createResumeTriggerView, isPersonTrigger, isResumeSource, isRetrySource, pickIncumbent } from './ResumeTriggerView.tsx';
export type { ResumeTriggerDeps, TriggerProps } from './ResumeTriggerView.tsx';
export { insertStyles, STYLE_TAG } from './styles.ts';
export { acceptsMessages, createTurnErrorView, handledByPlugin, INTERRUPTED_CODE, isFailedTurn } from './TurnErrorView.tsx';
export type { TurnErrorChatFields, TurnErrorChatNode, TurnErrorSessionFields, TurnErrorViewDeps, TurnErrorViewProps, } from './TurnErrorView.tsx';
export { createTurnProcessView, isInterruptedTurn } from './TurnProcessView.tsx';
export type { TurnProcessViewDeps, TurnProcessViewProps } from './TurnProcessView.tsx';
/** Required browser services; every `ctx.<name>` read below is listed. */
export declare const inject: string[];
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 * @returns once the Remote mount has settled, after every row is registered.
 */
export declare function apply(ctx: Context): Promise<void>;
//# sourceMappingURL=index.d.ts.map