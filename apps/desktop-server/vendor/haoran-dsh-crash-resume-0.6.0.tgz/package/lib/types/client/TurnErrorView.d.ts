/**
 * The chat's `turn-error` row: left out under a turn this plugin held or
 * continued, and given a Retry button under the last turn when that turn
 * ended in an error.
 *
 * From 0.2.1-alpha.3 the chat closes a turn the app's exit cut short with a
 * row of its own, 「任务已停止」 / "Task stopped" and the reason that the DSH
 * process exited before the turn finished. Its `turn-error` node carries the
 * code `INTERRUPTED`. Under a turn this plugin held, that row stands next to
 * the held row and says the same thing a second time; under a turn this plugin
 * continued, it reports a stop the continuation already took up.
 *
 * This view shadows the host's `turn-error` renderer at priority -1. It
 * renders nothing for an `INTERRUPTED` row whose turn this plugin handled:
 * the chat holds a held row naming that turn, or a message whose source is
 * this plugin's continuation of that turn. The continuation message is a
 * `turn-trigger` row, or a `context` row when its turn is the earliest
 * loaded one; the view matches it by source in either. Every other row,
 * including the `INTERRUPTED` row of a turn this plugin left alone, goes to
 * the host's own component, read from the slot ledger, with the props the
 * slot runtime handed this view.
 *
 * The held row and the continuation message are both logged after the
 * interrupted turn's `turn/end`, so once the chat has loaded the stop row it
 * has loaded them as well.
 *
 * A turn whose end the host's disposal logged (`aborted`, cause `disposed`)
 * gets no such row: the chat's `turn-error` Definition builds one for an
 * `aborted` end only when a sign-out cancelled the turn, so this view has
 * nothing to leave out under it.
 *
 * **Retry.** The host's row (`TurnErrorItem` in dsh-client-ui-chat) has no
 * slot for an action. Under a row whose turn ended `error`, is the session's
 * last turn, and belongs to a session the person may send messages to, the
 * view draws the host's component unchanged and one line after it: a Retry
 * text button indented past the row's status dot, so it starts under the
 * row's title, followed by a hint while the button is disabled or an alert
 * when the host refused the press. The end reason is read from the turn's
 * `turn/end` in the node's location, never from the row's code. Who may send
 * follows the composer: not a removed session, and not a subagent session
 * unless it is continuable and its parent is available. The button is
 * disabled while the session runs or holds a message not yet admitted, and
 * from a press until a later turn exists; the host checks the session again
 * on every press and is the one that decides.
 *
 * @module @haoran/dsh-crash-resume/client/TurnErrorView
 */
import { type ReactNode } from 'react';
import type { ConversationLocation } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { StoredEntry, Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { RetryFailedAction } from './continue.ts';
import type { CrashResumeKey } from './locales.ts';
/** The code the chat's `turn-error` Definition gives a turn closed after the process exited mid-turn. */
export declare const INTERRUPTED_CODE = "INTERRUPTED";
/** One chat node as this view reads it: its kind and its payload. */
export interface TurnErrorChatNode {
    readonly kind: string;
    readonly data?: unknown;
}
/** The chat snapshot fields this view reads. */
export interface TurnErrorChatFields {
    /** Every node the chat has built for the loaded history. */
    readonly nodes: {
        values(): readonly TurnErrorChatNode[];
    };
    /** The turn numbers the chat has seen, in log order. */
    readonly timeline: {
        readonly turnOrder: readonly number[];
    };
}
/** The session snapshot fields this view reads. */
export interface TurnErrorSessionFields {
    /** Whether the session's agent is running. */
    readonly running: boolean;
    /** Messages sent from this page that the host has not admitted yet. */
    readonly pendingSubmissions: readonly unknown[];
    /** Whether the session was removed. */
    readonly removed: boolean;
    /** The session's subagent address and parent availability; null for a top-level session. */
    readonly subagent: {
        readonly address: {
            readonly mode: string;
        };
        readonly parentAvailable?: boolean | undefined;
    } | null;
}
/** The props a keyed `turn-error` entry receives; only the parts this view reads are named. */
export interface TurnErrorViewProps {
    readonly node: {
        readonly location?: ConversationLocation;
        readonly data: {
            readonly turn: number;
            readonly code?: string | undefined;
        };
    };
    readonly sessionId: SessionId;
    readonly useChat: <S>(selector: (chat: TurnErrorChatFields) => S) => S;
    readonly useSession: <S>(selector: (session: TurnErrorSessionFields) => S) => S;
}
/** What the view needs from the plugin context, resolved per render. */
export interface TurnErrorViewDeps {
    /** Live ledger of `conversation.chat.node` entries. */
    readonly entries: () => readonly StoredEntry[];
    /** The Retry action. */
    readonly retryFailed: RetryFailedAction;
    /** Translate bound to this plugin's namespace. */
    readonly t: () => Translate<CrashResumeKey>;
}
/**
 * Whether this plugin held or continued a turn.
 * @param nodes - the chat's nodes.
 * @param turn - the interrupted turn.
 * @returns true when a held row names the turn, or a message carries this plugin's continuation source for it.
 */
export declare function handledByPlugin(nodes: readonly TurnErrorChatNode[], turn: number): boolean;
/**
 * Whether a node belongs to a turn that ended in an error.
 * @param node - a chat node; only its location is read.
 * @returns true when the node's turn is closed with end reason `error`.
 */
export declare function isFailedTurn(node: {
    readonly location?: ConversationLocation;
} | undefined): boolean;
/**
 * Whether the person may send the session a message, as the composer decides
 * from the session snapshot: a removed session takes none, and a subagent
 * session takes one only when it is continuable and its parent is available.
 * @param session - the session snapshot fields.
 * @returns true when a message may be sent.
 */
export declare function acceptsMessages(session: TurnErrorSessionFields): boolean;
/**
 * Build the shadowing renderer for the `turn-error` cell.
 * @param deps - ledger access, the Retry action, and this plugin's translator.
 * @returns the component to register at `priority: -1` with locale `chat`.
 */
export declare function createTurnErrorView(deps: TurnErrorViewDeps): (props: TurnErrorViewProps) => ReactNode;
//# sourceMappingURL=TurnErrorView.d.ts.map