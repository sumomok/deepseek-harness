/**
 * The `crashResume` Typert Remote: the host side of the held row's Continue
 * button and of the failed row's Retry button.
 *
 * The browser reaches it only through the harness's `/api` gateway, which
 * dispatches by the strict descriptors in `./typert.ts`: the descriptors name
 * the methods, so the class carries no `@Remote` decorator. It has no
 * decorator and no parameter property because the crash specs load
 * `src/index.ts` under plain Node, whose type stripping rejects both.
 *
 * @module @haoran/dsh-crash-resume/service
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { ContinueHeldResult } from './shared.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /**
         * The held row's Continue action and the failed row's Retry action
         * (provided by `@haoran/dsh-crash-resume` once its startup pass has
         * finished; absent before).
         */
        crashResume: CrashResumeService;
    }
}
/**
 * Continue one held turn at a person's request.
 * @param sessionId - the session the held row belongs to.
 * @param interruptedTurn - the turn the row's marker names.
 * @returns what happened.
 */
export type ContinueHeld = (sessionId: string, interruptedTurn: number) => Promise<ContinueHeldResult>;
/**
 * Retry one failed turn at a person's request.
 * @param sessionId - the session the failed row belongs to.
 * @param failedTurn - the turn whose end recorded the failure.
 * @returns what happened.
 */
export type RetryFailed = (sessionId: string, failedTurn: number) => Promise<ContinueHeldResult>;
/** The host actions the Remote methods delegate to. */
export interface CrashResumeActions {
    readonly continueHeld: ContinueHeld;
    readonly retryFailed: RetryFailed;
}
/** The `crashResume` service and Remote namespace. */
export declare class CrashResumeService extends TypertRemoteService {
    private readonly actions;
    /**
     * Register the service under `crashResume` and bind the same key as its
     * Remote namespace.
     * @param ctx - owning plugin context; the service is withdrawn with it.
     * @param actions - the host actions the Remote methods delegate to.
     */
    constructor(ctx: Context, actions: CrashResumeActions);
    /**
     * Continue the interrupted turn a held row names, by sending the
     * continuation message, when the session is still exactly where the
     * interruption left it: idle, nothing queued, and its log ending with the
     * end of that turn, written as `interrupted` when the session was opened
     * or logged as `aborted` by the host's disposal.
     * @param sessionId - the session the held row belongs to.
     * @param interruptedTurn - the turn the row's marker names.
     * @returns `sent`, or why nothing was sent.
     */
    continueHeld(sessionId: string, interruptedTurn: number): Promise<ContinueHeldResult>;
    /**
     * Retry a failed turn, by sending the retry message, when the session is
     * still exactly where the failure left it: idle, nothing queued, and its
     * log ending with that turn's end, recorded as `error`.
     * @param sessionId - the session the failed row belongs to.
     * @param failedTurn - the turn whose end recorded the failure.
     * @returns `sent`, or why nothing was sent.
     */
    retryFailed(sessionId: string, failedTurn: number): Promise<ContinueHeldResult>;
}
//# sourceMappingURL=service.d.ts.map