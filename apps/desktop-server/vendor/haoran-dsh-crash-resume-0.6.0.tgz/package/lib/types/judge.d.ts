/**
 * The decision this plugin makes for one session at startup, as a pure
 * function over the session's raw stored log (no synthetic closers applied).
 *
 * The log is a durable boundary: other builds and other plugins wrote it, so
 * every field this module reads is checked at runtime rather than trusted
 * from the event type.
 *
 * @module @haoran/dsh-crash-resume/judge
 */
import { type HeldReason } from './shared.ts';
/** The event fields the decision reads; a stored `SessionEvent` satisfies it. */
export interface JudgedEvent {
    readonly type: string;
    readonly data: unknown;
}
/** Session facts outside the event list. */
export interface JudgedSession {
    /** `header.origin` of the stored session. */
    readonly origin?: string | undefined;
    /** Whether the session is archived in the workspace registry. */
    readonly archived: boolean;
    /**
     * Whether the only in-flight registry that listed the session is this
     * process's own, written by an earlier load of the plugin in this process.
     * A host disposal that ended the session's last turn was then a reload
     * inside a process that kept running, not the exit of the process.
     */
    readonly listedByThisProcess: boolean;
}
/** Inputs that come from this launch rather than from the session. */
export interface JudgeOptions {
    /** Tool names that wait for the user's answer while their call is open. */
    readonly awaitUserTools: readonly string[];
    /** Whether the previous run was stopped on purpose (the sentinel was present). */
    readonly stopped: boolean;
}
/** Why a session is left exactly as it is: no continuation and no marker. */
export type SkipReason = 'balanced' | 'subagent' | 'archived' | 'not-human';
/** The outcome for one session. */
export type Verdict = {
    readonly kind: 'skip';
    readonly reason: SkipReason;
} | {
    readonly kind: 'hold';
    readonly turn: number;
    readonly reason: HeldReason;
} | {
    readonly kind: 'resume';
    readonly turn: number;
};
/**
 * Decide what to do with one stored session whose writer may have crashed
 * or been stopped.
 *
 * The decision is about the log's cut-short turn, from its `turn/start` to
 * the end of the log. That is the open turn when the log stops inside one: a
 * crash, a force-kill, or a shutdown whose closing events did not reach
 * storage. Otherwise it is the last turn when that turn ended `aborted` with
 * cancellation cause `disposed`, its `turn/end` names that turn, and no turn
 * started after it: the host's disposal cancelled the turn and logged its
 * end. It is not cut short when `session.listedByThisProcess` says that
 * disposal was an agent-loop reload inside this running process, or when a
 * held marker naming that turn follows its `turn/end`, because a startup
 * has already held it. A turn a person stopped (cause `user`), a parent
 * agent cancelled (`parent`), or a hook ended (`hook`) is never cut short.
 *
 * Rules, in order:
 * 1. A log without a cut-short turn needs nothing (`balanced`); that
 *    includes a last turn that already carries this plugin's held marker.
 * 2. Subagent sessions belong to their parent's routing and archived
 *    sessions run no model step; both are left alone.
 * 3. The turn is a continuation when it carries this plugin's own message,
 *    whether it was sent automatically or a person asked for it with the
 *    held row's button. It is held (`already-resumed`): continuing it again
 *    without asking could repeat the crash. A turn with no `user/message`
 *    at all that follows a turn closed as `interrupted` or by the host's
 *    disposal is held the same way, because `turn/start` is logged before
 *    the turn's message and such a turn may be this plugin's continuation
 *    that died in between. It may also be a scheduled turn that died at the
 *    same point; holding costs that one a row and never runs anything.
 * 4. A turn whose messages are all from something other than a person (a
 *    goal round, a schedule, a job notice) is left alone.
 * 5. A turn waiting on a person is held: an approval asked and never
 *    answered (`awaiting-approval`), or a listed question tool never
 *    answered (`awaiting-answer`). A wait a cancellation ended counts as
 *    unanswered: the approval's recorded outcome is `cancelled`, and the
 *    question tool's result records an `AbortError`. Continuing it would
 *    turn the wait into a refusal or an unanswerable question.
 * 6. A session with an active goal is held (`goal-active`). The goal service
 *    disarms every goal when an agent is created for the session, so no
 *    driver continues it after a restart until a person resumes it; an
 *    automatic continuation would work toward that goal without that consent.
 * 7. A turn cut short by a deliberate stop is held (`stopped`).
 * 8. Anything else is continued once.
 * @param events - the complete stored log, without synthetic closers.
 * @param session - header, workspace and registry facts for the same session.
 * @param options - this launch's tool list and quit flag.
 * @returns the verdict.
 */
export declare function judge(events: readonly JudgedEvent[], session: JudgedSession, options: JudgeOptions): Verdict;
//# sourceMappingURL=judge.d.ts.map