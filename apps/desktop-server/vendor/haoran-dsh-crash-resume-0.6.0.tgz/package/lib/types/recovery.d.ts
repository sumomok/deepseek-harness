/**
 * The two startup steps: the pass that runs inside `apply`, before the
 * gateway admits any client, and the continuation that runs once the
 * application reports it is ready. Also the retry a person asks for with a
 * failed turn's Retry button, which goes through the same final checks as a
 * continuation.
 *
 * @module @haoran/dsh-crash-resume/recovery
 */
import type { Context } from '@deepseek-ai/cordis';
import { type LlmFailure } from '@deepseek-ai/dsh-llm';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { ResolvedConfig } from './config.ts';
import { type Verdict } from './judge.ts';
import { PERSON_TRIGGER, type ContinueHeldResult } from './shared.ts';
/** A session the startup pass decided to continue, with the turn it continues. */
export interface ResumeCandidate {
    readonly id: string;
    readonly turn: number;
}
/** Why a candidate could not be judged; it is left as it is. */
export interface Unreadable {
    readonly kind: 'unreadable';
    readonly detail: string;
}
/** What the startup pass did, for the caller's registry update and for tests. */
export interface StartupOutcome {
    /** Sessions to continue once the application is ready. */
    readonly resume: readonly ResumeCandidate[];
    /** Candidates that stay in the in-flight registry: sessions already live in this process. */
    readonly keep: readonly string[];
    /** Every other candidate's verdict, or why none could be reached. */
    readonly verdicts: ReadonlyMap<string, Verdict | Unreadable>;
}
/** Inputs of the startup pass that come from this launch. */
export interface StartupInputs {
    readonly candidates: readonly string[];
    /**
     * The candidates that only this process's own registry listed, written by
     * an earlier load of the plugin in this process (see `JudgedSession`).
     */
    readonly listedByThisProcess: ReadonlySet<string>;
    readonly stopped: boolean;
    readonly config: ResolvedConfig;
    /**
     * Called with a candidate's id before its log is read and with undefined
     * after; the pass awaits it. The caller records the id durably, so a
     * process that dies while reading a log (out of memory, for one) tells the
     * next startup which log to skip.
     */
    readonly examining?: (id: string | undefined) => Promise<void>;
}
/**
 * The sessions the workspace registry lists as archived, read at the time of
 * the call.
 * @param ctx - the plugin context.
 * @returns the archived session ids; empty where no workspace registry is mounted.
 */
export declare function archivedIds(ctx: Context): readonly string[];
/**
 * The startup pass. Reads each candidate's complete stored log, decides, and
 * writes the held marker where the decision is to hold. Runs inside the
 * plugin's `apply`, which the launcher awaits before it reports the
 * application ready, so no client can open a session while a write handle
 * taken here is open. A candidate whose log is missing, larger than
 * `maxLogBytes`, slower than `readTimeoutMs`, or fails to read is left as it
 * is with a warning.
 * @param ctx - the plugin context.
 * @param inputs - candidates from the in-flight registries, the stop flag, and the policy.
 * @returns what to continue, what to keep listed, and every other verdict.
 */
export declare function runStartupPass(ctx: Context, inputs: StartupInputs): Promise<StartupOutcome>;
/**
 * Whether the live log still ends with the end of `turn`, written by the
 * host when it closed the interrupted turn or logged by the host's disposal,
 * and nothing after it started a new turn. Anything else means the session
 * moved on (a person sent a message first) and must not be continued.
 * @param events - the live session's events.
 * @param turn - the interrupted turn.
 * @returns true when the session is still exactly where the interruption left it.
 */
export declare function stillInterrupted(events: readonly SessionEvent[], turn: number): boolean;
/**
 * The failure that ended `turn`, while the live log still ends with that
 * turn's end and nothing after it started a new turn. Anything else means
 * the session moved on, or the turn did not end in an error, and it must not
 * be retried.
 * @param events - the live session's events.
 * @param turn - the failed turn.
 * @returns the turn's recorded failure, or undefined.
 */
export declare function stillFailed(events: readonly SessionEvent[], turn: number): LlmFailure | undefined;
/**
 * The retry message's model-facing text. Only the failure's code enters it,
 * and only when it reads as a machine code (capital letters, digits and
 * underscores); anything else is named `UNKNOWN`. The failure's message,
 * which can carry the provider's response body, is never used.
 * @param template - the configured text; every `{code}` is replaced.
 * @param failure - the failed turn's recorded failure, read from the log.
 * @returns the text to send.
 */
export declare function retryText(template: string, failure: Pick<LlmFailure, 'code'>): string;
/**
 * What {@link continueOne} and {@link retryOne} did.
 *
 * - `sent`: the message was handed to the agent.
 * - `busy`: the agent is running or has queued input; that turn's own end
 *   settles the session.
 * - `settled`: the session is idle and moved past the named turn.
 * - `unopened`: the session could not be opened; the named turn is still
 *   where it was.
 */
export type ContinueResult = Exclude<ContinueHeldResult, 'archived'>;
/** The continuation message {@link continueOne} sends. */
export interface ContinuationMessage {
    /** The text the model reads. */
    readonly text: string;
    /** The one-line summary stored with it. */
    readonly summary: string;
    /** Present when a person asked for the continuation; the automatic one has none. */
    readonly trigger?: typeof PERSON_TRIGGER;
}
/** A session whose last turn failed, with that turn. */
export interface FailedTurn {
    readonly id: string;
    readonly turn: number;
}
/** The retry message {@link retryOne} sends; a person always asked for it. */
export interface RetryMessage {
    /** The text the model reads; every `{code}` is replaced with the failed turn's error code (see {@link retryText}). */
    readonly text: string;
    /** The one-line summary stored with it. */
    readonly summary: string;
}
/**
 * Continue one interrupted turn by sending a continuation message. The
 * message is an ordinary logged `user/message`, so the model request it
 * produces is reconstructable from the log, and its source kind is what the
 * next startup reads to refuse a second continuation, whether it was sent
 * automatically or at a person's request. It is sent only while the agent is
 * idle, its inbox is empty and {@link stillInterrupted} holds, checked again
 * after the flush and immediately before the send.
 * @param ctx - the plugin context.
 * @param candidate - the session and its interrupted turn.
 * @param message - the text, the summary, and the trigger to record.
 * @returns what happened.
 */
export declare function continueOne(ctx: Context, candidate: ResumeCandidate, message: ContinuationMessage): Promise<ContinueResult>;
/**
 * Retry one failed turn at a person's request by sending a retry message,
 * an ordinary logged `user/message` in a new turn that the session's current
 * model answers. The failed turn stays in the log as it is. The message is
 * sent only while the agent is idle, its inbox is empty and
 * {@link stillFailed} finds the log still ending with the failed turn's end,
 * checked again after the flush and immediately before the send; its text
 * names the error code read at that last check (see {@link retryText}).
 * @param ctx - the plugin context.
 * @param failed - the session and its failed turn.
 * @param message - the text and the summary.
 * @returns what happened.
 */
export declare function retryOne(ctx: Context, failed: FailedTurn, message: RetryMessage): Promise<ContinueResult>;
//# sourceMappingURL=recovery.d.ts.map