/**
 * The DeepSeek member of the adapter registry: resolves the connection facts
 * `readBalance` needs, re-reading settings, the launch environment, and the
 * credential seam on every call so a rotated key or an edited endpoint
 * reaches the next poll without a restart.
 *
 * @module @sumomok/dsh-balance/deepseek-adapter
 */
import type { Context } from '@deepseek-ai/cordis';
import { type BalanceRequest } from './balance.ts';
import type { ResolvedConfig } from './config.ts';
import { DEEPSEEK_PROVIDER_ID } from './provider-id.ts';
/**
 * Build the resolver the balance reader calls before every read.
 *
 * Connection facts are re-read per call and the key is resolved per call, both
 * on purpose: a key rotated through the Models page, or an endpoint changed in
 * settings, reaches the next poll without restarting anything.
 * @param ctx - the plugin context.
 * @param config - the resolved plugin config.
 * @returns a resolver yielding the next read's facts, or `null` while unconfigured.
 */
export declare function providerResolver(ctx: Context, config: ResolvedConfig): () => Promise<BalanceRequest | null>;
export { DEEPSEEK_PROVIDER_ID };
//# sourceMappingURL=deepseek-adapter.d.ts.map