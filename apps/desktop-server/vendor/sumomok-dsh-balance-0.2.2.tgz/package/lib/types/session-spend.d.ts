/**
 * Per-session spend as a pure fold over the session's own logged usage.
 *
 * The harness already writes what one step cost in tokens; this unit multiplies
 * it by the deployment's price table and adds it up. It appends nothing, reads
 * nothing outside the event it is handed, and performs no I/O — the projection
 * registry replays it over a session's durable log and caches the result.
 *
 * @module @sumomok/dsh-balance/session-spend
 */
import type { TokenUsage } from '@deepseek-ai/dsh-llm';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import { type PriceEntry, type TokenCounts } from './prices.ts';
import type { SessionSpend, SessionSpendModel } from './types.ts';
/** The projection key this plugin owns. */
export declare const SESSION_SPEND_KEY = "balanceSessionSpend";
/**
 * A projection unit with a client view. The registry's client-visible overload
 * requires `wire`, which {@link ProjectionDefinition} leaves optional for
 * host-only units.
 */
export type ClientVisibleProjection = Omit<ProjectionDefinition<typeof SESSION_SPEND_KEY, SessionSpendState>, 'wire'> & {
    wire: NonNullable<ProjectionDefinition<typeof SESSION_SPEND_KEY, SessionSpendState>['wire']>;
};
/** Fold state; plain JSON, as the projection cache requires. */
export interface SessionSpendState {
    /** Cost of every priced step so far. */
    total: number;
    /** Per-model token buckets and cost. */
    byModel: Record<string, SessionSpendModel>;
    /** Cost split by the price tier that applied to each step. */
    bySchedule: Record<string, number>;
    /** Tokens no entry in the table prices. */
    unpricedTokens: number;
    /** Assistant steps folded, priced or not. */
    steps: number;
}
declare module '@deepseek-ai/dsh-session-projection/types' {
    interface SessionProjectionStateMap {
        /** `@sumomok/dsh-balance` per-session spend fold state. */
        balanceSessionSpend: SessionSpendState;
    }
    interface SessionProjectionMap {
        /** `@sumomok/dsh-balance` per-session spend, priced from the deployment's table. */
        balanceSessionSpend: SessionSpend;
    }
}
/**
 * Split one step's provider accounting into disjoint billing buckets.
 *
 * `TokenUsage` counts are already disjoint on the input side — `inputTokens`
 * excludes cache traffic — but `reasoningTokens` is a subset of
 * `outputTokens`, so the generated bucket has it taken back out; a provider
 * pricing reasoning at the output rate then reaches the same total either way.
 * @param usage - the step's provider-reported accounting.
 * @returns the buckets {@link costOf} multiplies.
 */
export declare function billingBuckets(usage: TokenUsage): TokenCounts;
/** Every token in one step, priced or not. */
export declare function totalTokens(counts: TokenCounts): number;
/** What one priced step contributes. */
export interface PricedStep {
    /** Cost of the step, or `null` when the table prices no such model. */
    cost: number | null;
    /** The tier that priced it; absent when unpriced. */
    scheduleName?: string;
    /** The step's disjoint token buckets. */
    counts: TokenCounts;
}
/**
 * Price one step.
 * @param entries - the active currency's price list.
 * @param subject - the provider route and model the step ran on.
 * @param atMs - the step's logged time, in epoch milliseconds.
 * @param usage - the step's provider-reported accounting.
 * @returns the cost and tier, or an unpriced verdict.
 */
export declare function priceStep(entries: readonly PriceEntry[], subject: {
    provider?: string;
    model: string;
}, atMs: number, usage: TokenUsage): PricedStep;
/**
 * Build the projection unit for one currency's price list.
 *
 * `stateVersion` is derived from the list and its currency: a persisted fold
 * was computed at the rates that were configured then, so changing a rate — or
 * switching to another currency's list — must discard it rather than continue
 * adding to it. Editing the table in `cordis.yml`, or an account whose
 * currency turns out to be the other one, therefore re-prices every session on
 * next read.
 * @param entries - the active currency's price list.
 * @param currency - that currency's ISO 4217 code, restated on the wire.
 * @returns the registrable projection definition.
 */
export declare function sessionSpendProjection(entries: readonly PriceEntry[], currency: string): ClientVisibleProjection;
/**
 * A stable non-negative integer identifying one priced configuration, used as
 * the projection's cache-invalidation version.
 * @param entries - the active currency's price list.
 * @param currency - that currency's ISO 4217 code.
 * @returns a 31-bit FNV-1a hash of both.
 */
export declare function priceTableVersion(entries: readonly PriceEntry[], currency: string): number;
//# sourceMappingURL=session-spend.d.ts.map