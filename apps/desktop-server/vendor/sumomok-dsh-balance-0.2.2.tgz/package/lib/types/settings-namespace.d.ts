/**
 * This plugin's own settings namespace name, shared between the host half
 * (which brands it through `settingsNamespace()` to register the section)
 * and the browser half (which binds a scope over the same raw string —
 * `SettingsScopeSpec.namespace` takes a plain string, not the branded type,
 * so the browser half has no reason to import `@deepseek-ai/dsh-settings`'s
 * host-side branding function at all).
 *
 * @module @sumomok/dsh-balance/settings-namespace
 */
/** The namespace name, matching this plugin's own cordis short name. */
export declare const BALANCE_SETTINGS_NAMESPACE_NAME = "balance";
//# sourceMappingURL=settings-namespace.d.ts.map