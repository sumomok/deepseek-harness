/**
 * Connection-fact resolution for the generic fallback adapter: any provider
 * but DeepSeek. Where DeepSeek's adapter knows its one settings namespace,
 * this one looks the provider up in `ctx.llm`'s own configurable-provider
 * directory — the same directory the harness's Models settings page reads —
 * so a custom base-URL entry the user added there is found by the same
 * `settingsNs`/`settingsPath` address, with no knowledge of which adapter
 * family owns it.
 *
 * @module @sumomok/dsh-balance/custom-provider
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ResolvedConfig } from './config.ts';
import type { GenericBalanceRequest } from './generic-adapter.ts';
/**
 * Build the resolver the generic reader calls before every read. Settings,
 * the launch environment, and the credential seam are all re-read per call,
 * matching the DeepSeek adapter's own resolver.
 * @param ctx - the plugin context.
 * @param provider - provider route id this resolver serves.
 * @param config - the resolved plugin config.
 * @returns a resolver yielding the next read's facts, or `null` while this
 * provider cannot be attempted at all (no directory entry, no configured
 * `baseURL`, or no key).
 */
export declare function customProviderResolver(ctx: Context, provider: string, config: ResolvedConfig): () => Promise<GenericBalanceRequest | null>;
//# sourceMappingURL=custom-provider.d.ts.map