/**
 * Time-of-day price table: the deployment owns the numbers, this module owns
 * the arithmetic.
 *
 * A price table is data. Nothing here fetches a pricing page, and no vendor's
 * tier names or window layout is compiled in: an entry states its base rates
 * and an ordered list of named schedules, each of which claims a set of
 * wall-clock windows in the entry's own IANA timezone and either restates the
 * rates or scales the base by a multiplier. Two tiers, five tiers, weekday and
 * weekend tiers, and a provider with no tiers at all are the same shape.
 *
 * Rates are quoted per currency, one entry set each, because a provider that
 * bills two currencies publishes two price lists rather than one list and an
 * exchange rate — and a balance in one currency beside a spend total in
 * another is a number nobody can act on. Which set is used is
 * {@link selectPriceCurrency}'s decision.
 *
 * @module @haoran/dsh-balance/prices
 */
/** One rate set, in currency units per {@link PriceEntry.per} tokens. */
export interface PriceRates {
    /** Input tokens the provider did not serve from its prompt cache. */
    input: number;
    /** Input tokens served from the provider's prompt cache. */
    inputCacheHit: number;
    /** Generated tokens. */
    output: number;
    /**
     * Tokens written into the provider's prompt cache. Absent means "billed as
     * {@link PriceRates.input}", which is what a provider that does not price
     * cache writes separately does.
     */
    cacheWrite?: number;
    /**
     * Reasoning tokens, when the provider bills them apart from other generated
     * tokens. Absent means "billed as {@link PriceRates.output}".
     */
    reasoning?: number;
}
/** A rate set after {@link PriceRates} defaulting, with every field settled. */
export interface ResolvedRates {
    input: number;
    inputCacheHit: number;
    output: number;
    cacheWrite: number;
    reasoning: number;
}
/**
 * One wall-clock window in its entry's timezone. `end` is exclusive, and a
 * window whose `end` is not after its `start` wraps past midnight — `22:00` to
 * `02:00` is four hours, not twenty.
 */
export interface PriceWindow {
    /** Window start, `HH:MM` in the entry's timezone. */
    start: string;
    /** Window end (exclusive), `HH:MM` in the entry's timezone. */
    end: string;
    /**
     * Weekdays this window opens on, as JavaScript day numbers: 0 is Sunday
     * through 6 is Saturday. Absent means every day. A wrapping window belongs
     * to the day it starts on, so a Friday `22:00`–`02:00` window covers
     * Saturday's first two hours.
     */
    days?: number[];
}
/** One named tier: when it applies, and what it charges. */
export interface PriceSchedule {
    /** Tier name, shown in the UI (`off-peak`, `weekend`, …). */
    name: string;
    /** Windows this tier claims; at least one. */
    windows: PriceWindow[];
    /** Explicit rates for this tier. Mutually exclusive with {@link PriceSchedule.multiplier}. */
    rates?: PriceRates;
    /** Factor applied to every base rate. Mutually exclusive with {@link PriceSchedule.rates}. */
    multiplier?: number;
}
/** One priced model. */
export interface PriceEntry {
    /** Model id exactly as the harness reports it. */
    model: string;
    /**
     * Provider route id, when the deployment prices the same model id
     * differently per provider. Absent matches any provider.
     */
    provider?: string;
    /** Tokens one rate unit covers; `1000000` for the usual per-1M rates. */
    per: number;
    /** Rates outside every schedule window. */
    base: PriceRates;
    /**
     * Name for the base tier in the UI. A provider that publishes its low rate
     * as the standard one and its high rate as a surcharge reads better with
     * `off-peak` here than with the default.
     */
    baseName?: string;
    /** IANA timezone the schedule windows are written in. */
    timezone: string;
    /** Ordered tiers; the first whose window contains the request time wins. */
    schedules?: PriceSchedule[];
}
/** One currency's price list. */
export interface CurrencyPrices {
    /** One entry per priced model, in the currency this list is keyed by. */
    entries: PriceEntry[];
}
/** A complete price table: one price list per currency the provider bills in. */
export interface PriceTable {
    /** Date the numbers were transcribed, `YYYY-MM-DD`; shown beside the currency. */
    asOf: string;
    /**
     * Price lists by ISO 4217 code. A deployment may add any currency its
     * provider bills in; nothing here is limited to the shipped two.
     */
    tables: Record<string, CurrencyPrices>;
}
/** What {@link resolveRates} found for one request. */
export interface ResolvedPrice {
    /** The settled rates that apply at that instant. */
    rates: ResolvedRates;
    /** Tokens one rate unit covers. */
    per: number;
    /** The tier that applied, or the entry's base-tier name. */
    scheduleName: string;
    /** Whether a schedule claimed the instant, as opposed to the base tier. */
    scheduled: boolean;
}
/** Token counts for one request, as disjoint billing buckets. */
export interface TokenCounts {
    /** Input tokens billed at the cache-miss rate. */
    input: number;
    /** Input tokens billed at the cache-hit rate. */
    cacheRead: number;
    /** Tokens billed at the cache-write rate. */
    cacheWrite: number;
    /** Generated tokens excluding {@link TokenCounts.reasoning}. */
    output: number;
    /** Reasoning tokens, billed at their own rate. */
    reasoning: number;
}
/** Default name for the tier outside every schedule window. */
export declare const DEFAULT_BASE_SCHEDULE_NAME = "standard";
/**
 * Whether a string is an `HH:MM` wall-clock time.
 * @param value - candidate time.
 * @returns true when the value is two-digit hours and minutes in range.
 */
export declare function isWallClockTime(value: string): boolean;
/**
 * Whether the running engine knows an IANA timezone. Validation calls this so
 * a mistyped zone fails at load rather than silently pricing everything in UTC.
 * @param timezone - candidate IANA zone id.
 * @returns true when `Intl` accepts it.
 */
export declare function isSupportedTimezone(timezone: string): boolean;
/** Wall-clock day number and minute-of-day at one instant in one timezone. */
interface WallClock {
    /** JavaScript day number, 0 for Sunday. */
    day: number;
    /** Minutes since local midnight. */
    minutes: number;
}
/**
 * Project one instant onto a timezone's wall clock.
 * @param atMs - the instant, in epoch milliseconds.
 * @param timezone - IANA zone id, already known to be supported.
 * @returns the local weekday and minute of day.
 */
export declare function wallClockAt(atMs: number, timezone: string): WallClock;
/**
 * Whether one window is open at a local wall-clock position.
 *
 * A wrapping window is anchored to the day it opens on, so the `days` filter
 * is tested against the previous day once the instant has passed midnight.
 * @param window - the window to test.
 * @param at - local weekday and minute of day.
 * @returns true when the window covers that position.
 */
export declare function windowContains(window: PriceWindow, at: WallClock): boolean;
/** What identifies the model whose rates are wanted. */
export interface PriceSubject {
    /** Provider route id, when the observation carried one. */
    provider?: string;
    /** Model id, exactly as the harness reported it. */
    model: string;
}
/**
 * Find the rates that apply to one request.
 *
 * An entry naming a provider matches only that provider, and is preferred over
 * an entry for the same model that names none, so a deployment can price one
 * route apart without restating the others.
 * @param entries - one currency's price list.
 * @param subject - the provider route and model of the request.
 * @param atMs - the request instant, in epoch milliseconds.
 * @returns the applicable rates, or `null` when the list prices no such model.
 */
export declare function resolveRates(entries: readonly PriceEntry[], subject: PriceSubject, atMs: number): ResolvedPrice | null;
/**
 * Price one request's token counts.
 * @param usage - disjoint billing buckets for the request.
 * @param rates - the settled rates that applied.
 * @param per - tokens one rate unit covers.
 * @returns the cost in the table's currency.
 */
export declare function costOf(usage: TokenCounts, rates: ResolvedRates, per: number): number;
/**
 * Choose which currency's price list to spend against.
 *
 * The account's own billing currency wins when the table prices it: a balance
 * read in CNY beside a spend total in USD is two numbers nobody can compare.
 * Before the first successful balance read — and for an account whose currency
 * the table does not price — the deployment's stated preference decides, then
 * `USD`, then the first list by name so the choice is never arbitrary.
 * @param table - the resolved price table.
 * @param options - the account currency when known, and the configured preference.
 * @returns the chosen ISO 4217 code, or `undefined` for an empty table.
 */
export declare function selectPriceCurrency(table: PriceTable, options?: {
    balanceCurrency?: string;
    preference?: readonly string[];
}): string | undefined;
/**
 * The price list for one currency.
 * @param table - the resolved price table.
 * @param currency - an ISO 4217 code the table prices.
 * @returns that currency's entries, empty when the table does not price it.
 */
export declare function pricesFor(table: PriceTable, currency: string): readonly PriceEntry[];
/**
 * Validate a price table's cross-field rules and reject a table this module
 * cannot price with. The schema behind `cordis.yml` settles types and
 * defaults; these are the rules a per-field schema cannot state.
 * @param table - the schema-validated table.
 * @param subject - diagnostic prefix naming the config path.
 * @returns the same table, once every rule holds.
 * @throws {Error} naming the first list, entry, schedule, or window that is unusable.
 */
export declare function resolvePriceTable(table: PriceTable, subject?: string): PriceTable;
export {};
//# sourceMappingURL=prices.d.ts.map