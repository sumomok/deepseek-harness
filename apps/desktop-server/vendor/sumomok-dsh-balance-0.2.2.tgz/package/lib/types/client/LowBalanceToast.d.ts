/**
 * The `shell.overlay` entry for a low-balance notice: a thin subscriber over
 * {@link LowBalanceAlertStore}, rendering the shared `Toast` atom once per
 * armed-then-fired transition and nothing otherwise.
 *
 * `shell.overlay` (`@deepseek-ai/dsh-client-ui-layout`) is a root-scope list
 * slot the host frame renders unconditionally from first paint, above every
 * column, documented for exactly "a badge, a toast stack or a status pill" —
 * `@haoran/dsh-connection-banner` is this workspace's own precedent for a
 * plugin registering into it. A one-shot balance notice fits the same seat:
 * it must reach the user whether or not the sidebar-footer chip happens to
 * be visible (narrow rail, or another plugin's slot entry currently
 * occupying the crowded row's remaining width), and `Toast` already owns its
 * own self-dismiss timing, so this component needs none of its own.
 *
 * @module @sumomok/dsh-balance/client/LowBalanceToast
 */
import { type ReactNode } from 'react';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { LowBalanceAlertStore } from './low-balance-alert.ts';
/** What the entry needs from the plugin install. */
export interface LowBalanceToastEntryDeps {
    /** The hysteresis store fed by every followed-provider balance read. */
    readonly store: LowBalanceAlertStore;
    /** Resolves a provider id to its display name, for the notice text. */
    readonly displayNameOf: (provider: string) => string;
    /** Reads the current localized copy (bound to the live locale). */
    readonly t: TranslateNS<'balance'>;
}
/**
 * Build the `shell.overlay` entry component.
 * @param deps - the hysteresis store, a provider-name resolver, and the bound translate seat.
 * @returns the component to register at `shell.overlay`.
 */
export declare function createLowBalanceToastEntry(deps: LowBalanceToastEntryDeps): () => ReactNode;
//# sourceMappingURL=LowBalanceToast.d.ts.map