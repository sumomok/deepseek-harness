/**
 * The browser half's own small store: what the last balance and spend reads
 * returned, the provider picker's roster, and one place to trigger the next
 * read.
 *
 * Polling lives here rather than in a component so that several mounted
 * surfaces share one request. The host caches the answer as well, so an extra
 * tab costs a round trip and no provider call, but a component per surface
 * asking on its own would still be noise nobody needs.
 *
 * Which provider is "followed" (the session's selected model's provider, or
 * DeepSeek when none resolves) is decided outside this store — `index.ts`
 * reads the session and calls {@link BalanceStore.refresh} with the answer —
 * so this module stays free of session/connection concepts and testable on
 * its own. The provider picker's own explicit choice ({@link BalanceStore.selectProvider})
 * is local to this store: it never changes which provider is followed.
 *
 * @module @sumomok/dsh-balance/client/store
 */
import type { BalanceView, ProviderOption, SpendView } from '../types.ts';
/** What every surface renders from. */
export interface BalanceState {
    /** Provider id the caller last resolved as followed (session's model, or DeepSeek). */
    followedProvider: string;
    /** The followed provider's last balance read; `undefined` until the first one returns. */
    balance: BalanceView | undefined;
    /** The last spend read; `undefined` until the first one returns. */
    spend: SpendView | undefined;
    /** Whether the followed-provider read is in flight. */
    loading: boolean;
    /** The provider picker's roster; empty until the first load. */
    providers: readonly ProviderOption[];
    /** The picker's own explicit choice; `undefined` means "follow", i.e. render `balance`. */
    selectedProvider: string | undefined;
    /** `selectedProvider`'s balance, once it differs from the followed provider and has been read. */
    preview: BalanceView | undefined;
    /** Whether the preview read is in flight. */
    previewLoading: boolean;
}
/** The reads the browser half performs. */
export interface BalanceApi {
    /**
     * Read one provider's balance.
     * @param provider - provider route id; the DeepSeek route when omitted.
     * @param force - bypass the host's refresh window.
     * @returns the view.
     */
    get(provider: string | undefined, force: boolean): Promise<BalanceView>;
    /**
     * Read day, month, and all-time spend.
     * @returns the view.
     */
    spend(): Promise<SpendView>;
    /**
     * Read the provider picker's roster.
     * @returns the roster.
     */
    providers(): Promise<ProviderOption[]>;
}
/** A store of one value with `useSyncExternalStore`'s subscribe/snapshot pair. */
export interface BalanceStore {
    /**
     * Subscribe to changes.
     * @param listener - called after every state replacement.
     * @returns the unsubscriber.
     */
    subscribe(listener: () => void): () => void;
    /**
     * The current state.
     * @returns a stable reference between changes.
     */
    getSnapshot(): BalanceState;
    /**
     * Read the followed provider's balance, the spend ledger, and the picker's
     * roster once.
     * @param followedProvider - provider id to read as followed.
     * @param force - bypass the host's refresh window for the balance.
     */
    refresh(followedProvider: string, force?: boolean): Promise<void>;
    /**
     * Change the picker's own explicit selection.
     * @param provider - the chosen provider id, or `undefined` to follow again.
     */
    selectProvider(provider: string | undefined): void;
}
/**
 * Build the store over one RPC face.
 * @param api - the mounted Remote namespace.
 * @param onError - receives a failed read; the store keeps its last good state.
 * @returns the store.
 */
export declare function createBalanceStore(api: BalanceApi, onError: (error: unknown) => void): BalanceStore;
//# sourceMappingURL=store.d.ts.map