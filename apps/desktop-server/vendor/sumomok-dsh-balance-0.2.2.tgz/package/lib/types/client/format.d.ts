/**
 * Turning host numbers into the few strings the chip shows.
 *
 * @module @sumomok/dsh-balance/client/format
 */
import type { BalanceUiConfig, BalanceView } from '../types.ts';
/**
 * The prefix one currency code renders with.
 * @param currency - ISO 4217 code.
 * @returns a symbol, or the code followed by a space.
 */
export declare function currencySymbol(currency: string): string;
/**
 * Render one amount with its currency prefix.
 * @param currency - ISO 4217 code.
 * @param amount - the amount, as a decimal string or a number.
 * @param digits - fraction digits; two for money, more for a fraction of a cent.
 * @returns the display string, or `undefined` when the amount is not a number.
 */
export declare function formatAmount(currency: string, amount: string | number, digits?: number): string | undefined;
/**
 * Render a spend amount, keeping a small-but-nonzero total from reading as zero.
 * @param currency - ISO 4217 code.
 * @param amount - the cost.
 * @returns the display string.
 */
export declare function formatSpend(currency: string, amount: number): string;
/** How the chip is tinted. */
export type BalanceTint = 'normal' | 'warning' | 'critical';
/**
 * Decide the chip's tint.
 *
 * A provider that says the account cannot serve requests is critical whatever
 * the number says: an account can be suspended with a positive balance.
 * @param view - a successful balance read.
 * @param ui - the deployment's thresholds.
 * @returns the tint.
 */
export declare function tintOf(view: Extract<BalanceView, {
    state: 'ok';
}>, ui: BalanceUiConfig): BalanceTint;
/**
 * Render a timestamp as a short local time.
 * @param atMs - epoch milliseconds.
 * @returns the local time of day.
 */
export declare function formatTime(atMs: number): string;
/**
 * Render a timestamp as a local date.
 * @param atMs - epoch milliseconds.
 * @returns the local date.
 */
export declare function formatDate(atMs: number): string;
/**
 * Fill `{name}` placeholders, for the few strings assembled outside the
 * framework's own translate seat.
 * @param template - the copy.
 * @param values - placeholder values.
 * @returns the filled string.
 */
export declare function fill(template: string, values: Readonly<Record<string, string>>): string;
//# sourceMappingURL=format.d.ts.map