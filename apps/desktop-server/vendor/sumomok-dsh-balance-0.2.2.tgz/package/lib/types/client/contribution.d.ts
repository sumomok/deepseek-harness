/**
 * The browser half's Typert contribution: the consumer-side mirror of
 * `../typert.ts`.
 *
 * Each descriptor must match the host manifest's invocation exactly — same id,
 * namespace, method, and parameter wire names — because the gateway matches
 * arguments by field name. The codecs are hand-written narrowings rather than a
 * schema library: this file is bundled into the browser and a validator's
 * bytes would ride into every page load for two small reads.
 *
 * @module @sumomok/dsh-balance/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { BalanceView, ProviderOption, SpendView } from '../types.ts';
/** Narrow one balance read. */
export declare function parseBalanceView(value: unknown): BalanceView;
/** Narrow the provider roster. */
export declare function parseProviderOptions(value: unknown): ProviderOption[];
/** Narrow one spend read. */
export declare function parseSpendView(value: unknown): SpendView;
/** The contribution `ctx.remote.$mount()` installs, mirroring `../typert.ts`. */
export declare const CONTRIBUTION: TypertRemoteContribution;
//# sourceMappingURL=contribution.d.ts.map