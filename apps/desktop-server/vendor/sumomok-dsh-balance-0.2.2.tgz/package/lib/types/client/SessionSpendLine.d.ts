/**
 * The per-session spend line under the composer.
 *
 * It reads the host's own projection of this session's log, so it needs no
 * request of its own and it stays right when a session is resumed weeks later.
 * It renders nothing until that session has priced usage, so a conversation
 * with no model call — or one on a model the price table does not price —
 * shows no line rather than a confident zero.
 *
 * @module @sumomok/dsh-balance/client/SessionSpendLine
 */
import type { ReactNode } from 'react';
import type { UseProjection } from '@deepseek-ai/dsh-client-runtime/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { BalanceState } from './store.ts';
/** A `useSyncExternalStore`-backed selector hook, as the slot framework binds it. */
type BalanceHook = <S>(selector: (state: BalanceState) => S) => S;
/** Props the line reads from its composed slot props. */
export interface SessionSpendLineProps {
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'balance'>;
    /** The framework's projection reader for the current session. */
    useProjection: UseProjection;
    /** Selector over the browser half's own store, for the surface toggle. */
    useBalance: BalanceHook;
}
/**
 * The registered slot component.
 * @param props - composed slot props.
 * @returns the line, or nothing while this session has no priced usage.
 */
export declare function SessionSpendLine(props: SessionSpendLineProps): ReactNode;
export {};
//# sourceMappingURL=SessionSpendLine.d.ts.map