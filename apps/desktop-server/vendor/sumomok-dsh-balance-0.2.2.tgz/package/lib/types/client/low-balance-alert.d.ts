/**
 * Hysteresis over the followed provider's balance: fires once when a read
 * first shows it below the deployment's `lowBalance` threshold, then stays
 * disarmed — however many further reads still show it low — until a read
 * shows it at or above the threshold again, which re-arms without itself
 * firing a notice.
 *
 * The armed bit is kept per provider id, not once for the whole store:
 * switching the followed provider (a session's model changing to a
 * different provider) is switching accounts, and one account's already-seen
 * low balance must not silence the next account's first one.
 *
 * @module @sumomok/dsh-balance/client/low-balance-alert
 */
import type { BalanceView } from '../types.ts';
/** One fired notice. */
export interface LowBalanceAlertState {
    /** Provider id the current notice is for; `undefined` while none is showing. */
    provider: string | undefined;
    /** Bumped every time a notice fires, so re-showing the same provider still remounts the toast. */
    seq: number;
}
/** The hysteresis store. */
export interface LowBalanceAlertStore {
    /** @returns the current state, a stable reference between changes. */
    getSnapshot(): LowBalanceAlertState;
    /**
     * Subscribe to changes.
     * @param listener - called after every state replacement.
     * @returns the unsubscriber.
     */
    subscribe(listener: () => void): () => void;
    /**
     * Feed one followed-provider balance read.
     * @param provider - the provider this read is for.
     * @param balance - the read; anything but a successful one is ignored — an
     * unconfigured or unavailable provider is not "low," it is unreadable, and
     * arming/disarming on a read that named no number would be arbitrary.
     * @param threshold - the low-balance threshold this read is judged against.
     */
    observe(provider: string, balance: BalanceView, threshold: number): void;
    /** Acknowledge the current notice once its toast has run its course. */
    dismiss(): void;
}
/**
 * Build a low-balance alert store.
 * @returns the store.
 */
export declare function createLowBalanceAlertStore(): LowBalanceAlertStore;
//# sourceMappingURL=low-balance-alert.d.ts.map