/**
 * Small settings-reading helpers shared by every adapter that resolves a
 * provider's connection facts from an untyped settings section.
 *
 * @module @sumomok/dsh-balance/settings-util
 */
/** Read one optional string from an untyped settings section. */
export declare function optionalString(value: unknown): string | undefined;
/**
 * Walk a settings section down to one provider's profile object.
 * @param section - the namespace's resolved value, or `undefined` while unregistered.
 * @param path - path from the section root to the profile; empty means the whole section.
 * @returns the profile object, or `undefined` when the path does not resolve to one.
 */
export declare function profileAtPath(section: unknown, path: readonly string[]): Record<string, unknown> | undefined;
/**
 * Derive the conventional credential reference for a provider route, matching
 * the Models settings page's own derivation exactly (`ui-settings-models`):
 * a typed key with no explicit `apiKeyEnv` stores under this reference, so a
 * profile naming none must resolve to the same name here.
 * @param provider - provider route id (e.g. `anthropic`, `minimax-cn`).
 * @returns the derived reference name (e.g. `MINIMAX_CN_API_KEY`).
 */
export declare function deriveKeyRef(provider: string): string;
//# sourceMappingURL=settings-util.d.ts.map