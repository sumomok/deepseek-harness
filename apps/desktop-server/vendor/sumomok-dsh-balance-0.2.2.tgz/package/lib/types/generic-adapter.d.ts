/**
 * The generic fallback adapter: best-effort balance reads for a provider
 * this plugin has no dedicated adapter for.
 *
 * It never guesses at a provider's own API — it tries a short, configured
 * list of endpoint shapes documented by widely deployed OpenAI-compatible
 * gateways (one-api/new-api's own user-quota endpoint, and the legacy OpenAI
 * dashboard billing endpoints several such gateways also answer), stopping at
 * the first one that returns something it understands. Egress is fenced to
 * the provider's own configured origin, the same fence
 * {@link file://./balance.ts}'s `balanceEndpoint` applies to DeepSeek; nothing
 * here is copied from any gateway's source, only the request/response shapes
 * its documentation describes.
 *
 * @module @sumomok/dsh-balance/generic-adapter
 */
import type { BalanceView } from './types.ts';
/** A successful read, before staleness is decided at serve time. */
type OkView = Extract<BalanceView, {
    state: 'ok';
}>;
/** A failed read. */
type UnavailableView = Extract<BalanceView, {
    state: 'unavailable';
}>;
/**
 * One-api/new-api's own convention: a self-quota endpoint returning a
 * dimensionless integer "quota" the deployment prices at some ratio per
 * currency unit. The ratio and currency are deployment facts (a self-hosted
 * gateway sets its own conversion), so both are configured per shape rather
 * than assumed.
 */
export interface OneApiQuotaShape {
    kind: 'one-api-quota';
    /** Path from the provider's origin to the endpoint. */
    path: string;
    /** Quota units the gateway counts as one unit of `currency`. */
    unitsPerCurrency: number;
    /** ISO 4217 code the converted amount is reported in. */
    currency: string;
}
/**
 * The legacy OpenAI dashboard billing pair several OpenAI-compatible gateways
 * still answer: a subscription endpoint naming the account's hard limit, and
 * a usage endpoint naming what has been spent against it. Both are fixed by
 * that protocol (USD, a hard limit in dollars, usage in cents), so neither is
 * configurable the way {@link OneApiQuotaShape}'s ratio is.
 */
export interface OpenAiBillingShape {
    kind: 'openai-billing';
    /** Path to the subscription endpoint (answers `hard_limit_usd`). */
    subscriptionPath: string;
    /** Path to the usage endpoint (answers `total_usage`, in cents). */
    usagePath: string;
}
/** One candidate endpoint shape the generic adapter tries, in configured order. */
export type GenericEndpointShape = OneApiQuotaShape | OpenAiBillingShape;
/** Shapes tried when a deployment configures none of its own. */
export declare const DEFAULT_GENERIC_ENDPOINTS: readonly GenericEndpointShape[];
/** Everything one generic read needs, resolved fresh by the caller. */
export interface GenericBalanceRequest {
    /** The provider's configured origin; every candidate URL is fenced to it. */
    origin: string;
    /** The API key, held only for the duration of the call. */
    apiKey: string;
    /** Wall-clock budget for one candidate request. */
    timeoutMs: number;
    /** Candidate shapes to try, in order. */
    shapes: readonly GenericEndpointShape[];
}
/**
 * Build one provider's generic `perform`. The returned function remembers
 * which shape last answered, across calls, and tries that one first — so a
 * provider matched once no longer pays for probing shapes it is known not to
 * serve. The remembered index is runtime state, not configuration: a restart
 * re-probes from the configured order, same as a provider matched for the
 * first time.
 * @returns a `perform` function for {@link BalanceReader}.
 */
export declare function createGenericPerform(): (request: GenericBalanceRequest, at: number, fetchImpl: typeof globalThis.fetch) => Promise<OkView | UnavailableView>;
export {};
//# sourceMappingURL=generic-adapter.d.ts.map