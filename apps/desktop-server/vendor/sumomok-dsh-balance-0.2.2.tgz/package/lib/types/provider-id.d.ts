/**
 * The one provider id this plugin hardcodes: the harness's own DeepSeek
 * route, shared between the host half (the adapter registry's first entry)
 * and the browser half (the fallback when a session names no provider).
 * Every other provider id is data — read from `ctx.llm`'s directory or from
 * a session's own model selection, never compiled in here.
 *
 * @module @sumomok/dsh-balance/provider-id
 */
/**
 * The provider route `@deepseek-ai/dsh-llm-deepseek` registers. This is a
 * protocol constant, not a deployment tunable: it names the one route this
 * plugin's DeepSeek-specific adapter serves, which is fixed by that adapter's
 * own registration, not by configuration.
 */
export declare const DEEPSEEK_PROVIDER_ID = "deepseek-official";
/** Display name shown for {@link DEEPSEEK_PROVIDER_ID} when no directory entry names one. */
export declare const DEEPSEEK_DISPLAY_NAME = "DeepSeek";
//# sourceMappingURL=provider-id.d.ts.map