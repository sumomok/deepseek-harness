# @haoran/dsh-crash-resume

English | [中文](README.zh.md)

When the app exits unexpectedly in the middle of a turn, the next launch continues that turn once. When continuing could do harm, a card is left in the conversation instead: 「已中断，需要你确认才继续」 / "Interrupted — continue when you are ready". Sending a message continues from there.

Display name: 崩溃恢复 / Crash recovery (working name, pending approval).

## What happens at the next launch

| The interrupted turn… | Result |
| --- | --- |
| was an ordinary turn a person started | continued once, after the app reports it is ready |
| had asked for an approval nobody answered | held: `awaiting-approval` |
| had a question tool waiting for an answer (`ask_user_question`, `exit_plan_mode`, configurable) | held: `awaiting-answer` |
| was itself an automatic continuation, or carries no message at all and follows an interrupted turn | held: `already-resumed` |
| was started by a person in a session whose goal is active | held: `goal-active` |
| was cut short by a stop request (the app was quit or restarted) | held: `stopped` |
| belongs to a subagent or an archived session, or was opened by a goal round, a schedule, or a job notice | left exactly as it is |

Continuing a turn that waited on a person would turn the wait into a refusal or an unanswerable question. Continuing an automatic continuation a second time could repeat the crash forever: restart, continue, crash. `turn/start` is logged before the turn's message, so a continuation that died between the two leaves a turn with no message; such a turn after an interrupted one is held for the same reason. A scheduled turn that died at the same point gets the same card, and nothing runs.

The goal service disarms every goal when an agent is created for its session, so after a restart no driver continues a goal until a person resumes it. An automatic continuation of a turn in such a session would work toward the goal without that consent, so the turn is held. A goal round's own turn is not a person's and is left as it is.

When more than one reason applies, the card names the first in the table's order.

## How it knows

**Which sessions to look at.** While it runs, each server process keeps its own registry, `$DSH_HOME/crash-resume/in-flight/<pid>.json`: the ids of top-level sessions whose turn started and has not ended. It adds an id on `turn/start`, observed on the host's `session/event` stream. On `turn/end` it first flushes the session, because storage batches appends and a crash inside that window would leave an open turn no registry lists; it removes the id once the flush completes, unless a new turn started meanwhile. Each write replaces the file atomically (uniquely named temporary file, fsync, rename, directory fsync); writes from a reloaded plugin are queued after the previous load's, and a disposed load writes nothing more. At startup the plugin reads the registries whose writers are gone and the one named by its own pid, and reads only the listed sessions, completely, through the persistence service. The session store is never scanned, older-format sessions are never opened, and the backend's directory layout is never used. A damaged registry means the sessions it listed are not recovered; the plugin says so in the log.

**Two servers on one home.** One registry per process, rather than one shared file under a lock file, means neither server overwrites the other's entries and a crashed server's lock is never left behind. A registry whose writer still runs is left alone. Two servers that start at the same moment can both read the same dead registry; the session store's single-writer ownership decides which one continues or marks each session.

**When a registry's writer is gone.** A pid alone is not enough: after a reboot, or after the pid wraps around, an unrelated live process can hold the same number. Each registry therefore records the machine's boot time (`Date.now()` minus Node's `os.uptime()`, which on macOS matches `sysctl kern.boottime`) and a heartbeat the server rewrites every quarter of `staleRegistryMs`. A registry counts as dead when no process has its pid, when its boot time differs from the current one by more than a minute, or when its heartbeat is older than `staleRegistryMs`. The last rule covers a pid reused within one boot; it can also take over the registry of a live server that did not run for that long, such as one on a machine that slept, and the session store's single-writer ownership then keeps the two from writing the same session.

**Order at startup.** This process's registry, listing every candidate, is written before any log is read. Held markers are written next. The registries read at startup and the sentinel are deleted last. A session to continue stays listed until its continuation's own turn ends, and one that could not be opened stays listed for the next launch. A crash at any point therefore leaves the next launch the same candidates and the same stop fact.

**Whether it was a crash.** A quit leaves the same open turn in the log as a crash does: on Windows the desktop shell force-kills the server, and on macOS the turn's closing events were measured not to reach storage during shutdown. So a deliberate stop is recorded outside the log, in `$DSH_HOME/crash-resume/intentional-stop.json`. This plugin writes it synchronously from its own `SIGTERM`, `SIGINT` and `SIGHUP` listeners (`SIGHUP` is what a closing terminal sends to `dsh web`), which run in the same signal emit as the launcher's before any teardown starts. Nothing else in the server writes it: a fatal error (an uncaught exception or unhandled rejection, which the launcher turns into a disposal and exit code 1), a disposal without a stop request, and a plugin reload leave none, so a turn cut short by a fatal error is continued. The three listeners change no exit behavior: the launcher's own listeners still decide the exit code, and when no other listener handles the signal the plugin removes its listeners and raises the signal again, so the process still ends by it. The desktop shell writes the same file, in the same format, before it force-kills the server on Windows (reason `quit`, `update` or `shutdown`). The next launch holds every interrupted turn it finds while the sentinel is present, and deletes the sentinel after it has written the held markers.

**Whether it was already continued once.** The continuation is an ordinary logged `user/message` whose `source.kind` is `plugin:crash-resume`. The model reads it, and the log keeps it, so the next launch can see it. The rule counts on the log alone, never on memory that dies with the process.

## What it writes into a session

- **The continuation message.** Model-visible, in the language chosen in Settings, read from the same place the desktop shell's boot page reads it. The text says that the app exited mid-turn, that in-flight tools were closed with unknown results, and that a partial action must be checked before it is repeated. It names no tool. The chat shows it as a collapsed row titled "Continued after an unexpected exit" rather than as something you typed.
- **The held marker.** A `plugin:crash-resume/held` event carrying only `interruptedTurn` and `reason` (plus `turn: null`, which the browser's conversation index reads as "between turns"), placed after the interrupted turn's closing events. It is written through a persistence write handle while no agent owns the session, before the app reports it is ready, and always with `ignorable: true`. A build without this plugin skips it; the session stays readable after the plugin is removed. The card text comes from the browser's dictionaries, so it reads in the viewer's language.

`Session.append` cannot write `ignorable`, and an unknown event without it makes a session unreadable to every build. Such an event also makes session search fail for all sessions. That is why the marker is never appended through a live session.

## Configuration

Every field is written out in `cordis.patch.yml`.

| Field | Default | Meaning |
| --- | --- | --- |
| `stateDir` | `$DSH_HOME/crash-resume` | Where the registry and the sentinel live. The desktop shell writes to the default path; move both or neither. |
| `awaitUserTools` | `ask_user_question`, `exit_plan_mode` | Tools whose open call means the turn was waiting for an answer. |
| `resumeTextZh` / `resumeTextEn` | see the patch | The continuation message the model reads. |
| `resumeSummaryZh` / `resumeSummaryEn` | see the patch | The one-line summary stored with it. |
| `maxLogBytes` | 67108864 (64 MiB) | Largest log the startup pass reads; a larger one is skipped with a warning. Applies where the backend reports a size (JSONL does). |
| `readTimeoutMs` | 15000 | Longest the startup pass waits for one log; a slower one is skipped with a warning. The read itself is not cancelled. |
| `staleRegistryMs` | 3600000 (one hour) | Heartbeat age after which another server's registry counts as dead although its pid is in use. |

## Known limitations

- **On Windows this plugin requires a desktop shell that writes the sentinel (DSH desktop from rc.35).** The shell stops the server with `taskkill /T /F`, which no listener sees; without the shell's sentinel every quit reads as a crash and every interrupted turn is continued.
- **Running out of memory cannot be caught.** A log that makes the startup pass run out of memory kills the process before any handler runs. The plugin records the id it is about to read in its registry and waits for that write before reading; a launch that finds a dead registry still naming an id it was reading skips that session with a warning. One bad log therefore costs one failed launch, not a crash loop. `maxLogBytes` refuses the largest logs before they are read.
- **A crash while the auto-review gateway judges a walled-mode sandbox escalation is held, not continued.** That escalation's `approval/asked` is written before the gateway answers. The log does not say whether a reviewer or a person holds the question, so the plugin treats it as a person's.
- **Questions are recognized by tool name.** A question asked from inside a `run_code` program, or by a plugin calling `ctx.userQuestions` directly, is not recognized, and such a turn is continued.
- **A turn no person started is never continued.** This covers the first turn after an interrupted one when a job notice or a goal round opened it.
- **One sentinel per home.** With two servers on one home, a stop of one can make the other's crash read as a stop. That holds turns that could have been continued and never continues one that should be held.
- **A launch that fails before this plugin loads leaves the sentinel in place.** A crash after that launch is then held as `stopped`.

## Requirements

DeepSeek Harness 0.1.7-rc.2 or later, with the session controller (the desktop app and `dsh web`). On Windows, a desktop shell that writes the sentinel (DSH desktop from rc.35).
