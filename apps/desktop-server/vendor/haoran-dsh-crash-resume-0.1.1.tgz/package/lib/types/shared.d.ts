/**
 * Durable names and payloads this plugin writes into session logs, shared by
 * both halves. Pure data: the browser half imports this module, so it must
 * not reach Node or any host service.
 *
 * @module @haoran/dsh-crash-resume/shared
 */
/**
 * Event type of the held marker. The `plugin:` prefix is the namespace V4
 * session logs use for extension-owned names, so a later first-party event
 * cannot collide with it.
 */
export declare const HELD_EVENT_TYPE = "plugin:crash-resume/held";
/** `source.kind` of the message that continues an interrupted turn. */
export declare const RESUME_SOURCE_KIND = "plugin:crash-resume";
/**
 * Why an interrupted turn was not continued automatically.
 *
 * - `awaiting-approval`: the turn had asked for an approval nobody answered.
 * - `awaiting-answer`: a question tool was waiting for the user's answer.
 * - `already-resumed`: the turn was itself an automatic continuation, so a
 *   second one could repeat the same crash.
 * - `goal-active`: the session has an active goal. After a restart the goal
 *   service leaves every goal disarmed until a person resumes it, and an
 *   automatic continuation would act on that goal without that consent.
 * - `stopped`: the app was quit or restarted on purpose.
 */
export type HeldReason = 'awaiting-approval' | 'awaiting-answer' | 'already-resumed' | 'goal-active' | 'stopped';
/** Every {@link HeldReason}, for validating a payload read back from a log. */
export declare const HELD_REASONS: readonly HeldReason[];
/**
 * Payload of the held marker. Facts only: the browser half renders the card
 * text in the viewer's language from these fields.
 */
export interface HeldEventData {
    /**
     * Always null. The browser's conversation index places an event by its
     * payload's `turn` field, and null is its explicit "session level" value
     * (`payloadCoordinates` in dsh-client-ui-conversation's location index), so
     * the row stands between turns instead of inside the turn it follows.
     */
    readonly turn: null;
    /** The interrupted turn the marker follows. */
    readonly interruptedTurn: number;
    /** Why the turn was held. */
    readonly reason: HeldReason;
}
/**
 * Narrow an untyped event payload to {@link HeldEventData}.
 * @param data - the payload read back from a session log or the wire.
 * @returns the payload when it is a well-formed held marker, else undefined.
 */
export declare function heldEventData(data: unknown): HeldEventData | undefined;
//# sourceMappingURL=shared.d.ts.map