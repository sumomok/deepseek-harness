/**
 * The two startup steps: the pass that runs inside `apply`, before the
 * gateway admits any client, and the continuation that runs once the
 * application reports it is ready.
 *
 * @module @haoran/dsh-crash-resume/recovery
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { ResolvedConfig } from './config.ts';
import type { Language } from './language.ts';
import { type Verdict } from './judge.ts';
/** A session the startup pass decided to continue, with the turn it continues. */
export interface ResumeCandidate {
    readonly id: string;
    readonly turn: number;
}
/** Why a candidate could not be judged; it is left as it is. */
export interface Unreadable {
    readonly kind: 'unreadable';
    readonly detail: string;
}
/** What the startup pass did, for the caller's registry update and for tests. */
export interface StartupOutcome {
    /** Sessions to continue once the application is ready. */
    readonly resume: readonly ResumeCandidate[];
    /** Candidates that stay in the in-flight registry: sessions already live in this process. */
    readonly keep: readonly string[];
    /** Every other candidate's verdict, or why none could be reached. */
    readonly verdicts: ReadonlyMap<string, Verdict | Unreadable>;
}
/** Inputs of the startup pass that come from this launch. */
export interface StartupInputs {
    readonly candidates: readonly string[];
    readonly stopped: boolean;
    readonly config: ResolvedConfig;
    /**
     * Called with a candidate's id before its log is read and with undefined
     * after; the pass awaits it. The caller records the id durably, so a
     * process that dies while reading a log (out of memory, for one) tells the
     * next startup which log to skip.
     */
    readonly examining?: (id: string | undefined) => Promise<void>;
}
/**
 * The startup pass. Reads each candidate's complete stored log, decides, and
 * writes the held marker where the decision is to hold. Runs inside the
 * plugin's `apply`, which the launcher awaits before it reports the
 * application ready, so no client can open a session while a write handle
 * taken here is open. A candidate whose log is missing, larger than
 * `maxLogBytes`, slower than `readTimeoutMs`, or fails to read is left as it
 * is with a warning.
 * @param ctx - the plugin context.
 * @param inputs - candidates from the in-flight registries, the stop flag, and the policy.
 * @returns what to continue, what to keep listed, and every other verdict.
 */
export declare function runStartupPass(ctx: Context, inputs: StartupInputs): Promise<StartupOutcome>;
/**
 * Whether the live log still ends with the closers of `turn` and nothing
 * after them started a new turn. Anything else means the session moved on
 * (a person sent a message first) and must not be continued.
 * @param events - the live session's events.
 * @param turn - the interrupted turn.
 * @returns true when the session is still exactly where the crash left it.
 */
export declare function stillInterrupted(events: readonly SessionEvent[], turn: number): boolean;
/**
 * What {@link continueOne} did.
 *
 * - `sent`: the continuation message was handed to the agent.
 * - `busy`: the agent is running or has queued input; that turn's own end
 *   settles the session.
 * - `settled`: the session is idle and moved past the interrupted turn.
 * - `unopened`: the session could not be opened; the interrupted turn is
 *   still where it was.
 */
export type ContinueResult = 'sent' | 'busy' | 'settled' | 'unopened';
/**
 * Continue one interrupted turn by sending the continuation message. The
 * message is an ordinary logged `user/message`, so the model request it
 * produces is reconstructable from the log, and its source kind is what the
 * next startup reads to refuse a second continuation. The agent's state is
 * checked again after the flush and immediately before the send, with no
 * await in between, so a message a person sent meanwhile wins.
 * @param ctx - the plugin context.
 * @param candidate - the session and its interrupted turn.
 * @param language - the settings language.
 * @param config - the policy holding the message text.
 * @returns what happened.
 */
export declare function continueOne(ctx: Context, candidate: ResumeCandidate, language: Language, config: ResolvedConfig): Promise<ContinueResult>;
//# sourceMappingURL=recovery.d.ts.map