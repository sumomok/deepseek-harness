/**
 * Browser half of @haoran/dsh-crash-resume: the held row and the
 * continuation message's row.
 *
 * Nothing here talks to the host. Both rows are built from events the chat
 * already folds — the held marker and the continuation `user/message` — so
 * they read the same on every reload, in the viewer's own language.
 *
 * @module @haoran/dsh-crash-resume/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type HeldNodeData } from './held-definition.ts';
import { type CrashResumeKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-crash-resume` copy. */
        'crash-resume': CrashResumeKey;
    }
}
declare module '@deepseek-ai/dsh-client-ui-chat/client' {
    interface ChatNodeDataMap {
        /** A turn interrupted by a crash or a quit that was not continued automatically. */
        'crash-resume-held': HeldNodeData;
    }
}
export { HeldCard } from './HeldCard.tsx';
export type { HeldCardProps } from './HeldCard.tsx';
export { HELD_NODE_KIND, heldDefinition } from './held-definition.ts';
export type { HeldChatNode, HeldNodeData } from './held-definition.ts';
export { en, NS, zh } from './locales.ts';
export type { CrashResumeKey } from './locales.ts';
export { createResumeTriggerView, isResumeSource, pickIncumbent } from './ResumeTriggerView.tsx';
export type { ResumeTriggerDeps } from './ResumeTriggerView.tsx';
export { insertStyles, STYLE_TAG } from './styles.ts';
/** Required browser services; every `ctx.<name>` read below is listed. */
export declare const inject: string[];
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map