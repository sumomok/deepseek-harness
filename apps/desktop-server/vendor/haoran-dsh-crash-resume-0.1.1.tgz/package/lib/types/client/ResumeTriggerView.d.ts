/**
 * The row of the continuation message.
 *
 * The chat renders a message no person sent, which opens a turn, as a
 * `turn-trigger` row titled by the message's source. It does not know this
 * plugin's source, so the title would read "Execution requested". This view
 * shadows the host's `turn-trigger` renderer at priority -1, as
 * `@sumomok/dsh-quote-message` does for user bubbles: it renders the
 * continuation message itself and hands every other trigger back to the
 * host's own component, read from the slot ledger.
 *
 * @module @haoran/dsh-crash-resume/client/ResumeTriggerView
 */
import { type ReactNode } from 'react';
import type { StoredEntry, Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { CrashResumeKey } from './locales.ts';
/** The props a keyed chat-node entry receives; only the parts this view reads are named. */
interface TriggerProps {
    readonly node?: {
        readonly data?: {
            readonly source?: unknown;
            readonly content?: readonly unknown[];
        };
    };
    readonly t?: unknown;
}
/** What the view needs from the plugin context, resolved per render. */
export interface ResumeTriggerDeps {
    /** Live ledger of `conversation.chat.node` entries. */
    readonly entries: () => readonly StoredEntry[];
    /** Translate bound to the host renderer's namespace. */
    readonly hostTranslate: () => unknown;
    /** Translate bound to this plugin's namespace. */
    readonly t: () => Translate<CrashResumeKey>;
}
/**
 * Whether a trigger node carries this plugin's continuation message.
 * @param source - the node's message source.
 * @returns true for this plugin's source kind.
 */
export declare function isResumeSource(source: unknown): boolean;
/**
 * The host's own entry for a keyed cell: the lowest priority other than this view.
 * @param entries - the slot ledger.
 * @param key - the keyed cell.
 * @param own - this view, excluded from the search.
 * @returns the incumbent component, or undefined when this view is alone in the cell.
 */
export declare function pickIncumbent(entries: readonly StoredEntry[], key: string, own: unknown): unknown;
/**
 * Build the shadowing renderer for the `turn-trigger` cell.
 * @param deps - ledger access and the two translators.
 * @returns the component to register at `priority: -1`.
 */
export declare function createResumeTriggerView(deps: ResumeTriggerDeps): (props: TriggerProps) => ReactNode;
export {};
//# sourceMappingURL=ResumeTriggerView.d.ts.map