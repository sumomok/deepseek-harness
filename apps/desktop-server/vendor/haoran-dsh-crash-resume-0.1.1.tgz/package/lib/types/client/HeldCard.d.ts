import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { HeldNodeData } from './held-definition.ts';
/** Props of the held row: the node the chat hands the keyed slot, and this plugin's translator. */
export type HeldCardProps = {
    readonly node: {
        readonly data: HeldNodeData;
    };
} & PropsLocale<'crash-resume'>;
/**
 * The held row: the turn above stopped and was not continued automatically.
 * Everything shown comes from the marker's two fields, so the row reads the
 * same on every reload and in the viewer's own language.
 * @param props - the node and translator.
 * @returns the row.
 */
export declare function HeldCard({ node, t }: HeldCardProps): import("react").JSX.Element;
//# sourceMappingURL=HeldCard.d.ts.map