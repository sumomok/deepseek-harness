/**
 * Copy for the browser half, in the two locales the harness ships.
 *
 * @module @haoran/dsh-crash-resume/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "crash-resume";
/** Every key the browser half looks up. */
export type CrashResumeKey = 'held.title' | 'held.reason.awaiting-approval' | 'held.reason.awaiting-answer' | 'held.reason.already-resumed' | 'held.reason.goal-active' | 'held.reason.stopped' | 'held.hint' | 'resumed.title' | 'resumed.explanation';
/** Chinese copy. */
export declare const zh: Record<CrashResumeKey, string>;
/** English copy. */
export declare const en: Record<CrashResumeKey, string>;
//# sourceMappingURL=locales.d.ts.map