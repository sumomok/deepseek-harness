/**
 * The decision this plugin makes for one session at startup, as a pure
 * function over the session's raw stored log (no synthetic closers applied).
 *
 * The log is a durable boundary: other builds and other plugins wrote it, so
 * every field this module reads is checked at runtime rather than trusted
 * from the event type.
 *
 * @module @haoran/dsh-crash-resume/judge
 */
import { type HeldReason } from './shared.ts';
/** The event fields the decision reads; a stored `SessionEvent` satisfies it. */
export interface JudgedEvent {
    readonly type: string;
    readonly data: unknown;
}
/** Session facts outside the event list. */
export interface JudgedSession {
    /** `header.origin` of the stored session. */
    readonly origin?: string | undefined;
    /** Whether the session is archived in the workspace registry. */
    readonly archived: boolean;
}
/** Inputs that come from this launch rather than from the session. */
export interface JudgeOptions {
    /** Tool names that wait for the user's answer while their call is open. */
    readonly awaitUserTools: readonly string[];
    /** Whether the previous run was stopped on purpose (the sentinel was present). */
    readonly stopped: boolean;
}
/** Why a session is left exactly as it is: no continuation and no marker. */
export type SkipReason = 'balanced' | 'subagent' | 'archived' | 'not-human';
/** The outcome for one session. */
export type Verdict = {
    readonly kind: 'skip';
    readonly reason: SkipReason;
} | {
    readonly kind: 'hold';
    readonly turn: number;
    readonly reason: HeldReason;
} | {
    readonly kind: 'resume';
    readonly turn: number;
};
/**
 * Decide what to do with one stored session whose writer may have crashed.
 *
 * Rules, in order:
 * 1. A log whose last turn has ended needs nothing (`balanced`).
 * 2. Subagent sessions belong to their parent's routing and archived
 *    sessions run no model step; both are left alone.
 * 3. The open turn is an automatic continuation when it carries this
 *    plugin's own message. It is held (`already-resumed`): continuing it
 *    again could repeat the crash. An open turn with no `user/message` at
 *    all that follows a turn closed as `interrupted` is held the same way,
 *    because `turn/start` is logged before the turn's message and such a
 *    turn may be this plugin's continuation that died in between. It may
 *    also be a scheduled turn that died at the same point; holding costs
 *    that one a card and never runs anything.
 * 4. A turn whose messages are all from something other than a person (a
 *    goal round, a schedule, a job notice) is left alone.
 * 5. A turn waiting on a person is held: an approval asked and never
 *    decided (`awaiting-approval`), or a listed question tool still open
 *    (`awaiting-answer`). Continuing it would turn the wait into a refusal
 *    or an unanswerable question.
 * 6. A session with an active goal is held (`goal-active`). The goal service
 *    disarms every goal when an agent is created for the session, so no
 *    driver continues it after a restart until a person resumes it; an
 *    automatic continuation would work toward that goal without that consent.
 * 7. A turn cut short by a deliberate stop is held (`stopped`).
 * 8. Anything else is continued once.
 * @param events - the complete stored log, without synthetic closers.
 * @param session - header and workspace facts for the same session.
 * @param options - this launch's tool list and quit flag.
 * @returns the verdict.
 */
export declare function judge(events: readonly JudgedEvent[], session: JudgedSession, options: JudgeOptions): Verdict;
//# sourceMappingURL=judge.d.ts.map