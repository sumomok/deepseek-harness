/**
 * The price tables this plugin ships with, transcribed from DeepSeek's own
 * pricing pages — one currency each, because DeepSeek bills two and publishes
 * a separate list for each.
 *
 * Sources, both read 2026-09-10:
 *
 * - CNY: https://api-docs.deepseek.com/zh-cn/quick_start/pricing, which states
 *   「空闲时段价格为高峰时段价格的一半。高峰时段为北京时间周一至周五 9:00 -
 *   12:00、14:00 - 18:00（其余为空闲时段）。」
 * - USD: https://api-docs.deepseek.com/quick_start/pricing, which states
 *   "Off-peak rates are half of the peak rates. Peak hours are 01:00 - 04:00
 *   and 06:00 - 10:00 UTC, Monday through Friday (all other hours are
 *   off-peak)."
 *
 * The two pages describe the same instants in their own timezones — 09:00
 * Beijing is 01:00 UTC — and each list is written in the zone its own page
 * uses rather than converted, so a reader can check either against its source.
 *
 * Both are expressed as the off-peak numbers in `base` plus a `peak` schedule
 * that doubles them, because the peak windows are two contiguous weekday spans
 * while the off-peak hours are their scattered complement. The resulting rates
 * are identical either way; `baseName: 'off-peak'` keeps the UI honest about
 * which tier the base is.
 *
 * Neither page prices cache-write tokens or reasoning tokens separately, so
 * both fields are left to their defaults: a cache write bills at the cache-miss
 * input rate and a reasoning token bills at the output rate.
 *
 * `deepseek-flash` is on neither page. Its rates come from DeepSeek's
 * open-platform notice of the Flash-series price change effective 2026-09-10
 * 12:00 Beijing (04:00 UTC), as relayed by
 * https://www.ithome.com/0/999/953.htm and
 * https://www.ithome.com/1/000/222.htm, in the same peak windows the pages
 * state. The same notice prices the Flash series as a whole, and the first
 * article applies it to `deepseek-v4-flash` and `deepseek-v4-flash-vision-exp`
 * as well; those two rows still carry what the official pages printed when
 * this file was read, which was unchanged.
 *
 * TODO: re-read both pricing pages and settle two questions against them —
 * whether the `deepseek-flash` row below matches what they publish for the
 * model, and whether `deepseek-v4-flash` and `deepseek-v4-flash-vision-exp`
 * moved to those same rates. Both pages still showed the three pre-notice rows
 * at 2026-09-10 04:51 UTC, 51 minutes after the change took effect.
 *
 * These numbers are the deployment's to maintain, and the currency set is
 * open — adding a third list is a third key under `tables`. Overriding
 * `prices` in `cordis.yml` replaces the whole table.
 *
 * @module @sumomok/dsh-balance/default-prices
 */
import type { PriceTable } from './prices.ts';
/** DeepSeek's published rates as of {@link DEFAULT_PRICES}.asOf, per 1M tokens. */
export declare const DEFAULT_PRICES: PriceTable;
//# sourceMappingURL=default-prices.d.ts.map