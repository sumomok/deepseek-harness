/**
 * Account balance and spend for the DeepSeek Harness web GUI.
 *
 * The question this answers is the one nothing in the harness answers today:
 * *how much is left, and how much has this cost*. The balance comes from the
 * provider's own account endpoint; the spend comes from usage the harness
 * already logs, multiplied by a price table the deployment owns. No pricing
 * page is scraped at runtime, and no number is invented — a model the table
 * does not price is reported as unpriced tokens rather than as zero.
 *
 * What this plugin touches:
 *
 * - The credential seam, once per balance read, for the provider API key. The
 *   key is never cached, never logged, never returned, and never put in a URL.
 * - The provider's configured origin, and nothing else on the network.
 * - Its own directory under the harness home, for a numbers-only spend ledger.
 * - The session-event feed, read-only. It appends no session event of its own.
 *
 * It registers no HTTP route. The browser half reaches it only through the
 * harness's `/api` Typert gateway, and every exported method is a read.
 *
 * @module @sumomok/dsh-balance
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session';
import { type BalanceRequest } from './balance.ts';
import { type Config, type ResolvedConfig } from './config.ts';
import { type LedgerRow } from './ledger.ts';
import { type PriceEntry, type PriceTable } from './prices.ts';
import type { BalanceView } from './types.ts';
export { balanceEndpoint, BalanceReader, parseAmount, parseBalanceResponse, readBalance, selectBalance } from './balance.ts';
export type { BalanceReaderOptions, BalanceRequest } from './balance.ts';
export { Config, resolveBalanceConfig } from './config.ts';
export type { ResolvedConfig, Surfaces } from './config.ts';
export { DEFAULT_PRICES } from './default-prices.ts';
export { dayKey, hostTimezone, Ledger, LEDGER_DIR, LEDGER_FILE, LEDGER_MODE, ledgerPath, parseLedgerRow } from './ledger.ts';
export type { LedgerOptions, LedgerRow } from './ledger.ts';
export { costOf, DEFAULT_BASE_SCHEDULE_NAME, isSupportedTimezone, isWallClockTime, pricesFor, resolvePriceTable, resolveRates, selectPriceCurrency, wallClockAt, windowContains, } from './prices.ts';
export type { CurrencyPrices, PriceEntry, PriceRates, PriceSchedule, PriceSubject, PriceTable, PriceWindow, ResolvedPrice, ResolvedRates, TokenCounts, } from './prices.ts';
export { AccountBalanceService } from './service.ts';
export { billingBuckets, priceStep, priceTableVersion, SESSION_SPEND_KEY, sessionSpendProjection, totalTokens, } from './session-spend.ts';
export type { PricedStep, SessionSpendState } from './session-spend.ts';
export type { BalanceUiConfig, BalanceUnavailableReason, BalanceView, SessionSpend, SessionSpendModel, SpendTotals, SpendView, } from './types.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "balance";
/**
 * Build the resolver the balance reader calls before every read.
 *
 * Connection facts are re-read per call and the key is resolved per call, both
 * on purpose: a key rotated through the Models page, or an endpoint changed in
 * settings, reaches the next poll without restarting anything.
 * @param ctx - the plugin context.
 * @param config - the resolved plugin config.
 * @returns a resolver yielding the next read's facts, or `null` while unconfigured.
 */
export declare function providerResolver(ctx: Context, config: ResolvedConfig): () => Promise<BalanceRequest | null>;
/**
 * Which currency's price list spend is computed against.
 *
 * The account's own billing currency decides it once a balance read reveals
 * one, because a CNY balance beside a USD spend total is two numbers nobody
 * can compare. Until then — and for an account whose currency the table does
 * not price — the configured preference decides. A change re-prices
 * everything, so listeners re-register what they derived from the old list.
 */
export declare class ActivePrices {
    private readonly table;
    private readonly preference;
    private readonly listeners;
    private code;
    /**
     * @param table - the resolved price table.
     * @param preference - configured currency preference, most wanted first.
     */
    constructor(table: PriceTable, preference: readonly string[]);
    /** The active ISO 4217 code. */
    get currency(): string;
    /** The active currency's price list. */
    get entries(): readonly PriceEntry[];
    /**
     * Adopt the account's own billing currency when a balance read reveals it.
     * @param view - the balance read; anything but a successful one is ignored.
     */
    observe(view: BalanceView): void;
    /**
     * Subscribe to currency changes.
     * @param listener - receives the new ISO 4217 code.
     * @returns the unsubscriber.
     */
    onChange(listener: (currency: string) => void): () => void;
}
/**
 * Turn one logged assistant step into a ledger row.
 * @param active - the active currency selection, supplying the price list the
 * row is written in; a row records the currency it was priced in so a later
 * switch cannot fold it into another currency's total.
 * @param session - the session the step belonged to.
 * @param event - the `assistant/message` event carrying the step's usage.
 * @returns the row, or `null` when the step reported no usage.
 */
export declare function ledgerRowOf(active: ActivePrices, session: Pick<Session, 'id'>, event: SessionEvent): LedgerRow | null;
/**
 * Mount the balance and spend capability.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map