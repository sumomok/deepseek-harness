/**
 * Browser half: the sidebar-footer balance chip and the per-session spend line.
 *
 * The only host path is the Typert Remote this package's host half exports —
 * two reads, no mutators — mounted here through `ctx.remote.$mount()`. This
 * plugin fetches nothing itself and knows no key, no endpoint, and no prompt.
 *
 * @module @sumomok/dsh-balance/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type BalanceKey } from './locales.ts';
import { type BalanceStore } from './store.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@sumomok/dsh-balance` copy. */
        balance: BalanceKey;
    }
}
export type { FooterChipProps } from './FooterChip.tsx';
export type { SessionSpendLineProps } from './SessionSpendLine.tsx';
export type { BalanceApi, BalanceState, BalanceStore } from './store.ts';
/** Required browser services. */
export declare const inject: string[];
/**
 * Start the shared polling loop.
 *
 * A hidden tab polls nothing: the numbers are only interesting to someone
 * looking at them, and the tick after the tab comes back is the one that
 * matters. The host's own cache means several visible tabs still cost the
 * provider one request per refresh window.
 *
 * `window.setInterval` rather than the `timer` service: this bundle is a real
 * module-table client bundle, where the browser globals are not withheld, and
 * the `timer` service is provided by an extension a composition need not
 * include. Disposal stays cordis-owned through the effect that starts it.
 * @param store - the store to refresh.
 * @param everyMs - the poll period.
 * @returns a disposer stopping the loop.
 */
export declare function startPolling(store: BalanceStore, everyMs: number): () => void;
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 */
export declare function apply(ctx: ClientContext): Promise<void>;
//# sourceMappingURL=index.d.ts.map