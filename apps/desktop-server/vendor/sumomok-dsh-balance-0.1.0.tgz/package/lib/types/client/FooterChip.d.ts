/**
 * The sidebar-footer chip: the remaining balance, and a popover breaking down
 * the balance and this installation's spend.
 *
 * Nothing renders while the plugin is unconfigured — no key, or an endpoint
 * this plugin may not talk to. An unconfigured deployment should see the
 * sidebar it had before installing this plugin, not a placeholder explaining
 * that a feature it did not ask for is not working.
 *
 * @module @sumomok/dsh-balance/client/FooterChip
 */
import { type ReactNode } from 'react';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { BalanceState } from './store.ts';
/** A `useSyncExternalStore`-backed selector hook, as the slot framework binds it. */
type BalanceHook = <S>(selector: (state: BalanceState) => S) => S;
/** Props the chip reads from its composed slot props. */
export interface FooterChipProps {
    /** Whether the sidebar renders wide content; `false` is the 56px rail. */
    wide: boolean;
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'balance'>;
    /** Selector over the browser half's own store. */
    useBalance: BalanceHook;
    /** Read both faces again, bypassing the host's refresh window. */
    refresh: (force: boolean) => void;
}
/**
 * The registered slot component.
 * @param props - composed slot props.
 * @returns the chip, or nothing while unconfigured.
 */
export declare function FooterChip(props: FooterChipProps): ReactNode;
export {};
//# sourceMappingURL=FooterChip.d.ts.map