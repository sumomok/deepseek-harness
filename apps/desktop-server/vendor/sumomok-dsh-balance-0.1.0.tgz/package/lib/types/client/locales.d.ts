/**
 * Copy for the browser half, in the two locales the harness ships.
 *
 * @module @sumomok/dsh-balance/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "balance";
/** Every key the browser half looks up. */
export type BalanceKey = 'title' | 'clickToRefresh' | 'granted' | 'toppedUp' | 'total' | 'suspended' | 'stale' | 'updated' | 'unavailable' | 'reason.http' | 'reason.network' | 'reason.timeout' | 'reason.malformed' | 'spend.title' | 'spend.today' | 'spend.month' | 'spend.allTime' | 'spend.since' | 'spend.sinceEmpty' | 'spend.pricesAsOf' | 'spend.unpriced' | 'spend.session' | 'spend.requests';
/** English copy. */
export declare const en: Record<BalanceKey, string>;
/** Chinese copy. */
export declare const zh: Record<BalanceKey, string>;
//# sourceMappingURL=locales.d.ts.map