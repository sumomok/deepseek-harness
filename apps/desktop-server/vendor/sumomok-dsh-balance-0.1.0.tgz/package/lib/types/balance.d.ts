/**
 * Reading the provider's account balance: where to ask, how to read the
 * answer, and how often to ask again.
 *
 * The API key is never held here. Every read resolves it through the
 * credential seam and drops it when the request completes, which is what makes
 * a rotated key reach the next poll without a restart. What is cached is the
 * *answer*, so a browser tab per monitor does not multiply into a request per
 * monitor.
 *
 * @module @sumomok/dsh-balance/balance
 */
import type { BalanceView } from './types.ts';
/** A successful read, before staleness is decided at serve time. */
type OkView = Extract<BalanceView, {
    state: 'ok';
}>;
/** A failed read. */
type UnavailableView = Extract<BalanceView, {
    state: 'unavailable';
}>;
/** One `balance_infos` row, as the provider documents it. */
interface BalanceInfo {
    currency: string;
    total_balance: string;
    granted_balance: string;
    topped_up_balance: string;
}
/** The endpoint's response body. */
interface BalanceResponse {
    is_available: boolean;
    balance_infos: BalanceInfo[];
}
/**
 * Derive the balance endpoint from a chat-completions base URL.
 *
 * Providers are configured with the URL their chat client uses, which may or
 * may not carry an API-version segment; the account endpoint sits beside that
 * segment rather than under it. Exactly one trailing `/v<digits>` is removed,
 * so `https://api.deepseek.com/v1` and `https://api.deepseek.com` both reach
 * the same place, and a path that genuinely ends in something else is left
 * alone.
 * @param baseURL - the configured provider base URL.
 * @returns the absolute balance endpoint, or `null` when the base URL is not a
 * usable http(s) URL.
 */
export declare function balanceEndpoint(baseURL: string): string | null;
/**
 * Select the balance row to show.
 * @param infos - the response's rows.
 * @param preference - currency codes in descending preference.
 * @returns the first row matching the preference, else the first row, else `undefined`.
 */
export declare function selectBalance(infos: readonly BalanceInfo[], preference: readonly string[]): BalanceInfo | undefined;
/**
 * Read a balance amount as a number for threshold comparisons. Display keeps
 * the provider's own string; only the tint thresholds need arithmetic.
 * @param value - a decimal string from the response.
 * @returns the number, or `null` when the text is not a decimal.
 */
export declare function parseAmount(value: string): number | null;
/**
 * Narrow a decoded response body to the fields this plugin renders.
 * @param body - the parsed JSON body.
 * @returns the validated response, or `null` when a required field is missing
 * or is not the documented type.
 */
export declare function parseBalanceResponse(body: unknown): BalanceResponse | null;
/** Everything one read needs, resolved fresh by the caller. */
export interface BalanceRequest {
    /** The absolute balance endpoint. */
    endpoint: string;
    /** The API key, held only for the duration of the call. */
    apiKey: string;
    /** Currency codes in descending preference. */
    currency: readonly string[];
    /** Wall-clock budget for the request. */
    timeoutMs: number;
}
/** The collaborators one reader needs, so tests can supply their own. */
export interface BalanceReaderOptions {
    /** Resolve the facts of the next read, or `null` while unconfigured. */
    resolve: () => Promise<BalanceRequest | null>;
    /** Epoch milliseconds. */
    now: () => number;
    /** How long a successful read is served before a refresh is attempted. */
    refreshMs: number;
    /** How long a failed read suppresses further attempts. */
    retryMs: number;
    /** The HTTP client; the global `fetch` in production. */
    fetch: typeof globalThis.fetch;
}
/**
 * Perform one balance read.
 * @param request - the resolved endpoint, key, and budget.
 * @param at - epoch milliseconds stamped on the result.
 * @param fetchImpl - the HTTP client.
 * @returns the read's outcome; never a partial or a thrown network error.
 */
export declare function readBalance(request: BalanceRequest, at: number, fetchImpl: typeof globalThis.fetch): Promise<OkView | UnavailableView>;
/**
 * The cache in front of the provider.
 *
 * Concurrent callers share one in-flight request, a success is served for the
 * refresh window, and a failure suppresses attempts for the retry window so a
 * broken endpoint is not hammered once per open tab. When a refresh fails but
 * an earlier read succeeded, the earlier numbers are served marked `stale`
 * rather than replaced by a dash: a balance from a minute ago is worth more to
 * the reader than no balance at all, as long as it says so.
 */
export declare class BalanceReader {
    private readonly options;
    private inflight;
    private lastOk;
    private lastFailure;
    /**
     * @param options - resolution, clock, windows, and HTTP client.
     */
    constructor(options: BalanceReaderOptions);
    /**
     * Read the balance, from cache when the cache is still valid.
     * @param force - bypass the refresh and retry windows; an in-flight read is
     * still joined rather than duplicated.
     * @returns the view to render.
     */
    get(force?: boolean): Promise<BalanceView>;
    /** The cached answer, or `undefined` when a fresh read is due. */
    private cached;
    /** Perform the read and fold its outcome into the cache. */
    private refresh;
}
export {};
//# sourceMappingURL=balance.d.ts.map