/**
 * The browser half's stylesheet, injected once as a tagged `<style>`.
 *
 * Every colour is a harness theme variable rather than a literal, so the
 * chooser, the blocked message, and the switched note follow the light and
 * dark schemes the shell already switches between.
 *
 * The chooser rules restate `ui-user-questions`' own question-card sheet —
 * card frame, row list, footer, and the 720px narrow-viewport step — against
 * the same variables. They are a restatement rather than an import because
 * that sheet is a CSS module whose class names the host's build hashes, and
 * a plugin bundle can neither name them nor import the module.
 *
 * @module @haoran/dsh-vision-switch/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-vision-switch";
/**
 * Put the stylesheet in the document, once.
 * @returns a disposer removing the tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map