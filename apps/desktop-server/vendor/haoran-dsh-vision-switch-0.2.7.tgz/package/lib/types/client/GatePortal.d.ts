/**
 * The `document.body` portal fallback: renders whatever `GateDock` would
 * have, for a session whose `conversation.composer.dock` entry has not
 * mounted yet.
 *
 * The host only renders that dock slot once a session has a turn in its
 * history (`ConversationRoot.tsx`'s `footer: !hero && zone !== undefined
 * ? renderSlot('conversation.composer.dock', zone) : null` — `hero` is
 * true for a session's blank first turn). Case 2 (the chooser) and case 3
 * (blocked) both hold the send back before any turn exists, so on a brand
 * new session's very first message the dock has nowhere to draw and a
 * click that should open the chooser, or explain why sending is refused,
 * would otherwise do nothing the user can see. `conversation.input.dock`
 * does not have that gap — the host renders it unconditionally once a
 * session and its input machine are both live (`{zone !== undefined &&
 * renderSlot('conversation.input.dock', zone)}`, computed before `hero` is
 * even consulted) — so this component is mounted there instead, purely as
 * a stable host for its own `useSyncExternalStore`/`useEffect` hooks; it
 * renders nothing into that seat itself.
 *
 * Sibling package `@sumomok/dsh-text-drop`'s `DragHintStrip` established
 * the pattern this mirrors: portal to `document.body`, not merely a high
 * `position: fixed` z-index. That component's module doc records the
 * measured cause — a `position: fixed` element left nested in the
 * composer's own DOM subtree can paint its background but not its own
 * text over a `backdrop-filter` host layer, a compositing interaction of
 * that filter with nested fixed descendants, not a CSS mistake fixable by
 * z-index alone. The identical markup appended as a late top-level sibling
 * of the host's own overlay nodes — exactly where a portal lands it —
 * paints correctly, which is why `createPortal` is required here too
 * rather than an equivalent style-only placement.
 *
 * Which of `GateDock` and this component is responsible for the current
 * status is `selectGateSurface`'s call, never a decision this component
 * makes on its own: it reads `gate.dockMounts` (incremented/decremented by
 * `GateDock`'s own mount effect) and defers whenever that count is
 * nonzero, so the two surfaces structurally cannot both render the same
 * status at once.
 *
 * Case 2 (the chooser) is a focused picker: a click outside the portaled
 * panel dismisses it exactly the way its own Cancel button does —
 * `gate.cancel()`, aborting the send with the draft intact. Escape does the
 * same, but from `VisionChooser`'s own document listener rather than from
 * here, so the docked seat answers that key identically. Case 3
 * (blocked) is a non-modal notice with no dismiss control of its own; it
 * self-hides after `SWITCHED_STATUS_MS` — the same duration
 * `submit-gate.ts` already uses to self-clear the switched note — so a
 * session with no vision-capable model anywhere does not leave a
 * fixed-position notice on screen indefinitely. That auto-hide is local to
 * this component (it does not touch the shared `gate.store`): the docked
 * seat's own rendering of a lingering `blocked` status, should the dock
 * mount later, is unaffected. The switched note needs no separate timer
 * here — `submit-gate.ts`'s `runSwitch` already clears it back to idle on
 * the same shared store this component reads, regardless of which surface
 * is displaying it at the time.
 *
 * @module @haoran/dsh-vision-switch/client/GatePortal
 */
import { type ReactNode } from 'react';
import type { SessionId } from '@deepseek-ai/dsh-api-remotes/client';
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { GateRegistry } from './gate-registry.ts';
import type { VisionSwitchKey } from './locales.ts';
/** Owner-supplied props this entry reads; everything else about the seat's own layout is the host's. */
export interface GatePortalOwnProps {
    /** Current session id; this entry is session-scoped, so this is always live where it renders. */
    readonly sessionId?: SessionId | undefined;
}
/** What the component needs from the plugin install. */
export interface GatePortalDeps {
    /** The registry that installs and tracks each session's gate. */
    readonly registry: GateRegistry;
    /** Translate bound to this plugin's own namespace. */
    readonly t: Translate<VisionSwitchKey>;
}
/**
 * Build the portal-fallback entry.
 * @param deps - the gate registry and this plugin's own translate.
 * @returns the component to register at `conversation.input.dock`.
 */
export declare function createGatePortal(deps: GatePortalDeps): (props: GatePortalOwnProps) => ReactNode;
//# sourceMappingURL=GatePortal.d.ts.map