/**
 * Copy for the surfaces this plugin owns: the model chooser, the blocking
 * message, the switched-note, and the settings section.
 *
 * @module @haoran/dsh-vision-switch/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "visionSwitch";
/** Chinese copy (the dictionary that defines the key domain). */
export declare const zh: {
    'chooser.title': string;
    'chooser.confirm': string;
    'chooser.cancel': string;
    'blocked.message': string;
    'switched.note': string;
    'settings.nav': string;
    'settings.intro': string;
    'settings.enabled.on': string;
    'settings.enabled.off': string;
    'settings.target': string;
    'settings.targetUnavailable': string;
    'settings.models.count': string;
    'settings.models.none': string;
    'settings.loading': string;
    'settings.failed': string;
};
/** English copy. */
export declare const en: Record<VisionSwitchKey, string>;
/** Dictionary key domain. */
export type VisionSwitchKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map