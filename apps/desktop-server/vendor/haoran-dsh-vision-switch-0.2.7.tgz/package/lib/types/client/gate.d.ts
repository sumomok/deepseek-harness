/**
 * Send-attempt gating: resolve what a submit with images should do, using
 * the model the composer's own picker already displays plus this plugin's
 * vision-capable catalog, and write through `session.selectModel` — the same
 * call a manual pick in the model popup or the composer's model seat makes.
 *
 * The read is not this plugin's own derivation of "the session's model". The
 * effective selection is `projected.next ?? catalog.default`: the session's
 * durable `modelSelection` projection when it carries one, and the
 * deployment default (`agentDefaultModel`, a live user setting) when it does
 * not. `ui-model-selection`'s per-session `ModelDirectory` owns that
 * resolution for the popup and the seat, and `ctx.modelDirectories`
 * (`ModelDirectoryResolver`) hands out the same instance both entries read,
 * so this gate reads it there rather than recomputing it. A session whose
 * projection is empty — every conversation that has not yet sent a
 * message — has no `next` and no `lastUsed`, and reading only the projection
 * resolves nothing while the picker, and the host's own image gate, both
 * resolve the deployment default.
 *
 * @module @haoran/dsh-vision-switch/client/gate
 */
import type { ModelSelection, SessionId } from '@deepseek-ai/dsh-api-remotes/client';
import type { SessionSelectModelRequest, SessionSelectModelValue } from '@deepseek-ai/dsh-api-session-controller/types';
import type { ModelDirectory, ModelDirectoryResolver } from '@deepseek-ai/dsh-client-ui-model-selection/client';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import { type VisionSwitchDecision } from '../core/decision.ts';
import type { ModelPin } from '../types.ts';
import type { CatalogCache } from './catalog-cache.ts';
/** One session's model directory, narrowed to what this plugin reads off the picker's own state. */
export interface ModelDirectoryFace {
    /**
     * The directory snapshot both selection entries render from. `current` is
     * the effective selection, and it is null in two states: while the shared
     * model catalog has not loaded (or failed), which {@link load} settles, and
     * while the session's `modelSelection` projection row has not arrived at
     * all, which it does not — `ModelDirectory.syncInputs` treats an
     * `undefined` projection snapshot exactly as it treats an unready catalog,
     * and the row is a push frame no read of this plugin's can hurry.
     */
    readonly store: {
        getSnapshot(): {
            readonly current: ModelSelection | null;
        };
    };
    /**
     * Ensure the Host-generation model catalog behind `current` is loaded,
     * joining the resolver's own in-flight read rather than starting a second.
     * @returns the fresh directory value, which this plugin ignores in favor of the store.
     */
    load(): Promise<unknown>;
}
/** `ctx.modelDirectories` (`ModelDirectoryResolver`), narrowed to the one call this plugin makes. */
export interface ModelDirectoriesFace {
    /**
     * Resolve the session's shared directory — the same instance the /model
     * popup and the composer's model seat both read.
     * @param sessionId - the session to resolve.
     * @returns the resident directory.
     * @throws when the session resolves no live scope or binding.
     */
    directoryFor(sessionId: SessionId): ModelDirectoryFace;
}
/** Constrains a real picker type to the narrow face this plugin declares for it. */
type Conforms<T extends F, F> = T;
/**
 * The real picker service and directory, each constrained to the face above:
 * a rename or retype of `directoryFor`, of `store.getSnapshot().current`, or
 * of `load` in `@deepseek-ai/dsh-client-ui-model-selection` fails `tsc` here
 * rather than degrading a live composer to a gate that resolves nothing —
 * the failure mode this plugin's 0.2.3 fix exists to remove.
 */
export type PickerService = Conforms<ModelDirectoryResolver, ModelDirectoriesFace>;
export type PickerDirectory = Conforms<ModelDirectory, ModelDirectoryFace>;
/** The one read and the one write this gate needs around a session's model selection. */
export interface ModelSelectionFace {
    /**
     * The model the composer's picker currently displays for this session.
     * @param sessionId - the session to read.
     * @returns the effective selection, or undefined when the picker itself resolves none.
     * @throws when the session has no live directory, or the shared catalog read fails.
     */
    effectiveSelection(sessionId: SessionId): Promise<ModelSelection | undefined>;
    /**
     * Apply a model switch through the same Remote call a manual pick in the
     * model popup or the composer's model seat makes.
     * @param request - session identity and requested selection.
     * @returns the Remote result.
     */
    selectModel(request: SessionSelectModelRequest): Promise<RemoteResult<SessionSelectModelValue>>;
}
/**
 * Log one line naming why a send left this gate without a decision, and
 * report the stand-aside to the caller. Falling open is correct behavior —
 * a broken read must never cost a send — but a silent one is undiagnosable
 * from the field, where the only visible symptom is the host's own refusal.
 * @param reason - what could not be resolved, in this plugin's own words.
 * @param error - the failure that caused it, when there was one.
 * @returns the degraded marker, so a caller can `return standAside(...)`.
 */
export declare function standAside(reason: string, error?: unknown): 'degraded';
/**
 * Read the effective selection off the picker's own per-session directory.
 *
 * A null `current` gets one `load()`, which joins the resolver's in-flight
 * catalog read; a directory whose projection row has not arrived stays null
 * through it and resolves undefined, exactly as the picker itself shows
 * nothing there. A directory that cannot be resolved at all throws, which
 * the caller treats as a genuinely missing session.
 * @param directories - the `ctx.modelDirectories` service.
 * @param sessionId - the session to read.
 * @returns the effective selection, or undefined when the picker resolves none either.
 * @throws when the session resolves no directory, or the catalog load fails.
 */
export declare function effectiveSelection(directories: ModelDirectoriesFace, sessionId: SessionId): Promise<ModelSelection | undefined>;
/**
 * Resolve a send-attempt decision, or `'degraded'` when the session's own
 * model cannot be resolved at all — an unreachable session or a broken
 * catalog read must never block sending, so the caller treats `'degraded'`
 * as "proceed, exactly as the host would have handled it without this
 * plugin". A selection the picker does resolve is never degraded, whatever
 * it names: an id the catalog no longer advertises is precisely the case
 * this plugin exists to switch away from.
 * @param selection - the picker read and the session write.
 * @param catalog - this plugin's own catalog cache.
 * @param sessionId - the session the draft belongs to.
 * @param hasImageAttachment - whether the draft carries at least one image
 * attachment. A draft of text plus non-image files is indistinguishable here
 * from a draft with nothing attached: both proceed untouched, because a
 * model's image support has no bearing on either.
 * @returns the decision, or `'degraded'` when nothing could be resolved.
 */
export declare function resolveGate(selection: ModelSelectionFace, catalog: CatalogCache, sessionId: SessionId, hasImageAttachment: boolean): Promise<VisionSwitchDecision | 'degraded'>;
/**
 * Perform the switch — the identical call a manual pick in the model popup
 * or the composer's model seat makes, so the result is session-sticky with
 * no separate persistence path of this plugin's own.
 * @param selection - the picker read and the session write.
 * @param sessionId - the session to switch.
 * @param target - the provider/model to select.
 * @throws when the host rejects the switch.
 */
export declare function applySwitch(selection: ModelSelectionFace, sessionId: SessionId, target: ModelPin): Promise<void>;
export {};
//# sourceMappingURL=gate.d.ts.map