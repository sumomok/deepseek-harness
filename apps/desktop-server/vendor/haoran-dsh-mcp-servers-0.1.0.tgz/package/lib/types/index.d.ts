/**
 * Connect external MCP tool servers from the Settings page.
 *
 * The harness already ships a client for one MCP server per composition entry
 * (`@deepseek-ai/dsh-mcp-client`), which requires editing a YAML file and
 * restarting. This plugin drives that client from a settings document instead,
 * so servers are added, switched off, and removed while the app runs, and adds
 * the two decisions a desktop needs on top of it:
 *
 * - A server connects only after someone confirmed that exact destination.
 *   Editing the command, arguments, URL, headers, or environment retires the
 *   confirmation, because the destination is no longer the one they agreed to.
 * - A tool reaches the model only after someone ticked that exact wording. A
 *   server may change its tool list at any time, so the tick is pinned to a
 *   fingerprint of the name, description, and input schema: a rewritten tool
 *   goes back to pending and stays out of every request until it is approved
 *   again.
 *
 * With no server stored the plugin registers no tool, starts no process, and
 * costs nothing in any request.
 *
 * What it touches: the settings document under its own namespace, the
 * credential seam (once per connection, for an HTTP header that names a saved
 * credential), and the tool registry through a per-server gate. It appends no
 * session event and registers no HTTP route.
 *
 * @module @haoran/dsh-mcp-servers
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.ts';
export { Config, MAX_TIMEOUT_MS, resolveTimeouts } from './config.ts';
export type { ConfirmChannel, ResolvedTimeouts } from './config.ts';
export { approvalConfirmer, resolveConfirmer, settingsConfirmer } from './confirm.ts';
export type { ServerConfirmer, ServerConnectRequest } from './confirm.ts';
export { credentialNames, resolveConnection, resolveNamedValues } from './credentials.ts';
export { canonicalJson, endpointFingerprint, isConfirmed, toolFingerprint } from './fingerprint.ts';
export { McpServersService } from './service.ts';
export { EMPTY_SECTION, parseDocument, SERVER_ID_PATTERN, Settings } from './settings-document.ts';
export type { McpServersSection } from './settings-document.ts';
export { MCP_SERVERS_SETTINGS_NAMESPACE_NAME } from './settings-namespace.ts';
export { buildClientConfig, describeEndpoint, endpointHasQuery, ServerSpecError } from './spec.ts';
export type { ResolvedEntry } from './spec.ts';
export { McpSupervisor } from './supervisor.ts';
export { ToolGate } from './tool-gate.ts';
export type { ToolRegistrar } from './tool-gate.ts';
export type { ApprovedTool, McpServersDocument, McpServerView, McpToolView, NamedValue, ServerReason, ServerRecord, ServerStatus, ServerTransport, } from './types.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "mcp-servers";
/** Required host services. */
export declare const inject: string[];
/**
 * Mount the MCP server capability.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map