/**
 * Keeps the running MCP connections equal to what the settings document says.
 *
 * One server is one child fiber holding one upstream MCP client plugin, so
 * removing a server disposes exactly that connection and nothing else. Inside
 * that fiber the tool registry is stood in for by the server's own
 * {@link ToolGate} — see that module for the property-access invariant the
 * substitution rests on — which is what makes an unapproved tool invisible
 * rather than merely unusable.
 *
 * Work is serialized PER SERVER, not across all of them. One server that
 * accepts a connection and then says nothing must not hold up the others, and
 * the MCP SDK's own `initialize` deadline is a minute long and not reachable
 * from here, so a first connection is additionally raced against this plugin's
 * own budget: past it the attempt is released — see {@link ForkEffects} — and
 * the server is reported as timed out, with nothing of it ever registered.
 *
 * Only three things restart a connection: the destination changed, a
 * credential behind it changed, or the server left and came back. Approving or
 * withdrawing a tool never does, because that is a registry change the gate
 * applies against the open connection.
 *
 * @module @haoran/dsh-mcp-servers/supervisor
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ServerConfirmer } from './confirm.ts';
import type { McpServerView, ServerRecord } from './types.ts';
/** A disposer the upstream plugin registered on its own fiber. */
type ForkDisposer = () => unknown;
/**
 * The effect disposers one fork's upstream plugin registered, so a first
 * connection this plugin gave up on can be released instead of waited for.
 *
 * A cordis fiber cannot be unloaded while its startup is still running:
 * `dispose()` records the epoch and then awaits the in-flight load, because
 * `_setEpoch` returns early while `inertia` is set. That load is the upstream
 * plugin's `apply`, which is awaiting `connection.ready` behind the MCP SDK's
 * minute-long `initialize` deadline, so disposing the fiber would wait out
 * exactly the deadline this plugin's budget exists to escape. Running the
 * upstream plugin's own disposers instead closes its client — which makes
 * `initialize` reject and its `apply` throw — and releases its `serverName`
 * reservation, so the next attempt at the same server is not refused as a
 * duplicate.
 *
 * Exported for `tests/supervisor.spec.ts`, which is the only way to reach the
 * arrive-after-release path: the upstream plugin registers both its effects
 * within microtasks of the mount, so no timer this plugin can set expires
 * first.
 */
export declare class ForkEffects {
    private readonly onError;
    private readonly disposers;
    private released;
    /** Every teardown started here, chained so a late arrival is still awaited. */
    private settling;
    /** @param onError - receives a disposer's failure; one must not stop the rest. */
    constructor(onError: (error: unknown) => void);
    /**
     * Take one disposer the upstream plugin just registered.
     *
     * A budget short enough to expire before the upstream plugin has registered
     * anything makes the ARRIVING disposer the one that closes the client, so it
     * is disposed on arrival and joined to {@link ForkEffects.release}'s
     * settlement rather than left running unwatched.
     * @param disposer - the disposer to hold.
     */
    capture(disposer: ForkDisposer): void;
    /**
     * Run every held disposer, newest first, and dispose any that arrive later
     * on arrival.
     * @returns settlement once every teardown started so far has finished.
     */
    release(): Promise<void>;
    /** Run one disposer, containing its failure. */
    private run;
}
/** Keeps live MCP connections equal to the settings document. */
export declare class McpSupervisor {
    private readonly ctx;
    private readonly toolCallTimeoutMs;
    private readonly connectTimeoutMs;
    private readonly mounted;
    private readonly failures;
    /** One serialized work chain per server id, so a slow server blocks only itself. */
    private readonly chains;
    /** Server ids with work in flight, which the view reports as connecting. */
    private readonly working;
    /** Attempts being let go of, which disposal waits for. */
    private readonly abandoned;
    private records;
    private confirmer;
    private stopped;
    /** Resolves at disposal, releasing every in-flight first connection at once. */
    private readonly cancelled;
    /**
     * @param ctx - the plugin context owning the child fibers.
     * @param toolCallTimeoutMs - per-tool-call timeout handed to every connection.
     * @param connectTimeoutMs - budget for one server's first connection.
     * @param confirmer - the channel that answers whether a server may connect.
     */
    constructor(ctx: Context, toolCallTimeoutMs: number, connectTimeoutMs: number, confirmer: ServerConfirmer);
    /**
     * Replace the channel that answers whether a server may connect.
     * @param confirmer - the replacement channel.
     * @returns the disposer restoring the previous channel.
     */
    useConfirmer(confirmer: ServerConfirmer): () => void;
    /**
     * Bring the live connections in line with these records.
     *
     * Servers are brought up in parallel and each one's work is serialized
     * against its own earlier work, so two quick edits to one server apply in
     * order while a server that never answers holds up nothing else.
     * @param records - the readable records, in document order.
     * @returns settlement once every server's share of this pass finished.
     */
    sync(records: readonly ServerRecord[]): Promise<void>;
    /**
     * What the settings page shows, one entry per record in document order.
     * @returns the views.
     */
    views(): McpServerView[];
    /**
     * Whether any stored record names one of these credential references, so a
     * change to it is worth a reconnect.
     * @param names - reference names that changed.
     * @returns true when at least one record names one of them.
     */
    usesCredential(names: ReadonlySet<string>): boolean;
    /**
     * Stop every connection and refuse further passes.
     *
     * A first connection still in flight is released rather than waited on: its
     * gate is disposed immediately, so nothing it might yet register can reach
     * the model, and its upstream effects are released in the background so the
     * fiber unwinds without this call waiting for the transport to shut down.
     * @returns settlement after every live connection is unmounted.
     */
    dispose(): Promise<void>;
    /** Which status one record is in right now. */
    private statusOf;
    /** Append one server's work to its own chain. */
    private enqueue;
    /** Bring one wanted record to a live connection, or record why it is not. */
    private apply;
    /**
     * Start letting go of a first connection this plugin gave up on, without
     * holding this pass for it.
     * @param fiber - the abandoned fork.
     * @param effects - the upstream plugin's own disposers.
     */
    private startAbandon;
    /**
     * Let go of a first connection this plugin gave up on.
     *
     * Order matters: the upstream effects go first, because disposing the fiber
     * before its startup settled would wait out the very deadline the budget
     * escaped — see {@link ForkEffects}.
     * @param fiber - the abandoned fork.
     * @param effects - the upstream plugin's own disposers.
     * @returns settlement once the fork unwound.
     */
    private abandon;
    /** Record why one server is not running, unless disposal already started. */
    private fail;
    /** Stop one connection, if it is running. */
    private unmount;
}
export {};
//# sourceMappingURL=supervisor.d.ts.map