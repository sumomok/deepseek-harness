/**
 * The settings document this plugin owns, and its durable-boundary parse.
 *
 * Two layers, deliberately: the schemastery schema handed to
 * `SettingsProvider.installSection` accepts any array of records, because a
 * schema failure there refuses the whole registration and would strand every
 * server over one bad row; the zod parse below then judges each record on its
 * own and drops only the ones it cannot read, warning about each.
 *
 * @module @haoran/dsh-mcp-servers/settings-document
 */
import s from '@deepseek-ai/schemastery';
import type { McpServersDocument } from './types.ts';
/**
 * A server id: the tool-name namespace, so it is limited to what the
 * harness's own `serverName` grammar accepts (`[A-Za-z0-9_-]{1,32}`),
 * narrowed further to lowercase so two records cannot differ by case alone.
 */
export declare const SERVER_ID_PATTERN: RegExp;
/** The section as the settings seam stores it, before per-record judgement. */
export interface McpServersSection {
    /** Stored server records; each one is judged by {@link parseDocument}. */
    servers?: unknown[];
}
/**
 * The namespace schema. It describes the section's outer form only — see this
 * module's own note on why the records stay `any` here.
 */
export declare const Settings: s<McpServersSection>;
/** The section value a composition without a stored document resolves to. */
export declare const EMPTY_SECTION: McpServersSection;
/**
 * Read the stored section into records this plugin can act on.
 *
 * A record it cannot read is dropped with a warning rather than failing the
 * document: one hand-edited row must not take every other server offline.
 * @param section - the resolved settings section, as the seam produced it.
 * @param warn - receives one message per dropped record.
 * @returns the readable records, in document order, ids unique.
 */
export declare function parseDocument(section: unknown, warn: (message: string) => void): McpServersDocument;
//# sourceMappingURL=settings-document.d.ts.map