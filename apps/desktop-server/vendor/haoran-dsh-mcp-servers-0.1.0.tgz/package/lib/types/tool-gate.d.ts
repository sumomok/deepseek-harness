/**
 * The per-server gate between the upstream MCP client plugin and the harness
 * tool registry.
 *
 * The upstream plugin registers every tool its server lists, straight onto
 * `ctx.tools`. This gate stands in for that service inside the one context the
 * upstream plugin runs in, so a tool the person has not approved is never
 * registered at all, rather than blocked at call time. An unregistered tool is
 * absent from the model's schema list, which is the only way to keep an
 * unreviewed tool out of the request entirely.
 *
 * **Invariant this rests on: the upstream plugin reaches the registry only
 * through the `ctx.tools` PROPERTY.** A context's own property shadows a
 * property read, not `ctx.get('tools')`, which resolves through the service
 * store and would return the real registry — so an upstream version that
 * switched to `ctx.get('tools')`, or that took a registry reference from
 * anywhere else, would register straight past this gate and every unapproved
 * tool would reach the model. `tests/tool-service-substitution.spec.ts` pins
 * the invariant against the real upstream plugin: it fails if a registration
 * ever arrives at the real registry instead of here.
 *
 * Approval is pinned to wording, not to a name: the fingerprint covers the
 * tool's name, description, and input schema, so a server that rewrites any of
 * them offers something the person has not seen, and it returns to pending
 * until they approve it again.
 *
 * @module @haoran/dsh-mcp-servers/tool-gate
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { ApprovedTool, McpToolView } from './types.ts';
/** The one `ctx.tools` member the upstream MCP client plugin uses. */
export interface ToolRegistrar {
    /**
     * Register one tool and return its unregister disposer.
     * @param definition - the complete tool definition.
     * @returns the disposer that unregisters it.
     */
    register(definition: ToolDefinition): () => void;
}
/**
 * One server's gate. It is both the stand-in tool service handed to the
 * upstream plugin and the read model the settings page renders.
 */
export declare class ToolGate implements ToolRegistrar {
    private readonly target;
    private readonly onError;
    private readonly entries;
    private approved;
    private lastCallFailure;
    private disposed;
    /**
     * @param target - the real tool registry an approved tool reaches.
     * @param approved - the tools the person has admitted.
     * @param onError - receives a registration failure raised outside the
     *   upstream plugin's own transaction, which is the case when an approval is
     *   switched on against an already open connection.
     */
    constructor(target: ToolRegistrar, approved: readonly ApprovedTool[], onError: (error: unknown) => void);
    /**
     * Take one tool from the upstream plugin, forwarding it to the real registry
     * only while it is approved.
     *
     * A throw here reaches the upstream plugin's own rollback, which is what
     * keeps a partially registered generation from ever becoming visible.
     *
     * After {@link ToolGate.dispose} it accepts nothing: a connection this
     * plugin has let go of can still be mid-sync, and a late registration would
     * put a tool back in front of the model for a server that is gone.
     * @param definition - the tool definition the upstream plugin built.
     * @returns the disposer the upstream plugin owns for this tool; a no-op once
     *   this gate is disposed.
     */
    register(definition: ToolDefinition): () => void;
    /**
     * Adopt a new approval set, registering and unregistering to match it.
     *
     * This is why approving a tool does not restart its server: ticking it in the
     * settings page moves it into the registry against the connection that is
     * already open. A registration that fails here is outside the upstream
     * plugin's transaction, so it is reported on that tool's own row instead of
     * failing anything else.
     * @param approved - the tools the person has admitted.
     */
    setApproved(approved: readonly ApprovedTool[]): void;
    /**
     * Why the last tool call this server ran never reached a result, or the
     * empty string when it did — including when the result it reached was the
     * server's own failure.
     *
     * The upstream client publishes no connection state and keeps a dropped
     * server's tools registered, so a call that never comes back is the only
     * evidence this plugin has that a server stopped answering.
     * @returns the failure message, or the empty string.
     */
    callFailure(): string;
    /**
     * Every tool this server currently offers, approved and pending alike.
     * @returns the tools, ordered by registered name.
     */
    tools(): McpToolView[];
    /** Unregister everything this gate put in the registry, and accept no more. */
    dispose(): void;
    /**
     * Wrap one definition so this gate learns whether its calls come back.
     * Everything else about the definition is passed through by reference, so
     * the registry sees the upstream contract unchanged.
     */
    private observed;
}
//# sourceMappingURL=tool-gate.d.ts.map