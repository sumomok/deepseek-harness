/**
 * Stable digests over two things a person is asked to agree to: where a
 * server connects, and the exact wording of one tool. Both are compared
 * against a stored value, so both must be order-independent and
 * representation-independent — the same facts written in a different key
 * order are the same facts.
 *
 * @module @haoran/dsh-mcp-servers/fingerprint
 */
import type { ServerRecord } from './types.ts';
/**
 * Serialize a JSON value with every object's keys in sorted order.
 * @param value - the value to serialize; `undefined` members are omitted.
 * @returns the canonical JSON text.
 */
export declare function canonicalJson(value: unknown): string;
/**
 * Digest one tool's model-facing wording. Description and input schema are
 * included because those are what a person read when they approved it: a
 * server that rewrites either is offering a different tool.
 * @param name - the registered, model-facing tool name.
 * @param description - the server's own description, verbatim.
 * @param parameters - the server's own input schema, verbatim.
 * @returns the fingerprint stored beside an approval.
 */
export declare function toolFingerprint(name: string, description: string, parameters: unknown): string;
/**
 * Digest where a server connects and under what identity. A change here
 * retires the person's confirmation: the record still carries their old
 * fingerprint, which no longer matches.
 *
 * Literal header and environment VALUES are included, so replacing a token
 * typed into the form is a change the person confirms again. An entry naming a
 * credential contributes only that name — the secret is never in the settings
 * document, and rotating it behind the same name is not a change of
 * destination.
 * @param record - the parsed server record.
 * @returns the fingerprint compared against `record.confirmedEndpoint`.
 */
export declare function endpointFingerprint(record: ServerRecord): string;
/**
 * Whether the person's stored confirmation still describes this record.
 * @param record - the parsed server record.
 * @returns true when the confirmed fingerprint matches the current facts.
 */
export declare function isConfirmed(record: ServerRecord): boolean;
//# sourceMappingURL=fingerprint.d.ts.map