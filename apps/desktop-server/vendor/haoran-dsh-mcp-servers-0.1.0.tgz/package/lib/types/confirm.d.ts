/**
 * The channel that asks a person whether one server may be connected.
 *
 * Connecting a server is the moment that matters: from then on the server
 * decides which tools exist, its stdio program runs outside the sandbox, and
 * its descriptions enter every request. The channel is a seam so the desktop
 * shell can later answer with a native window the web UI cannot forge, without
 * anything else in this plugin changing.
 *
 * @module @haoran/dsh-mcp-servers/confirm
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ServerTransport } from './types.ts';
/** What a person is being asked to allow. */
export interface ServerConnectRequest {
    /** The record's stable id, also its tool-name namespace. */
    id: string;
    /** The name the person gave this server. */
    label: string;
    /** Which transport it uses. */
    transport: ServerTransport;
    /** Where it connects: the command line, or the URL without its query. */
    endpoint: string;
    /** Whether `endpoint` left out a query string. */
    endpointHasQuery: boolean;
}
/** Answers whether one server may be connected. */
export interface ServerConfirmer {
    /**
     * Ask about one server.
     * @param request - what is being asked.
     * @returns true to connect it.
     */
    confirm(request: ServerConnectRequest): Promise<boolean>;
}
/**
 * The confirmation the settings page itself carries.
 *
 * A record only reaches this plugin as connectable after someone stored the
 * exact connection facts as confirmed, through the settings document, which no
 * model-facing surface writes. Nothing further is asked, because the answer is
 * already in the record being read.
 */
export declare const settingsConfirmer: ServerConfirmer;
/**
 * Ask through the harness's approval channel, which reaches whatever surface
 * currently answers approvals.
 *
 * The channel is agent-bound and turn-bound: it can only ask while exactly one
 * conversation is open and mid-turn. Outside that window there is nobody to
 * ask, and this confirmer refuses rather than connecting unasked.
 * @param ctx - the plugin context.
 * @returns the confirmer.
 */
export declare function approvalConfirmer(ctx: Context): ServerConfirmer;
/**
 * Pick the configured channel.
 * @param ctx - the plugin context.
 * @param mode - the configured channel name.
 * @returns the confirmer for that mode.
 */
export declare function resolveConfirmer(ctx: Context, mode: 'settings' | 'approval'): ServerConfirmer;
//# sourceMappingURL=confirm.d.ts.map