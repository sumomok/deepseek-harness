/**
 * Writing a capture to a file beside the image block it always returns.
 *
 * An image block is what a model can look at, and nothing else; it is not a
 * file, and the attachment store behind it is content-addressed, so two
 * identical captures produce one object and no path an agent can hand to
 * anything. Work that ends in files — a document with figures, a report, a
 * directory of evidence — needs the PNG on disk under a name the agent chose.
 *
 * There is no filesystem capability in this plugin's reach: `ctx.fs` writes
 * UTF-8 text and has no byte write, so a PNG cannot go through it. The write
 * is therefore an ordinary `node:fs` write, fenced by the one boundary this
 * plugin can establish honestly — the calling session's own workspace. A path
 * outside it is refused rather than written; an absent parent directory inside
 * it is created; an existing file is replaced and the replacement is reported,
 * because a capture that silently overwrote a file the agent still needed would
 * be discovered later, by something else.
 * @module @haoran/dsh-screenshot/output
 */
/** One capture written to disk. */
export interface WrittenOutput {
    /** The absolute path written. */
    readonly path: string;
    /** Whether a file was already there and has been replaced. */
    readonly overwritten: boolean;
}
/**
 * Settle the `outputPath` argument against the session's workspace.
 *
 * A relative path is resolved against the workspace, matching every other
 * file-writing tool in the harness; an absolute one is kept but must still land
 * inside it. Both rules need a workspace, so a call with no session — an
 * agentless invocation — cannot ask for a file at all.
 * @param raw - the `outputPath` argument as the model wrote it.
 * @param workspace - the calling session's workspace directory, when it has one.
 * @returns the absolute path to write.
 * @throws when the value is empty, there is no workspace, or the path leaves it.
 */
export declare function resolveOutputPath(raw: string, workspace: string | undefined): string;
/**
 * Write one capture to the settled path.
 * @param path - the absolute path from {@link resolveOutputPath}.
 * @param data - the PNG bytes.
 * @returns the path written and whether it replaced a file.
 * @throws whatever the filesystem refuses the write with.
 */
export declare function writeOutput(path: string, data: Uint8Array): Promise<WrittenOutput>;
//# sourceMappingURL=output.d.ts.map