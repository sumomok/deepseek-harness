/**
 * The desktop shell's own render service, used when it offers one.
 *
 * The desktop app already ships a browser engine and already has windows it can
 * render into, so a shell that exposes an endpoint renders faster and more
 * faithfully than a second browser started per call. It advertises the service
 * by putting `DSH_DESKTOP_RENDER_ENDPOINT` and `DSH_DESKTOP_RENDER_TOKEN` in
 * the harness process environment; a shell that offers no such service sets
 * neither, and every capture falls to the system browser instead.
 *
 * The wire protocol is stated in full in the package README, which is what a
 * shell implements against.
 * @module @haoran/dsh-screenshot/desktop
 */
import type { ReportHeader } from './report.ts';
import type { RenderSpec } from './request.ts';
/** Environment variable naming the render service's origin. */
export declare const ENDPOINT_ENV = "DSH_DESKTOP_RENDER_ENDPOINT";
/** Environment variable carrying the bearer token that service requires. */
export declare const TOKEN_ENV = "DSH_DESKTOP_RENDER_TOKEN";
/** Where the desktop render service lives and how to authenticate to it. */
export interface DesktopRoute {
    /** Origin of the service, without a trailing slash. */
    readonly endpoint: string;
    /** Bearer token the shell minted for this harness process. */
    readonly token: string;
}
/**
 * Read the desktop render route out of the environment.
 *
 * Both variables are required together: an endpoint without a token would be
 * rejected by the shell on every call, and a token without an endpoint names
 * nothing.
 * @param env - the environment to read.
 * @returns the route, or undefined when this deployment offers no render service.
 */
export declare function desktopRouteFromEnv(env: NodeJS.ProcessEnv): DesktopRoute | undefined;
/**
 * How much longer than the render's own deadline the client waits for an
 * answer. The shell measures its deadline from the moment it accepts a
 * request, behind the connection, the body read, the queue, and — for a render
 * that times out with pixels — the capture it takes at the deadline. The
 * margin is what keeps this abort from firing on a shell that is answering
 * exactly as asked, which is what made the plugin's own budget the one that
 * silently won.
 */
export declare const ABORT_MARGIN_MS = 5000;
/**
 * Response header a shell names the main frame's landing in, and only when
 * that is not the URL the request asked for. Its value is percent-encoded
 * outside printable ASCII, because a header carries no other encoding.
 */
export declare const LANDED_URL_HEADER = "x-dsh-render-landed-url";
/** One page the shell rendered, where its main frame ended up, and what it reported. */
export interface DesktopRender {
    /** PNG bytes. */
    readonly data: Uint8Array;
    /** Where the main frame landed, when the shell said that was not the requested URL. */
    readonly landedUrl?: string;
    /** What the shell's report header said about this render. */
    readonly report: ReportHeader;
}
/**
 * Render one page through the desktop shell.
 *
 * The request carries its own deadline, so the budget the caller set is the one
 * the render runs under; this client's abort sits {@link ABORT_MARGIN_MS} above
 * it so the shell's own answer — including the partial capture a timeout can
 * produce — arrives rather than being cut off.
 * @param route - the shell's endpoint and token.
 * @param spec - the settled render, whose `timeoutMs` is the deadline the shell runs under.
 * @param signal - caller cancellation.
 * @returns the PNG bytes the shell returned, where its main frame landed, and what it reported.
 * @throws when the shell refuses, returns something other than a PNG, or does not answer in time.
 */
export declare function renderWithDesktop(route: DesktopRoute, spec: RenderSpec, signal: AbortSignal): Promise<DesktopRender>;
//# sourceMappingURL=desktop.d.ts.map