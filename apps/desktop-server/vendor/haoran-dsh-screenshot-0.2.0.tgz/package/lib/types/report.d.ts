/**
 * The render report a desktop shell sends with every answer, and the few lines
 * of it the model reads.
 *
 * A render that fails is the moment a caller most needs to know what happened,
 * and one line of `render timed out after 25000ms` says nothing it can act on.
 * The shell measures the whole render — what the main document answered, what
 * the page asked the network for, what is still in flight and on which host,
 * what the page logged — and sends it on {@link REPORT_HEADER} with every
 * answer a render reached. This module reads that header and turns it into a
 * short bounded summary naming the remedies the next call can apply.
 *
 * Nothing here throws. A header this client cannot read is reported as one
 * phrase in the result text, because a report is a diagnostic and losing it
 * must never cost the capture it describes.
 * @module @haoran/dsh-screenshot/report
 */
/**
 * Response header carrying the whole report as percent-encoded JSON, on the
 * 200, on the 500 a failed render is refused with, and on the 504.
 */
export declare const REPORT_HEADER = "x-dsh-render-report";
/**
 * The report schema this client reads. A header naming any other version
 * describes fields this client knows nothing about, so it is ignored rather
 * than read for the parts whose names happen to match.
 */
export declare const REPORT_VERSION = 1;
/** How one render ended, as the report labels it. */
export type RenderOutcome = 'complete' | 'timeout' | 'failed';
/**
 * Where the main frame ended and what it answered.
 *
 * Every member is optional because this is a wire record: the shell sends
 * `null` for a render whose navigation never reported one, and a member this
 * client cannot read must not cost it the rest of the report.
 */
export interface ReportedDocument {
    /** The main frame's URL after every redirect it followed. */
    url?: string;
    /** Its HTTP status, or null for a navigation that carried none. */
    status?: number | null;
    /** Whether the navigation followed a redirect. */
    redirected?: boolean;
    /** The page title, or null when the page set none. */
    title?: string | null;
}
/** What the page asked the network for. */
export interface ReportedCounts {
    /** How many requests reached the wire. */
    total?: number;
    /** How many answered a status below 400. */
    completed?: number;
    /** How many failed or answered 400 and above. */
    failed?: number;
    /** How many were still in flight when the report was taken. */
    pending?: number;
    /** How many `blockHosts` cancelled before they went out. */
    blocked?: number;
}
/** One request still in flight. */
export interface ReportedRequest {
    /** The URL, as the shell cut it. */
    url?: string;
    /** Chromium's classification of it — `image`, `script`, `mainFrame`, and the rest. */
    type?: string;
    /** How long it had been in flight, measured from the moment its headers were sent. */
    ageMs?: number;
}
/** One request that ended in a network error or a status of 400 and above. */
export interface ReportedFailure {
    /** The URL, as the shell cut it. */
    url?: string;
    /** Chromium's classification of it. */
    type?: string;
    /** Chromium's `net::ERR_…` string, or null for a request that answered a status. */
    error?: string | null;
    /** The HTTP status, or null for a request that never got one. */
    status?: number | null;
}
/** What one host cost the render, which is what makes it worth naming in `blockHosts`. */
export interface ReportedHost {
    /** The host. */
    host?: string;
    /** How many of its requests were still in flight. */
    pending?: number;
    /** How many of its requests failed. */
    failed?: number;
    /** How many of its requests this render cancelled. */
    blocked?: number;
    /** The age of its oldest request still in flight. */
    maxAgeMs?: number;
}
/** What the page logged. */
export interface ReportedConsole {
    /** How many error-level messages. */
    errors?: number;
    /** How many warning-level messages. */
    warnings?: number;
    /** The first error-level messages, as the shell cut them. */
    samples?: string[];
}
/** Why the main frame's own load failed. */
export interface ReportedFrameError {
    /** Chromium's negative error code. */
    code?: number;
    /** Its description, as the shell cut it. */
    description?: string;
}
/** What became of the render process. */
export interface ReportedRenderer {
    /** Why it disappeared, or null while it is alive. */
    gone?: string | null;
    /** Whether the page stopped answering. */
    unresponsive?: boolean;
}
/** The pixels the answer carries. */
export interface ReportedCapture {
    /** Whether these are the pixels of a page that had not finished loading. */
    partial?: boolean;
    /** Width in CSS pixels. */
    width?: number;
    /** Height in CSS pixels. */
    height?: number;
}
/**
 * What one render did, whichever way it ended.
 *
 * Only `version` and `outcome` are required: they are what decides whether the
 * report can be read at all and which summary it becomes. Everything else is
 * optional so that a shell one field ahead of or behind this client still
 * teaches the model something instead of nothing.
 */
export interface RenderReport {
    /** {@link REPORT_VERSION}; any other version is not read. */
    version: typeof REPORT_VERSION;
    /** How the render ended. */
    outcome: RenderOutcome;
    /** How far it had got: `queued`, `navigating`, `loaded`, and the phases after the load event. */
    phase?: string;
    /** How long the request had been accepted for. */
    elapsedMs?: number;
    /** The deadline this request was running under. */
    deadlineMs?: number;
    /** The URL the request named. */
    requestedUrl?: string;
    /** Where the main frame ended, empty for a render whose navigation never reported one. */
    mainDocument?: ReportedDocument;
    /** Whether the load event fired, which is what the render waits for before it captures. */
    loadEventFired?: boolean;
    /** Whether the window had painted a frame, which is what makes a partial capture worth taking. */
    firstPaint?: boolean;
    /** What the page asked the network for. */
    requests?: ReportedCounts;
    /** The requests still in flight, oldest first. */
    pending?: ReportedRequest[];
    /** The requests that failed, in the order they failed. */
    failed?: ReportedFailure[];
    /** The hosts that cost the render most, most pending first. */
    hosts?: ReportedHost[];
    /** What the page logged. */
    console?: ReportedConsole;
    /** Why the main frame's own load failed, empty when it did not. */
    mainFrameError?: ReportedFrameError;
    /** What became of the render process. */
    renderer?: ReportedRenderer;
    /** The pixels this answer carries, empty for an answer that carries none. */
    capture?: ReportedCapture;
}
/** What one response's {@link REPORT_HEADER} turned out to be. */
export type ReportHeader = 
/** The response carried no report, which is every answer from a shell older than this protocol. */
{
    readonly kind: 'none';
}
/** A header was there and is not a version-1 report; the render it describes is unaffected. */
 | {
    readonly kind: 'unreadable';
}
/** The report the header carried. */
 | {
    readonly kind: 'report';
    readonly report: RenderReport;
};
/**
 * Read the report header a response carried.
 *
 * The header is decoded before it is parsed, and parsed again undecoded if
 * that fails: the shell percent-encodes bytes outside printable ASCII and
 * leaves a literal `%` alone, so a report quoting a percent-escaped URL comes
 * back as text this client did not receive. Trying both is what reads a report
 * whichever of the two the shell sent.
 * @param header - the header value, or null when the response carried none.
 * @returns what the header turned out to be.
 */
export declare function readRenderReport(header: string | null): ReportHeader;
/** The render report as the `screenshot` tool's canonical value carries it. */
export interface RenderValue {
    /** How the render ended. */
    outcome: RenderOutcome;
    /** How far it had got when the report was taken. */
    phase?: string;
    /** How long the request had been accepted for. */
    elapsedMs?: number;
    /** The URL the request named. */
    requestedUrl?: string;
    /** Where the main frame ended, absent for a render whose navigation never reported one. */
    mainDocument?: {
        /** The main frame's URL after every redirect it followed. */
        url: string;
        /** Its HTTP status, absent for a navigation that carried none. */
        status?: number;
        /** The page title, absent when the page set none. */
        title?: string;
        /** Whether the navigation followed a redirect. */
        redirected: boolean;
    };
    /** Whether the load event fired; false also covers a report that did not say. */
    loadEventFired: boolean;
    /** Whether the window had painted a frame; false also covers a report that did not say. */
    firstPaint: boolean;
    /** What the page asked the network for. */
    requests: {
        /** How many requests reached the wire. */
        total: number;
        /** How many answered a status below 400. */
        completed: number;
        /** How many failed or answered 400 and above. */
        failed: number;
        /** How many were still in flight. */
        pending: number;
        /** How many `blockHosts` cancelled before they went out. */
        blocked: number;
    };
    /** The hosts holding requests open, the one holding the most first. */
    pendingHosts: RenderHostValue[];
    /** The hosts whose requests failed, the worst first. */
    failedHosts: RenderHostValue[];
    /** How long the oldest request still in flight had been running. */
    oldestPendingMs?: number;
    /** What the page logged. */
    console: {
        /** How many error-level messages. */
        errors: number;
        /** How many warning-level messages. */
        warnings: number;
        /** The first error-level message, absent when the page logged none. */
        sample?: string;
    };
    /** Why the main frame's own load failed, absent when it did not. */
    mainFrameError?: {
        /** Chromium's negative error code. */
        code?: number;
        /** Its description. */
        description: string;
    };
    /** What became of the render process. */
    renderer: {
        /** Why it disappeared, absent while it is alive. */
        gone?: string;
        /** Whether the page stopped answering. */
        unresponsive: boolean;
    };
}
/** One host the canonical value names, which is what a `blockHosts` pattern is chosen from. */
export interface RenderHostValue {
    /** The host. */
    host: string;
    /** How many of its requests were still in flight. */
    pending: number;
    /** How many of its requests failed. */
    failed: number;
    /** How many of its requests this render cancelled. */
    blocked: number;
    /** The age of its oldest request still in flight. */
    maxAgeMs: number;
}
/**
 * Project one report into the value the tool returns and the summary is written from.
 *
 * The projection is what makes the summary replayable: `output.render` sees
 * only the canonical value, so everything the model reads about a render has
 * to be in it. It drops the report's URL lists — a host and an age are what a
 * caller acts on — and settles every absent count and flag, so nothing
 * downstream has to decide what a missing number meant.
 * @param report - the report the shell sent.
 * @returns the value the output schema declares.
 */
export declare function renderValue(report: RenderReport): RenderValue;
/** What a summary is written beside. */
export interface RenderSummaryOptions {
    /**
     * Whether an image accompanies the summary. A timed-out render that answered
     * pixels has to say what they are before anything else; one that answered
     * none has to say that instead.
     */
    readonly withImage: boolean;
    /**
     * Whether the summary names where the main frame landed and what to retry
     * with. False where the caller already prints that itself, which is what the
     * 200 envelope does from its own landing header.
     */
    readonly withLanding: boolean;
}
/**
 * Turn one render's report into the lines the model reads.
 *
 * Every clause is bounded and the order is what keeps the useful half of a long
 * summary in front of a reader: the outcome, then what the page did, then what
 * to call differently, and the console sample — the one clause whose content
 * the page itself writes — last, on its own line.
 * @param value - the render's report, as the canonical value carries it.
 * @param options - what the summary is written beside.
 * @returns the summary line, and the console line when the page logged something.
 */
export declare function renderSummary(value: RenderValue, options: RenderSummaryOptions): string[];
//# sourceMappingURL=report.d.ts.map