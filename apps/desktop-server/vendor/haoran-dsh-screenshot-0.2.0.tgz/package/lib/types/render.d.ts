/**
 * Choosing which of the two backends renders a page.
 *
 * The desktop shell's service wins whenever it is configured, because a shell
 * that advertises one has an engine already running and knows what its own
 * windows look like. A failure there is reported rather than retried against
 * the system browser: the two engines produce different pixels, and silently
 * swapping them would make a screenshot's provenance unknowable exactly when
 * something is already wrong.
 *
 * The two backends are not equally capable, and every difference is refused
 * rather than papered over. A system browser started with `--screenshot` cannot
 * be given request headers or cookies, cannot cancel a request the page makes,
 * and writes its PNG only when the page is done, so a call that asks for any of
 * the three fails here with what the backend cannot do. Ignoring a remedy the
 * caller applied is worse than refusing it: the render fails the same way
 * again, and nothing in the answer says the remedy never ran.
 * @module @haoran/dsh-screenshot/render
 */
import type { LaunchBrowser } from './chrome.ts';
import type { ReportHeader } from './report.ts';
import type { RenderSpec } from './request.ts';
/** Which engine produced a screenshot. */
export type RendererName = 'desktop' | 'chrome';
/** One rendered page, the engine that drew it, and what that engine reported. */
export interface RenderedImage {
    /** PNG bytes. */
    readonly data: Uint8Array;
    /** The engine that produced them. */
    readonly renderer: RendererName;
    /**
     * Where the main frame ended up, when the engine reported that as somewhere
     * other than the requested URL. Only the desktop service reports it; a
     * one-shot browser command line says nothing about where it went.
     */
    readonly landedUrl?: string;
    /**
     * What the render service reported about this render. A system browser
     * reports nothing — a one-shot command line has no channel for it — so every
     * capture from that backend carries `{ kind: 'none' }`.
     */
    readonly report: ReportHeader;
}
/** Everything a render reads from outside itself. */
export interface RenderBackends {
    /** The environment the desktop route is read from, per call. */
    readonly env: NodeJS.ProcessEnv;
    /** The system-browser probe, whose answer is cached across calls. */
    readonly locator: {
        locate(): string;
    };
    /** How a system browser is started. */
    readonly launch: LaunchBrowser;
}
/**
 * Render one page with whichever backend this deployment has.
 * @param spec - the settled render, which carries its own budget.
 * @param backends - environment, browser probe, and launcher.
 * @param signal - caller cancellation.
 * @returns the PNG bytes, the engine that produced them, and what it reported.
 * @throws when the chosen backend cannot render the page, including when it cannot carry the call's session, host blocking, or partial capture.
 */
export declare function renderScreenshot(spec: RenderSpec, backends: RenderBackends, signal: AbortSignal): Promise<RenderedImage>;
//# sourceMappingURL=render.d.ts.map