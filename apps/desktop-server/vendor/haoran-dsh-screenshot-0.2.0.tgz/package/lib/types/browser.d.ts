/**
 * Finding a browser that can render a page without a display.
 *
 * The plugin ships no browser and downloads none. Chrome, Edge, Chromium, and
 * Brave all speak the same `--headless=new --screenshot` command line, and one
 * of them is already installed on nearly every machine that runs the desktop
 * app, so the probe reads the platform's own install locations instead of
 * adding a hundred-megabyte dependency to a screenshot tool.
 * @module @haoran/dsh-screenshot/browser
 */
/** What the tool says when no browser is installed anywhere it knows to look. */
export declare const NO_BROWSER_FOUND = "no headless-capable browser found; install Google Chrome/Edge or set screenshot.browserPath in cordis.patch.yml";
/** Everything the probe reads about the machine, injectable so the table can be tested off its own platform. */
export interface BrowserLocatorOptions {
    /** The running platform, as `process.platform` reports it. */
    readonly platform: NodeJS.Platform;
    /** The environment the probe reads `CHROME_PATH`, `HOME`, `PATH`, and the Windows program directories from. */
    readonly env: NodeJS.ProcessEnv;
    /** Configured browser path; when set it is the only candidate. */
    readonly browserPath?: string;
    /** Candidate test; defaults to "an executable regular file exists here". */
    readonly isExecutable?: (candidate: string) => boolean;
}
/**
 * Whether a path names a file this process can launch.
 * @param candidate - absolute path to test.
 * @returns whether it is an executable regular file.
 */
export declare function isExecutableFile(candidate: string): boolean;
/**
 * Where a headless-capable browser lives on one platform, most likely first.
 * @param platform - the running platform.
 * @param env - the environment supplying `HOME` and the Windows program directories.
 * @returns absolute candidate paths, in probe order; empty on a platform with no table.
 */
export declare function browserCandidates(platform: NodeJS.Platform, env: NodeJS.ProcessEnv): string[];
/**
 * The probe, with its answer cached for the life of the plugin.
 *
 * Only a success is remembered. A machine that gains a browser after the first
 * failed call finds it on the next one, which costs one directory scan per
 * failed screenshot and nothing at all once a browser is found.
 */
export declare class BrowserLocator {
    private readonly options;
    private resolved;
    constructor(options: BrowserLocatorOptions);
    /**
     * Find the browser this machine renders with.
     * @returns the absolute path of an executable browser binary.
     * @throws when a configured path is unusable, or when nothing is installed.
     */
    locate(): string;
}
//# sourceMappingURL=browser.d.ts.map