/**
 * A tool that lets the agent look at a page instead of reasoning about its source.
 *
 * An agent writing HTML, CSS, or a component is working blind: it can read back
 * every byte it wrote and still not know that two elements overlap, that a
 * colour is unreadable on its background, or that a layout collapses at the
 * width it was asked for. `screenshot` renders the page and returns the pixels
 * as an image block, which is the only form of that information a model can
 * actually check.
 *
 * The same instrument documents a running system: `cookies` and `headers`
 * render a page that needs a session, and `outputPath` puts the PNG on disk
 * where the rest of the work can use it.
 *
 * A capture that goes wrong says why. The desktop render service reports what
 * the main document answered, what the page is still waiting for and on which
 * host, and what it logged; the tool turns that into a few lines beside the
 * image, and a render that runs out of time returns what had painted, labelled
 * as a partial capture, with `blockHosts` and `timeoutMs` named as the
 * remedies the next call can apply.
 *
 * Two backends render, chosen in this order:
 *
 * - The desktop shell's own render service, when the shell advertises one
 *   through `DSH_DESKTOP_RENDER_ENDPOINT` and `DSH_DESKTOP_RENDER_TOKEN`. Its
 *   wire protocol is stated in the package README.
 * - A system browser — Chrome, Edge, Chromium, or Brave — in headless mode,
 *   probed at the platform's install locations. Nothing is downloaded.
 *
 * The tool registers only while an attachment store is mounted, because the
 * image block it returns must reference durably committed bytes.
 *
 * Configuration reference and known limits live in the package README.
 * @module @haoran/dsh-screenshot
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { TimeoutBehavior } from './request.ts';
export { BrowserLocator, browserCandidates, isExecutableFile, NO_BROWSER_FOUND } from './browser.ts';
export type { BrowserLocatorOptions } from './browser.ts';
export { chromeArguments, launchBrowser, renderWithChrome } from './chrome.ts';
export type { BrowserProcess, ChromeRenderOptions, LaunchBrowser } from './chrome.ts';
export { ABORT_MARGIN_MS, desktopRouteFromEnv, ENDPOINT_ENV, LANDED_URL_HEADER, renderWithDesktop, TOKEN_ENV } from './desktop.ts';
export type { DesktopRender, DesktopRoute } from './desktop.ts';
export { resolveOutputPath, writeOutput } from './output.ts';
export type { WrittenOutput } from './output.ts';
export { readRenderReport, renderSummary, renderValue, REPORT_HEADER, REPORT_VERSION } from './report.ts';
export type { RenderHostValue, RenderOutcome, RenderReport, RenderSummaryOptions, RenderValue, ReportedCapture, ReportedConsole, ReportedCounts, ReportedDocument, ReportedFailure, ReportedFrameError, ReportedHost, ReportedRenderer, ReportedRequest, ReportHeader, } from './report.ts';
export { renderScreenshot } from './render.ts';
export type { RenderBackends, RenderedImage, RendererName } from './render.ts';
export { carriesSession, MAX_TIMEOUT_MS, MIN_TIMEOUT_MS, normalizeTarget, resolveRenderSpec } from './request.ts';
export type { RenderSpec, ScreenshotLimits, ScreenshotRequest, TimeoutBehavior } from './request.ts';
export { applyScreenshotTool, SCREENSHOT_GUIDANCE, screenshotContent, screenshotTool } from './tool.ts';
export type { ScreenshotToolOptions, ScreenshotValue } from './tool.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "screenshot";
/** The registries the tool and its one prompt line are contributed to. */
export declare const inject: string[];
/** Plugin configuration; every field is changeable from cordis.yml and validated at load. */
export interface Config {
    /** Viewport width used when a call names none. */
    defaultWidth?: number;
    /** Viewport height used when a call names none. */
    defaultHeight?: number;
    /** Post-load wait used when a call names none. */
    defaultDelayMs?: number;
    /**
     * Longest post-load wait a call may ask for. A call asking for more is an
     * argument error rather than a silently shortened wait, because a capture
     * taken before the page settled looks like a page that renders wrongly.
     */
    maxDelayMs?: number;
    /**
     * Render budget for one capture, in ms, used when a call names none. It is
     * the deadline the renderer runs under, not this plugin's own patience: the
     * desktop request carries it, and the HTTP abort sits above it.
     */
    timeoutMs?: number;
    /**
     * What a render does when its deadline passes, for a call that names
     * nothing: `capture` answers with whatever had painted, labelled partial,
     * and `fail` answers with an error. A page that lays out and then waits on a
     * third-party host is the case `capture` exists for — the pixels are there,
     * and a caller that gets none of them cannot tell a slow page from a broken
     * one.
     */
    onTimeout?: TimeoutBehavior;
    /**
     * Hosts every render of this deployment cancels requests to, as an exact
     * host or `*.suffix`. It is for a host known to hang every page here — an
     * analytics or avatar host behind a firewall that drops rather than
     * refuses — and it is merged with whatever a call names.
     */
    blockHosts?: string[];
    /** Largest viewport width a call may ask for. */
    maxWidth?: number;
    /** Largest viewport height a call may ask for. */
    maxHeight?: number;
    /**
     * Absolute path of the browser binary to render with. Leave it unset to probe
     * the platform's install locations; set it for a browser installed somewhere
     * else, or to pin which of several installed browsers renders. A path that is
     * not an executable file fails on the first capture rather than being skipped.
     */
    browserPath?: string;
}
export declare const Config: z<Config>;
/**
 * Register the tool.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map