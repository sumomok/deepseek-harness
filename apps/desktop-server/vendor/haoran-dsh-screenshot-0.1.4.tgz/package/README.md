# @haoran/dsh-screenshot

A `screenshot` tool for DeepSeek Harness: it renders a page in a headless browser and returns the pixels as an image block, so the agent can look at a page instead of inferring it.

## Why an agent needs this

An agent writing HTML, CSS, or a component is working blind. It can read back every byte it wrote and still not know that two elements overlap, that a colour is unreadable on its background, or that the layout collapses at the width it was asked for. Source is not appearance, and no amount of re-reading the source turns one into the other.

The same blindness applies to a system the agent did not write. Documenting a running application, checking what a deployment actually shows, illustrating a manual — all of it needs the page as pixels, and most such pages are behind a login. `cookies` and `headers` render one with a session, and `outputPath` puts the PNG on disk under a name the agent chose, so the capture can go into a document rather than only into the conversation.

`screenshot` closes that loop: render the page, look at it, use it. The tool description says so in the words the model reads, and the plugin contributes one line to the system prompt — `Use the screenshot tool to look at any page as pixels …` — because a tool the model does not think to call is a tool that does not exist, and an argument in a schema nobody re-reads is not a capability.

The current model must accept image input. On a text-only route the tool refuses instead of returning an image, because a tool result enters durable session history and would then ride every later request on that session.

## Install

```sh
pnpm run build
cd packages/screenshot && pnpm pack --pack-destination ../../dist
dsh plugin --profile <name> add ../../dist/haoran-dsh-screenshot-0.1.4.tgz
```

The manifest declares `dsh.bundle.patch`, so the install appends the package to the profile's `dsh.profile.bundles` and its patch layer mounts the plugin. Nothing needs to be added to the profile's own `cordis.patch.yml` unless you are changing a default.

The tool registers only while an attachment store is mounted — every shipped app bundle mounts one — because the image block it returns must reference durably committed bytes.

## The tool

```
screenshot(url, width?, height?, fullPage?, delayMs?, headers?, cookies?, outputPath?)
```

| Argument | Default | Meaning |
| --- | --- | --- |
| `url` | required | `http(s)://` URL, `file://` URL, or an absolute path to an `.html` file. |
| `width` | `defaultWidth` | Viewport width in px. The returned image is exactly this wide. |
| `height` | `defaultHeight` | Viewport height in px. |
| `fullPage` | `false` | Capture the whole scrollable page instead of the viewport. |
| `delayMs` | `defaultDelayMs` | Extra wait after load, for animations or scripts. |
| `headers` | none | Extra HTTP headers for the page request, as a map of name to string value. |
| `cookies` | none | Cookies to set before the load, as a map of name to string value. |
| `outputPath` | none | Also write the PNG here, absolute or relative to the session workspace. |

An absolute path becomes a `file://` URL. A relative path is refused: the browser would resolve it against its own working directory rather than the agent's, so it would render a different file than the model meant, or none. Every scheme other than `http`, `https`, and `file` is refused by name.

An out-of-range `width`, `height`, or `delayMs` is an argument error, not a clamped value. The model asked to see a specific viewport; rendering a different one silently would let it draw conclusions about a page it never saw.

The result is a two-block reply: an envelope naming the URL, the image size, the byte count, and the engine that drew it, followed by the image itself.

```
<url>file:///tmp/page.html</url>
<type>image</type>
<content>
image/png image, 1024x768 px, 24631 bytes (renderer: chrome)
</content>
```

The engine is named because the two backends below do not produce identical pixels, and a model comparing two screenshots of the same page needs to know when it is also comparing two renderers.

## A page that needs a session

`cookies` sets each entry on the render's own throwaway session before the page loads, so it reaches the page's subresources too — a signed-in page whose images all 401 is not the page anyone asked to see. `headers` rides the main-frame navigation only, which is what a bearer token or a host override needs. A `Cookie:` header is refused by name and pointed at `cookies`, because one sent that way would cover the document and nothing in it.

**Only the desktop backend can carry them.** A system browser started with `--headless=new --screenshot` has no way to set either, so a call carrying `headers` or `cookies` there is refused with what the backend cannot do rather than rendering the page logged out and returning the sign-in screen as though it were the page requested.

**A render that lands somewhere else says so.** When the desktop shell reports that the main frame ended at a URL other than the requested one, the envelope carries one more line:

```
image/png image, 1440x900 px, 61233 bytes (renderer: desktop)
The main frame ended at http://10.0.0.4:30010/login?back_url=/issues, not the requested URL: the site redirected the render, so pass cookies or headers to capture it with a session.
```

Without that line a capture of a sign-in page is a correct render of the wrong page, and nothing in the pixels says which of the two it is.

## Writing the capture to a file

`outputPath` writes the same PNG to disk in addition to returning the image block, and the result names the path it wrote. It is how a capture becomes a figure in a document: the attachment behind an image block is content-addressed and has no path, so re-capturing an identical page produces no new file to find.

A relative path resolves against the calling session's workspace, like every other file-writing tool in the harness, and the resolved path must stay inside it — one refusal line otherwise. A call from outside a session cannot ask for a file at all, because there is no workspace to place it in. Missing parent directories inside the workspace are created; an existing file is replaced and the result says so, rather than being replaced quietly.

The write is an ordinary `node:fs` write rather than a `ctx.fs` one: the filesystem seam has no byte write, only UTF-8 text, so a PNG cannot go through it. The workspace boundary above is what this plugin can enforce honestly, and it is narrower than the deployment's own sandbox policy rather than wider.

## Two backends, in this order

**1. The desktop shell's render service**, whenever `DSH_DESKTOP_RENDER_ENDPOINT` and `DSH_DESKTOP_RENDER_TOKEN` are both set in the harness process environment. A shell that advertises one already has a browser engine running and knows what its own windows look like. Its protocol is specified below.

**2. A system browser in headless mode.** Chrome, Edge, Chromium, and Brave all accept the same `--headless=new --screenshot` command line, and one of them is installed on nearly every machine that runs the desktop app, so this plugin probes for one instead of adding a hundred-megabyte browser download to a screenshot tool. Nothing is downloaded, ever.

The probe order is `browserPath` from the config, then `CHROME_PATH` from the environment, then the platform's install locations:

| Platform | Probed, in order |
| --- | --- |
| macOS | `/Applications/Google Chrome.app`, `~/Applications/Google Chrome.app`, `/Applications/Microsoft Edge.app`, `/Applications/Chromium.app`, `/Applications/Brave Browser.app` (each `…/Contents/MacOS/<binary>`) |
| Windows | `%ProgramFiles%` and `%ProgramFiles(x86)%` and `%LocalAppData%` `\Google\Chrome\Application\chrome.exe`, then `%ProgramFiles(x86)%` and `%ProgramFiles%` `\Microsoft\Edge\Application\msedge.exe` |
| Linux and others | `google-chrome`, `google-chrome-stable`, `chromium`, `chromium-browser`, `microsoft-edge` on `PATH` |

The first executable found is remembered for the life of the plugin. `browserPath` and `CHROME_PATH` are the two explicit settings, and a path that is not an executable file is reported rather than probed past: a path someone wrote down and got wrong is a mistake to hear about, not a reason to render with a different browser. With nothing installed anywhere, the tool answers:

```
no headless-capable browser found; install Google Chrome/Edge or set screenshot.browserPath in cordis.patch.yml
```

**A shell failure is not retried against the system browser.** Once a render service is configured it is the renderer; falling back would swap engines silently, exactly when something is already wrong, and make a screenshot's provenance unknowable.

## Configuration

```yaml
- id: screenshot
  name: '@haoran/dsh-screenshot'
  config:
    defaultWidth: 1024
    defaultHeight: 768
    defaultDelayMs: 0
    maxDelayMs: 10000
    timeoutMs: 30000
    maxWidth: 4096
    maxHeight: 4096
```

| Field | Default | Meaning |
| --- | --- | --- |
| `defaultWidth` | `1024` | Viewport width for a call that names none. |
| `defaultHeight` | `768` | Viewport height for a call that names none. |
| `defaultDelayMs` | `0` | Post-load wait for a call that names none. |
| `maxDelayMs` | `10000` | Longest wait a call may ask for. |
| `timeoutMs` | `30000` | Wall-clock budget for one capture, whichever backend runs it. |
| `maxWidth` | `4096` | Largest viewport width a call may ask for. |
| `maxHeight` | `4096` | Largest viewport height a call may ask for. |
| `browserPath` | unset | Absolute path of the browser binary; unset means probe. |

The defaults reach the model: they are the `default` annotations on the tool's own parameter schema, so a deployment that renders at 1440 wide tells the model that, rather than leaving it to guess.

An id-targeted patch in the profile's `cordis.patch.yml` **replaces the whole `config` block**, so restate every key you want to keep. A default above its own maximum is refused at load, because the call it would break is the one that names no size at all.

## Desktop renderer protocol

This is the contract a desktop shell implements. The plugin is the client; nothing in this package serves it.

**Discovery.** The shell puts two variables in the environment of the harness process it launches. Both are required: an endpoint without a token is rejected on every call, and a token without an endpoint names nothing.

| Variable | Value |
| --- | --- |
| `DSH_DESKTOP_RENDER_ENDPOINT` | Origin of the service, for example `http://127.0.0.1:53412`. A trailing slash is ignored. |
| `DSH_DESKTOP_RENDER_TOKEN` | Bearer token the shell minted for this harness process. |

They are read on every call rather than at load, so a shell that starts its render service after the harness is up is used from the next screenshot onward.

**Request.**

```http
POST {endpoint}/render
authorization: Bearer {token}
content-type: application/json
accept: image/png

{"url":"https://example.com","width":1024,"height":768,"fullPage":false,"delayMs":0}
```

| Field | Type | Meaning |
| --- | --- | --- |
| `url` | string | An `http:`, `https:`, or `file:` URL. Already normalized: the plugin never sends a bare path or another scheme. |
| `width` | integer | Viewport width in px, at least 1. The returned image must be exactly this wide, whatever scale factor the shell's display has. |
| `height` | integer | Viewport height in px, at least 1. |
| `fullPage` | boolean | Capture the whole scrollable page rather than the viewport. A shell that can measure the document should honour this exactly; that is the main thing it does better than the command-line backend. |
| `delayMs` | integer | Wait after load before capturing, in ms, at least 0. |
| `headers` | object | Absent unless the call carried some. A map of header name to string value, applied to the page request. |
| `cookies` | object | Absent unless the call carried some. A map of cookie name to string value, set on the render's own session before the load, so they reach subresources too. |

A shell that cannot honour `headers` or `cookies` must refuse the request rather than render without them: returning a sign-in page as a successful capture is the failure both fields exist to end. Bounding how many and how large they may be is the shell's job; the plugin checks only that the model wrote strings.

**Success.** `200` with `content-type: image/png` and the PNG bytes as the body. A `200` whose content type is not `image/png` is refused by the client, with the received type in the message — the alternative is bytes that fail magic-byte validation several steps later, under a message about attachments.

**Where it landed.** A `200` may carry `x-dsh-render-landed-url`, and should whenever the main frame ended at a URL other than the requested one — a redirect to a sign-in page, most often. Percent-encode anything outside printable ASCII; the client decodes it, keeps the raw value if it cannot, and turns it into the one sentence quoted above. Send no header when the render stayed where it was pointed.

**Failure.** Any non-`200`. The body is read as text and the first 500 characters are quoted into the tool error the model sees, so write a sentence there rather than a code:

```
the desktop renderer refused to render https://example.com (HTTP 422): no window is available to render into
```

**Timeout.** The client aborts the request after `timeoutMs`. A shell that cannot render in that budget should answer with a failure rather than holding the connection.

**Authentication.** The plugin sends the token it was given and does nothing else about it; comparing it is the shell's job. Bind the service to loopback: it renders arbitrary URLs, including `file:` URLs, for anyone who can reach it with the token.

## Pairing with `@haoran/dsh-llm-permission-gateway`

`screenshot` is reviewed by the gate like any other side-effecting call, and it should be. **Do not add it to `readOnlyTools`.** It makes a network request to whatever URL the model chose, it can now carry credentials the caller supplies to that host, it writes a file when `outputPath` names one, and with a `file:` URL it reads a local file through the browser rather than through `ctx.fs` — so the filesystem sandbox does not apply to what it can render. All of that is worth a review model's attention.

The review cost is one verdict per capture, next to a capture that already takes seconds.

## What this tool does not do

**`fullPage` is an approximation.** Headless `--screenshot` captures the window, not the document, so a full-page capture renders into a 4000px-tall window. A longer page is cut off, and a shorter one is padded with its background colour. `maxHeight` bounds what a call may ask for and deliberately does not bound this internal height. A desktop shell that can measure the document should implement `fullPage` properly; that is the main reason the first backend exists.

**No interaction.** There is no click, scroll, type, or hover. A widget that only appears after a click never appears, and a login form is never filled in — `cookies` and `headers` carry a session the caller already has, they do not obtain one. Every capture starts from a fresh throwaway profile, so nothing persists between captures and nothing is shared with the user's own browser. Driving a page is a different tool with a different risk profile; it is not this one.

**A capture is not free.** The browser writes the PNG and, on macOS, keeps running, so a capture ends when the file appears and stops growing — two 200ms polls — rather than when the process exits. The process group is terminated either way. Expect roughly two to three seconds per screenshot with the command-line backend.

**Chrome will not run as root without `--no-sandbox`,** which this plugin does not pass and will not: it would turn off the browser's own sandbox for every page the agent renders. In a container that runs as root, point `browserPath` at a wrapper script that adds the flag, and know what you turned off.

**The image is what the browser saw.** A page that fails to load renders as the browser's own error page, which the model then reads correctly as "this did not load". That is the intended behaviour, not a gap.

## Development

See the workspace README for the build, the tarball-based profile install, and why a `link:` dependency must not be used.

The suite runs without a browser. One opt-in spec starts a real one:

```sh
pnpm vitest run --dir packages/screenshot                    # no browser started
SCREENSHOT_E2E=1 pnpm vitest run --dir packages/screenshot   # renders a local page in the installed browser
```
