/**
 * Choosing which of the two backends renders a page.
 *
 * The desktop shell's service wins whenever it is configured, because a shell
 * that advertises one has an engine already running and knows what its own
 * windows look like. A failure there is reported rather than retried against
 * the system browser: the two engines produce different pixels, and silently
 * swapping them would make a screenshot's provenance unknowable exactly when
 * something is already wrong.
 *
 * The two backends are not equally capable, and the difference is refused
 * rather than papered over: a system browser started with `--screenshot` cannot
 * be given request headers or cookies, so a call that carries either fails here
 * with what the backend cannot do, instead of returning a picture of a login
 * page as though it were the requested one.
 * @module @haoran/dsh-screenshot/render
 */
import type { LaunchBrowser } from './chrome.ts';
import type { RenderSpec } from './request.ts';
/** Which engine produced a screenshot. */
export type RendererName = 'desktop' | 'chrome';
/** One rendered page and the engine that drew it. */
export interface RenderedImage {
    /** PNG bytes. */
    readonly data: Uint8Array;
    /** The engine that produced them. */
    readonly renderer: RendererName;
    /**
     * Where the main frame ended up, when the engine reported that as somewhere
     * other than the requested URL. Only the desktop service reports it; a
     * one-shot browser command line says nothing about where it went.
     */
    readonly landedUrl?: string;
}
/** Everything a render reads from outside itself. */
export interface RenderBackends {
    /** The environment the desktop route is read from, per call. */
    readonly env: NodeJS.ProcessEnv;
    /** The system-browser probe, whose answer is cached across calls. */
    readonly locator: {
        locate(): string;
    };
    /** How a system browser is started. */
    readonly launch: LaunchBrowser;
}
/**
 * Render one page with whichever backend this deployment has.
 * @param spec - the settled render.
 * @param timeoutMs - wall-clock budget for the capture.
 * @param backends - environment, browser probe, and launcher.
 * @param signal - caller cancellation.
 * @returns the PNG bytes and the engine that produced them.
 * @throws when the chosen backend cannot render the page, including when it cannot carry the call's session.
 */
export declare function renderScreenshot(spec: RenderSpec, timeoutMs: number, backends: RenderBackends, signal: AbortSignal): Promise<RenderedImage>;
//# sourceMappingURL=render.d.ts.map