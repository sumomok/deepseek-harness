/**
 * The desktop shell's own render service, used when it offers one.
 *
 * The desktop app already ships a browser engine and already has windows it can
 * render into, so a shell that exposes an endpoint renders faster and more
 * faithfully than a second browser started per call. It advertises the service
 * by putting `DSH_DESKTOP_RENDER_ENDPOINT` and `DSH_DESKTOP_RENDER_TOKEN` in
 * the harness process environment; a shell that offers no such service sets
 * neither, and every capture falls to the system browser instead.
 *
 * The wire protocol is stated in full in the package README, which is what a
 * shell implements against.
 * @module @haoran/dsh-screenshot/desktop
 */
import type { RenderSpec } from './request.ts';
/** Environment variable naming the render service's origin. */
export declare const ENDPOINT_ENV = "DSH_DESKTOP_RENDER_ENDPOINT";
/** Environment variable carrying the bearer token that service requires. */
export declare const TOKEN_ENV = "DSH_DESKTOP_RENDER_TOKEN";
/** Where the desktop render service lives and how to authenticate to it. */
export interface DesktopRoute {
    /** Origin of the service, without a trailing slash. */
    readonly endpoint: string;
    /** Bearer token the shell minted for this harness process. */
    readonly token: string;
}
/**
 * Read the desktop render route out of the environment.
 *
 * Both variables are required together: an endpoint without a token would be
 * rejected by the shell on every call, and a token without an endpoint names
 * nothing.
 * @param env - the environment to read.
 * @returns the route, or undefined when this deployment offers no render service.
 */
export declare function desktopRouteFromEnv(env: NodeJS.ProcessEnv): DesktopRoute | undefined;
/**
 * Response header a shell names the main frame's landing in, and only when
 * that is not the URL the request asked for. Its value is percent-encoded
 * outside printable ASCII, because a header carries no other encoding.
 */
export declare const LANDED_URL_HEADER = "x-dsh-render-landed-url";
/** One page the shell rendered, and where its main frame ended up. */
export interface DesktopRender {
    /** PNG bytes. */
    readonly data: Uint8Array;
    /** Where the main frame landed, when the shell said that was not the requested URL. */
    readonly landedUrl?: string;
}
/**
 * Render one page through the desktop shell.
 * @param route - the shell's endpoint and token.
 * @param spec - the settled render.
 * @param timeoutMs - wall-clock budget for the request.
 * @param signal - caller cancellation.
 * @returns the PNG bytes the shell returned, and where its main frame landed.
 * @throws when the shell refuses, returns something other than a PNG, or does not answer in time.
 */
export declare function renderWithDesktop(route: DesktopRoute, spec: RenderSpec, timeoutMs: number, signal: AbortSignal): Promise<DesktopRender>;
//# sourceMappingURL=desktop.d.ts.map