/**
 * Rendering one page with a system browser in headless mode.
 *
 * `--screenshot` is a one-shot command line rather than a protocol session: no
 * CDP socket, no client library, no browser download. The cost is that the run
 * is not bounded by process exit — on macOS the browser writes the PNG and then
 * keeps running — so a capture ends when the file appears and stops growing,
 * and the process is terminated either way.
 *
 * The browser is launched into its own process group (where the platform has
 * them) so that termination reaches the renderer and GPU children too. A
 * capture that left them behind would leak one browser tree per screenshot.
 * @module @haoran/dsh-screenshot/chrome
 */
import type { RenderSpec } from './request.ts';
/** One launched browser, reduced to what a capture needs from it. */
export interface BrowserProcess {
    /** Whether the process has already exited. */
    readonly exited: boolean;
    /** Terminate the process and, where the platform has process groups, its group. */
    kill(): void;
}
/**
 * Start a browser.
 * @param command - absolute path of the browser binary.
 * @param args - complete command line, target URL last.
 * @returns the running process.
 */
export type LaunchBrowser = (command: string, args: readonly string[]) => BrowserProcess;
/** One capture: which browser, what to render, and how long to wait for it. */
export interface ChromeRenderOptions {
    /** Absolute path of the browser binary, from {@link BrowserLocator}. */
    readonly browserPath: string;
    /** The settled render. */
    readonly spec: RenderSpec;
    /** Wall-clock budget for the whole capture. */
    readonly timeoutMs: number;
    /** How the browser is started; the default spawns a real one. */
    readonly launch: LaunchBrowser;
    /** Caller cancellation, observed between polls. */
    readonly signal: AbortSignal;
}
/**
 * Start a real browser, in its own process group where the platform has them.
 *
 * Windows has no process groups, so a Windows browser is killed by handle and
 * tears its own children down as it exits; `taskkill /T /F` is the equivalent
 * for a tree that outlives it.
 * @param command - absolute path of the browser binary.
 * @param args - complete command line.
 * @returns the running process, with group-wide termination attached.
 */
export declare const launchBrowser: LaunchBrowser;
/**
 * The command line for one capture.
 * @param spec - the settled render.
 * @param paths - the throwaway profile directory and the file the browser writes.
 * @returns the browser arguments, target URL last.
 */
export declare function chromeArguments(spec: RenderSpec, paths: {
    userDataDir: string;
    screenshotPath: string;
}): string[];
/**
 * Render one page with a system browser.
 * @param options - the browser, the render, the budget, and cancellation.
 * @returns the PNG bytes.
 * @throws when the browser writes nothing in time, or the caller cancels.
 */
export declare function renderWithChrome(options: ChromeRenderOptions): Promise<Uint8Array>;
//# sourceMappingURL=chrome.d.ts.map