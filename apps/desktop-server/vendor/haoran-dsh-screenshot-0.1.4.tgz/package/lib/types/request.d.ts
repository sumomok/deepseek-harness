/**
 * Model arguments to a render request: one explicit resolve step that settles
 * every default and rejects every out-of-range value before any browser starts.
 *
 * Out-of-range width, height, and delay are argument errors rather than silently
 * clamped values. The model asked for a specific viewport; rendering a different
 * one and saying nothing would make it draw conclusions about a page it never saw.
 * @module @haoran/dsh-screenshot/request
 */
/** Deployment-resolved bounds every render request is settled against. */
export interface ScreenshotLimits {
    /** Viewport width used when the call names none. */
    readonly defaultWidth: number;
    /** Viewport height used when the call names none. */
    readonly defaultHeight: number;
    /** Post-load wait used when the call names none. */
    readonly defaultDelayMs: number;
    /** Largest viewport width a call may ask for. */
    readonly maxWidth: number;
    /** Largest viewport height a call may ask for. */
    readonly maxHeight: number;
    /** Longest post-load wait a call may ask for. */
    readonly maxDelayMs: number;
}
/** The `screenshot` tool's arguments, before defaults are settled. */
export interface ScreenshotRequest {
    url: string;
    width?: number;
    height?: number;
    fullPage?: boolean;
    delayMs?: number;
    /** Extra request headers, as the model wrote them; values are checked here. */
    headers?: Record<string, unknown>;
    /** Cookies as a name→value map, as the model wrote them; values are checked here. */
    cookies?: Record<string, unknown>;
}
/** One fully settled render, handed to whichever backend runs it. */
export interface RenderSpec {
    /** Absolute `http:`, `https:`, or `file:` URL. */
    readonly url: string;
    /** Viewport width in px. */
    readonly width: number;
    /** Viewport height in px. */
    readonly height: number;
    /** Whether the whole scrollable page is wanted rather than the viewport. */
    readonly fullPage: boolean;
    /** Extra wait after load, in ms; `0` captures as soon as the page settles. */
    readonly delayMs: number;
    /** Extra request headers, absent when the call named none. */
    readonly headers?: Readonly<Record<string, string>>;
    /** Cookies to set before the load, by name, absent when the call named none. */
    readonly cookies?: Readonly<Record<string, string>>;
}
/**
 * Whether a settled render needs a session the renderer has to be told about.
 * @param spec - the settled render.
 * @returns true when the call carried headers or cookies.
 */
export declare function carriesSession(spec: RenderSpec): boolean;
/**
 * Turn the model's `url` argument into a URL a browser can open.
 * @param raw - the `url` argument as the model wrote it.
 * @returns an `http:`, `https:`, or `file:` URL.
 * @throws when the value is empty, carries an unsupported scheme, or is a relative path.
 */
export declare function normalizeTarget(raw: string): string;
/**
 * Settle one render request against the deployment's limits.
 * @param request - the tool's validated arguments.
 * @param limits - the resolved plugin configuration's bounds and defaults.
 * @returns the render every backend receives.
 * @throws when the target or any bounded argument is unusable.
 */
export declare function resolveRenderSpec(request: ScreenshotRequest, limits: ScreenshotLimits): RenderSpec;
//# sourceMappingURL=request.d.ts.map