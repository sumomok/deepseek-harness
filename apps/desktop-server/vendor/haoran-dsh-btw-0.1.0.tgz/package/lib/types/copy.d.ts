/**
 * Text the host half writes into `command/done`.
 *
 * This half runs with no locale service, and what it writes is durable: the
 * session log keeps it, and it is what a reader sees years later and what the
 * generic command card shows when this plugin's own card is not installed. So
 * every line here carries both languages rather than picking one at write
 * time. The card localizes only the one thing it can reconstruct — the model
 * name on the attribution line.
 *
 * @module @haoran/dsh-btw/copy
 */
/** No question followed the command. */
export declare const USAGE = "\u95EE\u9898\u5199\u5728\u547D\u4EE4\u540E\u9762\u3002 / Put the question after the command.";
/**
 * No configured pair, no route on the conversation, and no default model: a
 * deployment that can run this command at all normally has the last of those.
 */
export declare const NO_ROUTE = "\u6CA1\u6709\u53EF\u7528\u7684\u6A21\u578B\u3002 / There is no model to ask.";
/**
 * The person stopped the answer.
 *
 * Never reaches `command/done`: the registry settles a stopped handler with
 * its own abort text first. This is the answer `askSideQuestion` gives any
 * other caller.
 */
export declare const CANCELLED = "\u5DF2\u53D6\u6D88\u3002 / Cancelled.";
/** The answer ran past the configured deadline and was abandoned. */
export declare const TIMED_OUT = "\u7B49\u592A\u4E45\uFF0C\u6CA1\u6709\u7B54\u5B8C\u3002 / Took too long, so there is no answer.";
/** The model returned without any text. */
export declare const NO_ANSWER = "\u6CA1\u6709\u5F97\u5230\u56DE\u7B54\u3002 / No answer came back.";
/** Note appended to an answer the output cap cut short. */
export declare const TRUNCATED = "\uFF08\u56DE\u7B54\u592A\u957F\uFF0C\u53EA\u5230\u8FD9\u91CC\u3002 / The answer hit its length limit here.\uFF09";
/**
 * Why the answer could not be produced.
 * @param reason - the underlying failure text.
 * @returns the bilingual line carrying that reason once.
 */
export declare function failed(reason: string): string;
/** The prefix of the attribution line; the model id follows it. */
export declare const ATTRIBUTION_PREFIX = "\u2014 ";
/**
 * The attribution line closing one answer.
 *
 * An em dash and a name is the ordinary way to attribute a quotation, and it
 * needs no word in either language. The card reads the model back off this
 * line and renders it as a localized subtitle.
 * @param model - the model id that answered.
 * @returns the line, without a leading blank line.
 */
export declare function attribution(model: string): string;
/**
 * Split a settled answer into its body and the model that produced it.
 *
 * Shared with the browser half so both sides agree on the one format this
 * package writes; a text that does not end in an attribution line comes back
 * whole, which is what every failure line does.
 * @param text - the settled `command/done` text.
 * @returns the body without the attribution line, and the model when present.
 */
export declare function splitAttribution(text: string): {
    body: string;
    model?: string;
};
//# sourceMappingURL=copy.d.ts.map