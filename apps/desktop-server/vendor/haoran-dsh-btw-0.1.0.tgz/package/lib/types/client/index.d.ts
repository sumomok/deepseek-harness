/**
 * Browser half of @haoran/dsh-btw: the `/btw` row in the conversation.
 *
 * The chat's command row dispatches by command name through a keyed slot, so
 * taking the `btw` key is the whole registration — the generic command card
 * keeps every other command. Nothing here talks to the host: the row is built
 * from the `command/run` and `command/done` events the chat has already
 * folded, which is also why it survives a reload.
 *
 * @module @haoran/dsh-btw/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type BtwKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-btw` copy. */
        btw: BtwKey;
    }
}
export { BtwCard } from './BtwCard.tsx';
export type { BtwCardProps } from './BtwCard.tsx';
export { en, NS, zh } from './locales.ts';
export type { BtwKey } from './locales.ts';
export { insertStyles, STYLE_TAG } from './styles.ts';
/** Required browser services. */
export declare const inject: string[];
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map