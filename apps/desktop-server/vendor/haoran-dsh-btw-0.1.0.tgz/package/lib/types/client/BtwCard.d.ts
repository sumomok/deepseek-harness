import type { CommandRowOwnerProps } from '@deepseek-ai/dsh-client-ui-chat/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/**
 * The `/btw` row: the question, the answer, and who answered.
 *
 * Everything shown here is rebuilt from the command's own two log events, so
 * the card is identical on the run that produced it and on every later reload
 * of that session. Closing is view state and nothing else: it is not written
 * anywhere, and the row comes back open the next time the session is opened.
 */
export type BtwCardProps = CommandRowOwnerProps & PropsLocale<'btw'>;
export declare function BtwCard({ node, t }: BtwCardProps): import("react").JSX.Element;
//# sourceMappingURL=BtwCard.d.ts.map