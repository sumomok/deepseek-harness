/**
 * The browser half's stylesheet, injected once as a tagged `<style>`.
 *
 * Every colour is a harness theme variable rather than a literal, so the card
 * follows the light and dark schemes the shell already switches between.
 *
 * @module @haoran/dsh-btw/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-btw";
/**
 * Insert the stylesheet once.
 * @returns a disposer removing the tag this call inserted.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map