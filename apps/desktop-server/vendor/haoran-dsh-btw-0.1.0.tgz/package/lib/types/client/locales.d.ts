/**
 * Copy for the browser half, in the two locales the harness ships.
 *
 * @module @haoran/dsh-btw/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "btw";
/** Every key the browser half looks up. */
export type BtwKey = 'title' | 'running' | 'close' | 'reopen' | 'answeredBy' | 'cancelled';
/** Chinese copy. */
export declare const zh: Record<BtwKey, string>;
/** English copy. */
export declare const en: Record<BtwKey, string>;
//# sourceMappingURL=locales.d.ts.map