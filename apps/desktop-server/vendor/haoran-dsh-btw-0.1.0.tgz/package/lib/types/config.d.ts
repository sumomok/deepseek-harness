/**
 * Deployment policy for the side-question command.
 *
 * Every field is written out in this package's `cordis.patch.yml` at the value
 * declared here, so a profile that wants to change one can see what it is
 * replacing.
 *
 * @module @haoran/dsh-btw/config
 */
import z from '@deepseek-ai/schemastery';
/** The system instruction shipped with this plugin. */
export declare const DEFAULT_SYSTEM: string;
/** Validated deployment policy for `/btw`. */
export interface Config {
    /**
     * Instruction placed in the request's system slot, ahead of the conversation.
     *
     * The side question reaches the model with the conversation as context but
     * without the agent's own system prompt and without tools, so this text is
     * the only thing telling the model what kind of answer is wanted.
     */
    system?: string;
    /** Output-token cap for one answer. */
    maxOutputTokens?: number;
    /**
     * End-to-end deadline for one answer, in milliseconds. A request still
     * running at the deadline is abandoned and the card reports the timeout;
     * partial output is discarded because a half sentence is not an answer.
     */
    timeoutMs?: number;
    /**
     * Provider route for the side question. Absent means the route the
     * conversation itself is using. Must be set together with `model`.
     */
    provider?: string;
    /** Model id for the side question; must be set together with `provider`. */
    model?: string;
}
export declare const Config: z<Config>;
/** Settled policy: the optional route pair resolved to present or absent. */
export interface ResolvedConfig {
    readonly system: string;
    readonly maxOutputTokens: number;
    readonly timeoutMs: number;
    /** The configured override pair, or undefined to follow the conversation. */
    readonly route: {
        readonly provider: string;
        readonly model: string;
    } | undefined;
}
/**
 * Validate the half-configured route pair and detach the policy.
 *
 * Defaulting is explicit here rather than at the call site: a missing route
 * pair means "follow the conversation", which the caller must be able to see
 * as a value rather than infer from two undefined fields.
 * @param config - schema-validated plugin configuration.
 * @returns the settled policy.
 * @throws {Error} when exactly one of `provider` and `model` is set.
 */
export declare function resolveConfig(config: Config): ResolvedConfig;
//# sourceMappingURL=config.d.ts.map