/**
 * One side question: the conversation so far, plus the question, sent once.
 *
 * Three things this must not do, each of which would put the question into the
 * rest of the conversation:
 *
 * - It never appends a surface event (`user/message`, `assistant/message`,
 *   `tool/result`). Those are the only events `Session.deriveMessages()` reads,
 *   so a later request cannot see anything written here.
 * - It never routes the question through `agent.send`/`steer`/`inject`/
 *   `followup`. Every one of those inbox verbs ends as a `user/message`.
 * - It never marks the request as an agent-loop request, which is what holds
 *   off the two consumers that read the marker: `dsh-session-title` would take
 *   the side question for the conversation's first prompt and title the
 *   session from it, and `dsh-agent-loop`'s invariant companion would compare
 *   the request against `deriveMessages()` and fail it.
 *
 * What is recorded is the command's own lifecycle, written by the command
 * registry, not by this module: `command/run` carries the question in `args`
 * and `command/done` carries the answer in `text`. Both are log-only event
 * types the harness already knows, which is what keeps a session that used
 * this command readable by a harness that does not have this plugin installed.
 *
 * @module @haoran/dsh-btw/ask
 */
import type { Context } from '@deepseek-ai/cordis';
import type { CommandInvocation, CommandResult } from '@deepseek-ai/dsh-commands';
import type { ResolvedConfig } from './config.ts';
/** The route one side question is sent on. */
export interface SideQuestionRoute {
    readonly provider: string;
    readonly model: string;
}
/** A deadline over a caller's signal, released by `using`. */
interface LinkedDeadline extends Disposable {
    readonly signal: AbortSignal;
    /** Whether this deadline, rather than the caller, aborted the signal. */
    expired(): boolean;
}
/**
 * Abort a caller's work at a deadline without touching the caller's own signal.
 *
 * Hand-rolled rather than taken from the harness's timeout package, which this
 * plugin cannot depend on: it is not published. The two facts a caller needs
 * are which signal to pass on and, afterwards, which side aborted it.
 * @param signal - the caller's cancellation, forwarded to the derived signal.
 * @param ms - the deadline in milliseconds.
 * @returns the derived signal plus the expiry flag, releasing its timer on disposal.
 */
export declare function linkedDeadline(signal: AbortSignal, ms: number): LinkedDeadline;
/**
 * The route a side question follows.
 *
 * The conversation's own last logged route comes first among the two
 * unconfigured sources, so the answer comes from the same model the person is
 * already talking to and a model switch carries over without configuration.
 * The deployment default is behind it because a conversation only has a header
 * once its first request has been built: without the fallback, a `/btw` typed
 * as the first thing in a new conversation would have no route at all.
 * @param configured - the deployment's explicit route pair, when set.
 * @param header - the session's folded `request/header`, when the conversation has one.
 * @param fallback - the default-model selection, when that plugin is mounted.
 * @returns the route, or undefined when no source has one.
 */
export declare function resolveRoute(configured: SideQuestionRoute | undefined, header: {
    readonly config: {
        readonly provider: string;
        readonly model: string;
    };
} | undefined, fallback: SideQuestionRoute | undefined): SideQuestionRoute | undefined;
/**
 * Ask one side question and settle the command with the answer.
 *
 * @param ctx - context exposing the LLM service.
 * @param config - settled deployment policy.
 * @param invocation - the receiving agent, the raw question, and the UI's cancellation.
 * @returns the answer with its attribution line, or the reason there is none.
 */
export declare function askSideQuestion(ctx: Context, config: ResolvedConfig, invocation: CommandInvocation): Promise<CommandResult>;
export {};
//# sourceMappingURL=ask.d.ts.map