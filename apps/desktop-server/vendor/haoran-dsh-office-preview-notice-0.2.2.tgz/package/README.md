# @haoran/dsh-office-preview-notice

English | [中文](README.zh.md)

Word and PowerPoint previews in the DeepSeek Harness desktop's right sidebar. The desktop ships no document engine; where a Word or PowerPoint file is opened, this plugin offers to open it in Office or WPS or to download the engine once and preview it in place, shows the download's progress, and steps aside for the document preview's own renderer once the engine is installed.

## What it does

The document preview (`@deepseek-ai/dsh-client-ui-sidebar-documentpreview`) always registers its builtin Office renderer for `doc`, `docx`, `ppt`, and `pptx`. Without an engine that renderer fails with a message about enabling a preview service on the machine that runs the app, which means nothing to an end user.

While no engine is installed, this plugin registers its own implementation for the same four suffixes in the `extension` priority band, which the preview's automatic selection ranks above the builtin band, and its body under the same id.

The body is laid out like the preview's own empty states: the file's type icon, the headline 「这里暂时无法预览 Word 和 PPT 文件」, and two equal-width buttons under it. **用 Office/WPS 打开** (primary) opens the file in the computer's default application; **在这里预览** (secondary) downloads the preview engine, with 「需下载约 64 MB」 under it. When the tab is too narrow for both side by side (each needs 160 px), they stack. Every color, radius, and font comes from the design platform's variables, so light and dark themes both apply. What the preview side shows depends on what the desktop shell reports:

| The shell reports | The preview side of the document tab shows |
| --- | --- |
| a download can be offered | the **在这里预览** button with 「需下载约 64 MB」 under it |
| the confirmation is open | the button disabled, and 「请在弹出的窗口里确认下载。」 — the application's own window asks, and the download starts only when the person confirms there |
| downloading | 「正在下载预览组件…」 and `40% · 25 MB / 64 MB` over a progress bar, and **取消下载** in the button's place |
| the download did not finish | 「下载没有完成，请检查网络连接后再试一次。」 and a **重新下载** button; the application's own reason is the line's tooltip |
| a button press refused | one line naming why: 「预览组件已经装好了。」, 「正在等你在弹出的窗口里确认下载。」, 「预览组件已经在下载了。」, 「现在没有正在进行的下载。」, 「刚取消过下载，请稍后再试。」 (for 30 seconds after the person declines the confirmation), or 「这台电脑暂时无法下载预览组件。」; a refusal without a code or a failed request reads as the unfinished-download line above |
| installed | nothing: both registrations are withdrawn, and the preview's registry, which its text body subscribes to, falls to the builtin renderer |
| nothing can be downloaded here | no preview button; the open button alone |

**用 Office/WPS 打开** stays usable in every row, including while the download runs. Where the deployment offers neither button — a server deployment whose files do not open on the person's screen and which downloads no engine — the body is the headline and 「请用电脑上的 Office 或 WPS 打开。」. Where only the download is offered, **在这里预览** takes the primary look.

Sizes are whole MiB (1,048,576 bytes) rounded to the nearest, the figure the application's own confirmation quotes. Every line has an English counterpart. The last row covers a deployment without the shell's engine service (every `dsh web` on a server, which ships its engine), a host the shell has no engine for, and a state read that fails. When the first read already reports the engine installed, the plugin registers nothing. The body reads no file content, and every suffix is declared binary, so the viewer menu offers no plain-text view. Spreadsheets (`xls`, `xlsx`) are left alone: the preview renders them in the browser.

## How it opens the file

The open button calls the harness's own `session.openWorkspacePath({ path })` Remote — the call the document preview's header **Open** control makes — with the file's Host path from the standard `useResource` metadata. The Host checks the path against its composed root filesystem, which is not limited to the workspace, answers `session/path-not-found` for a file that is gone, and hands any other path to the platform opener (`open` on macOS, `explorer.exe` on Windows, `xdg-open` on Linux). This plugin adds no route and no shell code for it.

The button is offered only where `session.canOpenWorkspacePath()` answers true, the check the header control makes: on a server deployment the opener would act on the server's screen, not the person's. It is usable only once the file's Host path is known and ends in `.doc`, `.docx`, `.ppt`, or `.pptx` (any case): the Host path is the target of any symbolic link on the way, so a `report.docx` link to a program would otherwise run that program. It runs one open at a time. A failed open shows one line in the body: 「找不到这个文件，它可能已被移动或删除。」 for a missing file, and 「没能打开这个文件。」 for every other failure; the Host's own message is the line's tooltip.

## How it reaches the engine

The shell does the work: it reads which engine version the shipped converter requires, asks the person in a native window, runs the package manager, and puts the engine where the converter finds it. It advertises that service by putting `DSH_DESKTOP_OFFICE_ENGINE_ENDPOINT` and `DSH_DESKTOP_OFFICE_ENGINE_TOKEN` into the harness process environment.

The host half is the `officeEngine` Typert Remote with three methods. None takes a parameter, so a caller never names a package, a version, or a directory.

| Method | Shell route | Answer |
| --- | --- | --- |
| `state()` | `GET /state` | the shell's snapshot plus `available` and `pollMs`; `available: false` and phase `unsupported` with no service; phase `failed` carrying the reason when the shell does not answer |
| `download()` | `POST /install` | `{ ok: true }` once the confirmation is up; a refusal (`409`, JSON `{ code, message }`) as `{ ok: false, error, code }`, `code` being `unsupported`, `installed`, `confirming`, `installing`, `declined-recently`, or `not-running`; a body that is not that JSON as `{ ok: false, error }` quoting it |
| `cancel()` | `POST /cancel` | the same |

The browser half mounts that Remote through `ctx.remote.$mount()` and re-reads the state every `pollMs` only while the confirmation is open or the download runs.

**`NODE_PATH`.** The converter resolves its engine from its own directory and reads no path from configuration, so the shell names the engine's `node_modules` in the harness process's `NODE_PATH`, and names the same path in `DSH_DESKTOP_OFFICE_ENGINE_MODULES`. When the host half applies it removes exactly that entry from `process.env.NODE_PATH` and keeps any other. Node reads `NODE_PATH` once, at startup, so the harness keeps finding the engine, while the processes it starts — a shell command, a package install — no longer inherit the entry.

## Configuration

| Key | Default | What it does |
| --- | --- | --- |
| `pollMs` | `1000` | How often the document tab re-reads the engine state while the confirmation is open or a download runs; the progress bar advances on it |
| `requestTimeoutMs` | `15000` | How long the host half waits for one answer from the shell |

The protocol is not configuration: the three environment variable names, the three route paths, and the bearer scheme are fixed facts of the shell this plugin talks to.

## Known limitations

- The document toolbar's viewer menu still lists the builtin renderer as "Office document". Picking it by hand before the engine is installed shows the builtin message again. The plugin cannot hide or relabel that entry: the builtin renderer registers unconditionally, and its copy lives in the preview package's own locale namespace.
- The download is offered in the document tab only. There is no Settings entry for it, and no way to remove an installed engine from the app.
- The document header keeps the preview's own **Open** control beside the file path, so the tab shows two ways to open the file; both make the same call.
- A second window that was showing the download offer when another window finished the download keeps offering it until its next state read; pressing the button there reads `installed` and steps aside.

## Compatibility

Requires the desktop shell's Office engine service, which ships from `apps/desktop-shell` in the desktop repository from rc.35. Built against the `0.1.7-rc.2` harness base; every `@deepseek-ai/dsh-*` peer range is `>=0.1.7-rc.1 <0.2.0-0`. The Typert codecs carry the `create()` factory `0.1.7-rc.1` introduced. The open button needs `session.canOpenWorkspacePath` and `session.openWorkspacePath`, which the same base provides.

## Install

Desktop-internal; not published to npm. Pack a tarball and install it into a profile the way any local plugin is vendored:

```sh
pnpm run build && pnpm pack
dsh plugin --profile desktop-shell add /absolute/path/to/haoran-dsh-office-preview-notice-0.2.2.tgz
```
