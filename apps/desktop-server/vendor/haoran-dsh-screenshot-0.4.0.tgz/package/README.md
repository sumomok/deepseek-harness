# @haoran/dsh-screenshot

English | [中文](README.zh.md)

A `screenshot` tool for DeepSeek Harness: it renders a page in a headless browser and returns the pixels as an image block, so the agent can look at a page instead of inferring it. A page behind a login is captured after the person has signed in to it once, in a window the desktop shell opens.

## Why an agent needs this

An agent writing HTML, CSS, or a component is working blind. It can read back every byte it wrote and still not know that two elements overlap, that a colour is unreadable on its background, or that the layout collapses at the width it was asked for. Source is not appearance, and no amount of re-reading the source turns one into the other.

The same blindness applies to a system the agent did not write. Documenting a running application, checking what a deployment actually shows, illustrating a manual — all of it needs the page as pixels, and most such pages are behind a login. A capture that comes back showing a sign-in wall becomes one question to the person, who signs in once in a window the desktop shell opens; the session stays on their machine, and the capture is taken again with it. `cookieJar` is the other way in, for a session somebody exported by hand: the cookies live in this deployment's config and the model only ever names the jar. `headers` carries a bearer token, and `outputPath` puts the PNG on disk under a name the agent chose, so the capture can go into a document rather than only into the conversation.

`screenshot` closes that loop: render the page, look at it, use it. The tool description says so in the words the model reads, and the plugin contributes one line to the system prompt — `Use the screenshot tool to look at any page as pixels …` — because a tool the model does not think to call is a tool that does not exist, and an argument in a schema nobody re-reads is not a capability.

The current model must accept image input. On a text-only route the tool refuses instead of returning an image, because a tool result enters durable session history and would then ride every later request on that session.

## Install

```sh
pnpm run build
cd packages/screenshot && pnpm pack --pack-destination ../../dist
dsh plugin --profile <name> add ../../dist/haoran-dsh-screenshot-0.4.0.tgz
```

The manifest declares `dsh.bundle.patch`, so the install appends the package to the profile's `dsh.profile.bundles` and its patch layer mounts the plugin. Nothing needs to be added to the profile's own `cordis.patch.yml` unless you are changing a default.

The tool registers only while an attachment store is mounted — every shipped app bundle mounts one — because the image block it returns must reference durably committed bytes.

## The tool

```
screenshot(url, width?, height?, fullPage?, delayMs?, headers?, cookieJar?, outputPath?, timeoutMs?, onTimeout?, blockHosts?)
```

| Argument | Default | Meaning |
| --- | --- | --- |
| `url` | required | `http(s)://` URL, `file://` URL, or an absolute path to an `.html` file. |
| `width` | `defaultWidth` | Viewport width in px. The returned image is exactly this wide. |
| `height` | `defaultHeight` | Viewport height in px. |
| `fullPage` | `false` | Capture the whole scrollable page instead of the viewport. |
| `delayMs` | `defaultDelayMs` | Extra wait after load, for animations or scripts. |
| `headers` | none | Extra HTTP headers for the page request, as a map of name to string value. A `Cookie:` header is refused and pointed at `cookieJar`. |
| `cookieJar` | none | The name of a jar configured under `cookieJars`. The model names the jar; the cookies never appear in an argument. |
| `outputPath` | none | Also write the PNG here, absolute or relative to the session workspace, which it must stay inside. |
| `timeoutMs` | `timeoutMs` | How long the render may take, from 1000 up. The desktop render service refuses more than 120000 rather than shortening it. |
| `onTimeout` | `onTimeout` | `capture` returns whatever had painted when the deadline passed, labelled partial; `fail` returns an error. |
| `blockHosts` | `blockHosts` | Hosts whose requests the render cancels, each an exact host or `*.suffix`. The page's own host cannot be blocked. |


There is no argument for a login, and none is to be added. Whether a capture may be taken with a session this machine holds is decided from the page's own URL and answered by the person, never named by a call.

The result carries a `render` field beside the image: the report the renderer produced, `null` where the backend produces none, and `"unreadable"` for a report header this client could not read. `partial` says whether the pixels are of a page that had not finished loading, and `loginNote` says what the sign-in flow did about this capture, absent when it did nothing. A capture the person cancelled at the sign-in card returns instead as `{ url, cancelled: true, note }`, with no image and nothing describing the page.

An absolute path becomes a `file://` URL. A relative path is refused: the browser would resolve it against its own working directory rather than the agent's, so it would render a different file than the model meant, or none. Every scheme other than `http`, `https`, and `file` is refused by name.

An out-of-range `width`, `height`, or `delayMs` is an argument error, not a clamped value. The model asked to see a specific viewport; rendering a different one silently would let it draw conclusions about a page it never saw.

The result is a two-block reply: an envelope naming the URL, the image size, the byte count, and the engine that drew it, followed by the image itself.

```
<url>file:///tmp/page.html</url>
<type>image</type>
<content>
image/png image, 1024x768 px, 24631 bytes (renderer: chrome)
</content>
```

The engine is named because the two backends below do not produce identical pixels, and a model comparing two screenshots of the same page needs to know when it is also comparing two renderers.

## What the render did

The desktop render service reports every render it performs, and the tool turns that report into at most two lines beside the image. A page that finished says so in one:

```
image/png image, 1440x900 px, 61233 bytes (renderer: desktop)
render: complete in 1.8s · main document 200 · 31 requests, 0 failed
```

A page that ran out of time says what it was waiting for, and what to call the tool again with. The label comes first, because a partial capture read as a finished page is a page that renders wrongly, which is a worse conclusion than no capture at all:

```
render: TIMED OUT after 25s — this image is what had painted, not the finished page. main document 200 ("Issues - Redmine"), load event not fired. 63 requests: 41 done, 0 failed, 22 pending for 21s, all on www.gravatar.com. If that host is not needed, call again with blockHosts: ["www.gravatar.com"]; or raise timeoutMs (ceiling 120s).
image/png image, 1440x900 px, 61233 bytes (renderer: desktop)
console: 1 error, 1 warning — "Failed to load resource: net::ERR_CONNECTION_TIMED_OUT"
```

A render the service refused says the same thing as the tool error, without the image:

```
the desktop renderer refused to render https://intranet.example.test/board (HTTP 500) — render: FAILED after 0.1s. no main document, load event not fired. 1 request: 0 done, 1 failed. main frame did not load: ERR_NAME_NOT_RESOLVED (-105).
```

Every clause is bounded, and the order is the point: the outcome, then what the page did, then what to call differently, and the console sample — the one clause whose content the page itself writes — last, on its own line. A summary beside an image is at most 647 characters with every clause present and every value past its cap; the failure form, which also prints the landing URL and the session retry, is at most 718. The bound is set by a host at the 96 characters the render service reports one at, printed twice: cut to 48 as the fact, and whole inside the `blockHosts` pattern, because that pattern is copied into the next call and a cut host would match nothing. Growing the page grows nothing in it. The ordering is the rule the shell's own timeout line follows: an unbounded clause printed after the advice takes the advice with it, exactly on the renders that need it most.

A host the render service itself had to cut is named as a fact and never offered as a pattern: a cut host copied into the next call would block nothing, so that render is answered with `Raise timeoutMs (ceiling 120s).` instead.

Only the desktop render service produces a report. A system-browser capture carries `render: null` and no summary lines, because a one-shot `--screenshot` command line has no channel for one.

## A page behind a sign-in

A capture that comes back showing a sign-in wall becomes at most one question and at most one more capture. The model called `screenshot` on a URL; everything after that is the person's, and a render that already produced pixels is never failed over a login — the wall is a fact about the page, and a model told what it is looking at can act on it, while an error tells it nothing about the site at all.

**A wall is read from what the render already reported**, so a page that loaded fine costs nothing and a wall costs no extra request. Three signals, any one of which is a wall:

- The main frame ended on another registrable domain. A page that sends an anonymous visitor to its identity provider is the ordinary case.
- The main frame ended on the same site at a path in `loginPathPatterns`. This one is read only against a landing the render did not ask for: a call that asked for `/login` asked to see the login page, and a card about it would be arguing with the caller.
- The main document answered `401` or `403`. A site that refuses rather than redirects, and an API-backed page whose own document is refused, both land here.

The site a login is filed under is the registrable domain of the page that was **asked for**, never the landing's, so a hand-off through an identity provider on another domain still files the session under the site that sent the render there.

**Two cards, and one label each that means yes.** A site this machine holds no login for is asked 「截取 <url> 需要先登录 <domain>。」 and offered three choices: 【去登录】, 【截当前】, and 【取消】. 去登录 carries the only promise the card makes — 「登录状态只保存在这台电脑上，仅用于截图」 — and the other two carry no explanation, because neither stores anything. A site the machine already holds is offered 【允许】 and 【取消】. Both cards carry the header 截图登录 and the bare domain as their detail, so a UI that renders these cards itself shows the site on its own line while the sentence names the whole URL.

【取消】 means different things on the two cards, and they are told apart by the question id rather than the word. On the reuse card it declines: the signed-out capture already taken is returned with a sentence saying so. On the sign-in card it cancels: the capture is thrown away, and the result is one sentence and no image at all.

The package's browser half is such a UI: it registers a composer entry ahead of the stock question flow that claims only these two questions and draws them as its own card, and leaves every other question where it was. Where that half is not loaded — a terminal, an automation client, a web GUI without it — the stock flow asks the same question with the same labels, and the answer encoding is identical either way.

Anything other than a single press of the exact grant label is a no: a skipped question, typed free text, another label, a label with a trailing space, more than one selection, and an answer to a question this card did not ask. `ctx.userQuestions.ask()`'s generic flow always offers Skip and a free-text field beside the options a caller names, so an empty answer and a written-out one are both things a person can produce — and neither is somebody pressing the button that hands over their own session. Every such answer lands on 【截当前】, which keeps the capture that already exists; throwing that capture away is a decision only 【取消】 itself can make.

**The question goes to a person and never to the model.** The user-questions seam has a single active provider with no waterfall in front of it, so nothing that auto-approves tool calls can answer one of these cards; and `ask()` refuses a caller that is not the registry's exact live runtime root. A subagent therefore gets an unauthenticated capture and one sentence telling it to report the sign-in wall and let the agent that owns the conversation take the capture. A deployment with no question channel at all, a call with no conversation behind it, and a runtime that is no longer live each get their own sentence, because the remedy differs and the reader is a model deciding what to do next.

**The partition key is computed here and is never a tool argument.** A stored login lives in `persist:dsh-render-login-<registrable domain>`, the domain answered by `tldts` from the page's own URL. A model that could name a partition could ask for a capture taken with somebody's session under a site the call has nothing to do with, and the card that person answered would have been about a different site. The domain is a public-suffix question rather than a string-suffix one: `example.co.uk` and `other.co.uk` are two sites, and a rule that took the last two labels would file every `co.uk` login in one shared store.

**The window is the shell's, and it opens only after the grant.** For a site with no stored login the plugin asks the shell for a single-use nonce for exactly that page and that partition, spends it to open a visible window, and waits for the person to close it; then it renders the page again in that partition. For a site the machine already holds, nothing opens — the reuse card is the whole question, and the second render follows it. Either way the plugin sends a URL, a partition, and a nonce, and reads back a landing; no cookie crosses that wire in either direction.

**Four conditions take the whole flow out of the way**, all decided before anyone is asked:

- The deployment set `loginConsent: false`.
- The capture came from the system browser, which reports neither where it landed nor what the document answered, so there is nothing to read a wall from.
- The call carried its own `cookieJar`. The caller already supplied a session, and a wall then means that jar is stale, which is the caller's to fix.
- The page has no registrable domain — a `file:` URL, an IP literal, a development host — so there is no site to file a login under.

**What the result says.** `loginNote` carries one sentence, and the envelope prints it before the size line and before the partial-capture label: a reader that learns only afterwards that it is looking at a sign-in page has already drawn a conclusion about the site.

| Path | What `loginNote` says |
| --- | --- |
| Signed in, window opened | The user signed in to the site in a window the shell opened, this capture uses that session, and later captures of the site will ask before reusing it. |
| Stored login reused | The user allowed this capture to use the login stored on this machine. |
| Declined — 截当前 on the sign-in card, 取消 on the reuse card, or any answer that is neither of the card's labels | The user declined, followed by the sentence naming the wall. |
| Nobody to ask | Why the question could not be put, followed by the sentence naming the wall. |
| The window could not be finished | What the shell refused, followed by the sentence naming the wall. |
| Signed in and still walled | Both sentences: what was granted, and that the window was closed without a completed sign-in or the account cannot see this page. |
| No wall, or one of the four conditions above | Nothing. The field is absent. |

The sentence naming the wall is the one that stops the pixels being read as the page: `This image is a sign-in wall, not the page that was asked for … No stored login was used, so do not read the pixels as the requested page.`

**A cancelled capture has no `loginNote`, because it has no result to annotate.** Pressing 【取消】 returns before the image is saved or written anywhere: the tool answers `{ url, cancelled: true, note }`, the model is shown that sentence alone — `The user cancelled this capture; no image was taken.` — and nothing describes the page. A size, a landing, or a render report would each invite the same call again with one argument changed, which is the retry loop the cancel exists to end. The declared output schema is the union of those two results, and they share no field but `url`.

## Managing stored logins

Two surfaces, and **neither is a tool**. What they can do is read which sites have a login and erase one, and the second of those is the user's own decision about their own session.

**The settings page.** The package's browser half registers a settings section that lists the stored sites and signs out of one. It reaches the host through the package's own Typert Remote, which the harness's typert loader discovers from `exports["./typert"]` — the plugin appearing as a Loader entry under its own package name is the whole registration — and the section registers only once that Remote is mounted, because a page with nothing to read is worse than no page. The Remote projects two verbs and no third: `list` answers the stored sites with their two timestamps and whether a shell is reachable to sign out through, and `forget` erases one. There is no verb that returns a cookie, and none could be added from this side — the values live in Chromium's own store.

**`/screenshot-logout <domain>`.** A slash command is the second surface because it is provably a person: commands never enter the tool catalog, their run and done records are log-only rather than model surface, and the `/` plane is entered from the human composer. It takes `github.com`, `www.github.com`, or a whole URL, all read through the same public-suffix answer the partition key is built from, so what it erases is what the settings page lists. With no argument it says what this machine holds. It registers only where a commands registry is mounted.

A sign-out asks the shell first and the index second, so a failure to erase leaves the entry visible rather than hiding a login that is still there. A domain this installation never recorded is still sent to the shell — the index is this plugin's own note, the partitions are the truth, and somebody who knows the site should be able to clear it either way. On a deployment with no render service configured a sign-out is refused by name, because the logins live in the shell.

## What a login leaves behind

**A cookie value exists in exactly one place**: Chromium's own encrypted profile store, inside the desktop shell's userData directory. No route of the render service returns one, no field on any of the three sign-in routes carries one back, and nothing in this plugin has a way to ask for one — not the service, not its Typert Remote, not the tool.

**This plugin's own index holds a domain and two timestamps.** It lives at `$DSH_HOME/dsh-screenshot/logins.json`, written `0600` under a `0700` directory, and its entries are the site, when the sign-in window that created it closed, and when a capture last rendered with it. No cookie, token, header, or URL is written there. It is deliberately not the source of truth — the shell's partitions are — so a file this build cannot read starts from an empty list and costs one sign-in window rather than failing a capture, and a write that cannot land is reported to the host log and not to the model.

**Nothing about a login reaches the session log, a tool result, or a model request except the domain.** `loginNote` names the site and what was decided; the partition is computed inside the harness process and appears in the request body to the shell and nowhere else.

**A restart of the host loses an open card.** A consent card is a blocked tool call. Reloading a client replays the pending question, so closing a tab and opening it again puts the card back in front of the person. A restart of the host process while a card is open does not: the tool call resolves as a generic interrupted tool result, that card is never shown again, and the capture is simply gone. The model can call `screenshot` again, which starts the flow from the beginning.

**A deployment several people are connected to is not multi-user safe for this feature.** The card is broadcast to every connected client and the first answer wins — whoever answers first decides whether a sign-in window opens on the machine holding the shell, and whether a capture is taken with a session already stored there. Give each person their own harness, or set `loginConsent: false` on a deployment more than one person watches. A deployment with no render service at all never reaches a card, since the flow needs the desktop backend.

## A session exported by hand

`cookieJar` is the way in for a session nobody is going to sign in to interactively: one exported from a browser, or one a deployment holds for a service account.

**The cookies are configured, not passed.** A cookie value is a bearer credential, and anything a model writes as a tool argument is written into the session log, into every later model request on that session, and into whatever reads that transcript afterwards. So the values live in `cordis.yml` under `cookieJars`, each jar under a name, and the tool takes `cookieJar: "<name>"`. The plugin resolves the name in the process that holds the config and sends the cookies to the renderer over loopback; no cookie value is ever returned in a result, written to a log, or quoted into an error — a refusal about a cookie names its jar and its position, never what is in it.

```yaml
- id: screenshot
  name: '@haoran/dsh-screenshot'
  config:
    cookieJars:
      redmine:
        cookies:
          - name: _redmine_session
            value: '…'
            domain: redmine.internal.test
            path: /
            httpOnly: true
      grafana:
        cookies:
          - { name: grafana_session, value: '…', domain: grafana.internal.test, secure: true }
```

| Member | Default | Meaning |
| --- | --- | --- |
| `name` | required | The cookie's name, an HTTP token. |
| `value` | required | The credential. It reaches the renderer and nothing else. |
| `domain` | required | The host it belongs to, with or without a leading dot; it covers that host's subdomains. |
| `path` | `/` | The path prefix it is sent for. |
| `secure` | `false` | Send it only over https. |
| `httpOnly` | `false` | Keep the page's own script from reading it. |
| `expirationDate` | none | Seconds since the epoch. Absent makes it a session cookie, which is what a render wants. |

A jar name is letters, digits, dot, dash, or underscore, and it is the only part of a jar a model sees: the tool's `cookieJar` description lists the configured names so the model can reach for one, and lists nothing else. An unknown name is refused with `cookieJar "x" is not configured; add it under cookieJars in the plugin config` rather than rendered signed out, and the refusal does not list the jars this machine does have — it travels into the session log too. Every jar is validated at load, against the same grammars the render service enforces, so a mistyped domain fails when the deployment starts rather than on the capture someone needed.

`domain` is what each cookie is scoped to, so one jar carries the cookies of every host the page talks to — an app host and its API host are the ordinary case. `path` defaults to `/` rather than to RFC 6265's default-path, which is the directory a cookie was stored from: a cookie left at `/app/issues/` reaches none of the `/api/…` requests the page makes, and a signed-in page whose data all 401s is not the page anyone asked to see.

`headers` still takes what a header is for — a bearer token, a host override — and rides the main-frame navigation only. A `Cookie:` header is refused by name and pointed at `cookieJar`, because a cookie written there is a cookie written into the session log, which is the whole thing jars exist to prevent.

**Every render gets its own cookie store.** The desktop shell renders in a window whose session partition is created for that request, lives in memory, and is destroyed with the window. One render's cookies cannot be read by the next, and nothing is written to disk. The one exception is the second render of a granted sign-in, which runs in that site's login partition; a request carrying one carries no `cookies`, so a jar is never written into a store that outlives its request.

**Only the desktop backend can carry them.** A system browser started with `--headless=new --screenshot` has no way to set a cookie or a header, so a call carrying `cookieJar` or `headers` there is refused with what the backend cannot do rather than rendering the page logged out and returning the sign-in screen as though it were the page requested.

The same refusal covers the two arguments that backend also cannot honour: `blockHosts`, because a command line cannot cancel a request the page makes, and `onTimeout: "capture"`, because that browser writes its PNG only once the page is done. Both are refused rather than ignored. A remedy that is silently dropped fails the same way it did before, and nothing in the answer says the remedy never ran — which is how a caller ends up applying it again and again. The `onTimeout` refusal fires only for a call that named `capture` itself; the deployment default is not something a call asked for, so it never makes a system-browser capture fail. That backend also refuses a render with a stored login, which is reachable only when the shell's render service goes away between the capture that found a sign-in wall and the one the person approved: a capture taken signed out where somebody has just approved a signed-in one is the exact confusion consent exists to prevent.

**A render that lands somewhere else says so.** When the desktop shell reports that the main frame ended at a URL other than the requested one, the envelope carries one more line:

```
image/png image, 1440x900 px, 61233 bytes (renderer: desktop)
The main frame ended at http://10.0.0.4:30010/login?back_url=/issues, not the requested URL: the site redirected the render, so pass cookieJar or headers to capture it with a session.
```

Without that line a capture of a sign-in page is a correct render of the wrong page, and nothing in the pixels says which of the two it is. Where the landing is a sign-in wall and the flow above ran, this line sits under the `loginNote`: the note says what was decided about a login, and the line says where the frame went.

## Writing the capture to a file

`outputPath` writes the same PNG to disk in addition to returning the image block, and the result names the path it wrote. It is how a capture becomes a figure in a document: the attachment behind an image block is content-addressed and has no path, so re-capturing an identical page produces no new file to find.

A relative path resolves against the calling session's workspace, like every other file-writing tool in the harness, and the resolved path must stay inside it: `outputPath must stay inside the workspace (…); use a relative path like shots/page.png`. A call from outside a session cannot ask for a file at all, because there is no workspace to place it in. Missing parent directories inside the workspace are created; an existing file is replaced and the result says so, rather than being replaced quietly.

The containment is checked twice, because one check is not the boundary it looks like. Resolving the path settles `..`; resolving the symbolic links of the deepest part of it that exists settles the rest, since a directory inside the workspace can be a link to one outside it and a path that reads as contained would then be written outside. Both run before anything is created, so a refusal leaves no directory behind either.

The write is an ordinary `node:fs` write rather than a `ctx.fs` one: the filesystem seam has no byte write, only UTF-8 text, so a PNG cannot go through it. The workspace boundary above is what this plugin can enforce honestly, and it is narrower than the deployment's own sandbox policy rather than wider.

## Two backends

`backend` chooses which one renders. On `auto`, the default, they are tried in this order:

**1. The desktop shell's render service**, whenever `DSH_DESKTOP_RENDER_ENDPOINT` and `DSH_DESKTOP_RENDER_TOKEN` are both set in the harness process environment. A shell that advertises one already has a browser engine running and knows what its own windows look like. Its protocol is specified below.

**2. A system browser in headless mode.** Chrome, Edge, Chromium, and Brave all accept the same `--headless=new --screenshot` command line, and one of them is installed on nearly every machine that runs the desktop app, so this plugin probes for one instead of adding a hundred-megabyte browser download to a screenshot tool. Nothing is downloaded, ever.

The probe order is `browserPath` from the config, then `CHROME_PATH` from the environment, then the platform's install locations:

| Platform | Probed, in order |
| --- | --- |
| macOS | `/Applications/Google Chrome.app`, `~/Applications/Google Chrome.app`, `/Applications/Microsoft Edge.app`, `/Applications/Chromium.app`, `/Applications/Brave Browser.app` (each `…/Contents/MacOS/<binary>`) |
| Windows | `%ProgramFiles%` and `%ProgramFiles(x86)%` and `%LocalAppData%` `\Google\Chrome\Application\chrome.exe`, then `%ProgramFiles(x86)%` and `%ProgramFiles%` `\Microsoft\Edge\Application\msedge.exe` |
| Linux and others | `google-chrome`, `google-chrome-stable`, `chromium`, `chromium-browser`, `microsoft-edge` on `PATH` |

The first executable found is remembered for the life of the plugin. `browserPath` and `CHROME_PATH` are the two explicit settings, and a path that is not an executable file is reported rather than probed past: a path someone wrote down and got wrong is a mistake to hear about, not a reason to render with a different browser. With nothing installed anywhere, the tool answers:

```
no headless-capable browser found; install Google Chrome/Edge or set screenshot.browserPath in cordis.patch.yml
```

**A shell failure is not retried against the system browser.** Once a render service is configured it is the renderer; falling back would swap engines silently, exactly when something is already wrong, and make a screenshot's provenance unknowable.

A deployment that knows which engine it wants says so instead of relying on that order. `backend: shell` renders only through the shell and refuses by name when there is none — `backend is set to "shell" and this harness was given no render service … Start the desktop shell, or set backend to "auto" or "browser" in the plugin config` — which is what a deployment whose pages all need a session wants, since the fallback there can only ever produce sign-in screens. `backend: browser` renders through the machine's own Chrome even where a shell is running, for a capture that has to come from the browser the user actually has.

## Configuration

```yaml
- id: screenshot
  name: '@haoran/dsh-screenshot'
  config:
    defaultWidth: 1024
    defaultHeight: 768
    defaultDelayMs: 0
    maxDelayMs: 10000
    timeoutMs: 30000
    onTimeout: capture
    blockHosts: []
    maxWidth: 4096
    maxHeight: 4096
    backend: auto
    loginConsent: true
    loginPathPatterns:
      - /login
      - /signin
      - /sign-in
      - /sign_in
      - /auth
      - /oauth
      - /sso
      - /session/new
      - /users/sign_in
      - /account/login
```

| Field | Default | Meaning |
| --- | --- | --- |
| `defaultWidth` | `1024` | Viewport width for a call that names none. |
| `defaultHeight` | `768` | Viewport height for a call that names none. |
| `defaultDelayMs` | `0` | Post-load wait for a call that names none. |
| `maxDelayMs` | `10000` | Longest wait a call may ask for. |
| `timeoutMs` | `30000` | Render budget for a call that names none, in ms. It is the deadline the renderer runs under; the HTTP abort sits 5000 ms above it. |
| `onTimeout` | `capture` | What a render does at its deadline for a call that names nothing. |
| `blockHosts` | `[]` | Hosts every render here cancels requests to, merged with whatever a call names. |
| `maxWidth` | `4096` | Largest viewport width a call may ask for. |
| `maxHeight` | `4096` | Largest viewport height a call may ask for. |
| `browserPath` | unset | Absolute path of the browser binary; unset means probe. |
| `cookieJars` | `{}` | The sessions a capture may render with, by name. **This is where credentials live** — in this file on this machine, never in a tool argument and never in a session log. |
| `userAgent` | stable Chrome for this platform | What every render says it is. The empty string renders under the backend's own, which names Electron or the machine's browser. |
| `backend` | `auto` | `auto` prefers the shell's render service, `shell` requires it, `browser` always uses the machine's Chrome. |
| `loginConsent` | `true` | Whether a capture that comes back showing a sign-in wall asks the person about a login. It costs a deployment that never hits one nothing, since the decision is read from what the render already reported. Turn it off where nobody is watching the conversation — a scheduled run, an automation server — so such a capture answers with the wall instead of blocking on a question no one will see. |
| `loginPathPatterns` | the ten prefixes above | Path prefixes that read as a sign-in, matched case-insensitively against a landing the render did not ask for. Each must start with `/`, and each is a prefix rather than an exact path, because a real sign-in route carries a return URL, a tenant, or a step. Extend it for a site that signs in somewhere else; shorten it where `/auth` is an ordinary page. |

The defaults reach the model: they are the `default` annotations on the tool's own parameter schema, so a deployment that renders at 1440 wide tells the model that, rather than leaving it to guess.

An id-targeted patch in the profile's `cordis.patch.yml` **replaces the whole `config` block**, so restate every key you want to keep. A default above its own maximum is refused at load, because the call it would break is the one that names no size at all.

## Desktop renderer protocol

This is the contract a desktop shell implements. The plugin is the client; nothing in this package serves it.

**Discovery.** The shell puts two variables in the environment of the harness process it launches. Both are required: an endpoint without a token is rejected on every call, and a token without an endpoint names nothing.

| Variable | Value |
| --- | --- |
| `DSH_DESKTOP_RENDER_ENDPOINT` | Origin of the service, for example `http://127.0.0.1:53412`. A trailing slash is ignored. |
| `DSH_DESKTOP_RENDER_TOKEN` | Bearer token the shell minted for this harness process. |

They are read on every call rather than at load, so a shell that starts its render service after the harness is up is used from the next screenshot onward.

**Request.**

```http
POST {endpoint}/render
authorization: Bearer {token}
content-type: application/json
accept: image/png

{"url":"https://example.com","width":1024,"height":768,"fullPage":false,"delayMs":0,"timeoutMs":30000,"onTimeout":"capture","userAgent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"}
```

| Field | Type | Meaning |
| --- | --- | --- |
| `url` | string | An `http:`, `https:`, or `file:` URL. Already normalized: the plugin never sends a bare path or another scheme. |
| `width` | integer | Viewport width in px, at least 1. The returned image must be exactly this wide, whatever scale factor the shell's display has. |
| `height` | integer | Viewport height in px, at least 1. |
| `fullPage` | boolean | Capture the whole scrollable page rather than the viewport. A shell that can measure the document should honour this exactly; that is the main thing it does better than the command-line backend. |
| `delayMs` | integer | Wait after load before capturing, in ms, at least 0. |
| `headers` | object | Absent unless the call carried some. A map of header name to string value, applied to the page request. |
| `cookies` | array | Absent unless the call named a jar. `{ name, value, domain, path, secure, httpOnly, expirationDate? }` per cookie, every attribute but the last already settled, set on the render's own session before the load so they reach every request the page makes and not only the ones under its own directory. Scope each one to its own `domain` and `path`, not to the page's: a jar carries the cookies of every host the page talks to. |
| `userAgent` | string | Absent when the deployment renders under the backend's own. Apply it to the document and its subresources alike. |
| `timeoutMs` | integer | The deadline for this render, measured from the moment the service accepts it. Always sent. A service that cannot honour a budget must refuse it by name rather than rendering to a different one. |
| `onTimeout` | string | `fail` answers a passed deadline with a failure; `capture` answers `200` with whatever had painted and `outcome: "timeout"` in the report. Always sent. |
| `blockHosts` | array | Absent unless there are any. Host patterns — an exact host or `*.suffix`, lowercased — whose requests are cancelled before they go out. The main document's own host may not be blocked. |
| `partition` | string | Absent except on the second render of a sign-in the person granted. `persist:dsh-render-login-<registrable domain>`, lowercased, computed in the harness process from the page's own URL and never from anything a model wrote. Render in that persistent session. A request carrying it carries no `cookies`, and a shell refuses a partition outside that grammar, one on a `file:` URL, and one beside `cookies`. |

A shell that cannot honour `headers` or `cookies` must refuse the request rather than render without them: returning a sign-in page as a successful capture is the failure both fields exist to end. Bounding how many and how large they may be is the shell's job; the plugin validates every cookie against these grammars at load, so a jar it accepts is one a conforming shell accepts.

**Render each request in its own cookie store, and keep no value.** The cookies of one request must not be readable by the next, must not reach the user's own browsing session, and must not be written to disk. The desktop shell does this with a session partition created per render and destroyed with the window. A shell must also keep cookie values out of everything it writes — its logs, its refusals, and `x-dsh-render-report` — because those travel back into a transcript. A request naming a `partition` renders in that persistent store instead, which is the one render session written to disk; it carries no `cookies`, so nothing a caller supplied is persisted on its behalf.

**Success.** `200` with `content-type: image/png` and the PNG bytes as the body. A `200` whose content type is not `image/png` is refused by the client, with the received type in the message — the alternative is bytes that fail magic-byte validation several steps later, under a message about attachments.

**Where it landed.** A `200` may carry `x-dsh-render-landed-url`, and should whenever the main frame ended at a URL other than the requested one — a redirect to a sign-in page, most often. Percent-encode anything outside printable ASCII **and the `%` byte itself**, or a percent sequence the page wrote comes back as the character it stood for; the client decodes the header, keeps the raw value if it cannot, and turns it into the one sentence quoted above. Send no header when the render stayed where it was pointed.

**Failure.** Any non-`200`. The body is read as text and the first 500 characters are quoted into the tool error the model sees, so write a sentence there rather than a code:

```
the desktop renderer refused to render https://example.com (HTTP 422): no window is available to render into
```

**What the render did.** Every answer a render reached — the `200`, the `500` that refuses a failed render, and the timeout failure — carries `x-dsh-render-report`: the render's whole report as JSON, percent-encoded like the landing header — everything outside printable ASCII, and `%` itself. A refusal no render was started for carries none, which is also what a shell older than this protocol sends, and the client falls back to the body line for both. The client reads `version: 1` and ignores every other version rather than reading the members whose names it happens to know; a header it cannot read costs the capture nothing and is reported as one phrase.

The report says how the render ended (`complete`, `timeout`, `failed`), how far it got, what the main document answered, whether the load event fired and the window painted, how many requests reached the wire and how many are still in flight, the hosts holding them, what the page logged, why the main frame failed, and what became of the render process. The shell owns the schema and bounds every list and string so the header cannot grow with the page.

**Timeout.** The request carries its own deadline and the client's HTTP abort sits 5000 ms above it, so the shell's answer — including the partial capture `onTimeout: "capture"` produces at the deadline — arrives rather than being cut off. A shell that cannot render in the budget it was given answers with a failure rather than holding the connection.

**Authentication.** The plugin sends the token it was given and does nothing else about it; comparing it is the shell's job. Bind the service to loopback: it renders arbitrary URLs, including `file:` URLs, for anyone who can reach it with the token.

**The three sign-in routes.** They carry the same `authorization: Bearer {token}` and `content-type: application/json` as `/render`, and each takes and answers one JSON object:

```
POST {endpoint}/login-grant        {"url":"https://app.example.com/board","partition":"persist:dsh-render-login-example.com"}   →  {"nonce":"<single-use value>"}
POST {endpoint}/login              {"nonce":"<single-use value>"}                                                              →  {"landedUrl":"…","sameSite":true}
DELETE {endpoint}/login-sessions   {"partition":"persist:dsh-render-login-example.com"}                                        →  {"cleared":true}
```

The plugin reads `nonce` from the grant and nothing else from any of the three: the `/login` answer only has to be JSON, since the capture that follows is what says whether the sign-in worked, and a sign-out is done when the shell says so. Any non-`2xx` is a refusal whose body — one line of text, as everywhere else in this protocol — is quoted into the sentence the tool result carries or into the command's error. A shell that serves `/render` and not these answers `404` to all three, and a capture that hits a sign-in wall there ends as the unauthenticated capture it already was.

The grant fixes the page and the partition together, so `/login` chooses neither and a window cannot be opened for a site other than the one the person just consented to. The plugin aborts a grant or a sign-out after 10 seconds, and `/login` after 20 minutes — above the shell's own deadline for a window standing open on the user's screen, so the shell's answer arrives rather than being cut off here, which is the relationship `timeoutMs + 5000` keeps for a render. Reading a form, finding a password, and clearing a second factor is what that number is scaled to.

## Pairing with `@haoran/dsh-llm-permission-gateway`

`screenshot` is reviewed by the gate like any other side-effecting call, and it should be. **Do not add it to `readOnlyTools`.** It makes a network request to whatever URL the model chose, a call naming a jar sends this machine's credentials to that host, it writes a file when `outputPath` names one, and with a `file:` URL it reads a local file through the browser rather than through `ctx.fs` — so the filesystem sandbox does not apply to what it can render. All of that is worth a review model's attention.

The review cost is one verdict per capture, next to a capture that already takes seconds.

**A gate verdict is not consent.** The gate decides whether the call runs; whether it may run with the person's own stored session is a separate question, asked of a human through the user-questions seam, which the gate does not sit in front of and cannot answer. A deployment that auto-approves every tool call still gets a card in front of a person for every sign-in wall.

## What this tool does not do

**`fullPage` is an approximation.** Headless `--screenshot` captures the window, not the document, so a full-page capture renders into a 4000px-tall window. A longer page is cut off, and a shorter one is padded with its background colour. `maxHeight` bounds what a call may ask for and deliberately does not bound this internal height. A desktop shell that can measure the document should implement `fullPage` properly; that is the main reason the first backend exists.

**No interaction.** There is no click, scroll, type, or hover. A widget that only appears after a click never appears, and no login form is ever filled in by the agent: a cookie jar and `headers` carry a session the deployment already has, and the sign-in window is the person filling one in themselves, in a window the shell owns and the tool cannot reach into. Every capture other than the second render of a granted sign-in starts from a fresh in-memory profile, so nothing persists between captures and nothing is shared with the user's own browsing session. Driving a page is a different tool with a different risk profile; it is not this one.

**The sign-in flow needs the desktop backend.** A system-browser capture reports neither where it landed nor what the main document answered, so no wall is detected there: the capture is the unauthenticated one, with no note and no error. A deployment whose pages are all behind a login wants `backend: shell` for the same reason.

**One sign-in window at a time.** The shell opens one, and a second request while one is open is refused; the capture that asked for it comes back with the sentence about a window that could not be finished, and the model can call `screenshot` again once the first is done.

**A stored login is never expired.** The shell keeps the partition until somebody signs out of it — the settings page, `/screenshot-logout`, or the app's userData being removed. The index's two timestamps say when it was created and when a capture last used it; nothing acts on either. A session the site itself has expired costs one more card, since the next capture hits the wall again.

**A capture is not free.** The browser writes the PNG and, on macOS, keeps running, so a capture ends when the file appears and stops growing — two 200ms polls — rather than when the process exits. The process group is terminated either way. Expect roughly two to three seconds per screenshot with the command-line backend.

**Chrome will not run as root without `--no-sandbox`,** which this plugin does not pass and will not: it would turn off the browser's own sandbox for every page the agent renders. In a container that runs as root, point `browserPath` at a wrapper script that adds the flag, and know what you turned off.

**Every render says it is Chrome.** `userAgent` defaults to the ordinary stable-Chrome string for the platform the plugin runs on, because both backends announce themselves otherwise: the desktop shell's Chromium sends `… Chrome/150.0.7871.224 Electron/43.4.0 Safari/537.36`, which tells every page the agent looks at that an Electron app is looking at it, and some sites answer a different page for it. Set `userAgent: ''` to render under whatever the backend sends by itself. It reaches the document and its subresources on both backends — the render service sets it on the render's session and web contents, and the system browser gets `--user-agent`.

**The image is what the browser saw.** A page that fails to load renders as the browser's own error page, which the model then reads correctly as "this did not load". That is the intended behaviour, not a gap.

**A partial capture is not a page that finished.** `onTimeout: "capture"` returns the pixels that had painted when the deadline passed, which is a page mid-load: images missing, late scripts unrun, and anything below the fold of a `fullPage` measurement absent. It is labelled in the result and in the `partial` field, and it exists because a caller with pixels and a report can decide what to do next, while a caller with a one-line timeout cannot.

## Development

See the workspace README for the build, the tarball-based profile install, and why a `link:` dependency must not be used.

The suite runs without a browser. One opt-in spec starts a real one:

```sh
pnpm vitest run --dir packages/screenshot                    # no browser started
SCREENSHOT_E2E=1 pnpm vitest run --dir packages/screenshot   # renders a local page in the installed browser
```
