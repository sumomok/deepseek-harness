/**
 * The desktop shell's own render service, used when it offers one.
 *
 * The desktop app already ships a browser engine and already has windows it can
 * render into, so a shell that exposes an endpoint renders faster and more
 * faithfully than a second browser started per call. It advertises the service
 * by putting `DSH_DESKTOP_RENDER_ENDPOINT` and `DSH_DESKTOP_RENDER_TOKEN` in
 * the harness process environment; a shell that offers no such service sets
 * neither, and every capture falls to the system browser instead.
 *
 * The same service owns the sign-in flow. A page behind a login cannot be
 * captured from a partition that starts empty every time, and nobody has
 * exported its cookies, so the shell opens a visible window the user signs in
 * to and keeps that session in a named partition a later render can be taken
 * from. Three routes carry it — {@link grantLogin}, {@link openLogin}, and
 * {@link clearLogin} — and this module never sees a cookie on any of them: it
 * sends a domain and reads back a landing.
 *
 * The wire protocol is stated in full in the package README, which is what a
 * shell implements against.
 * @module @haoran/dsh-screenshot/desktop
 */
import type { ReportHeader } from './report.ts';
import type { RenderSpec } from './request.ts';
/** Environment variable naming the render service's origin. */
export declare const ENDPOINT_ENV = "DSH_DESKTOP_RENDER_ENDPOINT";
/** Environment variable carrying the bearer token that service requires. */
export declare const TOKEN_ENV = "DSH_DESKTOP_RENDER_TOKEN";
/** Where the desktop render service lives and how to authenticate to it. */
export interface DesktopRoute {
    /** Origin of the service, without a trailing slash. */
    readonly endpoint: string;
    /** Bearer token the shell minted for this harness process. */
    readonly token: string;
}
/**
 * Read the desktop render route out of the environment.
 *
 * Both variables are required together: an endpoint without a token would be
 * rejected by the shell on every call, and a token without an endpoint names
 * nothing.
 * @param env - the environment to read.
 * @returns the route, or undefined when this deployment offers no render service.
 */
export declare function desktopRouteFromEnv(env: NodeJS.ProcessEnv): DesktopRoute | undefined;
/**
 * How much longer than the render's own deadline the client waits for an
 * answer. The shell measures its deadline from the moment it accepts a
 * request, behind the connection, the body read, the queue, and — for a render
 * that times out with pixels — the capture it takes at the deadline. The
 * margin is what keeps this abort from firing on a shell that is answering
 * exactly as asked, which is what made the plugin's own budget the one that
 * silently won.
 */
export declare const ABORT_MARGIN_MS = 5000;
/**
 * Response header a shell names the main frame's landing in, and only when
 * that is not the URL the request asked for. Its value is percent-encoded
 * outside printable ASCII, because a header carries no other encoding.
 */
export declare const LANDED_URL_HEADER = "x-dsh-render-landed-url";
/** One page the shell rendered, where its main frame ended up, and what it reported. */
export interface DesktopRender {
    /** PNG bytes. */
    readonly data: Uint8Array;
    /** Where the main frame landed, when the shell said that was not the requested URL. */
    readonly landedUrl?: string;
    /** What the shell's report header said about this render. */
    readonly report: ReportHeader;
}
/**
 * Render one page through the desktop shell.
 *
 * The request carries its own deadline, so the budget the caller set is the one
 * the render runs under; this client's abort sits {@link ABORT_MARGIN_MS} above
 * it so the shell's own answer — including the partial capture a timeout can
 * produce — arrives rather than being cut off.
 * @param route - the shell's endpoint and token.
 * @param spec - the settled render, whose `timeoutMs` is the deadline the shell runs under.
 * @param signal - caller cancellation.
 * @returns the PNG bytes the shell returned, where its main frame landed, and what it reported.
 * @throws when the shell refuses, returns something other than a PNG, or does not answer in time.
 */
export declare function renderWithDesktop(route: DesktopRoute, spec: RenderSpec, signal: AbortSignal): Promise<DesktopRender>;
/** Route that mints the single-use nonce one sign-in window is opened with. */
export declare const LOGIN_GRANT_PATH = "/login-grant";
/** Route that spends a nonce and opens the window. */
export declare const LOGIN_PATH = "/login";
/** Route that erases what one login partition holds. */
export declare const LOGIN_SESSIONS_PATH = "/login-sessions";
/**
 * How long this client waits for a sign-in window to be closed.
 *
 * The shell owns the real deadline — it is the side holding a window on the
 * user's screen — and answers 504 when it passes. This budget sits above
 * whatever that is so the shell's own answer arrives rather than being cut off
 * here, which is the same relationship {@link ABORT_MARGIN_MS} keeps for a
 * render. A person reading a form, finding a password, and clearing a second
 * factor is what the number is scaled to.
 */
export declare const LOGIN_ABORT_MS: number;
/** How long this client waits for a grant or a sign-out, neither of which opens a window. */
export declare const LOGIN_CALL_ABORT_MS = 10000;
/** One granted sign-in, as the shell answered it. */
export interface LoginGrant {
    /** The single-use value {@link openLogin} is called with. */
    readonly nonce: string;
}
/** How one sign-in window ended, as the shell answered it. */
export interface LoginLanding {
    /** Where the window was when the user closed it. */
    readonly landedUrl: string;
    /** Whether that landing is still on the site the partition is keyed by. */
    readonly sameSite: boolean;
}
/**
 * Ask the shell for permission to open one sign-in window.
 *
 * The nonce this answers with is what {@link openLogin} spends, and it is minted
 * for exactly this page and this partition: a window cannot be opened for a
 * different site than the one the person just consented to, and it cannot be
 * opened twice.
 * @param route - the shell's endpoint and token.
 * @param url - the page whose sign-in wall the capture hit.
 * @param partition - the partition this site's login is stored in.
 * @param signal - caller cancellation.
 * @returns the nonce.
 * @throws when the shell refuses the pair or does not answer in time.
 */
export declare function grantLogin(route: DesktopRoute, url: string, partition: string, signal: AbortSignal): Promise<LoginGrant>;
/**
 * Spend a nonce, opening the window, and wait for the user to close it.
 * @param route - the shell's endpoint and token.
 * @param nonce - what {@link grantLogin} answered with.
 * @param signal - caller cancellation.
 * @returns where the window was when it closed.
 * @throws when the shell refuses the nonce, the window is closed unfinished, or the shell does not answer in time.
 */
export declare function openLogin(route: DesktopRoute, nonce: string, signal: AbortSignal): Promise<LoginLanding>;
/**
 * Erase everything one login partition holds.
 * @param route - the shell's endpoint and token.
 * @param partition - the partition to clear.
 * @param signal - caller cancellation.
 * @returns resolves once the shell reports the partition empty.
 * @throws when the shell refuses the partition or does not answer in time.
 */
export declare function clearLogin(route: DesktopRoute, partition: string, signal: AbortSignal): Promise<void>;
//# sourceMappingURL=desktop.d.ts.map