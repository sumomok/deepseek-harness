/**
 * Asking the person, and reading the answer strictly.
 *
 * A stored login is the user's own session. Two decisions are theirs alone and
 * neither is reachable by the model: whether a sign-in window opens at all, and
 * whether a capture is taken with a session that is already stored. Both go
 * through `ctx.userQuestions.ask()`, which blocks this tool call until a human
 * answers in the UI.
 *
 * That channel is what makes the decision human-only. Its provider is the
 * api-proxy's single slot with no waterfall in front of it, so nothing that
 * auto-approves tool calls can answer one of these; and `ask()` refuses a
 * request from an agent that is not the live runtime root, so a subagent cannot
 * obtain a login the person never granted. Every way that refusal can arrive is
 * a capture taken signed out, never a capture taken with a session nobody
 * approved.
 *
 * The answer is read as an exact label match and nothing else. The generic
 * question flow always offers Skip and a free-text field beside the options a
 * caller names, so an answer can come back empty, as typed prose, or as a
 * different label — and each of those is a person who did not press the one
 * button that means yes. Every such answer lands on the decline, which keeps
 * the signed-out capture the render already produced; only the cancel label
 * itself throws that capture away.
 * @module @haoran/dsh-screenshot/consent
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { AskUserQuestionAnswer } from '@deepseek-ai/dsh-user-questions';
/** Question id of the card that offers to open a sign-in window. */
export declare const LOGIN_CONSENT_ID = "screenshot.login-consent";
/** Question id of the card that asks to reuse a login this machine already holds. */
export declare const LOGIN_REUSE_ID = "screenshot.login-reuse";
/** The one label that opens a sign-in window. Anything else is no. */
export declare const SIGN_IN_LABEL = "\u53BB\u767B\u5F55";
/** The label that keeps the signed-out capture the render already produced. */
export declare const CAPTURE_ANYWAY_LABEL = "\u622A\u5F53\u524D";
/**
 * The label that throws the capture away.
 *
 * Same glyph as {@link DECLINE_LABEL} and a different decision: on the reuse
 * card 取消 keeps the signed-out image, and here it means the person wants no
 * image at all. The two are told apart by the question id they answer, never
 * by the word.
 */
export declare const CANCEL_LABEL = "\u53D6\u6D88";
/** The fine print under the sign-in option, which is the only promise the card makes. */
export declare const LOGIN_PRIVACY_NOTE = "\u767B\u5F55\u72B6\u6001\u53EA\u4FDD\u5B58\u5728\u8FD9\u53F0\u7535\u8111\u4E0A\uFF0C\u4EC5\u7528\u4E8E\u622A\u56FE";
/** The one label that lets a capture use a stored login. Anything else is no. */
export declare const ALLOW_LABEL = "\u5141\u8BB8";
/** The label beside it, which declines. */
export declare const DECLINE_LABEL = "\u53D6\u6D88";
/** Header both cards carry, which is what a stock question UI shows above the text. */
export declare const CONSENT_HEADER = "\u622A\u56FE\u767B\u5F55";
/** How a consent request ended. */
export type ConsentOutcome = 
/** The person pressed the one label that means yes. */
{
    readonly kind: 'granted';
}
/** The person answered, and not with that label. The capture already taken stands. */
 | {
    readonly kind: 'declined';
}
/**
 * The person wants no capture at all. Unlike a decline, the image the render
 * already produced is thrown away rather than returned with a note, so the
 * only thing that reaches the model is the sentence saying so.
 */
 | {
    readonly kind: 'cancelled';
}
/**
 * Nobody could be asked. `reason` is the sentence the tool result carries,
 * because a capture taken signed out for a reason the caller cannot see reads
 * as a site that simply refused it.
 */
 | {
    readonly kind: 'unavailable';
    readonly reason: string;
};
/** What a consent request needs from the call it belongs to. */
export interface ConsentRequest {
    /** The URL the capture was asked for, which the sign-in card names. */
    readonly url: string;
    /** The registrable domain the login belongs to. */
    readonly domain: string;
    /** The live root agent whose UI shows the card; `ask()` requires the exact instance. */
    readonly agent: Agent | undefined;
    /** The running tool call's cancellation. */
    readonly signal: AbortSignal;
}
/**
 * The exact label one answer batch pressed, if it pressed exactly one.
 *
 * Everything else reads as no label at all: a skipped question, typed prose,
 * more than one selection, or an answer to a question this request did not
 * ask. A stored login is not something to hand over on a generous reading, and
 * the generic question flow always offers Skip and a free-text field beside the
 * labels a caller names, so those answers are the ordinary case rather than a
 * malformed one.
 * @param answer - the whole answer batch.
 * @param id - the question id this consent was asked under.
 * @returns the single pressed label, or undefined when the answer pressed none.
 */
export declare function pressed(answer: AskUserQuestionAnswer, id: string): string | undefined;
/**
 * Ask whether to open a sign-in window for one site.
 * @param ctx - the plugin context.
 * @param request - the site, the live root agent, and the call's cancellation.
 * @returns what the person decided.
 */
export declare function askToSignIn(ctx: Context, request: ConsentRequest): Promise<ConsentOutcome>;
/**
 * Ask whether one capture may use a login this machine already holds.
 * @param ctx - the plugin context.
 * @param request - the site, the live root agent, and the call's cancellation.
 * @returns what the person decided.
 */
export declare function askToReuse(ctx: Context, request: ConsentRequest): Promise<ConsentOutcome>;
/** The sentence a result carries when the person declined. */
export declare const DECLINED_NOTE = "The user declined to use a login for this capture, so this image is what a signed-out visitor sees.";
/**
 * The whole result of a cancelled capture.
 *
 * One sentence and nothing else: no image, no landing, no render report. A
 * cancelled capture is a decision about this call rather than a fact about the
 * page, so a result that described the page would invite the same call again
 * with a different width or a longer delay.
 */
export declare const CANCELLED_NOTE = "The user cancelled this capture; no image was taken.";
//# sourceMappingURL=consent.d.ts.map