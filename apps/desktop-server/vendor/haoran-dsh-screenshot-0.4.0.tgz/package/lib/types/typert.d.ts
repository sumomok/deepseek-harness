/**
 * Host-face Typert manifest, discovered by `@deepseek-ai/dsh-typert-loader`.
 *
 * The loader resolves `<package>/package.json` from the config tree, reads
 * `exports["./typert"]`, imports this module, and registers the `TYPERT`
 * export — so this Remote needs no allowlist and no change in the harness
 * repository: the plugin appearing as a Loader entry under its own package name
 * is the whole registration. The manifest is hand-written because the Typert
 * generator runs over the harness workspace rather than over out-of-repo
 * packages; it is structurally what that generator emits, and every codec is a
 * zod v4 schema, which the loader checks.
 *
 * It projects two verbs and no third: read which sites have a stored login, and
 * erase one. Neither carries a cookie, and there is no verb that could — the
 * values live in Chromium's own store and nothing on this side can ask for one.
 *
 * Keep this file free of imports other than `zod`: the loader imports it
 * directly by file path, outside the plugin's own module graph.
 * @module @haoran/dsh-screenshot/typert
 */
import { z } from 'zod';
/** The contribution `dsh-typert-loader` registers for this package. */
export declare const TYPERT: {
    package: string;
    face: string;
    schemas: never[];
    invocations: ({
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: never[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodObject<{
                entries: z.ZodArray<z.ZodObject<{
                    domain: z.ZodString;
                    createdAt: z.ZodNumber;
                    lastUsedAt: z.ZodNumber;
                }, z.core.$strip>>;
                shellAvailable: z.ZodBoolean;
            }, z.core.$strip>;
        };
    } | {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: string;
        };
        parameters: {
            name: string;
            wire: string;
            source: string;
            codec: {
                mode: string;
                typeSymbol: string;
                schema: z.ZodString;
            };
        }[];
        result: {
            mode: string;
            typeSymbol: string;
            schema: z.ZodObject<{
                domain: z.ZodString;
                known: z.ZodBoolean;
            }, z.core.$strip>;
        };
    })[];
    model: {
        services: {
            description: string;
            summary: string;
            tags: never[];
            jsDoc: string;
            key: string;
            exportName: string;
            members: {
                kind: string;
                name: string;
                signature: string;
                summary: string;
                jsDoc: string;
            }[];
            types: never[];
        }[];
        events: never[];
        objects: never[];
    };
};
export default TYPERT;
//# sourceMappingURL=typert.d.ts.map