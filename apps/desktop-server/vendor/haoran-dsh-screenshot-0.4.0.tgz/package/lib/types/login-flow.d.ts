/**
 * What happens between the capture that found a sign-in wall and the capture
 * the person approved.
 *
 * One capture, at most one question, and at most one more capture. The first
 * render is the ordinary one; if it came back showing a sign-in wall, this
 * module asks the person — to open a sign-in window for a site with no stored
 * login, or to use one this machine already holds — and re-renders in that
 * site's partition only when they pressed the one label that means yes.
 *
 * Every path that is not "yes" ends with the capture that already exists and
 * one sentence saying so, except the one the person asks for by name: pressing
 * cancel on the sign-in card throws the capture away and returns that sentence
 * alone. A render that produced pixels is otherwise never failed over a login:
 * the sign-in wall is a fact about the page, and a model that is told what it
 * is looking at can act on it, while an error tells it nothing about the site
 * at all.
 *
 * Four conditions take the whole flow out of the way, all decided before anyone
 * is asked:
 *
 * - The deployment turned it off.
 * - The capture came from a system browser, which reports neither where it
 *   landed nor what the document answered, so there is nothing to read a wall
 *   from.
 * - The call carried its own cookie jar. The caller already supplied a session;
 *   a wall then means that jar is stale, which is the caller's to fix.
 * - The page has no registrable domain — a `file:` URL, an IP literal, a
 *   development host — so there is no site to store a login for.
 * @module @haoran/dsh-screenshot/login-flow
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { LoginWall } from './login-wall.ts';
import type { LoginIndex } from './login-index.ts';
import type { RenderedImage } from './render.ts';
import type { RenderSpec } from './request.ts';
/** What the flow reads from the plugin that runs it. */
export interface LoginFlowOptions {
    /** Whether this deployment offers the flow at all. */
    readonly enabled: boolean;
    /** Path prefixes that read as a sign-in. */
    readonly loginPathPatterns: readonly string[];
    /** This installation's record of which sites have a login. */
    readonly index: LoginIndex;
    /** The environment the desktop route is read from, per call. */
    readonly env: NodeJS.ProcessEnv;
}
/** What the flow decided for one capture. */
export interface LoginFlowResult {
    /**
     * The partition the capture should be re-rendered in, absent whenever no
     * signed-in capture was approved — which is every path except a granted one.
     */
    readonly partition?: string;
    /**
     * Set only when the person asked for no capture at all. The caller throws
     * the image away rather than saving it, writing it to a file, or describing
     * it, and answers with one sentence of its own.
     */
    readonly cancelled?: true;
    /** One sentence the tool result carries, absent when there is nothing to say. */
    readonly note?: string;
}
/** The running call, as the flow needs it. */
export interface LoginFlowCall {
    /** The live root agent whose UI shows the consent card. */
    readonly agent: Agent | undefined;
    /** The call's cancellation. */
    readonly signal: AbortSignal;
}
/**
 * Read one finished capture for a wall this flow may act on.
 * @param spec - the settled render that produced it.
 * @param rendered - the capture.
 * @param options - the deployment's settings.
 * @returns the wall, or undefined when this capture is not one the flow acts on.
 */
export declare function actionableWall(spec: RenderSpec, rendered: RenderedImage, options: LoginFlowOptions): LoginWall | undefined;
/**
 * Ask about one sign-in wall, and say what to render next.
 *
 * A failure to open the window is reported in the same sentence a decline is,
 * because the outcome the caller has to act on is the same: the capture it
 * holds is of a sign-in page. A cancel is the one answer that is not about the
 * page, so it carries no wall sentence at all.
 * @param ctx - the plugin context, for the user-questions channel.
 * @param spec - the settled render that hit the wall.
 * @param wall - the wall it hit.
 * @param call - the live root agent and the call's cancellation.
 * @param options - the deployment's settings.
 * @returns the partition to re-render in, or the sentence explaining why there is none.
 */
export declare function resolveLoginConsent(ctx: Context, spec: RenderSpec, wall: LoginWall, call: LoginFlowCall, options: LoginFlowOptions): Promise<LoginFlowResult>;
/**
 * The sentence a capture carries when the person signed in and the site still
 * refused the page.
 * @param wall - the wall the second capture hit.
 * @returns the sentence, in the words the model reads.
 */
export declare function stillWalledNote(wall: LoginWall): string;
//# sourceMappingURL=login-flow.d.ts.map