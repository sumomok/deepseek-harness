/**
 * A tool that lets the agent look at a page instead of reasoning about its source.
 *
 * An agent writing HTML, CSS, or a component is working blind: it can read back
 * every byte it wrote and still not know that two elements overlap, that a
 * colour is unreadable on its background, or that a layout collapses at the
 * width it was asked for. `screenshot` renders the page and returns the pixels
 * as an image block, which is the only form of that information a model can
 * actually check.
 *
 * The same instrument documents a running system: `cookieJar` names a session
 * this machine holds — the cookies live in the config, never in a tool
 * argument — `headers` carries a token, and `outputPath` puts the PNG on disk
 * where the rest of the work can use it.
 *
 * A capture that goes wrong says why. The desktop render service reports what
 * the main document answered, what the page is still waiting for and on which
 * host, and what it logged; the tool turns that into a few lines beside the
 * image, and a render that runs out of time returns what had painted, labelled
 * as a partial capture, with `blockHosts` and `timeoutMs` named as the
 * remedies the next call can apply.
 *
 * Two backends render, chosen by `backend` and by default in this order:
 *
 * - The desktop shell's own render service, when the shell advertises one
 *   through `DSH_DESKTOP_RENDER_ENDPOINT` and `DSH_DESKTOP_RENDER_TOKEN`. Its
 *   wire protocol is stated in the package README.
 * - A system browser — Chrome, Edge, Chromium, or Brave — in headless mode,
 *   probed at the platform's install locations. Nothing is downloaded.
 *
 * The tool registers only while an attachment store is mounted, because the
 * image block it returns must reference durably committed bytes.
 *
 * Configuration reference and known limits live in the package README.
 * @module @haoran/dsh-screenshot
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { CookieJarConfig } from './cookies.ts';
import type { BackendChoice } from './render.ts';
import type { TimeoutBehavior } from './request.ts';
export { BrowserLocator, browserCandidates, isExecutableFile, NO_BROWSER_FOUND } from './browser.ts';
export type { BrowserLocatorOptions } from './browser.ts';
export { cookieJarSummary, CookieJarsConfig, resolveCookieJars, unknownCookieJar } from './cookies.ts';
export type { CookieConfig, CookieJarConfig, CookieJars, CookieSpec } from './cookies.ts';
export { defaultUserAgent } from './user-agent.ts';
export { applyLogoutCommand, LOGOUT_COMMAND, logoutTarget } from './commands.ts';
export { ALLOW_LABEL, askToReuse, askToSignIn, CANCEL_LABEL, CANCELLED_NOTE, CAPTURE_ANYWAY_LABEL, CONSENT_HEADER, DECLINE_LABEL, DECLINED_NOTE, LOGIN_CONSENT_ID, LOGIN_PRIVACY_NOTE, LOGIN_REUSE_ID, pressed, SIGN_IN_LABEL, } from './consent.ts';
export type { ConsentOutcome, ConsentRequest } from './consent.ts';
export { LoginIndex, LOGIN_INDEX_DIR, LOGIN_INDEX_DIR_MODE, LOGIN_INDEX_FILE, LOGIN_INDEX_MODE, loginIndexPath } from './login-index.ts';
export type { StoredLogin } from './login-index.ts';
export { actionableWall, resolveLoginConsent, stillWalledNote } from './login-flow.ts';
export type { LoginFlowCall, LoginFlowOptions, LoginFlowResult } from './login-flow.ts';
export { LOGIN_SERVICE_KEY, LoginStore, ScreenshotLoginService } from './login-store.ts';
export type { LoginEntry, LoginForgetResult, LoginListResult, LoginStoreOptions } from './login-store.ts';
export { DEFAULT_LOGIN_PATH_PATTERNS, detectLoginWall, unauthenticatedNote } from './login-wall.ts';
export type { LoginWall, LoginWallReason, LoginWallSignals } from './login-wall.ts';
export { loginPartition, LOGIN_PARTITION_PREFIX, registrableDomain, sameSite } from './partition.ts';
export { chromeArguments, launchBrowser, renderWithChrome } from './chrome.ts';
export type { BrowserProcess, ChromeRenderOptions, LaunchBrowser } from './chrome.ts';
export { ABORT_MARGIN_MS, clearLogin, desktopRouteFromEnv, ENDPOINT_ENV, grantLogin, LANDED_URL_HEADER, LOGIN_ABORT_MS, LOGIN_CALL_ABORT_MS, LOGIN_GRANT_PATH, LOGIN_PATH, LOGIN_SESSIONS_PATH, openLogin, renderWithDesktop, TOKEN_ENV, } from './desktop.ts';
export type { DesktopRender, DesktopRoute, LoginGrant, LoginLanding } from './desktop.ts';
export { resolveOutputPath, writeOutput } from './output.ts';
export type { WrittenOutput } from './output.ts';
export { readRenderReport, renderSummary, renderValue, REPORT_HEADER, REPORT_VERSION } from './report.ts';
export type { RenderHostValue, RenderOutcome, RenderReport, RenderSummaryOptions, RenderValue, ReportedCapture, ReportedConsole, ReportedCounts, ReportedDocument, ReportedFailure, ReportedFrameError, ReportedHost, ReportedRenderer, ReportedRequest, ReportHeader, } from './report.ts';
export { NO_RENDER_SERVICE, renderScreenshot } from './render.ts';
export type { BackendChoice, RenderBackends, RenderedImage, RendererName } from './render.ts';
export { carriesSession, MAX_TIMEOUT_MS, MIN_TIMEOUT_MS, normalizeTarget, resolveRenderSpec } from './request.ts';
export type { RenderSpec, ScreenshotLimits, ScreenshotRequest, TimeoutBehavior } from './request.ts';
export { applyScreenshotTool, SCREENSHOT_GUIDANCE, screenshotContent, screenshotTool } from './tool.ts';
export type { ScreenshotCancelled, ScreenshotCapture, ScreenshotToolOptions, ScreenshotValue } from './tool.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "screenshot";
/**
 * The registries the tool and its one prompt line are contributed to.
 *
 * `userQuestions` and `commands` are absent on purpose: a deployment without a
 * UI channel still takes screenshots, it just cannot ask about a login, and a
 * deployment without a commands registry still manages logins from the settings
 * page. Both are reached through `ctx.get` and `ctx.inject` where they are used.
 */
export declare const inject: string[];
/** Plugin configuration; every field is changeable from cordis.yml and validated at load. */
export interface Config {
    /** Viewport width used when a call names none. */
    defaultWidth?: number;
    /** Viewport height used when a call names none. */
    defaultHeight?: number;
    /** Post-load wait used when a call names none. */
    defaultDelayMs?: number;
    /**
     * Longest post-load wait a call may ask for. A call asking for more is an
     * argument error rather than a silently shortened wait, because a capture
     * taken before the page settled looks like a page that renders wrongly.
     */
    maxDelayMs?: number;
    /**
     * Render budget for one capture, in ms, used when a call names none. It is
     * the deadline the renderer runs under, not this plugin's own patience: the
     * desktop request carries it, and the HTTP abort sits above it.
     */
    timeoutMs?: number;
    /**
     * What a render does when its deadline passes, for a call that names
     * nothing: `capture` answers with whatever had painted, labelled partial,
     * and `fail` answers with an error. A page that lays out and then waits on a
     * third-party host is the case `capture` exists for — the pixels are there,
     * and a caller that gets none of them cannot tell a slow page from a broken
     * one.
     */
    onTimeout?: TimeoutBehavior;
    /**
     * Hosts every render of this deployment cancels requests to, as an exact
     * host or `*.suffix`. It is for a host known to hang every page here — an
     * analytics or avatar host behind a firewall that drops rather than
     * refuses — and it is merged with whatever a call names.
     */
    blockHosts?: string[];
    /** Largest viewport width a call may ask for. */
    maxWidth?: number;
    /** Largest viewport height a call may ask for. */
    maxHeight?: number;
    /**
     * Absolute path of the browser binary to render with. Leave it unset to probe
     * the platform's install locations; set it for a browser installed somewhere
     * else, or to pin which of several installed browsers renders. A path that is
     * not an executable file fails on the first capture rather than being skipped.
     */
    browserPath?: string;
    /**
     * The cookie jars a capture may render with, by name.
     *
     * This is where a session lives. A model names a jar and never a cookie,
     * because a cookie written as a tool argument is a credential written into
     * the session log, into every later model request on that session, and into
     * whatever reads that transcript afterwards. The values here reach the
     * renderer and nothing else.
     */
    cookieJars?: Record<string, CookieJarConfig>;
    /**
     * What every render of this deployment says it is.
     *
     * Both backends announce themselves otherwise — the desktop shell's Chromium
     * names Electron and the app, a system browser names its own build — which
     * some sites answer a different page for, and which tells every page the
     * agent looks at what is looking at it. The default is the ordinary
     * stable-Chrome string for this platform. Set it to the empty string to
     * render under whatever the backend sends by itself.
     */
    userAgent?: string;
    /**
     * Which backend renders: `auto` takes the desktop shell's service when one is
     * configured and a system browser otherwise, `shell` renders only through the
     * shell and fails by name when there is none, and `browser` renders through
     * the machine's own Chrome even where a shell is running.
     */
    backend?: BackendChoice;
    /**
     * Whether a capture that comes back showing a sign-in wall asks the person
     * about a login.
     *
     * On by default, and it costs a deployment nothing that does not hit one: the
     * decision is read from what the render already reported. Turn it off for a
     * deployment where nobody is watching the conversation — a scheduled run, an
     * automation server — so a capture that hits a wall answers with the wall
     * instead of blocking on a question no one will see. The desktop shell's
     * render service is the only backend that can carry it either way.
     */
    loginConsent?: boolean;
    /**
     * Path prefixes that read as a sign-in, matched case-insensitively against a
     * landing the render did not ask for.
     *
     * The default list covers what the common frameworks and identity products
     * put a sign-in form at. Extend it for a site that signs in somewhere else,
     * or replace it with a shorter list for a deployment where a `/auth` path is
     * an ordinary page. It never applies to the URL the call asked for: a call
     * that asked for a login page asked to see one.
     */
    loginPathPatterns?: string[];
}
export declare const Config: z<Config>;
/**
 * Register the tool.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map