/**
 * The settings page listing the sites this installation holds a screenshot
 * login for, with a sign-out per site.
 *
 * Three facts per row and no fourth: which site, when the sign-in window that
 * created it closed, and when a capture last used it. That is the whole of what
 * the host will tell this page — the session itself lives in the browser
 * profile Chromium encrypts, and no verb on the wire returns any part of it.
 * @module @haoran/dsh-screenshot/client/LoginsSection
 */
import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { LoginForgetResult, LoginListResult } from '../login-store.ts';
/** The two reads and writes the section performs, bound to the mounted Remote. */
export interface LoginsSectionInjected {
    /**
     * Read the stored logins.
     * @returns the entries, most recently used first, and whether a shell is there to sign out through.
     */
    list: () => Promise<LoginListResult>;
    /**
     * Erase one site's stored login.
     * @param domain - the registrable domain, as the list shows it.
     * @returns the domain and whether the index held it.
     */
    forget: (domain: string) => Promise<LoginForgetResult>;
}
/** Full component props. */
export type LoginsSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'screenshotLogins'> & InjectFace<LoginsSectionInjected>;
/**
 * The registered settings section.
 * @param props - the framework standard kit plus this plugin's Remote face.
 * @returns the page.
 */
export declare function LoginsSection({ list, forget, t }: LoginsSectionProps): ReactNode;
//# sourceMappingURL=LoginsSection.d.ts.map