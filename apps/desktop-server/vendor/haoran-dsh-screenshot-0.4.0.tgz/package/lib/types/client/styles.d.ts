/**
 * The browser half's stylesheet, injected once as a tagged `<style>`.
 *
 * A CSS module would be the shell's own idiom, but this package's build hands
 * `tsc` output to the bundler, and `tsc` emits no stylesheet: the browser entry
 * is bundled from `lib/types/client/index.js`, where a `.module.css` next to
 * the source no longer exists. So the rules live here as text, the way the
 * other out-of-repo plugins carry theirs.
 *
 * Every colour is a harness theme variable rather than a literal, so both
 * surfaces follow the light and dark schemes the shell switches between. The
 * tint is the business-state token, whose light and dark values are the two
 * ends of the same accent, so the card reads as a distinct surface in either.
 * @module @haoran/dsh-screenshot/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-screenshot-logins";
/**
 * Put the stylesheet in the document, once.
 * @returns a disposer removing the tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map