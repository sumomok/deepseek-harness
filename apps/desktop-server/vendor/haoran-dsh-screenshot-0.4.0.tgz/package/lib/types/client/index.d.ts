/**
 * Browser half: the login-consent card that replaces the composer while a
 * capture waits on a login decision, and the settings page that lists the
 * logins already stored.
 *
 * The only host path is the Typert Remote this package's host half exports —
 * one list and one delete, mounted here through `ctx.remote.$mount()`. The card
 * needs no host path at all: it rides the pending-question carrier the runtime
 * already dispatches, and answers back through it.
 *
 * Nothing here ever sees a cookie. The list carries a domain and two dates, the
 * card carries a sentence and two labels, and the wire has no verb that could
 * return anything else.
 * @module @haoran/dsh-screenshot/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { ComposerChainProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import { type QuestionWait } from './contract/slots.ts';
import { type ScreenshotLoginsKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** `@haoran/dsh-screenshot` copy. */
        screenshotLogins: ScreenshotLoginsKey;
    }
}
export { loginConsentOf, PendingLoginConsent } from './contract/slots.ts';
export type { LoginConsent, LoginConsentCardProps, LoginConsentKind, QuestionAnswer, QuestionWait, } from './contract/slots.ts';
export { parseLoginForget, parseLoginList } from './contribution.ts';
export type { LoginsSectionInjected, LoginsSectionProps } from './LoginsSection.tsx';
export type { ScreenshotLoginsKey } from './locales.ts';
/** Required browser services. */
export declare const inject: string[];
/**
 * Chain routing: claim the composer only for this package's own two login
 * decisions, so every other question stays with the stock flow.
 *
 * Pure, as a chain selector must be: a function of the owner props alone.
 * @param props - the composer chain's owner share.
 * @returns the carrier to render, or null to pass to the next entry.
 */
export declare function selectLoginConsent({ interactions }: ComposerChainProps): QuestionWait | null;
/**
 * Mount the browser half.
 * @param ctx - the browser root context.
 */
export declare function apply(ctx: ClientContext): Promise<void>;
//# sourceMappingURL=index.d.ts.map