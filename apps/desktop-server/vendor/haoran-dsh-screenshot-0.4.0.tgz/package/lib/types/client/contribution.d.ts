/**
 * The browser half's Typert contribution: the consumer-side mirror of
 * `../typert.ts`.
 *
 * Each descriptor matches the host manifest's invocation exactly — same id,
 * namespace, method, and parameter wire names — because the gateway matches
 * arguments by field name and rejects a contribution whose descriptors do not
 * line up. The codecs are hand-written narrowings rather than a schema
 * library: this file is bundled into the browser, and a validator's bytes would
 * ride into every page load for one list and one delete.
 *
 * Neither verb carries a cookie, and there is no third one that could.
 * @module @haoran/dsh-screenshot/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { LoginForgetResult, LoginListResult } from '../login-store.ts';
/**
 * Narrow one list read.
 * @param value - the wire value.
 * @returns the stored sites and whether a shell is there to sign out through.
 */
export declare function parseLoginList(value: unknown): LoginListResult;
/**
 * Narrow one sign-out result.
 * @param value - the wire value.
 * @returns the domain asked for and whether this installation had recorded it.
 */
export declare function parseLoginForget(value: unknown): LoginForgetResult;
/** The contribution `ctx.remote.$mount()` installs, mirroring `../typert.ts`. */
export declare const CONTRIBUTION: TypertRemoteContribution;
//# sourceMappingURL=contribution.d.ts.map