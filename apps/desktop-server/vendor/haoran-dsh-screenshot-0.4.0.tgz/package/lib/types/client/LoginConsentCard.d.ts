/**
 * The card the composer shows when a capture needs a decision about a login.
 *
 * It is deliberately not the generic question card. A login decision is the
 * one thing in this plugin the model cannot reach, and the person answering it
 * has to see which site they are about to hand a session to before they see
 * the buttons — so the site is the card's title, in large type, over a tinted
 * surface that reads as its own thing in the transcript.
 *
 * Every word of the decision is the host's. The heading, the sentence and every
 * option description render exactly as they arrived, and each button submits
 * its own label unchanged, because the asker reads the answer as an exact label
 * match. This file translates nothing but its own chrome, and it renders
 * however many choices the host offered rather than a fixed pair.
 * @module @haoran/dsh-screenshot/client/LoginConsentCard
 */
import { type ReactNode } from 'react';
import { type LoginConsentCardProps } from './contract/slots.ts';
/**
 * The registered chain entry.
 *
 * The selector already proved this carrier is one of the two login decisions,
 * so the narrowing here cannot fail; it renders nothing rather than throwing if
 * it ever does, which leaves the request pending and answerable after a reload
 * instead of taking the composer down with it.
 * @param props - the selector-matched carrier plus the framework standard kit.
 * @returns the card for this request.
 */
export declare function LoginConsentCard(props: LoginConsentCardProps): ReactNode;
//# sourceMappingURL=LoginConsentCard.d.ts.map