/**
 * Copy for the browser half, in the two locales the harness ships.
 *
 * The consent card's words are not here. Its header, its question sentence,
 * and both option descriptions arrive on the wire as the host wrote them, and
 * every button submits its label back verbatim — a translated label is a label
 * the host will not recognise as the one that grants a login. Only the card's
 * chrome, which carries no decision, takes a dictionary key.
 * @module @haoran/dsh-screenshot/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "screenshotLogins";
/** Every key the browser half looks up. */
export type ScreenshotLoginsKey = 'nav' | 'intro' | 'privacy' | 'loading' | 'failed' | 'empty' | 'forget' | 'forgetting' | 'signedIn' | 'lastUsed' | 'shellUnavailable' | 'card.dismiss' | 'card.submitting';
/** English copy. */
export declare const en: Record<ScreenshotLoginsKey, string>;
/** Chinese copy. */
export declare const zh: Record<ScreenshotLoginsKey, string>;
//# sourceMappingURL=locales.d.ts.map