/**
 * The login-consent card's slot contract: the narrowing that decides which
 * pending questions this package claims, and the domain face over the
 * runtime's carrier.
 *
 * The carrier (`PendingWait`) transports the envelope and nothing else, so the
 * question protocol — the answer value, the cancelled error, the receipt check
 * — lives here, beside the code that consumes it. The narrowing and the face
 * are two halves of one obligation: the card may claim a request only when it
 * can send every answer that request allows, and {@link PendingLoginConsent}
 * sends exactly one option label per question, so {@link loginConsentOf}
 * accepts only a request a single label answers completely.
 * @module @haoran/dsh-screenshot/client/contract/slots
 */
import type { QuestionResponsePayload } from '@deepseek-ai/dsh-api-remotes/client';
import type { PendingWait } from '@deepseek-ai/dsh-client-runtime/client';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** The pending question carrier the conversation dispatches into the composer chain. */
export type QuestionWait = PendingWait<'question'>;
/** One structured answer batch covering every question of the request. */
export type QuestionAnswer = QuestionResponsePayload['answer'];
/** One question of the request, as the carrier payload carries it. */
type QuestionItem = QuestionWait['payload']['questions'][number];
/** One option the host offered on a question. */
type QuestionOption = NonNullable<QuestionItem['options']>[number];
/** Which of this plugin's two decisions a card carries. */
export type LoginConsentKind = 'sign-in' | 'reuse';
/**
 * A request narrowed to one login decision: everything the card renders and
 * answers with, so the component never re-reads the request itself.
 *
 * Every text field is the host's own copy, carried through unchanged. The card
 * translates none of it.
 */
export interface LoginConsent {
    /** The question id, echoed in the answer. */
    id: string;
    /** Which decision this is, which is what picks the card's wording of its own chrome. */
    kind: LoginConsentKind;
    /** The question sentence, rendered verbatim. */
    question: string;
    /** The host's short heading; absent when the asker sent none. */
    header?: string;
    /** The bare registrable domain, rendered as the card's title; absent when the asker sent no detail. */
    domain?: string;
    /** Every choice the asker offered, in its order; the card renders them all. */
    options: readonly QuestionOption[];
    /** The label that grants the login, which is the first option's. */
    grantLabel: string;
}
/**
 * Narrow a request to a renderable login decision, or return undefined to
 * leave it to the generic question flow.
 *
 * A stored login is the user's own session, so this card claims a request only
 * when it recognises the whole request: one question, one of this package's two
 * ids, exactly the labels that id is asked under, in that order, and a single
 * choice. Anything else — a second question, an extra option, a renamed label,
 * a multi-select batch, a foreign id — has answers these buttons cannot
 * express, and the generic flow keeps it.
 *
 * The domain comes from the question's `detail`, which the host fills with the
 * bare registrable domain. Nothing here reads a domain out of the sentence:
 * prose is copy, and copy changes.
 * @param questions - the request's whole question batch.
 * @returns the narrowed decision, or undefined when the generic flow owns it.
 */
export declare function loginConsentOf(questions: readonly QuestionItem[]): LoginConsent | undefined;
/**
 * The login-decision face over the carrier: render identity and questions
 * forwarded, while `answer` and `cancel` own the wire encoding and turn a
 * rejected receipt into a thrown error. Components mint one per carrier via
 * `useMemo`, never inside a selector — a per-dispatch mint would churn
 * identity and break memoization.
 */
export declare class PendingLoginConsent {
    private readonly wait;
    /**
     * @param wait - the runtime carrier for one pending question request.
     */
    constructor(wait: QuestionWait);
    /** Opaque render identity (React key), forwarded from the carrier. */
    get key(): string;
    /** The request's question list, forwarded from the carrier payload. */
    get questions(): QuestionWait['payload']['questions'];
    /**
     * Answer with one option label and nothing else — no free text, no second
     * selection. The label is sent exactly as the host offered it, because the
     * asker reads the answer as an exact match and treats every other reading as
     * a refusal.
     *
     * The batch this face is minted for is a single question ({@link
     * loginConsentOf} accepts no other), so this sends one answer item.
     * @param label - the pressed option's label, verbatim.
     * @throws when the carrier rejects the response.
     */
    answer(label: string): Promise<void>;
    /**
     * Reject the whole wait, which the host resolves as a capture taken signed
     * out.
     * @throws when the carrier rejects the cancellation.
     */
    cancel(): Promise<void>;
}
/**
 * Full card props: the framework runtime share, the chain entry's selector
 * result already narrowed to the question carrier, and the locale seat this
 * package's chrome reads.
 */
export type LoginConsentCardProps = PropsRuntime<'conversation.composer'> & {
    matched: QuestionWait;
} & PropsLocale<'screenshotLogins'>;
export {};
//# sourceMappingURL=slots.d.ts.map