/**
 * Reading one finished render for whether it shows a sign-in wall instead of
 * the page that was asked for.
 *
 * A capture of a login form returned as the requested page is the failure the
 * whole session story exists to end: the pixels are a correct render of the
 * wrong page, and nothing in them says which of the two it is. This module
 * decides that from what the render already reported, so a wall costs no extra
 * request and a page that loaded fine costs nothing at all.
 *
 * Three signals, any one of which is a wall:
 *
 * - The main frame ended on another site. A page that redirects an anonymous
 *   visitor to its identity provider is the ordinary case.
 * - The main frame ended on the same site at a path that reads as a sign-in.
 *   Checked only for a landing the render did not ask for: a call that asked
 *   for `/login` asked to see the login page, and answering that with a consent
 *   card would be arguing with the caller.
 * - The main document answered 401 or 403. An API-backed page and a site that
 *   refuses rather than redirects both land here.
 *
 * Everything here is pure. The desktop render service is the only backend that
 * reports any of it — a one-shot browser command line says nothing about where
 * it went or what it answered — so a system-browser capture is never read for a
 * wall and degrades to the unauthenticated capture it already was.
 * @module @haoran/dsh-screenshot/login-wall
 */
/**
 * Path prefixes that read as a sign-in, used when a deployment configures none.
 *
 * Prefixes rather than exact paths, because a real sign-in route carries a
 * return URL, a tenant, or a step (`/login/password`, `/auth/callback`). They
 * are matched case-insensitively against the landing's path.
 */
export declare const DEFAULT_LOGIN_PATH_PATTERNS: readonly string[];
/** What one finished render said about where it went and what it answered. */
export interface LoginWallSignals {
    /** The URL the call asked for. */
    readonly requestedUrl: string;
    /** Where the main frame ended, absent when the shell said that was the requested URL. */
    readonly landedUrl?: string;
    /** What the main document answered, absent when the report carried no status. */
    readonly status?: number;
}
/** Which signal named the wall, kept for the note the tool result carries. */
export type LoginWallReason = 'redirected' | 'login-path' | 'status';
/** One sign-in wall, and the site it belongs to. */
export interface LoginWall {
    /** Which signal named it. */
    readonly reason: LoginWallReason;
    /**
     * The registrable domain of the page that was asked for — never the
     * landing's. A login is stored for the site whose page the caller wants, so a
     * hand-off through an identity provider on another domain still files the
     * session under the site that sent the user there.
     */
    readonly domain: string;
    /** Where the wall showed itself, for the note the result carries. */
    readonly landedUrl?: string;
}
/**
 * Read one finished render for a sign-in wall.
 * @param signals - what the render reported.
 * @param patterns - the deployment's login path prefixes.
 * @returns the wall and the site it belongs to, or undefined when the render showed the page that was asked for.
 */
export declare function detectLoginWall(signals: LoginWallSignals, patterns: readonly string[]): LoginWall | undefined;
/**
 * The one sentence a result carries about a wall nobody signed in past.
 * @param wall - the detected wall.
 * @returns the sentence, in the words the model reads.
 */
export declare function unauthenticatedNote(wall: LoginWall): string;
//# sourceMappingURL=login-wall.d.ts.map