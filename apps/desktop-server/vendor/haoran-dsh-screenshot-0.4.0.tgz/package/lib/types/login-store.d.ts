/**
 * The capability behind both ways a person manages their stored logins: the
 * settings page's list, and the `/screenshot-logout` command.
 *
 * Neither surface is reachable by the model. The service is registered on the
 * context so a Typert Remote can project it to the browser and a slash command
 * can call it, and it is deliberately not a tool: what it can do is read which
 * sites have a login and erase one, and the second of those is the user's own
 * decision about their own session.
 *
 * The browser reaches it only through the harness's own `/api` Typert gateway,
 * which inherits the host's trust fence. This plugin registers no HTTP route of
 * its own; the gateway projects exactly the two methods marked below, and a
 * method without that mark is not reachable from a browser at all.
 *
 * It reads nothing a login holds. `list` reads this plugin's own index —
 * domain and two timestamps — and `forget` asks the shell to erase a partition
 * and drops the index entry. A cookie value exists in exactly one place on this
 * machine, Chromium's encrypted profile store, and nothing in this module has a
 * way to ask for one.
 * @module @haoran/dsh-screenshot/login-store
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { LoginIndex } from './login-index.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        screenshotLogins: ScreenshotLoginService;
    }
}
/** The service key, which is also the Typert namespace the browser half calls. */
export declare const LOGIN_SERVICE_KEY = "screenshotLogins";
/** One site with a stored login, as the settings page and the command read it. */
export interface LoginEntry {
    /** The registrable domain. */
    domain: string;
    /** When the sign-in window that created it was closed, as epoch ms. */
    createdAt: number;
    /** When a capture last rendered with it, as epoch ms. */
    lastUsedAt: number;
}
/** What one sign-out did. */
export interface LoginForgetResult {
    /** The domain that was asked for. */
    domain: string;
    /** Whether this installation had recorded a login for it. */
    known: boolean;
}
/** What a `list` answers with. */
export interface LoginListResult {
    /** The sites with a stored login, most recently used first. */
    entries: LoginEntry[];
    /**
     * Whether the desktop shell that holds the logins is reachable. False on a
     * web or server deployment, where the list is what this machine recorded and
     * a sign-out cannot be carried out.
     */
    shellAvailable: boolean;
}
/** How the sign-out reaches the shell, injected so the service can be driven without one. */
export interface LoginStoreOptions {
    /** This plugin's own index of which sites have a login. */
    readonly index: LoginIndex;
    /** The environment the desktop route is read from, per call. */
    readonly env: NodeJS.ProcessEnv;
}
/**
 * The two verbs, without the service registration around them.
 *
 * Split from {@link ScreenshotLoginService} because everything worth checking
 * about them — which entries come back, what reaches the shell, what a refused
 * sign-out leaves behind — is decidable without a cordis root, and a capability
 * that can only be driven through one is a capability that only gets tested
 * through the plugin that mounts it.
 */
export declare class LoginStore {
    private readonly options;
    /**
     * @param options - the index to read and the environment the shell route is read from.
     */
    constructor(options: LoginStoreOptions);
    /**
     * The sites this installation holds a login for.
     * @returns the entries, most recently used first, and whether a shell is there to sign out through.
     */
    list(): Promise<LoginListResult>;
    /**
     * Erase one site's stored login.
     *
     * The shell is asked first and the index second, so a failure to erase leaves
     * the entry visible rather than hiding a login that is still there. A domain
     * this installation never recorded is still sent to the shell: the index is
     * this plugin's own note, the partitions are the truth, and a person who
     * knows the site should be able to clear it either way.
     * @param domain - the registrable domain, as the list shows it.
     * @returns the domain and whether the index held it.
     * @throws when there is no shell to erase through, or when it refuses.
     */
    forget(domain: string): Promise<LoginForgetResult>;
}
/** `ctx.screenshotLogins`: which sites have a stored login, and erasing one. */
export declare class ScreenshotLoginService extends TypertRemoteService {
    private readonly store;
    /**
     * @param ctx - the plugin context this service is registered on.
     * @param options - the index to read and the environment the shell route is read from.
     */
    constructor(ctx: Context, options: LoginStoreOptions);
    /**
     * The sites this installation holds a login for.
     * @returns the entries, most recently used first, and whether a shell is there to sign out through.
     */
    list(): Promise<LoginListResult>;
    /**
     * Erase one site's stored login.
     * @param domain - the registrable domain, as the list shows it.
     * @returns the domain and whether the index held it.
     * @throws when there is no shell to erase through, or when it refuses.
     */
    forget(domain: string): Promise<LoginForgetResult>;
}
export default ScreenshotLoginService;
//# sourceMappingURL=login-store.d.ts.map