/**
 * The list of sites this installation holds a stored login for.
 *
 * The logins themselves live in Chromium's own encrypted profile store, which
 * only the shell can read and which nothing here ever asks it for. What this
 * index holds is the three facts a person needs to manage them — which site,
 * when they signed in, and when a capture last used it — so the settings page
 * can list them and `DELETE /login-sessions` can be aimed at one.
 *
 * It is deliberately not the source of truth about what is stored: the shell's
 * partitions are. An index entry the shell has no partition for costs one
 * sign-in window the next time that site is captured, which is the same thing
 * that happens with no index at all. That asymmetry is why nothing here fails a
 * capture: a read that cannot parse the file starts from an empty list, and a
 * write that cannot land is reported to the log and not to the model.
 *
 * No cookie, token, header, or URL is written here. The file is a domain, two
 * timestamps, and nothing else, at `0600` under a `0700` directory.
 * @module @haoran/dsh-screenshot/login-index
 */
/** Directory under the harness home this plugin owns. */
export declare const LOGIN_INDEX_DIR = "dsh-screenshot";
/** File name under {@link LOGIN_INDEX_DIR}. */
export declare const LOGIN_INDEX_FILE = "logins.json";
/** Mode the index is written with: readable by its owner alone. */
export declare const LOGIN_INDEX_MODE = 384;
/** Mode the directory is created with. */
export declare const LOGIN_INDEX_DIR_MODE = 448;
/** One site this installation holds a login for. */
export interface StoredLogin {
    /** The registrable domain, which is also what its partition is keyed by. */
    readonly domain: string;
    /** When the sign-in window that created it was closed, as epoch ms. */
    readonly createdAt: number;
    /** When a capture last rendered with it, as epoch ms; equal to `createdAt` until one does. */
    readonly lastUsedAt: number;
}
/**
 * The index file inside one plugin-owned root.
 * @param root - the plugin's directory, `$DSH_HOME/dsh-screenshot` by default.
 * @returns the absolute path of the index.
 */
export declare function loginIndexPath(root: string): string;
/**
 * The sites this installation holds a login for, newest use first.
 *
 * Reads on every call rather than caching: the file is a handful of entries,
 * and a settings page that shows a stale list after a sign-out is worse than a
 * read.
 */
export declare class LoginIndex {
    private readonly file;
    private readonly onFailure;
    /**
     * @param file - absolute path of the index file.
     * @param onFailure - told about a write that could not land, so it reaches the host log and nothing else.
     */
    constructor(file: string, onFailure: (message: string) => void);
    /**
     * Every site with a stored login.
     * @returns the entries, most recently used first; empty when there is no readable index.
     */
    list(): Promise<StoredLogin[]>;
    /**
     * Record that a sign-in window created a login for one site, or refresh the
     * time it was last used.
     * @param domain - the registrable domain.
     * @param at - the moment, as epoch ms.
     * @param created - whether a sign-in window just created it, rather than a capture using one that was there.
     * @returns resolves once the index is written, or once the failure is logged.
     */
    record(domain: string, at: number, created: boolean): Promise<void>;
    /**
     * Drop one site from the index.
     * @param domain - the registrable domain.
     * @returns whether the index held it.
     */
    forget(domain: string): Promise<boolean>;
    /**
     * Replace the index.
     *
     * Written to a neighbouring file and renamed, so a process that dies mid-write
     * leaves the previous list rather than half of the new one.
     * @param logins - the entries to keep.
     * @returns resolves once the index is written, or once the failure is logged.
     */
    private write;
}
//# sourceMappingURL=login-index.d.ts.map