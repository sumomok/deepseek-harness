/**
 * The key a stored login is filed under: one persistent partition per
 * registrable domain.
 *
 * A login belongs to a site, not to a URL. `app.example.com` and
 * `accounts.example.com` are the same sign-in, and `example.com` and
 * `example.co.uk` are not — which is a public-suffix question, not a
 * string-suffix one, so `tldts` answers it rather than a hand-rolled rule that
 * would file every `co.uk` site under one shared store.
 *
 * The key is computed in this process and sent to the shell. It is never a tool
 * argument: a model that could name a partition could ask for a capture taken
 * with somebody's session under a domain that has nothing to do with the page,
 * and the whole consent flow would be answering about the wrong site.
 * @module @haoran/dsh-screenshot/partition
 */
/**
 * The prefix the desktop shell requires of every partition it will open a
 * sign-in in, render from, or erase. It is protocol, fixed on both sides.
 */
export declare const LOGIN_PARTITION_PREFIX = "persist:dsh-render-login-";
/**
 * The registrable domain one URL belongs to.
 * @param url - an absolute URL.
 * @returns the eTLD+1, or undefined for a URL with no registrable domain — an IP
 * literal, `localhost`, a `file:` URL, or a host under a public suffix with
 * nothing in front of it.
 */
export declare function registrableDomain(url: string): string | undefined;
/**
 * The partition one site's login is stored in.
 * @param domain - the registrable domain, as {@link registrableDomain} answered it.
 * @returns the partition name the shell accepts for that site.
 */
export declare function loginPartition(domain: string): string;
/**
 * Whether two URLs are the same site.
 * @param left - one absolute URL.
 * @param right - the other.
 * @returns true when both name the same registrable domain; false when either names none.
 */
export declare function sameSite(left: string, right: string): boolean;
//# sourceMappingURL=partition.d.ts.map