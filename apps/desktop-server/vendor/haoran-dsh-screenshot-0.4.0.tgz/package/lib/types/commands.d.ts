/**
 * `/screenshot-logout <domain>`: erase one site's stored login from the
 * conversation, without opening settings.
 *
 * A slash command is the second management surface because it is provably a
 * person: commands never enter the tool catalog, their run and done records are
 * log-only rather than model surface, and the `/` plane is entered from the
 * human composer. A model cannot reach this, which matters more here than for
 * an ordinary command — the verb erases the user's own session.
 *
 * It is registered only where the commands registry is mounted, so a deployment
 * without one keeps the settings page as its single surface and says nothing
 * about a command that is not there.
 * @module @haoran/dsh-screenshot/commands
 */
import type { Context } from '@deepseek-ai/cordis';
/** The command name, without its leading slash. */
export declare const LOGOUT_COMMAND = "screenshot-logout";
/**
 * The registrable domain one argument names.
 *
 * A person types `github.com`, `https://github.com/foo`, or `www.github.com`,
 * and all three mean the same stored login. The argument is read through the
 * same public-suffix answer the partition key is built from, so what the
 * command erases is what the settings page lists.
 * @param raw - everything the person typed after the command name.
 * @returns the domain, or undefined when the argument names no site.
 */
export declare function logoutTarget(raw: string): string | undefined;
/**
 * Register the command where a commands registry is mounted.
 * @param ctx - the plugin context; the command is registered inside `ctx.inject(['commands', 'screenshotLogins'], …)`.
 */
export declare function applyLogoutCommand(ctx: Context): void;
//# sourceMappingURL=commands.d.ts.map