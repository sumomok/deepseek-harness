import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { PrefillStore } from '../core/pending-prefill.ts';
/** The business face this entry's `inject` factory supplies. */
export interface PrefillApplierFace {
    store: PrefillStore;
}
export type PrefillApplierProps = PropsRuntime<'conversation.input.dock'> & PrefillApplierFace;
/**
 * Apply the question waiting for this session, then optionally send it.
 * @param props - slot runtime props and the prefill store.
 * @returns null; this entry occupies no space.
 */
export declare function PrefillApplier(props: PrefillApplierProps): null;
//# sourceMappingURL=PrefillApplier.d.ts.map