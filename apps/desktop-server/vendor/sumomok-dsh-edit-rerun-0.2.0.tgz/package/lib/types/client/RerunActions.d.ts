import type { PropsRuntime, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { StartRerun } from './rerun.ts';
/** The business face this entry's `inject` factory supplies. */
export interface RerunActionsFace {
    startRerun: StartRerun;
}
export type RerunActionsProps = PropsRuntime<'conversation.chat.assistant-actions'> & {
    t: TranslateNS<'edit-rerun'>;
} & RerunActionsFace;
/**
 * Render the edit-and-rerun and rerun-as-is buttons for one assistant message.
 * @param props - slot runtime props, the locale seat, and the rerun flow.
 * @returns the two icon buttons, or null when this turn offers no rerun.
 */
export declare function RerunActions(props: RerunActionsProps): import("react").JSX.Element | null;
//# sourceMappingURL=RerunActions.d.ts.map