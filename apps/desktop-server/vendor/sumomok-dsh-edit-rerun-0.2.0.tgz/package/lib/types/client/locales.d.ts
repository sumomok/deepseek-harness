/**
 * Surface copy for the edit-and-rerun actions. The zh dictionary is the key
 * source; en is typed against it, so a key added to one and not the other is a
 * compile error.
 */
export declare const zh: {
    readonly 'edit.label': "编辑上一条提问并重跑";
    readonly 'edit.hint': "从这一轮之前分叉出新会话，把原提问填进输入框；原会话保持不变。";
    readonly 'rerun.label': "直接重跑这一轮";
    readonly 'rerun.hint': "从这一轮之前分叉出新会话，并原样重发这条提问；原会话保持不变。";
    readonly 'user.edit.label': "修改";
    readonly 'user.edit.hint': "修改这条提问并重跑：从这一轮之前分叉出新会话，原会话保持不变。";
    readonly busy: "正在创建分支…";
    readonly 'error.fork': "创建分支失败：{reason}";
};
/** Every key this plugin's dictionaries define. */
export type EditRerunKey = keyof typeof zh;
export declare const en: Record<EditRerunKey, string>;
//# sourceMappingURL=locales.d.ts.map