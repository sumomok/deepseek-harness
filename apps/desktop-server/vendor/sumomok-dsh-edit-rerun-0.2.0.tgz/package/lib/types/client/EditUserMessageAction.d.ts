import type { PropsRuntime, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { StartRerun } from './rerun.ts';
/** The business face this entry's `inject` factory supplies. */
export interface EditUserMessageFace {
    startRerun: StartRerun;
}
export type EditUserMessageActionProps = PropsRuntime<'conversation.chat.user-actions'> & {
    t: TranslateNS<'edit-rerun'>;
} & EditUserMessageFace;
/**
 * Render the edit-and-rerun button under one user message.
 * @param props - slot runtime props, the locale seat, and the rerun flow.
 * @returns the icon button, or null when this message cannot be re-asked.
 */
export declare function EditUserMessageAction(props: EditUserMessageActionProps): import("react").JSX.Element | null;
//# sourceMappingURL=EditUserMessageAction.d.ts.map