/**
 * Browser half of `@sumomok/dsh-edit-rerun`.
 *
 * Three registrations, all on published conversation seats:
 * - `conversation.chat.assistant-actions` — the edit-and-rerun and
 *   rerun-as-is buttons on each completed turn's action row;
 * - `conversation.chat.user-actions` — the 「修改」 button under the reader's
 *   own question. Hosts before that seat existed never declare it, so this one
 *   is registered lazily and simply never appears there;
 * - `conversation.input.dock` — the invisible applier that hands the parked
 *   question to the forked session's composer.
 *
 * Nothing here writes a session event, calls a host route, reads the
 * filesystem, or opens a network connection.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type EditRerunKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** edit-and-rerun surface copy. */
        'edit-rerun': EditRerunKey;
    }
}
/** Client services this plugin requires. */
export declare const inject: string[];
/**
 * Mount the rerun surface.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map