/**
 * The plugin's one stylesheet, injected once as a tagged `<style>` element.
 *
 * The two action buttons sit inside the host's message IconActions row, so
 * they reuse that row's geometry and `--dsw-*` alias tokens; hover and
 * disabled states need real CSS rules, which inline styles cannot express.
 */
/** Class name of the icon button (mirrors the host's own action chrome). */
export declare const ACTION_CLASS = "dsh-edit-rerun-action";
/** `data-*` attribute marking a button that is busy and refuses clicks. */
export declare const BUSY_ATTR = "data-busy";
/**
 * Install the stylesheet, once per document.
 * @returns a disposer removing the tag, so unloading the plugin leaves no residue.
 */
export declare function installStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map