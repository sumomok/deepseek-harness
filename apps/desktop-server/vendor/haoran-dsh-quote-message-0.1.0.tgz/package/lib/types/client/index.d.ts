import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type QuoteKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Selection pill and `@message` picker copy. */
        'quote-message': QuoteKey;
    }
}
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * Register the `@message` reference source and the selection pill.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map