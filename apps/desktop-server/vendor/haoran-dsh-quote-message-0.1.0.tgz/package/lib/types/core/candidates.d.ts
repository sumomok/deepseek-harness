/**
 * Message candidates for the `@message` picker, derived from the current
 * session's conversation snapshot. Pure: the client half hands in the node
 * list and the localized role words, everything else is computed here.
 *
 * @module @haoran/dsh-quote-message/core/candidates
 */
import type { ConversationNode } from '@deepseek-ai/dsh-client-runtime/client';
import type { QuoteRole } from './quote.ts';
/** One quotable message: the identity the header needs plus its full text. */
export interface QuoteSource {
    /** Session event seq — the picker's key and the header's `#<seq>`. */
    readonly seq: number;
    readonly role: QuoteRole;
    /** Assistant message identity, when the host recorded one. */
    readonly messageId?: string;
    /** Complete message text, uncapped (capping happens when a payload is built). */
    readonly text: string;
}
/** Characters of message text shown in one menu row. */
export declare const CANDIDATE_PREVIEW_LIMIT = 80;
/**
 * Quotable messages of one session, newest first. Assistant reasoning, tool
 * calls, and images are left out: a quote carries what was said, and a
 * message whose text is empty is not offered at all.
 *
 * A steering message is a human prompt admitted mid-turn, so it lists as a
 * user message; every other node kind (tool results, context injections,
 * compaction markers, command rows) is not a message and is skipped.
 * @param nodes - the conversation snapshot's finalized node list.
 * @returns quotable messages ordered newest first.
 */
export declare function quoteSources(nodes: readonly ConversationNode[]): QuoteSource[];
/**
 * Narrow the roll to the messages whose text contains the typed query
 * (case-insensitive, order preserved).
 * @param sources - candidate messages.
 * @param query - the text typed after `@`.
 * @returns the matching messages.
 */
export declare function filterQuoteSources(sources: readonly QuoteSource[], query: string): QuoteSource[];
/**
 * One-line preview of a message: newlines and runs of whitespace collapse to
 * single spaces so a menu row cannot wrap or break the menu's own layout.
 * @param text - message text.
 * @returns at most {@link CANDIDATE_PREVIEW_LIMIT} characters, with an ellipsis when cut.
 */
export declare function candidatePreview(text: string): string;
/**
 * Menu row title: `#12 助手 · the first line of what it said`.
 * @param source - the candidate message.
 * @param roleWord - localized word for a role (the picker's copy, unlike the header's fixed wording).
 * @returns the row title.
 */
export declare function candidateName(source: QuoteSource, roleWord: (role: QuoteRole) => string): string;
/**
 * Resolve the message a picked row names.
 * @param sources - candidate messages.
 * @param seq - seq carried by the picked candidate.
 * @returns the message, or undefined when the snapshot no longer holds it.
 */
export declare function quoteSourceBySeq(sources: readonly QuoteSource[], seq: number): QuoteSource | undefined;
/**
 * Identity of the message a selection landed in. A selection inside a tool
 * result or any other non-message row resolves to its seq alone, which is
 * still worth quoting — the header then names the position without a role.
 * @param nodes - the conversation snapshot's finalized node list.
 * @param seq - anchor seq of the row the selection sits in.
 * @returns seq, plus role and message identity when the row is a message.
 */
export declare function quoteIdentityAt(nodes: readonly ConversationNode[], seq: number): {
    seq: number;
    role?: QuoteRole;
    messageId?: string;
};
//# sourceMappingURL=candidates.d.ts.map