/**
 * Browser half of @sumomok/dsh-quote-message.
 *
 * One way to cite the current session: select text in the chat and click the
 * pill (`conversation.input.dock` entry, see QuoteDock.tsx). The `@` trigger
 * belongs to files, and this plugin contributes no rows to it.
 *
 * Once sent, the quote is shown as a card above the bubble rather than as raw
 * `>` lines inside it: this plugin shadows the host's own user-message
 * renderer and delegates the bubble itself back to it (QuotedUserNodeView).
 *
 * The chip carries the quoted text in its own `ref` payload — never a key
 * into module state, so a chip keeps working after this plugin re-registers.
 * Nothing is written to the session log: the quote reaches the model as part
 * of the ordinary prompt, expanded by the codec below when the composer
 * submits.
 *
 * @module @sumomok/dsh-quote-message/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { type QuoteKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Selection pill and chip copy. */
        'quote-message': QuoteKey;
    }
}
/**
 * Services required by this plugin. Every name a `ctx.<name>` property read
 * reaches must be listed here — the context proxy throws on any other name —
 * so `uiConversation` is present for `identity.ts`, which is the one call site
 * that reads chat node data off it.
 */
export declare const inject: string[];
/**
 * Register the selection pill and the codec that expands its chips.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map