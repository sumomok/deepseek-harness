/**
 * The Moonshot AI members of the adapter registry: one settings-driven
 * resolver shared by the `moonshotai` (international) and `moonshotai-cn`
 * (China) routes — the same account-balance endpoint shape
 * ({@link file://./moonshot-balance.ts}), addressed at each route's own base
 * URL and billed in its own fixed currency.
 *
 * Neither route ships as a dedicated harness LLM provider plugin the way
 * DeepSeek does; both are pi-ai catalog entries. So — unlike the DeepSeek
 * adapter's hardcoded settings namespace — connection facts are found the
 * same way the generic fallback adapter finds any other pi-ai-routed
 * provider's: through `ctx.llm`'s configurable-provider directory
 * ({@link file://./custom-provider.ts}'s `findConfigurableEntry`). What
 * makes this a *named* adapter rather than a generic-fallback candidate is
 * the dedicated endpoint parser plus the default credential reference:
 * pi-ai's own built-in auth for both routes reads `MOONSHOT_API_KEY` from
 * the process environment directly
 * (`@earendil-works/pi-ai`'s `moonshotai`/`moonshotai-cn` provider
 * declarations), not the per-id name
 * ({@link file://./settings-util.ts}'s `deriveKeyRef`) the generic fallback
 * would otherwise assume — so a key set the same way pi-ai itself reads it
 * is found here too, with no dsh-balance-specific configuration.
 *
 * @module @sumomok/dsh-balance/moonshot-adapter
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ResolvedConfig } from './config.ts';
import { type MoonshotBalanceRequest } from './moonshot-balance.ts';
/** One Moonshot route this plugin's dedicated adapter serves. */
export interface MoonshotRoute {
    /** Provider route id, as pi-ai's catalog and `ctx.llm`'s directory name it. */
    provider: string;
    /** Base URL used when the directory names none. */
    publicBaseURL: string;
    /** ISO 4217 code this route's account is always billed in; the endpoint names none of its own. */
    currency: string;
}
/** Provider route id pi-ai registers for the international route. */
export declare const MOONSHOTAI_PROVIDER_ID = "moonshotai";
/** Provider route id pi-ai registers for the China route. */
export declare const MOONSHOTAI_CN_PROVIDER_ID = "moonshotai-cn";
/** The international route: `https://api.moonshot.ai`, billed in USD. */
export declare const MOONSHOTAI_ROUTE: MoonshotRoute;
/** The China route: `https://api.moonshot.cn`, billed in CNY. */
export declare const MOONSHOTAI_CN_ROUTE: MoonshotRoute;
/**
 * Build the resolver the balance reader calls before every read.
 *
 * Connection facts are re-read per call and the key is resolved per call,
 * matching the DeepSeek adapter's own resolver: a key rotated through the
 * Models page, or an endpoint changed in settings, reaches the next poll
 * without restarting anything.
 * @param ctx - the plugin context.
 * @param route - which Moonshot route this resolver serves.
 * @param config - the resolved plugin config.
 * @returns a resolver yielding the next read's facts, or `null` while unconfigured.
 */
export declare function moonshotProviderResolver(ctx: Context, route: MoonshotRoute, config: ResolvedConfig): () => Promise<MoonshotBalanceRequest | null>;
//# sourceMappingURL=moonshot-adapter.d.ts.map