/**
 * Reading Moonshot AI's own account balance: the response shape shared by
 * both the `moonshotai` (international) and `moonshotai-cn` (China) routes,
 * and the perform function the Moonshot member of the adapter registry
 * (`moonshot-adapter.ts`) feeds into {@link file://./balance.ts}'s
 * `BalanceReader`.
 *
 * Both routes answer the identical `GET /v1/users/me/balance` shape at their
 * own origin — verified against <https://platform.kimi.com/docs/api/balance>
 * (China) and <https://platform.kimi.ai/docs/api/balance> (international) on
 * 2026-08-31; both doc domains now redirect from `platform.moonshot.cn` /
 * `platform.moonshot.ai`, which the API's own request domain
 * (`api.moonshot.cn` / `api.moonshot.ai`) is unaffected by. Neither route's
 * response names its own billing currency, so the caller supplies the fixed
 * currency each route is always billed in.
 *
 * @module @sumomok/dsh-balance/moonshot-balance
 */
import type { BalanceView } from './types.ts';
/** A successful read, before staleness is decided at serve time. */
type OkView = Extract<BalanceView, {
    state: 'ok';
}>;
/** A failed read. */
type UnavailableView = Extract<BalanceView, {
    state: 'unavailable';
}>;
/** The endpoint's `data` object, as the provider documents it. */
interface MoonshotBalanceData {
    available_balance: number;
    voucher_balance: number;
    cash_balance: number;
}
/** The endpoint's response body. */
interface MoonshotBalanceResponse {
    code: number;
    data: MoonshotBalanceData;
    scode: string;
    status: boolean;
}
/**
 * Derive the balance endpoint from a route's configured origin.
 *
 * Unlike DeepSeek's own account endpoint ({@link file://./balance.ts}'s
 * `balanceEndpoint`, derived from a chat-completions base URL that may or
 * may not carry a version segment), Moonshot's balance endpoint is
 * documented at a fixed path under the provider's origin regardless of
 * whatever path a configured chat base URL carries, so no path arithmetic is
 * needed beyond discarding it.
 * @param baseURL - the configured provider base URL.
 * @returns the absolute balance endpoint, or `null` when the base URL is not
 * a usable http(s) URL.
 */
export declare function moonshotBalanceEndpoint(baseURL: string): string | null;
/**
 * Narrow a decoded response body to the fields this plugin renders.
 * @param body - the parsed JSON body.
 * @returns the validated response, or `null` when a required field is
 * missing or is not the documented type.
 */
export declare function parseMoonshotBalanceResponse(body: unknown): MoonshotBalanceResponse | null;
/** Everything one read needs, resolved fresh by the caller. */
export interface MoonshotBalanceRequest {
    /** The absolute balance endpoint. */
    endpoint: string;
    /** The API key, held only for the duration of the call. */
    apiKey: string;
    /** ISO 4217 code this route is always billed in; the endpoint names none of its own. */
    currency: string;
    /** Wall-clock budget for the request. */
    timeoutMs: number;
}
/**
 * Perform one balance read.
 * @param request - the resolved endpoint, key, currency, and budget.
 * @param at - epoch milliseconds stamped on the result.
 * @param fetchImpl - the HTTP client.
 * @returns the read's outcome; never a partial or a thrown network error.
 */
export declare function readMoonshotBalance(request: MoonshotBalanceRequest, at: number, fetchImpl: typeof globalThis.fetch): Promise<OkView | UnavailableView>;
export {};
//# sourceMappingURL=moonshot-balance.d.ts.map