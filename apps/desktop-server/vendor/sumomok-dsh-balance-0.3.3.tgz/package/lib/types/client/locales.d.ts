/**
 * Copy for the browser half, in the two locales the harness ships.
 *
 * @module @sumomok/dsh-balance/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "balance";
/** Every key the browser half looks up. */
export type BalanceKey = 'title' | 'clickToPin' | 'clickToUnpin' | 'refresh' | 'granted' | 'toppedUp' | 'total' | 'suspended' | 'stale' | 'updated' | 'unavailable' | 'reason.http' | 'reason.network' | 'reason.timeout' | 'reason.malformed' | 'provider.label' | 'provider.unsupported' | 'loading' | 'quota.title' | 'quota.used' | 'quota.resets' | 'quota.window.weekly' | 'spend.title' | 'spend.today' | 'spend.month' | 'spend.allTime' | 'spend.since' | 'spend.sinceEmpty' | 'spend.pricesAsOf' | 'spend.unpriced' | 'spend.session' | 'spend.requests' | 'settings.nav' | 'settings.unavailable' | 'settings.readOnly' | 'settings.saving' | 'settings.saved' | 'settings.error' | 'settings.thresholds.title' | 'settings.thresholds.low' | 'settings.thresholds.critical' | 'settings.prices.title' | 'settings.prices.currency' | 'settings.prices.model' | 'settings.prices.provider' | 'settings.prices.per' | 'settings.prices.input' | 'settings.prices.inputCacheHit' | 'settings.prices.output' | 'settings.prices.cacheWrite' | 'settings.prices.reasoning' | 'settings.prices.addRow' | 'settings.prices.removeRow' | 'settings.prices.save' | 'settings.prices.tiers' | 'lowBalance.notice';
/** English copy. */
export declare const en: Record<BalanceKey, string>;
/** Chinese copy. */
export declare const zh: Record<BalanceKey, string>;
//# sourceMappingURL=locales.d.ts.map