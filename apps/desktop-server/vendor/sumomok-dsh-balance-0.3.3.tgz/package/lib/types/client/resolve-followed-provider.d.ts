/**
 * Resolves which provider the balance chip should follow.
 *
 * Split out of `./index.ts` (the plugin's composition root) so a test that
 * only wants this pure function does not have to load that root — which now
 * also wires the `shell.overlay` low-balance toast, and so pulls in
 * `@deepseek-ai/dsh-client-ui-primitives`'s real browser bundle transitively.
 * That bundle's CSS Modules imports fail to load under plain Node/vitest
 * outside an actual bundler pass, unrelated to anything this function does.
 *
 * @module @sumomok/dsh-balance/client/resolve-followed-provider
 */
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client';
/**
 * Resolve the provider whose balance the chip should follow: the current
 * session's selected model's provider, read straight off the session's own
 * durable `modelSelection` projection — the same synchronous, no-round-trip
 * read `@haoran/dsh-vision-switch`'s `SessionsFace.projectedSelection` uses.
 * Falls back to DeepSeek for a blank/no-session view, an addressed-subagent
 * session (no live scope, so `binding` reads undefined), or a session with no
 * recorded selection yet — following is a convenience, never a reason to show
 * nothing.
 *
 * Takes `sessions` on its own — not `ctx` — because this package's host half
 * also imports `@deepseek-ai/dsh-session`, whose own `Context.sessions`
 * merge (an unrelated host-side concept sharing the property name) coexists
 * with `@deepseek-ai/dsh-api-session-controller`'s in this package's single
 * TypeScript program; only an explicit `ISessions`-typed value here is
 * trustworthy, not `ctx.sessions` read fresh at every call site.
 * @param sessions - the sessions service (`ctx.sessions`, cast at the one call site that reads it off `ctx`).
 * @returns the provider id to read as followed.
 */
export declare function resolveFollowedProviderId(sessions: Pick<ISessions, 'list' | 'binding'>): string;
//# sourceMappingURL=resolve-followed-provider.d.ts.map