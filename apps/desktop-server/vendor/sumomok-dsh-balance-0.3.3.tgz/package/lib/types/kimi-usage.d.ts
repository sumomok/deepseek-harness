/**
 * Reading Kimi For Coding's subscription usage quota: the response the Kimi
 * Code endpoint answers, the parser that turns it into the windows the UI
 * renders, and the perform function the Kimi member of the adapter registry
 * (`kimi-adapter.ts`) feeds into {@link file://./balance.ts}'s `BalanceReader`.
 *
 * Unlike DeepSeek and Moonshot, Kimi For Coding meters a subscription in usage
 * windows (a weekly allowance and one or more rolling windows), not a money
 * balance — so this adapter produces the `quota` {@link BalanceView}, never the
 * `ok` money view.
 *
 * The endpoint is Kimi's own coding-plan usage route — the same one the Kimi
 * CLI reads a subscription's remaining quota from, addressed with the
 * subscription key (`sk-kimi-*`) the CLI itself uses. It is not part of the
 * Moonshot Open Platform's documented HTTP surface; its response is decoded
 * defensively and every missing or off-type field degrades to "unavailable"
 * rather than a thrown error, because an undocumented route may change its
 * shape between client releases. A read is against the caller's own account
 * with the caller's own credential; nothing here is exercised against a live
 * credential in this package's tests.
 *
 * @module @sumomok/dsh-balance/kimi-usage
 */
import type { BalanceView, QuotaWindow } from './types.ts';
/** A successful quota read, before staleness is decided at serve time. */
type QuotaView = Extract<BalanceView, {
    state: 'quota';
}>;
/** A failed read. */
type UnavailableView = Extract<BalanceView, {
    state: 'unavailable';
}>;
/**
 * The client identifier the Kimi Code usage endpoint gates on: it answers the
 * usage payload only to its own CLI's user agent, and a request without it is
 * rejected. This is an external interface requirement of that endpoint, not a
 * deployment tunable — the value is fixed by the endpoint, so it is a constant
 * here rather than configuration. The credential (`sk-kimi-*`), not this
 * header, is what authenticates the account.
 */
export declare const KIMI_CLI_USER_AGENT = "KimiCLI/1.6";
/** One window's allowance figures, however the endpoint spells the pair. */
interface RawAllowance {
    used?: unknown;
    limit?: unknown;
    remaining?: unknown;
    resetTime?: unknown;
    reset_at?: unknown;
    resetsAt?: unknown;
}
/**
 * The percent of an allowance already used, from whichever of `used` or
 * `remaining` the window carries against its `limit`.
 * @param allowance - the window's raw figures.
 * @returns the used percent clamped to 0–100, or `null` when no usable pair is present.
 */
export declare function usedPercentOf(allowance: RawAllowance): number | null;
/**
 * Read a reset time the endpoint may write as an ISO string, epoch seconds, or
 * epoch milliseconds.
 * @param value - the raw reset field.
 * @returns epoch milliseconds, or `null` when absent or unparseable.
 */
export declare function resetsAtOf(value: unknown): number | null;
/**
 * Turn a decoded usage body into the windows the UI renders.
 *
 * The top-level `usage` object is the weekly allowance and becomes the primary
 * (`weekly`) window the chip shows; each `limits[]` entry is a rolling window
 * named by its own span. A window with no usable allowance pair is skipped.
 * @param body - the parsed JSON body.
 * @returns the windows, weekly first, or `null` when none could be read.
 */
export declare function parseKimiUsage(body: unknown): QuotaWindow[] | null;
/** Everything one quota read needs, resolved fresh by the caller. */
export interface KimiUsageRequest {
    /** The absolute usage endpoint tried first. */
    endpoint: string;
    /** The endpoint tried when the first answers 404 — the older singular path of the same route. */
    fallbackEndpoint: string;
    /** The subscription API key, held only for the duration of the call. */
    apiKey: string;
    /** The client identifier the endpoint gates on. */
    userAgent: string;
    /** Wall-clock budget for the request. */
    timeoutMs: number;
}
/**
 * Perform one usage read, trying the endpoint and then its 404 fallback.
 * @param request - the resolved endpoints, key, user agent, and budget.
 * @param at - epoch milliseconds stamped on the result.
 * @param fetchImpl - the HTTP client.
 * @returns the read's outcome; never a partial or a thrown network error.
 */
export declare function readKimiUsage(request: KimiUsageRequest, at: number, fetchImpl: typeof globalThis.fetch): Promise<QuotaView | UnavailableView>;
export {};
//# sourceMappingURL=kimi-usage.d.ts.map