# @haoran/dsh-llm-permission-gateway

A permission gate for DeepSeek Harness that asks a model instead of consulting a rule table.

Every side-effecting tool call the agent makes is handed to a separately configured review model, which answers `allow`, `ask`, or `deny` together with one sentence saying what running the call would cost. Rule tables were rejected for this job because they accumulate until their entries contradict each other and nobody can say what the set as a whole permits; a review model has no such maintenance surface, at the price of latency, money, and a judgment that is not always the same twice.

## Where it sits

`tools/pre-execute` is the only extension point that sees a call's arguments — the approval seam downstream of it is deliberately blind to them, receiving just a tool name and a call id. The gate registers there with `prepend: true`, so a listener registered earlier cannot allow a call past it.

Without this plugin, two things reach a human, and neither covers an ordinary tool:

- A listener returning `{kind:'ask'}` from `tools/pre-execute`. In the harness that is `hooks-claude-code`, `hooks-codex`, and `tool-jobs`, and nothing else.
- The sandbox-escape path, where `tool-bash` and `tool-fs` hand an approver to the sandbox. A human sees the call only when it tries to leave the sandbox, not when it is made.

A capability plugin that does neither — which is the normal case — contributes tools that no gate ever examines. That gap is what this plugin closes.

## Decision order

1. **Red lines.** Two categories are refused without consulting the review model and without consulting configuration. They run before every skip below, so no config field can route a call around them.
2. **`alwaysAsk`.** Tools that always deserve a human glance, asked with the cost sentence configured for them.
3. **`readOnlyTools`.** Skipped, delegating to the rest of the chain.
4. **Oversized arguments.** Held rather than reviewed in a shortened form.
5. **Cache.** A verdict already reached for the same tool and arguments in the same agent run.
6. **Review model.** One call, one JSON verdict.

An allow returns `next()`, so every other listener on the waterfall still decides. The gate can add denials; it never removes another plugin's.

## Failure never opens the gate

`onFailure` ranges over `ask` and `deny`. There is no `allow` to configure, so a timeout, an unreachable model, an unparsable answer, or arguments too large to review cannot become an allow. This matters more than the review itself: against a fail-open gate an attacker does not have to convince the reviewer, only to make it slow, which is a far lower bar.

Failures are not cached. A single slow moment decides one call, not every later occurrence of it.

## Red lines

Neither is configurable, and neither can be disabled.

**Credential exfiltration** — reading a credential store and sending data off the machine in the same call. Detection is narrow on purpose: it needs a store read (`~/.ssh/id_*`, `~/.aws/credentials`, `.netrc`, a keychain lookup, an environment dump, and similar) together with a way off the machine. An `Authorization: Bearer $TOKEN` header names a secret but reads no store, so an ordinary authenticated API call goes to the review model rather than being refused outright.

**Permission-system self-modification** — any argument that reaches this package's own directory, `$DSH_HOME/profiles`, or `$DSH_HOME/settings.yaml`, by resolved path or by literal text including `$DSH_HOME/profiles`, `cordis.patch.yml`, and this package's name. These locations are derived at load from the running installation, not written down as literals.

The second red line exists because a permission plugin that can be edited by the agent it governs is not a permission plugin. Reads are refused along with writes: whether a given `bash` command writes is not decidable from its arguments, and an agent reading the permission configuration is reconnaissance either way. The cost is real — `ls ~/.dsh/profiles` is refused too — and it is not adjustable.

The review model is told about both categories as well, so it can catch forms the scanner does not match. Neither layer can override the other into an allow.

## Configuration

```yaml
- id: llm-permission-gateway
  name: '@haoran/dsh-llm-permission-gateway'
  config:
    provider: deepseek-official
    model: deepseek-v4-flash
```

| Field | Default | Meaning |
| --- | --- | --- |
| `provider` | required | Registered LLM provider route for the review model. |
| `model` | required | Model id for reviews, chosen independently of the agent's own model. |
| `reasoningEffort` | `off` | Provider-owned effort id; `''` takes the provider default. |
| `timeoutMs` | `30000` | Wall-clock budget for one review. |
| `maxOutputTokens` | `256` | Output cap for the verdict. |
| `maxArgumentsChars` | `200000` | Serialized-argument size above which a call is held instead of reviewed. |
| `onFailure` | `ask` | `ask` or `deny`. No third value exists. |
| `readOnlyTools` | `read`, `read_image`, `glob`, `grep`, `todo_write`, `plan` | Tools passed straight through. |
| `alwaysAsk` | `browser_auth` | Tool name to the cost sentence shown when it is asked about. |
| `cacheEntries` | `512` | Per-agent cap on remembered verdicts; `0` disables reuse. |
| `reasonLanguage` | `English` | Language the review model writes the reason in. |
| `verdictLog` | `$DSH_HOME/llm-permission-gateway/verdicts.jsonl` | JSONL file every decision is appended to; `false` writes no file. |
| `verdictLogArgsPreview` | `0` | Characters of each call's serialized arguments kept in its record; `0` keeps none. |

`alwaysAsk` maps a name to a sentence rather than listing names, because the approval event carries only a tool name and a call id. Without a sentence the user is asked to approve `browser_auth` with no way to know that answering yes hands over a live logged-in session. An entry with an empty sentence fails at load.

`reasoningEffort` defaults to `off` because reviewing one call is a single classification, and thinking tokens otherwise crowd the verdict out of `maxOutputTokens` — which fails closed, so the symptom is an approval prompt on every call rather than a silent allow.

`maxArgumentsChars` and `timeoutMs` are set from measurement rather than from caution. A low argument cap defeats the plugin: the `code` preset's `run_code` calls routinely carry 9-10K characters, so an 8000 cap sent exactly the calls most worth reviewing past the model and into a manual approval prompt. `deepseek-v4-flash` reviews a 200K-character call whole in roughly 5-8 seconds, which the 30-second budget covers.

`reasonLanguage` stays `English` even where the surrounding product is not. Only the review model's own sentence follows this field; the reasons this plugin writes itself — a red line, an oversized call, a review that produced no verdict — are compiled English, so changing the default alone would make the gate answer in one language or the other depending on which step decided. Set the field to make the model's half match a non-English surface, and expect the other half to stay English until the plugin's own strings move with it.

Separating the review model from the agent's model does not defend against a compromised provider. It keeps one model's blind spots from being both the attack surface and the check on it, and a small model keeps review inside the latency budget.

## `ask` needs somewhere to ask

`ask` reaches a human only where an approval answerer is composed. In the harness today that is the Web surface (`@deepseek-ai/dsh-web-app`, through `dsh-host-apiproxy`) and the ACP bridge. Under `@deepseek-ai/dsh-headless`, and in any composition with no answerer, the approval service records the question and returns `unavailable`, so **`ask` is equivalent to `deny`**. The call is refused, the session log still carries the `approval/asked` and `approval/decided` pair, and the model is told an approval channel was unavailable.

That is the correct fail-closed behaviour, and it means a headless deployment gets a gate that refuses rather than a gate that asks. Choose `onFailure` and `alwaysAsk` knowing this.

## The full-access preset it ships with

This gate is what makes a `{sandbox: danger-full-access, approval: ask}` permission preset defensible. The operating system's walls are down, so every judgment about a call is the review model's; `ask` is the channel it uses when it is unsure, and it stays silent the rest of the time because a fully open sandbox raises no escalation of its own.

**The preset travels in this package's own `cordis.patch.yml`**, so mounting the bundle is what makes `yolo-access` exist and unmounting it is what takes the preset away. The pairing needs that to be structural: a profile that defines such a preset without mounting this plugin is strictly worse than `danger-full-access` itself — full access, no model review, and an `ask` policy whose only remaining effect is that the residual approval requests a `never` policy would have refused now reach a human who has no context for them. A plugin that is not mounted runs no code, so it cannot detect its own absence; shipping both rows in one patch file is the only place the coupling can hold.

The preset is `{danger-full-access, ask}` rather than `{danger-full-access, never}` because the latter pair is already `danger-full-access`, and the service resolves a preset by looking its knob values up in the table — two entries sharing a pair both resolve to `custom`, which nobody can select.

The row also carries `glyph: danger-full-access`, so the preset control draws the full-access shield beside it instead of leaving a host-configured preset icon-less; the glyph names presentation only and says nothing about the review the gate performs.

**It is offered, never imposed.** The patch leaves `defaultPreset` unset and declares `yolo-access` last, so the default stays whatever the composed sandbox and approval defaults resolve to — `workspace-write` under `@deepseek-ai/dsh-base`. Turning the sandbox off is always an explicit pick from the preset control.

An id-targeted patch replaces the target row's whole `config`, so the patch restates the three presets `@deepseek-ai/dsh-base` composes, unchanged. That copy is what goes stale: a base release that adds a preset, renames one, or changes a knob pair is shadowed by this file until it is updated, and the symptom is a preset control that quietly keeps offering the old table. `tests/preset-patch.spec.ts` holds the second copy that makes such a change a deliberate two-place edit.

## Cost

Measured against `deepseek-v4-flash` with thinking off: 484 prompt tokens in, roughly 30 out, **median 1.12s** per review (min 0.83s, max 1.33s over six samples).

Three things keep that from multiplying: read-only tools are never reviewed, the verdict is a single turn rather than a conversation, and a repeated call with identical arguments reuses the verdict for the rest of the agent's run.

## Observability

Every decision appends one JSON line to `$DSH_HOME/llm-permission-gateway/verdicts.jsonl` and writes one summary to the host log — `dsh-server.log` in the desktop app, stdout when `dsh` runs in a terminal.

```
verdict allow demo_write_file 1.2s (model) in=36 out=30 cache=448
verdict allow demo_write_file 0.0s (cache)
verdict ask browser_auth 0.0s (alwaysAsk)
verdict ask demo_upload 20.0s (failure: timeout)
```

A step that answered without a review shows no token figures, because it spent none.

```sh
tail -f ~/.dsh/llm-permission-gateway/verdicts.jsonl
```

| Field | Meaning |
| --- | --- |
| `at` | When the decision was reached, ISO-8601. |
| `tool`, `callId` | The call, by the same id the approval seam and the session log carry. |
| `rootCallId` | The enclosing model-requested call; present only for a nested dispatch such as a `run_code` sub-call. |
| `agent` | Session id of the agent the call belongs to; absent for a call made outside an agent. |
| `argsChars` | Serialized size of the call, the number `maxArgumentsChars` is compared against. |
| `argsDigest` | First 12 characters of the arguments' SHA-256 — the cache key's argument half, on every record. Two records sharing it were offered the same arguments. |
| `source` | Which step of the decision order answered: `redline`, `alwaysAsk`, `readOnly`, `oversize`, `cache`, `model`, `failure`. |
| `decision` | `allow`, `ask`, or `deny`. A `readOnly` skip records `allow`, because delegating admits the call. |
| `latencyMs` | Wall-clock time the gate held the call, review round trip included. |
| `model` | The judge route's model, so a record names the reviewer that produced it. |
| `inputTokens`, `outputTokens` | What the review request spent. Present only where a request was issued: every `model` record, and a `failure` whose stream reported usage before it broke. A `cache`, `readOnly`, `alwaysAsk`, `oversize`, or `redline` record has none, because none was paid for. |
| `cacheReadTokens` | Prompt tokens the provider served from its cache. The counts are disjoint, so one review's billed prompt is `inputTokens + cacheReadTokens`. Absent when the provider reported no cache hit. |
| `reasoningTokens` | Thinking tokens inside the answer; absent at the default `reasoningEffort: off`, which produces none. |
| `redLine` | `credential-exfiltration` or `permission-self-modification`; present only on `redline`, so a refusal says which category matched. |
| `failureCause` | `timeout`, `cancelled`, `model-error`, or `unparsable-answer`; present only on `failure`. |
| `reason` | The sentence attached to the decision, truncated at 300 characters. |
| `argsPreview` | Opening characters of the serialized call, whitespace collapsed; present only when `verdictLogArgsPreview` is above zero. |

`verdictLog` sets another path, or `false` to write no file; the host-log summary is written either way.

**`verdictLogArgsPreview` records the user's own argument text.** A digest says two calls were identical without saying what either one asked for, which is enough to count repeated reviews and not enough to read one. The preview closes that gap and is as sensitive as the session log while it does so — a `write` call's preview is the opening of the file being written. The record is created with the process umask under `$DSH_HOME`, so it is protected by whatever protects that directory and by nothing this plugin adds; the host-log summary never carries the preview. Leave it at `0` unless a specific question needs it, and set it to the smallest number that answers the question — `200` is enough to see which file and which command a record was about.

### Reading the record

`scripts/verdict-stats.mjs` reports what a record file says. It is a zero-dependency Node program, installed as the `dsh-gateway-verdicts` command, and it only reads.

```sh
dsh-gateway-verdicts                                  # $DSH_HOME/llm-permission-gateway/verdicts.jsonl
dsh-gateway-verdicts --since 2026-08-21T00:00:00Z --last 50
node scripts/verdict-stats.mjs /path/to/verdicts.jsonl --last 0
```

A profile install puts the command in the profile's own `node_modules/.bin`; from a checkout of this workspace, run the file with `node`. The agent cannot run it either way: `$DSH_HOME/profiles` and this package's own directory are both inside the self-modification red line, so a tool call naming either path is refused. Reading the record is something you do, from a terminal.

A report looks like this:

```
89 records  2026-08-21 15:01:18 → 2026-08-21 15:21:30

by source    model 78   readOnly 9   failure 2
by decision  allow 87   ask 2
by tool      run_code 36   bash 30   write 10   read_image 5   edit 4   read 4

model reviews  78 of 89 records
  latency      p50 1.1s   p90 1.5s   max 2.7s
  requests     79 billed, failures that still spent tokens included
  tokens       in 2844   out 2370   cacheRead 35392
  per request  in 36   out 30   cacheRead 448
  cached       92.6% of prompt tokens (cacheRead of in + cacheRead)

duplicate reviews  2 repeats over 1 set of arguments, 1028 tokens
nested dispatch    53 sub-call records, 24672 tokens — each reviewed on top of the outer call that dispatched it
```

Three of those lines answer questions the file exists for. **`cached`** is why the review is affordable: `in 36` plus `cacheRead 448` is the same 484-token judge prompt the Cost section measures, and it is identical on every call, so the provider serves almost all of it from its cache. **`duplicate reviews`** counts records whose arguments were reviewed again under a different call id within a minute, with one of the two a nested dispatch — a retry or a second agent asking for exactly what was already judged. **`nested dispatch`** counts the sub-calls of a transport tool: under Code Mode, a `run_code` program is reviewed, and then each native call it dispatches is reviewed again. Those two lines are separate on purpose, because a wrapper and its sub-call never have identical arguments — the program text differs from the `write` inside it — so the digest cannot link them and the count does.

`--since` takes any ISO-8601 instant, `--last` sets how many records are listed one per line at the end (`0` lists none), and a positional path reads a file other than the default. A half-written trailing line — the file is appended to by a running gate — is skipped and counted rather than failing the report.

**An allow is visible nowhere else.** A denial surfaces to the model as a tool error and an `ask` reaches the session log as an `approval/asked` pair, but a call this gate allowed is indistinguishable in the session log from one it never saw — which leaves the most common outcome, and the one the review model is actually paid for, unaccounted for. A session event would be the natural home and is not available to an out-of-tree plugin: a `SessionEventMap` member is required-on-read, the harness registers event types in its own tree, and an unknown non-ignorable event makes the host refuse to replay the whole log. Hence a file this package owns, which nothing in the harness reads back.

**The record is an observation, never a control.** Each write is contained, an unwritable path is reported once and then ignored, and no decision depends on the result — a gate that could be jammed by filling a disk would be worse than one that keeps no record. The file is outside the self-modification red line for the same reason: it is evidence of what happened, and red-lining it would claim a tamper-resistance this plugin cannot provide.

## What this gateway does not stop

**It gates what the model asks for, not what a plugin does.** A plugin's own work — inside its HTTP route handlers, background timers, and event listeners — produces no tool call at all, so `tools/pre-execute` never sees it. A plugin calling `node:fs` or `node:child_process` directly bypasses this gate *and* the sandbox-escape path, because it never enters the `ctx.fs` or `ctx.shell` seams either. This is not a gap to be closed here; it belongs to sandboxing and process isolation. Reviewing a third-party plugin still means reading it for bare `fs`/`child_process` use and for registered HTTP routes, which do not pass through the tool pipeline. A gate that leaves people believing otherwise is worse than no gate.

**Red-line detection is textual.** The self-modification scanner matches resolved paths and literal spellings. It does not follow indirection: a path assembled at runtime, `cd` followed by a relative path, a base64 blob, or a helper script written first and run later can all reach a protected location without matching. The review model is the second layer here, not a proof.

**A verdict is a judgment.** The reviewer can be wrong in both directions, and the same call can be judged differently twice. It is a filter, not a decision procedure.

**Injected text is weighed, not neutralised.** Arguments are framed as data on both sides of the fence and the model is told that a claim of prior approval is itself an attack signal. That is a defence with a success rate, not a boundary.

**Caching trusts the arguments.** A call whose arguments are byte-identical to one already allowed in the same agent run is allowed again without review, even though the world may have changed in between.

**The gate sees one call at a time.** A sequence that is harmful only in aggregate — reading a file, then writing it elsewhere, then sending the copy — is reviewed as three separately reasonable calls.

**The decision record sits beside the session log, not in it.** Denials surface as tool errors and asks as `approval/asked`, both durable in the session log; every decision including an allow is in the probe file above, which no session replay reads. A session copied to another machine carries no evidence of what the gate allowed, and deleting the file loses that history with nothing to reconstruct it from.

## Development

See the workspace README for the build, the tarball-based profile install, and why a `link:` dependency must not be used.
