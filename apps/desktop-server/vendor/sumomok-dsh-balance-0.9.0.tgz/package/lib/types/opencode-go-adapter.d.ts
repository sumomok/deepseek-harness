/**
 * The `opencode-go` member of the adapter registry: resolves the connection
 * facts a subscription-usage read needs ({@link file://./opencode-usage.ts}).
 *
 * `opencode-go` is a pi-ai catalog route rather than a dedicated harness LLM
 * provider plugin, so — like the Moonshot and Kimi For Coding adapters — the
 * provider is located through `ctx.llm`'s configurable-provider directory
 * ({@link file://./custom-provider.ts}'s `findConfigurableEntry`). What makes
 * this a *named* adapter is the usage route and its default credential
 * reference: pi-ai's own built-in key variable for the route
 * (`OPENCODE_API_KEY`), resolved when the profile names no `apiKeyEnv`.
 *
 * The usage endpoint is the subscription service's fixed console route, not the
 * chat base URL a `opencode-go` model is called at — a configured base URL
 * points the model's own requests somewhere and says nothing about where the
 * account's usage lives, so this adapter does not read it. Keeping the route
 * fixed also keeps the subscription key from being sent to a host the profile
 * names.
 *
 * @module @sumomok/dsh-balance/opencode-go-adapter
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ResolvedConfig } from './config.ts';
import { type OpencodeUsageRequest } from './opencode-usage.ts';
import { type SettingsSource } from './settings-util.ts';
export { OPENCODE_GO_PROVIDER_ID } from './provider-id.ts';
/**
 * Build the resolver the usage reader calls before every read.
 *
 * Settings are read through `settings` per call and the key is resolved per
 * call, matching the other named adapters' resolvers: a key rotated through the
 * Models page reaches the next poll without restarting anything.
 * @param ctx - the plugin context.
 * @param config - the resolved plugin config.
 * @param settings - where the entry's values are read; per-call `describe()` when omitted.
 * @returns a resolver yielding the next read's facts, or `null` while unconfigured.
 */
export declare function opencodeGoProviderResolver(ctx: Context, config: ResolvedConfig, settings?: SettingsSource): () => Promise<OpencodeUsageRequest | null>;
//# sourceMappingURL=opencode-go-adapter.d.ts.map