/**
 * Reading OpenCode Go's subscription usage: the endpoint, its response body,
 * and the perform function the `opencode-go` member of the adapter registry
 * (`opencode-go-adapter.ts`) feeds into {@link file://./balance.ts}'s
 * `BalanceReader`.
 *
 * OpenCode Go meters a subscription in usage windows (a rolling window, a
 * weekly allowance, and a monthly allowance), not a money balance, so this
 * adapter produces the `quota` {@link BalanceView}, never the `ok` money view.
 *
 * The route is OpenCode's own console API, not the chat base URL a model is
 * called at: `GET https://opencode.ai/zen/go/v1/usage`, authenticated with the
 * same API key the chat routes take. It answers
 * `{ usage: { rolling, weekly, monthly } }`, each window carrying a `status`
 * (`ok` or `rate-limited`), a `percent` already used, and an ISO `resetsAt`
 * (`anomalyco/opencode`'s `zen/go/v1/usage` route, read 2026-10-27). A key with
 * no Go subscription is refused with 403.
 *
 * The response names no window length, so the keys here are the plan's own
 * published windows — a five-hour rolling window, a week, and a month
 * (<https://opencode.ai/go>) — which are also the spans the UI localizes.
 *
 * @module @sumomok/dsh-balance/opencode-usage
 */
import type { BalanceView, QuotaWindow } from './types.ts';
/** A successful quota read, before staleness is decided at serve time. */
type QuotaView = Extract<BalanceView, {
    state: 'quota';
}>;
/** A failed read. */
type UnavailableView = Extract<BalanceView, {
    state: 'unavailable';
}>;
/**
 * The usage endpoint. Fixed: the route belongs to the subscription service, so
 * a chat base URL configured to point somewhere else says nothing about where
 * the account's own usage lives, and the subscription key must not be sent to
 * whatever host a profile names.
 */
export declare const OPENCODE_GO_USAGE_ENDPOINT = "https://opencode.ai/zen/go/v1/usage";
/**
 * Turn a decoded usage body into the windows the UI renders.
 *
 * A window is read from its `percent`; `status: 'rate-limited'` is the
 * endpoint's own verdict that the window is spent, so it reads as fully used
 * whether or not the reported percent has caught up. A window with no usable
 * percent is skipped rather than guessed at.
 * @param body - the parsed JSON body.
 * @returns the windows, rolling first, or `null` when none could be read.
 */
export declare function parseOpencodeUsage(body: unknown): QuotaWindow[] | null;
/** Everything one usage read needs, resolved fresh by the caller. */
export interface OpencodeUsageRequest {
    /** The usage endpoint. */
    endpoint: string;
    /** The subscription API key, held only for the duration of the call. */
    apiKey: string;
    /** Wall-clock budget for the request. */
    timeoutMs: number;
}
/**
 * Perform one usage read.
 * @param request - the resolved endpoint, key, and budget.
 * @param at - epoch milliseconds stamped on the result.
 * @param fetchImpl - the HTTP client.
 * @returns the read's outcome; never a partial or a thrown network error.
 */
export declare function readOpencodeUsage(request: OpencodeUsageRequest, at: number, fetchImpl: typeof globalThis.fetch): Promise<QuotaView | UnavailableView>;
export {};
//# sourceMappingURL=opencode-usage.d.ts.map