/**
 * The price tables this plugin ships with: DeepSeek's published lists, plus
 * Ollama's published per-token cloud rates, and explicit verdicts for models
 * that are published but have no per-token price to copy.
 *
 * Sources, each read on the date named beside it:
 *
 * - DeepSeek CNY: https://api-docs.deepseek.com/zh-cn/quick_start/pricing, read
 *   2026-09-10. It states 「空闲时段价格为高峰时段价格的一半。高峰时段为北京时间
 *   周一至周五 9:00 - 12:00、14:00 - 18:00（其余为空闲时段）。」
 * - DeepSeek USD: https://api-docs.deepseek.com/quick_start/pricing, read
 *   2026-09-10. It states "Off-peak rates are half of the peak rates. Peak
 *   hours are 01:00 - 04:00 and 06:00 - 10:00 UTC, Monday through Friday (all
 *   other hours are off-peak)."
 * - Ollama: https://registry.ollama.com/pricing, read 2026-10-27. It states
 *   "Prices are per million tokens. Off-peak pricing apply outside 12:00 and
 *   18:00 UTC on weekdays and all day on weekends." Model context windows in
 *   `default-providers.ts` come from the corresponding
 *   https://ollama.com/library/<model> page, read on the same date.
 * - Kimi Code: https://www.kimi.com/code/docs/en/kimi-code/membership.html and
 *   https://www.kimi.com/code/docs/en/third-party-tools/codex.html, read
 *   2026-10-27. Both describe Kimi Code as a subscription plan whose models
 *   (`k3.1-pro` included) are metered by usage windows and Extra Usage, not by
 *   a published per-token price list.
 *
 * The DeepSeek pages describe the same instants in their own timezones —
 * 09:00 Beijing is 01:00 UTC — and each list is written in the zone its own
 * page uses rather than converted, so a reader can check either against its
 * source. The same shape serves Ollama's off-peak list: the base rates are the
 * off-peak numbers and a `peak` schedule doubles them during 12:00–18:00 UTC
 * on weekdays, which leaves all weekend and every other weekday hour on the
 * base.
 *
 * DeepSeek prices neither cache-write tokens nor reasoning tokens separately,
 * so both fields are left to their defaults: a cache write bills at the
 * cache-miss input rate and a reasoning token bills at the output rate. Ollama
 * publishes a distinct cached-input rate, which every priced Ollama row states
 * explicitly.
 *
 * DeepSeek's pages list exactly two models, `deepseek-flash` and
 * `deepseek-v4-pro`. The two retired Flash ids are priced here anyway, at the
 * `deepseek-flash` rates, on the pages' own instruction: 「旧模型名
 * deepseek-v4-flash、deepseek-v4-flash-vision-exp 仍可调用，但对应模型已下线，
 * 请求将由 DeepSeek-V4.1-Flash 模型提供服务，并按 Flash 价格计费。」 A stored
 * selection can still name one, and a request on it bills at this rate, so
 * dropping the rows would report those turns as unpriced tokens.
 *
 * `deepseek-v4-pro` keeps its own rates after 2026-09-14. DeepSeek's update
 * log entry of 2026-09-10 (https://api-docs.deepseek.com/zh-cn/updates):
 * 「为响应广大用户的需求，我们决定在 2026 年 9 月 14 日之后继续提供 DeepSeek V4 Pro
 * 的 API 调用服务，计费方式保持不变；如有变动，我们将另行通知。」
 *
 * Ollama's table names models that are served by ollama.com, not models run
 * from local weights: a local Ollama server has no per-token charge. The
 * rows are scoped to the `ollama` route because that is the route a
 * deployment points at `https://ollama.com`; a deployment that points that
 * route at a local server should remove these rows with `pricesOverride`.
 *
 * `kimi-coding` and `kimi-coding-openai` are deliberately absent from every
 * currency's `entries`: Kimi Code bills a subscription, so there is no public
 * per-token number to transcribe and inventing one would overcharge every
 * plan-only turn. Both routes' `k3.1-pro` verdict is recorded under
 * `unpriced` instead, which is what the UI must show when a reader asks why a
 * published model has no number.
 *
 * Maintenance: when a vendor changes a rate, restates an off-peak window, adds
 * a model to its published list, or starts/stops publishing a per-token
 * price, update the row here and bump `asOf`; then run
 * `node scripts/build-price-feed.ts`, upload `feed/prices.json`, and only then
 * ship the package (see README "Where the prices come from"). A model that
 * cannot be priced from a public per-token source gets an entry under
 * `unpriced` with the source and the date it was read — never a guessed rate
 * and never a silent zero.
 *
 * These numbers are the deployment's to maintain, and the currency set is
 * open — adding a third list is a third key under `tables`. Overriding
 * `prices` in `cordis.yml` replaces the whole table.
 *
 * @module @sumomok/dsh-balance/default-prices
 */
import type { PriceTable } from './prices.ts';
/** The shipped price table's date: the latest source read above. */
export declare const DEFAULT_PRICES_AS_OF = "2026-10-27";
/** Published rates and explicit unpriced verdicts this plugin ships with. */
export declare const DEFAULT_PRICES: PriceTable;
//# sourceMappingURL=default-prices.d.ts.map