/**
 * Default metadata for providers this plugin knows from public catalogs but
 * has no user-supplied model list for.
 *
 * This is display and pricing metadata only. It never registers an LLM
 * adapter and never changes `llm-pi-ai` or any other provider plugin: a
 * provider still has to be configured (or registered by its own plugin)
 * before the harness can route a request to it. What this module supplies is
 * the fallback a reader sees when no such configuration exists — the provider
 * id, its display name, and the models and context windows its public
 * catalog lists — so a model list is not silently empty and a price row can
 * be tied back to the model it names.
 *
 * Only `ollama` currently ships defaults. Its sources, read 2026-10-27:
 *
 * - Pricing: https://registry.ollama.com/pricing
 * - Model pages: https://ollama.com/library/<model>, each naming its context
 *   window; `gpt-oss` is read from https://ollama.com/library/gpt-oss because
 *   its tags are size variants of one page.
 *
 * Explicit configuration always wins: {@link resolveProviderDefaults} returns
 * the caller's display name and model list whenever either is supplied, and
 * falls back to this table only for what was omitted. An omitted model list
 * and an explicitly empty one are different — the latter states "this
 * provider has no models", so it is returned as empty rather than replaced by
 * the shipped catalog.
 *
 * @module @sumomok/dsh-balance/default-providers
 */
/** Provider id `ollama` (the route a deployment points at `https://ollama.com`). */
export declare const OLLAMA_PROVIDER_ID = "ollama";
/** One model a default provider lists, with the context window its own page states. */
export interface DefaultProviderModel {
    /** Model id exactly as the provider's catalog writes it. */
    id: string;
    /** Context window in tokens, as the model's own page states it. */
    contextWindow: number;
    /** Page that states the context window. */
    source: string;
}
/** One provider's shipped fallback metadata. */
export interface DefaultProvider {
    /** Provider route id. */
    id: string;
    /** Display name the provider itself uses. */
    displayName: string;
    /** Models its public catalog lists, in catalog order. */
    models: readonly DefaultProviderModel[];
    /** Page listing the provider's public model catalog. */
    source: string;
    /** Pricing page for the same catalog, when it publishes per-token rates. */
    pricingSource?: string;
    /** Date the pages above were read, `YYYY-MM-DD`. */
    checkedAt: string;
}
/** What a caller can explicitly configure, overriding the shipped defaults. */
export interface ProviderDefaultsOverride {
    /** Display name to use in place of the shipped one. */
    displayName?: string;
    /**
     * Model list to use in place of the shipped one. An explicitly empty array
     * is honoured as "no models"; leave the field out to keep the defaults.
     */
    models?: readonly DefaultProviderModel[];
}
/** The display facts after explicit configuration has been applied. */
export interface ResolvedProviderDefaults {
    /** Provider route id. */
    id: string;
    /** The explicit display name when one was supplied, otherwise the shipped one. */
    displayName: string;
    /** The explicit model list when one was supplied, otherwise the shipped catalog. */
    models: readonly DefaultProviderModel[];
}
/**
 * Ollama's default metadata, for a deployment that has not configured the
 * route and still wants the catalog shown. The models are the ones
 * `default-prices.ts` prices (plus the two chat models whose published rate
 * set is incomplete and is recorded there as unpriced), with the context
 * window each model page states. `clef` is not listed: Ollama publishes no
 * output rate for it, so it has no complete chat price either.
 */
export declare const OLLAMA_DEFAULT: DefaultProvider;
/** Every provider whose fallback metadata ships with this plugin. */
export declare const DEFAULT_PROVIDERS: readonly DefaultProvider[];
/**
 * Find a shipped default provider by route id.
 * @param id - provider route id.
 * @returns its metadata, or `undefined` when this plugin ships none.
 */
export declare function findDefaultProvider(id: string): DefaultProvider | undefined;
/**
 * Apply explicit configuration over one provider's shipped defaults.
 *
 * A supplied `displayName` or `models` wins outright, including an explicitly
 * empty model list; only an omitted field falls back to the shipped value.
 * This is the rule the rest of the plugin follows for prices too: a user's
 * configuration overrides the shipped table, and a value the plugin cannot
 * establish is shown as unpriced or unavailable rather than filled with zero.
 * @param provider - the shipped defaults for one provider.
 * @param configured - the caller's explicit display facts, when any.
 * @returns the display facts to show.
 */
export declare function resolveProviderDefaults(provider: DefaultProvider, configured?: ProviderDefaultsOverride | undefined): ResolvedProviderDefaults;
//# sourceMappingURL=default-providers.d.ts.map