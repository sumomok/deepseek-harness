/**
 * The balance adapter registry: one memoized {@link BalanceReader} per
 * provider id, keyed by provider so a deployment reading several providers
 * (the session-followed one, plus whatever the provider picker last
 * previewed) gets each its own refresh/retry cache instead of sharing one.
 *
 * DeepSeek, the two Moonshot AI routes (`moonshotai`, `moonshotai-cn`), Kimi
 * For Coding (`kimi-coding`), Ollama (`ollama`), and OpenCode Go
 * (`opencode-go`) are the named members — each with its own dedicated reader,
 * ahead of the generic fallback. Kimi For Coding and OpenCode Go report a
 * subscription quota ({@link BalanceView}'s `quota` state) rather than a money
 * balance; Ollama reports money for a current plan and a quota for a legacy
 * one; the others report money. Every other provider id falls through to the
 * generic fallback adapter, which only ever runs when `ctx.llm`'s own
 * configurable-provider directory names a settings address for that id
 * (`custom-provider.ts`); nothing here special-cases which adapter family
 * registered it. A future named adapter for another specific provider joins
 * this registry the same way.
 *
 * @module @sumomok/dsh-balance/adapters
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ResolvedConfig } from './config.ts';
import type { BalanceView, ProviderOption } from './types.ts';
/**
 * Owns one memoized reader per provider id that has been read at least once.
 * Memoization is what makes the refresh/retry windows mean something: a
 * fresh reader per call would never serve from cache, and the generic
 * adapter's remembered endpoint shape (`generic-adapter.ts`) would never
 * survive between calls either.
 *
 * Every reader resolves its provider's settings through one
 * {@link SettingsSnapshot}, held for `refreshMs` or until
 * {@link AdapterRegistry.invalidateSettings}, so the reads of one provider
 * picker load share one `ctx.settings.describe()` call.
 */
export declare class AdapterRegistry {
    private readonly ctx;
    private readonly config;
    private readonly adapters;
    private readonly settings;
    /**
     * @param ctx - the plugin context.
     * @param config - the resolved plugin config.
     */
    constructor(ctx: Context, config: ResolvedConfig);
    /**
     * Drop the shared settings snapshot, so the next resolver reads settings
     * again. The plugin calls this when the settings service reports a changed
     * entry and when `ctx.llm`'s adapter routes change.
     */
    invalidateSettings(): void;
    /**
     * Read one provider's balance.
     * @param provider - provider route id.
     * @param force - bypass the refresh and retry windows and drop the shared
     *   settings snapshot; an in-flight read is joined rather than duplicated.
     * @returns the view. A generic-adapter failure comes back as the quiet
     * `unconfigured` state rather than `unavailable`: see the registry's module
     * doc. A route in {@link EXCLUDED_PROVIDER_IDS} is `unconfigured` without
     * resolving a key or making a request, whether the picker or the followed
     * session names it.
     */
    get(provider: string, force: boolean): Promise<BalanceView>;
}
/**
 * The provider picker's roster: every provider route the harness knows,
 * active or dormant, DeepSeek always included even when `ctx.llm` is not
 * composed (this plugin can still query it through its own settings-only
 * resolver), and the routes in {@link EXCLUDED_PROVIDER_IDS} never. Carries
 * no adapter or configuration fact — see {@link ProviderOption}.
 * @param ctx - the plugin context.
 * @returns the roster, DeepSeek first, in directory then registration order.
 */
export declare function providerRoster(ctx: Context): ProviderOption[];
/**
 * The provider picker's roster, filtered to providers this deployment can
 * actually show a balance for.
 *
 * Filtering happens in two passes because "configured" (a credential
 * actually resolves) is not knowable without asking each adapter, while
 * "supported" (an adapter exists that could ever resolve one) is a static
 * fact of the directory: {@link supportedProviderIds} narrows the full
 * roster to the statically eligible providers first, then this function
 * probes only those — one `AdapterRegistry.get` read each, sharing the same
 * refresh/retry cache the chip's own balance reads use, so a poll tick
 * already holding a fresh answer costs no extra network call, and the same
 * settings snapshot, so all the probes together call
 * `ctx.settings.describe()` at most once. A candidate
 * whose read comes back `unconfigured` (no credential resolves; see
 * {@link AdapterRegistry.get}'s doc on the generic adapter's quiet failure)
 * is dropped.
 *
 * Carries no notion of which provider is "followed" — the caller's own
 * followed-provider balance read already exercises that id through this same
 * registry, and folding it back into the roster if this filter ever excluded
 * it is the browser half's job ({@link file://./client/store.ts}), not this
 * one's.
 * @param ctx - the plugin context.
 * @param registry - the adapter registry probed for each supported candidate.
 * @returns the filtered roster, in {@link providerRoster}'s order.
 */
export declare function pickableProviderRoster(ctx: Context, registry: AdapterRegistry): Promise<ProviderOption[]>;
//# sourceMappingURL=adapters.d.ts.map