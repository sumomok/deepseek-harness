/**
 * The Ollama member of the adapter registry: resolves the connection facts a
 * balance read needs ({@link file://./ollama-balance.ts}).
 *
 * Ollama is not a pi-ai catalog route and ships no dedicated harness LLM
 * provider plugin, so — like the Moonshot and Kimi For Coding adapters, and
 * unlike the DeepSeek adapter's hardcoded settings namespace — whether the
 * provider is configured is found through `ctx.llm`'s configurable-provider
 * directory ({@link file://./custom-provider.ts}'s `findConfigurableEntry`).
 * The route id is the one a Models-page entry for Ollama's OpenAI-compatible
 * endpoint (`https://ollama.com/v1`) conventionally carries.
 *
 * What makes this a *named* adapter rather than a generic-fallback candidate
 * is the balance route: it lives on Ollama's cloud service
 * (`https://ollama.com/api/balance`), not beside the chat path a provider is
 * configured with, so the endpoint is derived from the configured origin by
 * {@link ollamaBalanceEndpoint} and refused outright when that origin is not
 * Ollama Cloud. The credential defaults to `OLLAMA_API_KEY` — the name the
 * provider's own tooling reads, and the same name the Models page would derive
 * for this id.
 *
 * @module @sumomok/dsh-balance/ollama-adapter
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ResolvedConfig } from './config.ts';
import { type OllamaBalanceRequest } from './ollama-balance.ts';
import { type SettingsSource } from './settings-util.ts';
export { OLLAMA_PROVIDER_ID } from './provider-id.ts';
/**
 * Build the resolver the balance reader calls before every read.
 *
 * Settings are read through `settings` per call and the key is resolved per
 * call, matching the other named adapters' resolvers: a key rotated through the
 * Models page, or an endpoint changed in settings, reaches the next poll
 * without restarting anything.
 * @param ctx - the plugin context.
 * @param config - the resolved plugin config.
 * @param settings - where the entry's values are read; per-call `describe()` when omitted.
 * @returns a resolver yielding the next read's facts, or `null` while unconfigured.
 */
export declare function ollamaProviderResolver(ctx: Context, config: ResolvedConfig, settings?: SettingsSource): () => Promise<OllamaBalanceRequest | null>;
//# sourceMappingURL=ollama-adapter.d.ts.map