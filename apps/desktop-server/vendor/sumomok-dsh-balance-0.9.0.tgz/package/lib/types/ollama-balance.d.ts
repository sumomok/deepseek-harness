/**
 * Reading Ollama Cloud's account balance: the endpoint, the two response
 * bodies it documents, and the parser the Ollama member of the adapter
 * registry (`ollama-adapter.ts`) feeds into {@link file://./balance.ts}'s
 * `BalanceReader`.
 *
 * Ollama's cloud service documents both an account balance and a usage
 * history; this module reads the balance
 * (<https://docs.ollama.com/api/balance>, checked 2026-10-27). A plan in the
 * current shape answers money — included credits for the period, plus
 * purchased credits — and becomes the `ok` view. A legacy plan answers session
 * and weekly limits as a remaining percent instead, with no money in the
 * response at all, and becomes the `quota` view: the plugin never converts a
 * percent into a currency amount.
 *
 * The route exists on the cloud service alone. A local Ollama daemon has no
 * account and no such route, so {@link ollamaBalanceEndpoint} refuses any
 * origin but `https://ollama.com` rather than letting a poll address an
 * unrelated local server with a cloud API key, and refuses plaintext even
 * there: the one host it accepts is a public https service, so an `http:` base
 * URL would only carry the key in the clear.
 *
 * @module @sumomok/dsh-balance/ollama-balance
 */
import type { BalanceView, QuotaWindow } from './types.ts';
/** A successful money read, before staleness is decided at serve time. */
type OkView = Extract<BalanceView, {
    state: 'ok';
}>;
/** A successful quota read, before staleness is decided at serve time. */
type QuotaView = Extract<BalanceView, {
    state: 'quota';
}>;
/** A failed read. */
type UnavailableView = Extract<BalanceView, {
    state: 'unavailable';
}>;
/**
 * Derive the balance endpoint from a chat base URL.
 *
 * The balance route hangs off the service origin, not off the OpenAI-compatible
 * path a chat client is configured with, so `https://ollama.com/v1` and
 * `https://ollama.com` both reach `https://ollama.com/api/balance`.
 * @param baseURL - the configured provider base URL.
 * @returns the absolute balance endpoint, or `null` when the base URL is not a
 * usable http(s) URL or does not address Ollama Cloud.
 */
export declare function ollamaBalanceEndpoint(baseURL: string): string | null;
/** A response that carries money amounts. */
export interface OllamaMoneyBalance {
    kind: 'money';
    /** Remaining included credits for the current period, in USD. */
    included: number;
    /** Remaining unexpired purchased credits, in USD. */
    purchased: number;
}
/** A legacy plan's response: percent-of-limit windows, with no money at all. */
export interface OllamaQuotaBalance {
    kind: 'quota';
    /** The metered windows, the shorter one first; never empty. */
    windows: QuotaWindow[];
}
/** One decoded response body. */
export type OllamaBalanceResponse = OllamaMoneyBalance | OllamaQuotaBalance;
/**
 * Narrow a decoded balance body to what this plugin renders.
 *
 * The two shapes are told apart by what `included` carries: the current plan's
 * money fields, or a legacy plan's `session`/`weekly` limits. A body carrying
 * neither — or carrying one with an unusable figure — is no balance.
 * @param body - the parsed JSON body.
 * @returns the decoded response, or `null` when no shape matches.
 */
export declare function parseOllamaBalance(body: unknown): OllamaBalanceResponse | null;
/** Everything one balance read needs, resolved fresh by the caller. */
export interface OllamaBalanceRequest {
    /** The absolute balance endpoint. */
    endpoint: string;
    /** The API key, held only for the duration of the call. */
    apiKey: string;
    /** Wall-clock budget for the request. */
    timeoutMs: number;
}
/**
 * Perform one balance read.
 * @param request - the resolved endpoint, key, and budget.
 * @param at - epoch milliseconds stamped on the result.
 * @param fetchImpl - the HTTP client.
 * @returns the read's outcome; never a partial or a thrown network error.
 */
export declare function readOllamaBalance(request: OllamaBalanceRequest, at: number, fetchImpl: typeof globalThis.fetch): Promise<OkView | QuotaView | UnavailableView>;
export {};
//# sourceMappingURL=ollama-balance.d.ts.map