# @sumomok/dsh-balance

[English](README.md) | 中文

DeepSeek Harness Web 界面的账户余额与消费统计。侧边栏底部一个图框跟随当前会话所选模型所属的供应商,显示该账户的剩余余额(`DeepSeek ¥12.34`)——切换会话、或在会话内切换模型都会跟着变。悬停展开面板,顶部是一个供应商下拉(覆盖本部署当前能查到余额的那些供应商),下面是该供应商的余额构成,以及本机在该供应商上今日、本月、累计的消费——消费跟着下拉走,余额下面那个数字就是这条路由自己的。当前会话花了多少,在打了核心补丁的构建里直接长在输入框下方自带的 token 用量药丸上,其余构建里单独占一行。

余额是服务方自己给的数字:DeepSeek 和 Moonshot AI(`moonshotai`、`moonshotai-cn`)的货币余额走各自的专属适配器;Kimi For Coding 与 OpenCode Go(`kimi-coding`、`opencode-go`)的订阅配额走各自的适配器(按窗口给「已用百分比」,而不是货币余额);Ollama(`ollama`)的云端额度走它自己的适配器,其旧版套餐给的是会话与周限额,因此按配额显示而不是编一个金额;其余任何已配置的供应商走一个尽力而为的通用适配器,依次尝试几种常见 OpenAI 兼容网关会回答的端点形状。消费是把 harness 已经记录的 token 用量,乘以本部署自己拥有的价格表算出来的——运行时不抓取任何页面;价格表里没有的模型,记为「未计价 token」,而不是悄悄当成 0。订阅配额路由(`kimi-coding`、`opencode-go`)上的流量无论价格表里有什么都不计价:它的 token 记为「套餐内」。随包价格表开箱即带 DeepSeek 的两种货币与 Ollama 的云模型目录;已发布但没有完整公开按 token 价格的模型,会在表里显式记为「未计价」,并写明来源与读取日期。

## 显示什么,显示在哪

**侦察结论:落位在 `sidebar.footer.action`,不在「设置」同一行。** 没有槽位能让第三方插件挤进「设置」触发按钮的同一行:`SidebarRoot.tsx` 的 `.footArea` 里,`sidebar.settings` 与 `sidebar.footer.action` 是纵向堆叠(`flex-direction: column`)的两个独立满宽 flex 子项,而「设置」触发按钮自己的内容(图标+文字)本身是一个单占用槽位(`settings.trigger`),已经被 `ui-settings-general` 占用。要落到「设置」同一行,core 需要二选一:(a) 把 `.footArea` 改成 `flex-direction: row`,让 `sidebar.footer.action` 靠右而不是堆叠在 `sidebar.settings` 上方;(b) 在触发按钮内部新开一个「尾部内容」槽位,且不能抢走按钮本身的点击目标。两者都没有,于是维持原位(`sidebar.footer.action`,仍在「设置」正上方),只是改成单行样式。

| 界面 | Slot | 内容 |
| --- | --- | --- |
| 侧边栏底部图框 | `sidebar.footer.action` | `供应商 ¥12.34`,按配置的阈值着色,供应商为当前会话所选模型所属的那一个。作为普通 flex 子项——这一行可能有别的插件共享——会撑满这一行留给它的宽度(独占时是整行,与别的插件共享时是它自己的那一份),供应商名靠最左、金额靠最右;挤不下供应商名时才退化成 `¥12.34`,而不是把邻居挤开或换行。56 px 窄栏下只显示金额;展开态悬停打开浮层。开启 `maskBalance` 后显示 `¥ ••••`(配额型供应商是 `••••`),可见文字、tooltip、以及窄栏测量用的离屏 span 一律如此。 |
| 浮层 | — | 顶部是供应商下拉(覆盖本部署当前能查到余额的供应商,见下),然后是该供应商的余额构成,以及本机在**该供应商**上的今日 / 本月 / 累计消费及各价格档位占比、价格表日期。按订阅配额计量的供应商(`kimi-coding`、`opencode-go`),消费显示为 `1.2K tok 套餐内`——订阅没有单次金额;按供应商路由判定,所以额度读取失败时也不会变成未计价;按量计费但价格表没配的,显示为「N token 未计价」。列表不足两项时下拉隐藏——没什么可选的。浮层底部除「刷新」外还有「充值」——针对下拉当前所指的那个供应商,且本插件收录了它的充值页时才出现。 |
| 会话消费 | `conversation.chat.stats.usageLabel` 与 `conversation.chat.stats.usageRows`,或 `conversation.composer.dock` | `¥0.10`;若该会话有模型不在价格表内,追加 `· N tok 未计价`;该会话在订阅配额路由(`kimi-coding`、`opencode-go`)上的 token 追加 `· N tok 套餐内`,既不计入金额,也不算未计价;只在套餐内跑过的会话不显示金额,只显示 `N tok 套餐内`。它是自带 token 用量药丸最前面那一段——后面的 `· 缓存命中 93%` 仍由药丸自己画;点开药丸的弹层里再加几行:本会话合计一行;模型与价格档位在不止一个时各自逐行列出;有未计价 token 时再加一行;有套餐内 token 时再加一行。这两个座位只存在于打了核心补丁的构建;没有补丁时,同样这些数字单独占输入框下方一行,写作 `本会话花费 ¥0.10`。金额变化时约半秒滚动到新值;系统开启「减少动态效果」时直接跳变。不受供应商下拉影响:这里始终是当前会话自己在同一份部署价格表下的账目(见「不做的事」)。 |

悬停图框预览浮层;移出后进入 200ms 宽限期,让指针能跨过到 `position: fixed` 浮层之间的空隙而不被关闭,重新进入图框或浮层都会取消这次关闭。点击图框会把浮层固定展开——鼠标移出不再关闭它——直到在图框与浮层之外点击、按 Escape,或再次点击图框;浮层内部有元素处于焦点(例如供应商下拉的选项列表展开中)时,鼠标移出同样不会关闭它。浮层底部的「刷新」按钮才会立即刷新所跟随供应商的两项读取;图框自身的点击不再触发刷新。旁边的「充值」按钮在新窗口打开下拉当前所指供应商自己的充值页——桌面应用下交给系统浏览器,普通浏览器下是新标签页。

`maskBalance`(设置 → 余额,默认关)把图框上的金额换成打码,供投屏或录屏时使用。保存开关会立刻反映到图框上:设置页会主动触发一次携带该标志的读取,而不是等下一跳轮询。有三处刻意不打码——浮层,打开浮层本身就是「我要看这个数字」的动作;着色,余额告急时图框照样变红,只是不说还剩多少;以及当前会话的消费(无论它显示在哪里),它显示的金额来自当前会话自己的账目投影,不经过图框的那次余额读取。而 56 px 窄栏下根本没有浮层可悬停打开,所以打码后要看真实余额,得先展开侧栏。

## 跟随会话

图框显示的供应商 = 主视图里打开的那个会话(会话列表报告主视图正占用的那一个)所选模型所属的供应商,直接读取该会话自己的持久 `modelSelection` 投影——与 `@haoran/dsh-vision-switch` 所用的同一条同步、零往返读取——绝不额外猜测。切换会话会立即重新解析,并读取该供应商的余额与消费,下拉名单留给轮询和「刷新」;共享轮询每一跳也会重新解析一次,这同时也是「会话内切换模型」被跟上的机制。空白/无会话视图、被寻址的子代理会话、尚未记录任何选择的会话、或走 `deepseek-account`(DeepSeek 的登录路由,这里查不到它的余额)的会话,都回落到 DeepSeek。

## 供应商下拉

浮层顶部的下拉只列本部署当前能查到余额的供应商,分两步筛:先静态筛到这个插件的适配器原则上够得着的供应商——DeepSeek 的专属适配器,加上可配置供应商目录声明的每条路由(通用适配器唯一够得着的范围);再逐一探测这些候选里哪些真的有凭据能解出来(目录里 DeepSeek 的登录路由 `deepseek-account` 不列:它没有可以查余额的 API key),每个供应商复用 `AdapterRegistry` 同一份缓存读一次,轮询已经有新鲜答案的那一跳不会多打一次网络请求,所有供应商共用同一次 profile 设置读取。名单在页面加载时、每一跳轮询时、点「刷新」时拉取——切换会话不拉,切换会话不改任何供应商设置或密钥。没通过任一步筛选的供应商根本不会出现在下拉里——不会再点开看到一句「暂不支持余额查询」。所跟随的供应商无论是否通过筛选都会排在第一位:它的余额由把它设为跟随对象的那一次调用读取,浏览器一侧会在宿主自己的答案漏掉它时补回来。列表不足两项时整行隐藏,浮层其余部分照常显示。选中某一项只预览它的余额与它自己的消费,不会改变图框跟随的对象;选回被跟随的供应商(或不选)即恢复跟随。这次选择只在这一次浮层里有效:每次打开浮层——悬停打开,或点击固定打开——下拉都从当前会话所跟随的供应商重新开始,所以刚才那次对比不会带到下一次;期间会话若换了模型,下一次打开就落在新模型所属的供应商上。

## 充值链接

浮层里的「充值」按钮打开下拉当前所指供应商自己收款的那个页面。地址是一张硬编码表(`src/client/top-up-links.ts`),**由人工维护,每次发版逐条重新核对**——它们是控制台页面而不是接口,页面搬家时本插件无从察觉。最近一次核对:2026-09-03。

| 供应商 | 页面 |
| --- | --- |
| `deepseek-official` | `https://platform.deepseek.com/top_up` |
| `moonshotai` | `https://platform.kimi.ai/console/pay` |
| `moonshotai-cn` | `https://platform.kimi.com/console/pay` |
| `kimi-coding` | `https://www.kimi.com/membership/pricing` |
| `ollama` | `https://ollama.com/pricing` |
| `opencode-go` | `https://opencode.ai/go` |

表里没有的供应商不显示按钮:部署自己配置的各种网关都属于这一类,它们的账单页本插件无从知晓,也不会拿 API 的 origin 去猜。Kimi For Coding 与 OpenCode Go 卖的是订阅而不是余额,所以它们这两条指向购买与续费所在的页面;Ollama 那条指向它的定价页,因为控制台自己的账单路由需要先登录。按钮打开的是新窗口而不是就地跳转——桌面外壳会把它交给系统浏览器,正在运行的会话不会被顶掉。

## 适配器注册表

一套缓存(刷新窗口、重试窗口、在途请求去重、刷新失败时served旧值)之下有两类成员:

- **专属适配器**,各自带自己的端点解析逻辑,排在通用兜底之前:本插件一直有的 DeepSeek,以及 Moonshot AI 的两条路由。
- **通用兜底**,服务于 `ctx.llm` 可配置供应商目录能给出一个已配置 `baseURL` 的任何其他供应商(用 Models 页的话说,即自定义 base URL 条目)。它依次尝试**one-api/new-api 形状**的用户余量端点(`GET /api/user/self`,把返回的无量纲 `quota` 按配置比例换算成货币金额)和**旧版 OpenAI dashboard billing 组合**(`GET /dashboard/billing/subscription` + `/dashboard/billing/usage`,`hard_limit_usd` 减去以分为单位的 `total_usage`)。这里只按公开文档参考端点*形状*,不抄任何第三方源码。端点候选列表是 `genericEndpoints`(见下),网关两种都不认时可以自己配一份。首个应答成功的形状会按供应商记住(仅存于运行时;重启后重新探测),这样匹配过的供应商不必每次都重新探测一遍。每个候选 URL 都被限定在该供应商自己配置的 origin 内。任何失败——目录里没有该条目、没有配置 `baseURL`、没有 key、或全部形状都失败——都回答安静的 `unconfigured` 状态(短 TTL 负缓存,与读取器平时的重试窗口相同),绝不是专属适配器那种带具体原因的 `unavailable`。

### 专属适配器

| 供应商 id | 端点 | Base URL | 币种 | 余额行映射 |
| --- | --- | --- | --- | --- |
| `deepseek-official` | `GET /user/balance`(由 chat base URL 推导) | `llm-deepseek` 设置,默认 `https://api.deepseek.com` | 账户自身货币,来自 `balance_infos` | `total`/`granted`/`toppedUp` ← `total_balance`/`granted_balance`/`topped_up_balance` |
| `moonshotai` | `GET /v1/users/me/balance` | `llm-pi-ai` 设置(`providers.moonshotai`),默认 `https://api.moonshot.ai` | 固定 **USD**——端点本身不带币种 | `total`/`granted`/`toppedUp` ← `available_balance`/`voucher_balance`/`cash_balance` |
| `moonshotai-cn` | `GET /v1/users/me/balance` | `llm-pi-ai` 设置(`providers.moonshotai-cn`),默认 `https://api.moonshot.cn` | 固定 **CNY**——端点本身不带币种 | 映射与 `moonshotai` 相同 |
| `kimi-coding` | `GET /coding/v1/usages`(404 → `/coding/v1/usage`) | 固定 `https://api.kimi.com` | —(是订阅配额,不是货币余额) | 一个 `quota` 视图——每个计量周期一个窗口,各自一个「已用百分比」(界面上按剩余显示);见下 |
| `ollama` | `GET /api/balance`(由配置的 origin 推导) | Models 设置,默认 `https://ollama.com` | 固定 **USD**——端点本身不带币种 | 一个 `ok` 视图——`total`/`granted`/`toppedUp` ← 包含额度 + 已购额度;旧版套餐改回 `quota` 视图;见下 |
| `opencode-go` | `GET /zen/go/v1/usage` | 固定 `https://opencode.ai` | —(是订阅配额,不是货币余额) | 一个 `quota` 视图——滚动、周、月三个窗口,各自一个「已用百分比」(界面上按剩余显示);见下 |

`kimi-coding` 报告的是订阅配额而非货币余额,因此它产出 `quota` 视图(见下)而不是 `ok`。Kimi For Coding 把订阅按用量窗口计量——一个周窗加一个或多个滚动窗口——从 Kimi 自己的 coding-plan 用量端点读取,也就是 Kimi CLI 读取订阅剩余配额的同一个端点。该端点不属于 Moonshot 开放平台文档化的 HTTP 面;它只对 Kimi CLI 自己的客户端标识回答用量数据,所以请求带 `User-Agent: KimiCLI/1.6`(该端点要求的客户端标识头——真正给账户鉴权的是订阅 Key 而非这个头,账户是调用者自己的)。响应按防御式解析:未公开的端点结构可能随客户端版本变化,所以任何缺失或类型不符的字段都降级为 `unavailable` 而不是报错。计数既可能是 JSON 数字,也可能——自该端点改为 protobuf-JSON 后(2026-09-02 实测)——是十进制字符串,单位是枚举名(`TIME_UNIT_MINUTE`);两种都读,整小时的分钟跨度按小时命名(`300 MINUTE` → `5h`)。profile 未命名 `apiKeyEnv` 时,凭据默认取 `KIMI_CODING_API_KEY`(CLI 自己用的 `sk-kimi-*` 订阅 Key);固定的用量端点忽略任何已配置的聊天 base URL。这条路由的流量不套用任何价格表条目——写了 `kimi-coding` 的不套用,同模型未写 provider 的也不套用:会话消费把它的 token 记为套餐内,账本把它的行记为未计价,浮层在配额下面显示为 `N tok 套餐内`。

OpenCode Go 从 `GET https://opencode.ai/zen/go/v1/usage` 读取订阅用量——这是套餐服务自己的控制台路由,用与聊天路由相同的 `OPENCODE_API_KEY` 鉴权(这是 pi-ai 为该路由内置的默认 Key 变量,profile 未命名 `apiKeyEnv` 时取它)。这条路由是固定的,不从配置的聊天 base URL 推导,理由与 Kimi 那条相同:base URL 指向的是模型自己的请求,说明不了账户用量在哪里;固定路由也保证订阅 Key 不会被发到 profile 指定的其他主机。响应体是 `{ usage: { rolling, weekly, monthly } }`,每个窗口带 `status`(`ok` 或 `rate-limited`)、已用的 `percent`,以及 ISO 格式的 `resetsAt`;被判为 `rate-limited` 的窗口无论百分比是多少都按用满处理;没有 Go 订阅的 Key 会收到 403,显示为 `http` 失败,而不是一个 0 的配额。响应本身不带窗口长度,所以窗口标签用套餐公布的口径——5 小时、1 周、1 个月(<https://opencode.ai/go>)——并复用界面已有的三个键(`5h`、`weekly`、`1mo`)。它的流量与 Kimi 一样按订阅计费,因此任何价格表条目都不会给它计价。

Ollama 从 `GET https://ollama.com/api/balance` 读取云端账户的剩余额度——这是其文档公布的余额路由(<https://docs.ollama.com/api/balance>,2026-10-27 核对)。端点由配置的 origin 推导:`https://ollama.com/v1` 与 `https://ollama.com` 都到 `https://ollama.com/api/balance`,其他主机一律拒绝——本地 Ollama 守护进程没有账户、也没有这条路由,所以配到 `localhost:11434` 的供应商报「查不到余额」而不是一次失败的请求,下拉里也不会出现它。当前套餐给的是金额——`included.balance_usd` 加 `purchased.balance_usd`——于是图框把两者之和作为 `total`,包含额度作为 `granted`,已购额度作为 `toppedUp`,币种固定 USD,因为响应本身不带币种。旧版套餐给的则是 `session`/`weekly` 限额的「剩余百分比」,完全没有金额:这些变成 `quota` 视图(`usedPercent` 是 100 减去返回的百分比),因为本插件绝不把百分比折算成货币金额。profile 未命名 `apiKeyEnv` 时,凭据默认取 `OLLAMA_API_KEY`。它的流量按 token 从这些额度里扣,因此与任何按量计费路由一样参与计价。

两条 Moonshot 路由读的是同一份文档化响应体——`{ code, data: { available_balance, voucher_balance, cash_balance }, scode, status }`,已于 2026-08-31 对照 <https://platform.kimi.com/docs/api/balance>(中国)与 <https://platform.kimi.ai/docs/api/balance>(国际)核实;两个文档域名如今都从 `platform.moonshot.cn`/`platform.moonshot.ai` 重定向而来,与 API 自己的请求域名(`api.moonshot.cn`/`api.moonshot.ai`)无关,两者都不受这次重定向影响——两条路由只在 base URL 与计费币种上不同,所以由一个参数化的适配器同时服务,按 id 分别注册进适配器注册表。`isAvailable` 读的是响应自身的 `status` 字段,是文档里离 DeepSeek 那种明确 `is_available` 最近的等价物。连接信息的查找方式与通用兜底查找任何其他 pi-ai 路由供应商完全一致——都走 `ctx.llm` 的可配置供应商目录——但 profile 未命名 `apiKeyEnv` 时,默认值是 `MOONSHOT_API_KEY`:pi-ai 自己两条路由共用的内置环境变量,而不是通用兜底会推导出的按 id 区分的名字(`MOONSHOTAI_API_KEY`/`MOONSHOTAI_CN_API_KEY`)。这两条路由都不需要、也不会查任何价格表条目:余额读取不带任何按模型的消费,只有账户合计。

## 刷新策略

宿主缓存的是答案,不是密钥。

- 一次成功读取在 `refreshMs`(默认 60 秒)内直接复用。窗口内所有标签页共享它,多开一个屏幕不会多打一次服务方请求。
- 一次失败读取在 `retryMs`(默认 15 秒)内不再尝试,避免一个坏掉的端点被每个标签页各敲一遍。
- 并发调用共用同一个在途请求。点击浮层的「刷新」按钮会跳过刷新窗口,但仍然并入已在途的请求。
- 刷新失败而此前读到过数值时,旧数值继续显示(变暗),浮层写明它是旧值。一分钟前的余额比一个破折号有用,只要它承认自己旧。
- 浏览器端按 `refreshMs` 轮询,标签页不可见时整跳过该次。
- 供应商设置(路由的 `baseURL` 与 `apiKeyEnv`)从设置服务读一次,所有供应商的读取共用——在 dsh 0.1.7 和 0.2 上这次读取要重新合成整个 profile。经设置服务保存的修改(模型页)下一次读取立即生效;还没有被任何设置读取观察到的 profile 改动最迟 `refreshMs` 后生效;「刷新」会重读。密钥每次读取都重新解析,加或删密钥不用等。

## 三种状态,各自渲染什么

`get(provider?, force?)` 返回三种状态之一,针对它点名的那个供应商(省略时即被跟随的供应商)。

| 状态 | 字段 | 渲染 |
| --- | --- | --- |
| `ok` | `currency`、`total`、可选的 `granted`/`toppedUp`、`isAvailable`、`fetchedAt`、`stale` | 图框,余额保留两位小数。高于 `lowBalance` 为常态色;低于它为警告色;低于 `criticalBalance`、或服务方报告 `isAvailable: false` 时为危险色——账户可能余额充足却被停用。`stale: true` 时图框变暗,浮层加一行说明。`granted`/`toppedUp` 是专属适配器自己的构成拆分(DeepSeek 的 `granted_balance`/`topped_up_balance`,或 Moonshot 的 `voucher_balance`/`cash_balance`);通用适配器的读取只有 `total`。 |
| `quota` | `windows`(每个含 `key`、`usedPercent`、`resetsAt`)、`isAvailable`、`fetchedAt`、`stale` | 订阅配额(`kimi-coding`、`opencode-go`,以及旧版套餐下的 `ollama`)。图框显示每个窗口**剩余**多少并带标签(`剩余 7天 58% · 5小时 95%`),代替货币金额;浮层逐个列出每个窗口的「剩余 58%」及其重置时间——一天之内只显示时刻,更远的带日期。周窗命名为「7 天窗口」,滚动窗口按跨度命名(「5 小时窗口」)。不着色(配额没有货币阈值);`isAvailable: false`——主窗口已用满——加「已停用」说明,`stale: true` 与 `ok` 一样变暗。 |
| `unconfigured` | — | 对**被跟随**的供应商:**什么都不渲染。** 没有可用密钥、没有适配器能服务这个供应商、或通用适配器探测无果。从没打算用这个功能的部署,看到的就是装插件之前那个侧边栏。对**下拉**里显式选中的供应商:「该供应商暂不支持余额查询」——用户主动问了,这次就给解释而不是隐藏。 |
| `unavailable` | `reason`(`http` / `network` / `timeout` / `malformed`)、可选 `status`、`fetchedAt` | 只有专属适配器会用到(DeepSeek、`moonshotai`、`moonshotai-cn`、`kimi-coding`、`ollama`、`opencode-go`)——通用适配器的失败都并入上面那个安静的 `unconfigured`。变暗的 `—`,原因写在 tooltip 里。原因只是分类,不含服务方原文,也不含端点。 |

`providers()` 返回下拉的名单:`{ id, displayName }[]`,DeepSeek 排第一。

## 配置

每一项都在加载时校验,都可以从 `cordis.yml` 改。bundle 行不写 `config`:所有默认值都只在 schema 里。设置页第一次保存时,`balance` 的 profile 行会存下这个条目完整的生效配置,所以 bundle 行里重述的任何键都会在那一刻被钉进每个 profile,以后的版本再也改不到。条目 id 必须保持 `balance`:设置页和一次性导入都按这个 id 找条目。

有三项是 volatile 字段——`lowBalance`、`criticalBalance`、`maskBalance`。设置 → 余额页面(`settings.section`)编辑它们,写进这个条目的 profile 行,运行中的插件不用重启就会接过去。打码开关在保存的那一刻就反映到图框上,阈值则在下一次余额读取时生效(最多 `refreshMs`)。宿主因条目期间被改过而拒绝的保存,页面会说明,并显示存下的值。同一页面只读地显示正在使用的价格表:币种切换,每个模型一行基础费率,每个分时价格档写成一句话,例如「工作日 09:00–12:00、14:00–18:00 为高峰时段，按 2 倍计价（Asia/Shanghai）。」;超过 316 px 高时在自己的框里滚动,表头保持可见;另有一行说明价格从哪里来(见「价格从哪里来」)。页面上没有任何修改价格的控件。其余每一项都是普通字段:只能通过 profile 行或 `cordis.yml` 修改,改了会重新加载插件。

0.6.0 之前的版本把 `prices`、`lowBalance`、`criticalBalance`、`maskBalance` 存在 `settings.yaml` 里的 `balance` 一段。第一次在 dsh 0.1.7 或更新版本上启动时,这一段会被一次性导入到这个条目,文件改名为 `settings.yaml.imported`。之后再退回到这个插件 0.6.0 之前的桌面版本,存下的阈值都会丢失:那些版本从 `settings.yaml` 读它们,而这个文件已经被改了名。`prices` 仍然接受,因为这次导入和 0.6.x 的设置页都把它写进了 profile 行;但从 0.7.0 起不再读取:这样存下的价格表不参与任何计价。存下的表和随包的表不同时,插件在加载时记一条警告说明这一点。需要自己价格表的部署请设 `pricesOverride`。

| 键 | 默认值 | 含义 |
| --- | --- | --- |
| `refreshMs` | `60000` | 一次成功读取、以及供应商设置读取的复用时长。最小 5000。 |
| `retryMs` | `15000` | 一次失败读取的静默时长。最小 1000。 |
| `timeoutMs` | `8000` | 单次余额请求的墙钟预算。最小 1000。 |
| `currency` | `[CNY, USD]` | 货币优先顺序。这一个列表决定两件事:账户持有多种货币余额时显示哪一行,以及在账户自身货币未知之前按哪份价格表计价。 |
| `lowBalance` | `10` | 低于此值显示警告色。 |
| `criticalBalance` | `1` | 低于此值显示危险色。先判它,所以高于 `lowBalance` 时没有警告区间。 |
| `maskBalance` | `false` | 底栏图框的金额位置显示 `••••` 而非真实数字。浮层仍然显示真实数字。 |
| `ledgerDays` | `400` | 账目保留天数;更早的行在启动时丢弃并重写文件。 |
| `timezone` | `''` | 计算「今日 / 本月」边界所用的 IANA 时区。留空表示宿主进程所在时区。 |
| `root` | `''` | 账目文件所在目录。留空表示 `$DSH_HOME/dsh-balance`。 |
| `surfaces.footer` | `true` | 是否放出侧边栏底部图框。 |
| `surfaces.sessionSpend` | `true` | 是否显示当前会话的消费。关掉后 token 用量药丸恢复显示它自己的 token 合计。 |
| `prices` | DeepSeek 公布的 CNY 与 USD 价,加上 Ollama 的 USD 价 | 为 0.6.x 和 `settings.yaml` 导入写下的行保留;不读取。 |
| `pricesOverride` | 不设 | 一份价格表(结构见下),设了就用它计价,取代价格源和随包的表,也不再请求价格源;随包行(包括 Ollama)不会合并进来。加载时检查;不可用的表会让加载失败。设置页不显示、也不能编辑它。 |
| `priceFeedUrl` | `https://lhr.ink/dsh-prices/v1/prices.json` | 插件维护方价格表的地址。必须是 `https`;留空表示不请求价格源。 |
| `priceFeedRefreshMs` | `86400000` | 启动时请求一次之后,每隔多久再请求一次。最小 3600000(一小时),最大 2147483647(约 24.8 天,计时器能接受的最长间隔)。 |
| `priceFeedMaxBytes` | `524288` | 价格源响应最多读多少字节;更长的整份丢弃。最小 4096。 |
| `genericEndpoints` | one-api/new-api 用户余量端点,其次 OpenAI dashboard billing 组合 | 通用兜底适配器为 DeepSeek 以外的任何供应商依次尝试的候选端点形状,见「适配器注册表」。 |

这里不配置任何供应商的连接。DeepSeek 的从可配置供应商目录指向的 `llm-deepseek` 条目的配置读取,解析顺序与该 provider 自己完全一致(`baseURL`,其次 `$DEEPSEEK_BASE_URL`,再次 `https://api.deepseek.com`;`apiKeyEnv` 默认 `DEEPSEEK_API_KEY`)。`moonshotai` 与 `moonshotai-cn` 从 `ctx.llm` 可配置供应商目录所说的地址读取,即 `llm-pi-ai` 设置分节下的 `providers.moonshotai`/`providers.moonshotai-cn`,与任何其他 pi-ai 路由供应商一致;`baseURL` 默认取各自路由自己的公开 origin(`https://api.moonshot.ai`、`https://api.moonshot.cn`),`apiKeyEnv` 默认 `MOONSHOT_API_KEY`——这是 pi-ai 自己两条路由共用的内置默认值,而不是下面推导出的按 id 区分的名字。`opencode-go` 读同一个目录条目(`providers.opencode-go`),`apiKeyEnv` 默认 `OPENCODE_API_KEY`——pi-ai 为该路由内置的默认值——并忽略 `baseURL`,因为它的用量路由是固定的。`ollama` 读 `providers.ollama`,`baseURL` 默认 `https://ollama.com`,`apiKeyEnv` 默认 `OLLAMA_API_KEY`。其余任何供应商的 `baseURL`/`apiKeyEnv` 都按同样的目录寻址方式读取;profile 未命名 `apiKeyEnv` 时,推导规则与 Models 页完全一致(`<供应商>_API_KEY`)。把供应商指到别处,本插件跟着走。

## 价格从哪里来

用插件的人不需要维护价格。插件维护方在 `priceFeedUrl` 放一份价格表——由 `node scripts/build-price-feed.ts` 从随包的 `src/default-prices.ts` 生成到 `feed/prices.json`(这个文件不进包)——每个安装都去取它:

1. **`pricesOverride`**,配置里设了的话。它优先,并且不再请求价格源。
2. **价格源的表**:启动时请求一次,之后每 `priceFeedRefreshMs` 一次。不跟随重定向。响应不是 200(包括 3xx)、超过 `priceFeedMaxBytes`、超过 `timeoutMs`、不是 JSON、没通过配置价格表同样的检查(schema,包括 `asOf`,以及「结构」一节的规则),或者某个币种一个模型都没列时,整份丢弃并记日志,继续用手上的表。日期早于随包价格表 `asOf` 或早于正在用的表的,不采用,只记一次日志;日期早于随包价格表的缓存文件会被忽略并记日志,所以随新版本带来的更新价格在价格源跟上之前一直生效。通过检查的表会写进插件目录下的 `price-feed.json`(`0o600`,整份替换),下次启动在自己的请求返回之前就先用这份文件计价;没通过检查的缓存文件会被忽略并记日志。
3. **随包的表**(`src/default-prices.ts`),在上面两者都还没给出表的时候。

改价的发布顺序:先重新生成 `feed/prices.json` 并上传到价格源,再发布 `src/default-prices.ts` 里是同一份表的包。反过来也不会出错,只是已安装的副本在上传之前一直用价格源上较旧的表。上游新增模型、重述价格区间或开始/停止公布按 token 价格时也走同一条规则:更新对应行(新增、修改,或移到显式的未计价列表),改 `asOf`,重新生成并向价格源上传,再发布。任何数字都必须把来源 URL 和读取日期写进 `src/default-prices.ts` 文件头,没有来源就不写数字。

新表不用重启就生效,会更新消费读数的 `pricesAsOf`,并让会话重新计价(见下)。当前价格表里没有的模型保持未计价:它的 token 记为未计价,绝不借用别的模型的价格;表可以给这种模型加一条 `unpriced` 记录说明原因(见「价格表」)。订阅配额路由永远不按任何价格表计价。显式配置永远压过随包默认值:`pricesOverride` 整份替换价格表(不会把随包行合并进来),用户配置的供应商/模型清单或显示名也整份替换 `src/default-providers.ts` 里对应的默认元数据,而不是被默认值补齐。插件无法确定的值显示为「未计价」或「不可用」——绝不显示 0,也绝不套用别的模型的费率。

设置页会说明用的是哪一种。那一行的文字:价格源为「价格由插件维护方更新，当前为 2026-10-27 的价格，3 小时前检查过更新。」;最近一次检查失败时为「价格由插件维护方更新，当前为 2026-10-27 的价格。20 分钟前检查更新没有成功，先沿用这份价格。」;随包的表为「正在使用插件自带的 2026-10-27 价格，还没有取到插件维护方更新的价格。」(检查失败过则为「正在使用插件自带的 2026-10-27 价格：20 分钟前检查更新没有成功。」);`pricesOverride` 为「价格来自插件配置里指定的价格表（2026-10-27 的价格），不会自动更新。」

## 价格表

价格**按币种**分表,每个币种一份:一家收两种货币的服务方公布的是两份价目表,而不是一份表加一个汇率——而「余额 ¥ / 消费 $」这两个数字没人能对得起来。

随包默认值带着 DeepSeek 与 Ollama 的价目表,以及「已发布但没有完整公开按 token 价格」的显式判定。来源与读取日期写在 `src/default-prices.ts` 文件头;下面这些行与文件里的数字一致:

- **DeepSeek**,读取于 **2026-09-10**——DeepSeek 公布的两种货币。每份页面只列两个模型;两个已下线的 Flash id 也一并定价,用的是页面所说它们实际计费的 `deepseek-flash` 价。
- **Ollama**,读取于 **2026-10-27**——`ollama.com` 所服务模型的 USD 价目表。`src/default-providers.ts` 里的模型上下文窗口来自各自的 `https://ollama.com/library/<model>` 页面,同日读取。
- **Kimi Code**,读取于 **2026-10-27**——`kimi-coding` 与 `kimi-coding-openai` 路由上的 `k3.1-pro` 按订阅计费,因此显式记为「未计价」,而不是编一个数字。[Kimi Code 会员页](https://www.kimi.com/code/docs/en/kimi-code/membership.html)与[第三方工具页](https://www.kimi.com/code/docs/en/third-party-tools/codex.html)描述了套餐和 1M token 模型;两者都没有公布 coding 路由的按 token 价格。

DeepSeek 表:

| 模型 | CNY 每 1M(未命中 / 命中 / 输出) | USD 每 1M(未命中 / 命中 / 输出) |
| --- | --- | --- |
| `deepseek-flash` | ¥1 / ¥0.02 / ¥4 | $0.15 / $0.003 / $0.60 |
| `deepseek-v4-flash`(已下线,由 V4.1 Flash 提供服务) | ¥1 / ¥0.02 / ¥4 | $0.15 / $0.003 / $0.60 |
| `deepseek-v4-pro` | ¥4.5 / ¥0.15 / ¥13.5 | $0.66 / $0.022 / $1.98 |
| `deepseek-v4-flash-vision-exp`(已下线,由 V4.1 Flash 提供服务) | ¥1 / ¥0.02 / ¥4 | $0.15 / $0.003 / $0.60 |

以上是空闲时段价,高峰时段翻倍。来源:<https://api-docs.deepseek.com/zh-cn/quick_start/pricing>(CNY,原文「空闲时段价格为高峰时段价格的一半。高峰时段为北京时间周一至周五 9:00 - 12:00、14:00 - 18:00(其余为空闲时段)。」)与 <https://api-docs.deepseek.com/quick_start/pricing>(USD,原文 "Peak hours are 01:00 - 04:00 and 06:00 - 10:00 UTC, Monday through Friday")。两者指的是同一批时刻——北京时间 09:00 就是 UTC 01:00——每份表都按它自己那一页的时区书写而不做换算,于是两份都能直接和来源对照。两个已下线的 id 都不在页面上。给它们定价是因为存着的选择仍可能指名其中之一,而这样的请求确实按 Flash 价计费——「旧模型名 deepseek-v4-flash、deepseek-v4-flash-vision-exp 仍可调用,但对应模型已下线,请求将由 DeepSeek-V4.1-Flash 模型提供服务,并按 Flash 价格计费。」——去掉这两行会把那些轮次报成未定价 token。`deepseek-v4-pro` 在 2026-09-14 之后仍按自己的费率计价:DeepSeek 更新日志 2026-09-10 的条目(<https://api-docs.deepseek.com/zh-cn/updates>)写明 9 月 14 日之后继续提供它的 API 调用服务,计费方式保持不变。DeepSeek 改价时,维护方更新 `src/default-prices.ts`、改 `asOf`(浮层和设置页都会显示)、重新生成 `feed/prices.json` 并上传到价格源;各安装在下一次请求时取到。运行时不会去抓 DeepSeek 的页面。

Ollama 的云模型价目表只有 USD,来源 <https://registry.ollama.com/pricing>,读取于 **2026-10-27**。页面写明空闲时段价是高峰时段价的一半,高峰为工作日 12:00–18:00 UTC,其余时间与整个周末为空闲;表里把空闲价存为 `base`,再用覆盖工作日 12:00–18:00 UTC 的 `peak` 档位把它翻倍。页面把输入、缓存命中输入、输出三个数字都印出来的模型都已定价;缓存命中输入(或输出)一栏是短横线的模型放进 `unpriced`,不猜数字。

| Ollama 云模型 | USD 每 1M(输入 / 缓存命中输入 / 输出) |
| --- | --- |
| `deepseek-v4.1-flash` | 空闲 $0.15 / $0.003 / $0.60;高峰 $0.30 / $0.006 / $1.20 |
| `deepseek-v4-pro` | 空闲 $0.66 / $0.022 / $1.98;高峰 $1.32 / $0.044 / $3.96 |
| `gemma4` | $0.14 / $0.05 / $0.40 |
| `glm-5.3` | $1.40 / $0.26 / $4.40 |
| `glm-5.3-flash` | $0.15 / $0.03 / $0.50 |
| `glm-5.2` | $1.40 / $0.26 / $4.40 |
| `gpt-oss:120b` | $0.15 / $0.014 / $0.60 |
| `gpt-oss:20b` | $0.07 / $0.035 / $0.30 |
| `kimi-k3` | $3.00 / $0.30 / $15.00 |
| `kimi-k2.7-code` | $0.95 / $0.19 / $4.00 |
| `kimi-k2.6` | $0.95 / $0.16 / $4.00 |
| `minimax-m3.1-flash` | $0.15 / $0.015 / $0.60 |
| `minimax-m3` | $0.60 / $0.12 / $2.40 |
| `minimax-m2.7` | $0.30 / $0.06 / $1.20 |
| `mistral-large-4` | $0.68 / $0.07 / $2.09 |
| `muse-spark-open` | $1.25 / $0.15 / $4.25 |
| `nemotron-3-super` | $0.015 / $0.015 / $0.60 |
| `nemotron-3-ultra` | $0.10 / $0.10 / $3.00 |

这些行只挂在 `ollama` 路由上,因为那是部署指向 `ollama.com` 时使用的路由。本地权重没有按 token 的费用;把 `ollama` 指向本地服务器的部署应当用 `pricesOverride` 替换或删掉这些行(覆盖是整份替换,所以还必须带上该部署想保留的其他供应商行)。

### 显式未计价模型

模型可以已发布、却仍然没有插件敢用的数字。这些模型列在价格表的 `unpriced` 数组里,每条写清三件事:为什么没有费率、来源 URL、读取日期。插件把它们的 token 记为未计价(在订阅配额路由上则记为套餐内),绝不显示 0,也不套用别的模型的费率。

| 模型 | 路由 | 原因 |
| --- | --- | --- |
| `k3.1-pro` | `kimi-coding` | Kimi Code 按订阅配额计费;token 记为套餐内,从不计价。 |
| `k3.1-pro` | `kimi-coding-openai` | 同一订阅套餐的 OpenAI 兼容路由;没有公开的 coding 按 token 价格,因此保持未计价。 |
| `mistral-large-3` | `ollama` | Ollama 没有公布缓存命中输入价,表里凑不出完整费率。 |
| `nemotron-3-nano` | `ollama` | 同上,缺缓存命中输入价。 |
| `clef` | `ollama` | Ollama 只公布输入价,没有缓存命中输入价与输出价。 |

部署自己的价格表可以省略 `unpriced`(缺失与空数组同义),但显式记录不能和已定价的行矛盾,且必须带 `https` 来源与 `YYYY-MM-DD` 读取日期。

### 默认 provider 元数据

`src/default-providers.ts` 随包提供插件从公开目录知道、但部署尚未配置的供应商展示信息:`ollama` 的 provider id、显示名、云模型清单,以及每个模型的上下文窗口;每项都带来源页面与读取日期。它只用于兜底展示与计价依据,不注册 LLM 适配器,也不改 `llm-pi-ai` 或任何其他 provider 插件——请求仍然只能走到它自己的插件或部署配置注册过的供应商。

显式配置优先:`resolveProviderDefaults` 只要收到调用方的显示名或模型清单就原样返回(包括显式空清单),只有被省略的字段才回落到随包目录。既没有随包默认、也没有显式元数据的供应商显示为「不可用」,不会被猜一个名字,也不会得到一行全 0 的价格。随包目录与价格表一起维护:Ollama 新增、下线或改名模型时,同时更新 `src/default-providers.ts` 和对应的价格行(或 `unpriced` 记录),改日期,并按上面的价格源发布顺序发布。

### 用哪一份表

1. 账户自身的计费货币——只要有一次余额读取成功就知道了;正是它让余额和消费两个数字可比。
2. 否则取 `currency` 里第一个该表有价格的币种。
3. 否则 `USD`,再否则按名称排序的第一份表——这样选择永远不是随机的。

浮层会写明用的是哪一份:`价格:CNY(2026-10-27)`。切换会重算一切——会话投影的缓存版本把币种和费率一起算进去了。Ollama 只按 USD 计费,所以只消费 Ollama、又没有 USD 余额读取的部署,应把 `currency` 设为 `[USD]`(或把 USD 放前面);否则默认的 `[CNY, USD]` 会先选中不带 Ollama 行的 CNY 表,那些 token 会保持未计价,而不是按猜出来的汇率换算。

### 结构

schema 里没有任何厂商专有词汇。一个条目写出自己的基准价,和一组有序的具名档位;每个档位在该条目自己的 IANA 时区里声明若干时间窗,并且要么重写价格,要么给基准价乘一个系数。请求时刻落入的第一个档位生效;不落入任何窗口时用基准价。

价格源文件和 `pricesOverride` 都是这个结构:

```yaml
pricesOverride:
  asOf: '2026-10-27'          # 界面上显示在币种旁边
  tables:                     # 每个币种一份;服务方收哪种货币就加哪一份
    CNY:
      entries:
        - model: deepseek-flash
          provider: deepseek-official   # 可选;省略则该模型在任意路由上都用这条
          per: 1000000                  # 一个费率单位覆盖多少 token
          timezone: Asia/Shanghai       # 下面时间窗所用的时区
          baseName: off-peak            # 基准档在界面上的名字(默认 "standard")
          base:
            input: 1                    # 未命中缓存的输入 token
            inputCacheHit: 0.02         # 命中缓存的输入 token
            output: 4                   # 生成 token
            # cacheWrite: 省略即取 `input`
            # reasoning:  省略即取 `output`
          schedules:
            - name: peak
              multiplier: 2             # …… 或 `rates: { input, inputCacheHit, output }`,二者只能取其一
              windows:
                - { start: '09:00', end: '12:00', days: [1, 2, 3, 4, 5] }
                - { start: '14:00', end: '18:00', days: [1, 2, 3, 4, 5] }
    USD:
      entries:
        - model: deepseek-flash
          provider: deepseek-official
          per: 1000000
          timezone: UTC
          baseName: off-peak
          base: { input: 0.15, inputCacheHit: 0.003, output: 0.6 }
          schedules:
            - name: peak
              multiplier: 2
              windows:
                - { start: '01:00', end: '04:00', days: [1, 2, 3, 4, 5] }
                - { start: '06:00', end: '10:00', days: [1, 2, 3, 4, 5] }
  unpriced:                   # 可选;缺失与空数组都表示「没有显式判定」
    - model: k3.1-pro
      provider: kimi-coding    # 可选;省略则表示该模型在所有路由上都未计价
      reason: '按订阅配额计费;没有公开的按 token 价格。'
      source: 'https://www.kimi.com/code/docs/en/kimi-code/membership.html'
      checkedAt: '2026-10-27'  # 来源读取日期
```

加载时强制校验、不合规即报错的规则:

- `tables` 至少要有一个币种,且每个键都是三字母 ISO 4217 代码。
- 一个档位必须且只能声明 `rates` 与 `multiplier` 之一。
- `start` / `end` 为 `HH:MM`,`end` 不含端点;`end` 不晚于 `start` 表示跨午夜(`22:00`–`02:00` 是四小时),跨午夜的窗口归属于它开始的那一天。
- `days` 用 JavaScript 星期序号——**0 是周日**,6 是周六。省略(或空数组)表示每天。
- `timezone` 必须是本运行时认识的 IANA 时区;`per` 必须为正;费率不得为负;同一份币种表内、同一 provider 下同一模型只能出现一次。
- 每条 `unpriced` 记录必须有非空模型与原因、`https` 来源 URL,以及 `YYYY-MM-DD` 读取日期;同一对象只能声明一次;且不得与已定价的行矛盾——同一模型既定价又未计价会让加载失败。

DeepSeek 两份表都没有单独给缓存写入和思考 token 定价,所以这两项留空取默认:**缓存写入按未命中输入价计费,思考 token 按输出价计费。** Ollama 公布了独立的缓存命中输入价,所以每一行 Ollama 都显式写出 `inputCacheHit`。

再加一个币种,带三档周末价——**此例为虚构,仅作说明**:

```yaml
    EUR:                                # 并非真实服务方,也不是真实价格
      entries:
        - model: example-large
          per: 1000000
          timezone: Europe/Berlin
          base: { input: 3, inputCacheHit: 0.3, output: 9, cacheWrite: 4 }
          schedules:
            - name: weekend             # 先匹配先生效,覆盖面最大的放最后
              multiplier: 0.6
              windows: [{ start: '00:00', end: '23:59', days: [0, 6] }]
            - name: night
              rates: { input: 1.5, inputCacheHit: 0.15, output: 4.5 }
              windows: [{ start: '22:00', end: '06:00', days: [1, 2, 3, 4, 5] }]
            - name: business
              multiplier: 1.4
              windows: [{ start: '09:00', end: '18:00', days: [1, 2, 3, 4, 5] }]
```

### harness 实际提供哪些匹配字段

一次计价观测就是一次已结算的模型尝试。`assistant/message` 带 **provider 路由 id**(`deepseek-official`)、**模型 id**(`deepseek-flash`)、事件自身的时间戳与 `TokenUsage`。写了 `provider` 的条目只匹配该路由,并优先于同模型未写 provider 的条目——于是可以只给一条路由单独定价,而不必把其余的重写一遍。

没能提交消息就结算的尝试——被取消、失败、或被重试的那些——同样计入:它照样花掉了 token,而紧挨着金额的 token 药丸也把它算在内。这类事件不写自己的路由,于是按该会话最后一条 `request/context` 的路由计价;会话还没记过路由时,它的 token 记为未计价。它的用量取自事件所记录流里的最后一个 usage 采样——适配器上报太晚、没能写进消息事件本身的用量,也是从同一处读回来的。同一个 `(turn, step)` 结算两次时(一次失败的尝试,随后是顶替它的那条消息)只计费一次,以最后一次结算为准;`llm/retry-started` 会关掉这个槽位,于是重试的那次尝试是累加而不是顶替。

`TokenUsage` 的输入侧计数互不重叠(`inputTokens` 不含缓存流量),但 `reasoningTokens` 是 `outputTokens` 的子集,所以本插件在计价前会把它从生成 token 中扣除。流式采样里没有推理桶的服务方,那部分 token 按输出价计——它自己报的生成总数就是这么说的。

价格源或缓存给出新价格表、切到另一个币种的表、或装上改了折叠算法本身的版本,都会改变会话投影的缓存版本,于是每个会话下次读取时按新价重算,而不是在旧价算出的合计上继续累加。

## 账目文件

聚合数字来自本插件自己的一个文件:

- **路径** `$DSH_HOME/dsh-balance/ledger.jsonl`(或 `<root>/ledger.jsonl`)。目录以 `0o700` 创建,文件以 `0o600` 创建。
- **内容** 每次 LLM 请求一行 JSON:时间、会话 id 与日志序号、模型与 provider id、五个 token 桶、费用、计价所用币种、生效的价格档位。未计价的行——价格表没有费率的模型,或订阅配额路由上的任何请求——带 `"unpriced": true` 且费用为 0。**不含 prompt、不含回复、不含密钥、不含端点。** 聚合按供应商、按币种分开保存,所以切换价格表时新币种从零开始,而不会继承旧币种的合计;一家供应商的行也绝不会算进另一家的合计——浮层里余额下面的消费就是那条路由自己的。没记录 provider 的行归到空 id 下,任何下拉项都不读它。
- **保留** 早于 `ledgerDays`(默认 400)的行在启动时丢弃并重写文件。加载走流式读取;内存里的聚合按本地日期分桶,所以内存由保留窗口决定,而不是由请求数决定。一个 5 万行、12 MB 的账目文件,启动约 0.11 秒;需要压实重写时再约 0.11 秒。
- **观测点** 只读订阅 `session/event`。该事件在提交之后单向广播,监听者出错不会让本轮失败;它在一条已经组装好的记录里同时给出模型、provider、用量,以及可持久化的 `(session, seq)` 身份。没有选 `llm/stream` 瀑布:那会把本插件放进请求路径,而且它不提供可落盘的请求身份。

### 哪些不会回填

聚合从本机写下的第一行开始计——浮层写明「自 &lt;日期&gt; 起统计」。安装之前就存在的会话,以及从磁盘恢复的会话(其种子历史不会在事件流上重播),都不计入今日 / 本月 / 累计。

**会话内**那一行不受影响:它是对该会话自身持久日志的投影,所以打开一个几个月前的会话,会按当前价格表把它的全部历史算一遍。

从既有会话回填账目是可能的后续工作。它必须走 `sessionQuery` 能力,绝不能直接读会话日志文件。

## 权限与安全

- **网络出口**:只有两类请求。查余额时,只访问*被查询*那个供应商自己配置的 origin。DeepSeek 的端点由它自己的 `baseURL` 推导——去掉末尾一个 `/v<数字>`,再接 `/user/balance`;每条 Moonshot 路由的端点是它的 origin 加上文档写明的 `/v1/users/me/balance`,配置 `baseURL` 里的任何路径都被丢弃;通用适配器的候选 URL 都从解析出的供应商 origin 构造,运算结果一旦会离开该 origin 就拒绝。`baseURL` 不是 `http(s)`,或推导会离开 origin 时,一律拒绝并报为 `unconfigured`,不会发出请求。取价格时,访问维护方的价格源,见下一条。不抓供应商的价格页,无遥测,不检查插件新版本。
- **价格源出口**:对 `priceFeedUrl`(默认 `https://lhr.ink/dsh-prices/v1/prices.json`,插件维护方自己的服务器)发一个普通的 `GET`,启动时一次,之后每 `priceFeedRefreshMs`(默认一天)一次,只走 `https`,不跟随重定向:3xx 整份丢弃并记日志。请求不带 API key、不带 cookie(`credentials: 'omit'`)、不带账户/会话/安装 id,除运行时默认请求头外不加任何请求头;服务器能看到的是请求方地址和运行时默认的 `User-Agent`。不上传任何东西。响应最多读 `priceFeedMaxBytes`,检查通过后只当价格表用。`priceFeedUrl` 留空,或设了 `pricesOverride`,就不发请求。
- **凭据**:无论查询哪个供应商,其 API key **每次读取**都通过宿主凭据缝(`ctx.credentials.resolve`)重新解析,请求结束即丢弃——正因如此,轮换后的密钥无需重启即可在下一次轮询生效。它以 `Authorization: Bearer` 请求头发送:不进 URL、不写日志、不返回给浏览器、不写入账目文件、不与余额一起缓存。被缓存的只有*余额数字*。
- **不注册任何 HTTP 路由。** 浏览器端只经 harness 自己的 `/api` Typert 网关访问宿主,继承它的信任边界。
- **自有 Typert RPC 只读。** 网关上本插件自己的方法只有 `accountBalance/get`、`accountBalance/spend`、`accountBalance/providers`、`accountBalance/prices`(给设置页的当前价格表及其来源)四个,没有任何写方法。设置 → 余额页面的写操作走的是 harness 自己的设置 Remote(应用里每一行设置都走这条路,不是本插件新加的路由)。这个 Remote 对任意可配置条目开放(`SettingsController.update` / `replace` / `mutate`,dsh 0.2.0-rc.2 的 `packages/api/settings-controller/src/index.ts:116`、`:133`、`:152`),没有「仅本机可写」的规则,所以任何已经被放进 `/api` 的调用方,都能像写其他条目一样改这个条目的 volatile 字段——阈值、打码开关,以及本版本已不读取的 `prices`。这个 Remote 拒绝写非 volatile 字段,所以 `pricesOverride`、`priceFeedUrl` 和其余普通字段只能通过 `cordis.yml` 改。反向代理后被放行到 `/api` 的调用方拿不到密钥、端点和 prompt。
- **不写会话事件。** 本插件不向任何会话日志追加内容,只读。
- **账目文件始终纯数字、单账户。** 供应商下拉只预览其他供应商的余额,绝不写入或重新计价账目文件——账目文件始终是下方描述的那份 DeepSeek 账户计价账目,不受下拉影响。
- **磁盘**:只有上述账目文件,以及它旁边的价格源缓存 `price-feed.json`。

## 兼容性

针对 `@deepseek-ai/*` **0.2.0-rc.2** 构建;dsh peer 范围接受 `>=0.2.0-rc.2 <0.3.0-0`。设置页需要 `@deepseek-ai/dsh-client-ui-settings`,浏览器端排在它之后加载;没有它时,图框和会话消费照常显示。设置页的控件来自 `@deepseek-ai/dsh-client-ui-primitives`,由 Web 界面的模块表提供。Node `^22.19 || >=24`。浏览器端需要 Web 界面(`dsh web`)、slot 注册表、locale 服务与 Typert Remote 网关;宿主端不依赖其中任何一项,只是不会有界面。

这里没有任何东西要求打过补丁的 harness。token 用量药丸里那两个座位,构建声明了就坐、没声明就不坐——依据是运行时的 slot 声明台账而不是版本号;没有补丁的构建拿到的就是输入框下方那一行。计入「没提交消息的尝试」同理需要 `assistant/attempt` 事件:老到不写这种事件的 harness,本来也就没有多出来的东西可计。

## 安装

```sh
dsh plugin --profile <name> add ./sumomok-dsh-balance-0.8.0.tgz
# 发布后也可以:
dsh plugin --profile <name> add @sumomok/dsh-balance
```

包声明了 `dsh.bundle`,所以 `dsh plugin` 会自动把它的 patch 层追加到 profile。启动前先确认:

```sh
dsh --profile <name> --dump-config   # 应出现 "# == @sumomok/dsh-balance" 层
dsh web --profile <name>
```

用 `dsh plugin --profile <name> remove @sumomok/dsh-balance` 卸载,依赖与层一起移除。账目文件会原样留下;要丢弃就删掉 `$DSH_HOME/dsh-balance/`。

## 不做的事

多供应商**账目文件**(账目文件始终是一份按部署价格表计价的账户,不管下拉预览的是哪个供应商)、在设置页修改价格(价格来自维护方的价格源,见「价格从哪里来」)、以及在请求因配额报错时刷新余额(那需要在 LLM 错误路径上加宿主监听)。设计上都没有堵死。

针对具体供应商的专属适配器(DeepSeek、Moonshot AI、Kimi For Coding、Ollama、OpenCode Go 之外的):注册表(`adapters.ts`)预留了按供应商 id 在通用兜底之前插入专属适配器的结构——其余每个供应商仍走通用适配器的尽力而为探测。今后若有供应商按订阅配额而非货币余额计量,按 `kimi-coding` 与 `opencode-go` 同样的方式接入,产出 `quota` 视图。

## 许可

MIT
