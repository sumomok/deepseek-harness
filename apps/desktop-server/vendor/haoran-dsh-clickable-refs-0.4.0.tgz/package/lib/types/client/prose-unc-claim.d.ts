/**
 * The `referent/open` waterfall listener that claims a chat-prose UNC click
 * before `dsh-render`'s own default (`workspaces.openPath`) would run.
 * Extracted from `client/index.ts`'s `apply()` (where it is registered via
 * `ctx.on('referent/open', …)`) so it has its own directly-callable, directly-testable
 * export — the same reason `referent-click.ts`'s `openReferentTarget` is its
 * own module rather than an inline closure.
 *
 * A UNC target (`\\server\share\…`) is never opened, on any surface: see
 * `referent-click.ts`'s own `unc` outcome for the terminal/web surfaces this
 * module leaves untouched. Prose has no per-span notice slot to render that
 * outcome into (`prose-unc-toast.ts`'s own header), so this listener is
 * prose's equivalent — refuse the open, copy the path, and confirm via the
 * frame-wide toast instead.
 *
 * @module @haoran/dsh-clickable-refs/client/prose-unc-claim
 */
import type { ReferentRef } from '@deepseek-ai/dsh-api-session-controller/client';
/** The clipboard/label plumbing this listener needs, bound by the caller. */
export interface ProseUncClaimDeps {
    /** Writes text to the clipboard; resolves the write's own success. */
    writeClipboard: (text: string) => Promise<boolean>;
    /** The localized "copied" confirmation text for the toast. */
    copiedLabel: () => string;
}
/**
 * Claim a chat-prose UNC reference before the dispatch's own default runs.
 * A non-`chat-prose` source (terminal/web, which handle their own UNC
 * targets inside `openReferentTarget`'s `onDefault`) or a non-UNC target
 * always falls through to `next()` unchanged — this listener never re-enters
 * the seam or calls a workspace/window opener itself.
 * @param ref - the dispatched reference.
 * @param next - the waterfall's next listener, or its default action.
 * @param deps - clipboard write and the copied-confirmation toast text.
 */
export declare function claimProseUnc(ref: ReferentRef, next: () => Promise<void>, deps: ProseUncClaimDeps): Promise<void>;
//# sourceMappingURL=prose-unc-claim.d.ts.map