/**
 * Bash-only row/terminal-card derivation, narrowed from the built-in
 * `toolRowModel`/`terminalCardModel` (`packages/client/ui-tool` in
 * `dsh-render`, not published) to exactly what a `bash` keyed toolview needs.
 * Reads only the public `ToolCallBlock` shape — never those internal
 * modules, which this out-of-tree package cannot import (their sources are
 * not part of the published npm package) — so this file, not a shared
 * import, is what keeps this plugin's bash view in step with the built-in
 * one; docs/clickable-refs-spec.md §2 requires 1:1 chrome, and this is where
 * that fidelity is re-derived. Local, not `core/`: it depends on
 * `ToolCallBlock` (a `dsh-client-ui-chat` type), so it stays client-only
 * rather than diluting the zero-UI-dependency purity `core/` promises.
 *
 * @module @haoran/dsh-clickable-refs/client/bash/terminal-model
 */
import type { ToolCallBlock } from '@deepseek-ai/dsh-client-ui-chat/client';
/** Row state semantic (mirrors the built-in `ToolRowState`). */
export type BashRowState = 'running' | 'ok' | 'error' | 'stopped';
/** The terminal card's own props, mirroring `TerminalBlockProps`'s data-carrying subset. */
export interface TerminalCard {
    readonly command: string;
    readonly cwd: string | undefined;
    readonly output: string | undefined;
    readonly exitCode: number | undefined;
    readonly signal: string | undefined;
    readonly running: boolean;
}
/** Everything `BashRow` needs, derived once from the frozen call slice. */
export interface BashRowModel {
    readonly state: BashRowState;
    readonly summary: string;
    readonly errorSummary: string | null;
    /** Present exactly when the call declared the `terminal` render intent; null routes to the generic IN/OUT fallback. */
    readonly terminal: {
        readonly card: TerminalCard;
        readonly description: string | undefined;
    } | null;
    /** Generic-fallback input text (pretty JSON args), for an execution failure with no terminal card. */
    readonly body: string | null;
    /** Generic-fallback flattened result text. */
    readonly output: string | null;
}
/** True when a settled terminal card's exit status is a failure (non-zero code or a signal). */
export declare function terminalFailed(card: TerminalCard): boolean;
/**
 * Derive the bash row model from a frozen call slice.
 *
 * `terminal` is always `null` (the generic IN/OUT fallback): the Host-computed
 * `callView`/`resultView` render intent this rich card used to key off
 * (`@deepseek-ai/dsh-client-runtime`'s `RunningToolCall`/`ToolResultNode`) has
 * no replacement on `ToolCallBlock` as of the rc.26 base — the built-in
 * `terminal-card-model.ts` now derives its own card by parsing the raw call
 * args/result content directly (`parsedToolCall`) instead of reading a
 * precomputed field. Restoring the rich terminal card needs the equivalent
 * raw-parsing rewrite here; tracked as a known regression, not implemented in
 * this port.
 * @param block - RunningToolCall or ToolResultNode off the owner's `block` prop.
 * @param sessionCwd - session workspace root; unused while `terminal` stays null, kept for the eventual raw-parsing rewrite's signature.
 * @returns the derived model.
 */
export declare function bashRowModel(block: ToolCallBlock, sessionCwd: string | undefined): BashRowModel;
//# sourceMappingURL=terminal-model.d.ts.map