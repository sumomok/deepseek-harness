import { type ClickableRefsKey } from './locales.ts';
import { type ClientContext } from './referent-click.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Not-found, refusal-list, and UNC-copy copy this plugin adds. */
        'clickable-refs': ClickableRefsKey;
    }
}
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * Register the bash/web_fetch shadows, the `proseReferents` service, and
 * this plugin's dictionaries.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map