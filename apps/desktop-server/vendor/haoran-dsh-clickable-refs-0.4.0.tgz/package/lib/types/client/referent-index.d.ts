/**
 * B2 of the three-layer spec (`docs/referents-three-layer-spec.md`): the
 * session truth index. Built from session events' own **structured**
 * fields only — a tool call's parsed JSON arguments, a completed mutation's
 * follow-along `locations` (the render-intent vocabulary every tool
 * presenter already declares), and a completed `web_fetch`'s final URL —
 * never a tool result's free-text output (that is the nomination layer's
 * territory, `core/detect.ts`). Absolute paths are the primary key;
 * basenames alias back to their one unambiguous absolute owner, the same
 * disambiguation rule `@deepseek-ai/dsh-client-ui-deliverables`'s
 * `producedFileMentions` already uses (a basename two paths share resolves
 * to neither, rather than guessing).
 *
 * One `MutableReferentIndex` instance is created per client apply() and
 * reset at the start of each session's replay (`start()` below, matched
 * to that session's very first `turn/start`) — "会話切换重建" (rebuilt on
 * session switch). A `ConversationNodeDefinition`'s own State channel
 * cannot carry session-wide (non-turn/step-scoped) data out to the
 * `proseReferents` service, which is a plain per-apply object, not
 * itself session-scoped — so this Definition's `start`/`update` mutate the
 * shared index as a deliberate, documented side effect, while still
 * returning a (trivial, unread) State value to satisfy the engine's own
 * per-Context bookkeeping.
 *
 * @module @haoran/dsh-clickable-refs/client/referent-index
 */
import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-ui-conversation/client';
/** Read-only face `prose-referents.ts`/terminal scanning consult. */
export interface ReferentIndexReader {
    /** Whether `absolute` is a known-real path recorded from a structured session field. */
    hasPath(absolute: string): boolean;
    /** The one unambiguous absolute path a basename/relative alias resolves to, or `undefined` (unknown, or shared by more than one recorded path). */
    resolveAlias(alias: string): string | undefined;
    /** Whether `url` was actually fetched (`web_fetch`'s final URL) in this session. */
    hasUrl(url: string): boolean;
    /**
     * Subscribe to index growth (a later mention of an already-rendered path
     * may now resolve once the index records it).
     * @param listener - called with no arguments on every recorded fact.
     * @returns unsubscribe function.
     */
    subscribe(listener: () => void): () => void;
}
/** Mutable index + subscribe channel; the Definition below is its only writer. */
export declare class MutableReferentIndex implements ReferentIndexReader {
    private paths;
    private aliasCandidates;
    private urls;
    private readonly listeners;
    /** Discard every recorded fact — called once at the start of each session's replay. */
    reset(): void;
    /**
     * Record an absolute path as real, and its basename as an alias toward it.
     * @param absolute - an already-absolute path (a relative value is not this method's job to resolve).
     */
    recordPath(absolute: string): void;
    /** Record a URL as actually fetched this session. */
    recordUrl(url: string): void;
    hasPath(absolute: string): boolean;
    resolveAlias(alias: string): string | undefined;
    hasUrl(url: string): boolean;
    /**
     * Subscribe to index growth (a later mention of an already-rendered path
     * may now resolve once the index records it).
     * @param listener - called with no arguments on every recorded fact.
     * @returns unsubscribe function.
     */
    subscribe(listener: () => void): () => void;
    private notify;
}
/**
 * Build the `ConversationNodeDefinition` that populates `index` as a side
 * effect. A single session-wide Context (`id: 'session'`) starts on that
 * session's very first turn (`turn/start` with `turn === 1` — always the
 * earliest turn-scoped event in any session's log, before any tool call
 * can occur) and updates on every `tool/call`/`tool/result` after that; a
 * later session's own turn 1 lands in a fresh Context (a new session gets
 * a fresh `ConversationNodeAssembler`), so `reset()` at `start()` only ever
 * discards this same session's own prior nothing.
 * @param index - the shared index this Definition writes into.
 * @returns the Definition to pass to `ctx.conversationEvents.register`.
 */
export declare function createReferentIndexDefinition(index: MutableReferentIndex): ConversationNodeDefinition<null>;
//# sourceMappingURL=referent-index.d.ts.map