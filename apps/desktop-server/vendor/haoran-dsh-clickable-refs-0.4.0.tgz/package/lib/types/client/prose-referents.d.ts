/**
 * The `proseReferents` optional-service provider (`ctx.provide('proseReferents', …)`,
 * consumed by `@deepseek-ai/dsh-client-ui-chat`'s chat view, which adapts it
 * into the `MarkdownProseReferents` render-time shape per session —
 * `ui-chat/apply.ts`'s own `buildProseReferents`). B4/B1 of the three-layer
 * spec: `core/detect.ts` still does 100% of nomination (unchanged), but
 * `scan`/`resolveLink` now filter every candidate through the
 * {@link VerificationStore} before returning it — an unverified candidate
 * never leaves this module, which is what makes "blue = openable" hold
 * structurally at the render layer. `subscribe` forwards the store's own
 * tick channel straight through, unwrapped.
 *
 * `ProseReferents`/`ProseReferentSpan` mirror `@deepseek-ai/dsh-client-ui-chat`'s
 * own contract (`contract/slots.ts`) structurally: that package declares the
 * `ctx.proseReferents` Context merge but does not re-export the interfaces
 * from its public `client` entry point, so this out-of-tree provider
 * declares its own copy rather than importing one. TypeScript's structural
 * typing (not the two declarations' nominal identity) is what makes the
 * object this module builds assignable to `ctx.proseReferents` in the
 * assembled app; each package's own isolated compilation never sees the
 * other's identical `declare module` block, so the two never conflict.
 *
 * @module @haoran/dsh-clickable-refs/client/prose-referents
 */
import type { ReferentKind } from '@deepseek-ai/dsh-api-session-controller/client';
/** One clickable reference a scan found, verified (mirrors `dsh-client-ui-chat`'s `ProseReferentSpan`). */
export interface ProseReferentSpan {
    readonly start: number;
    readonly end: number;
    readonly kind: ReferentKind;
    readonly target: string;
    readonly raw: string;
}
/** The `proseReferents` optional-service contract (mirrors `dsh-client-ui-chat`'s `ProseReferents`). */
export interface ProseReferents {
    scan(text: string, context: {
        cwd?: string | undefined;
        home?: string | undefined;
        inlineCode: boolean;
    }): readonly ProseReferentSpan[];
    resolveLink?(destination: string, displayText: string, context: {
        cwd?: string | undefined;
        home?: string | undefined;
    }): ProseReferentSpan | undefined;
    subscribe?(listener: () => void): () => void;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Prose-referent scanning provider this plugin supplies; consumed via `ctx.get('proseReferents')`. */
        proseReferents: ProseReferents;
    }
}
import type { VerificationStore } from './verification-store.ts';
/**
 * Build the `ProseReferents` service this plugin provides, bound to one
 * session's {@link VerificationStore}.
 * @param store - verification cache/scheduler for the active session (the
 * plugin owns one instance, rebuilt on session switch — see `client/index.ts`).
 * @returns the service to `ctx.provide('proseReferents', …)`.
 */
export declare function createProseReferents(store: VerificationStore): ProseReferents;
//# sourceMappingURL=prose-referents.d.ts.map