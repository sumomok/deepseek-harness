/**
 * The click chokepoint every detected span and the web card's URL route
 * through: build one `ReferentRef`, dispatch it over `referent/open` (via
 * `ctx.referent.open`), and run the plugin's own default open action when
 * nothing upstream claims it. This is the ONLY place that ever calls
 * `remote.session.openWorkspacePath`/`window.open` for a clickable-refs hit —
 * never the toolview's own `openFile` owner prop, which would dispatch a
 * second, differently-provenanced `referent/open` for the same click (see
 * `docs/clickable-refs-spec.md` §3).
 *
 * @module @haoran/dsh-clickable-refs/client/referent-click
 */
import type { Context } from '@deepseek-ai/cordis';
import type { IReferent, ReferentRef } from '@deepseek-ai/dsh-api-session-controller/client';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { DetectedRef } from '../core/detect.ts';
/** `ctx.referent` and `ctx` narrowed to exactly what this module dispatches through. */
export type ClientContext = Context & {
    readonly referent: IReferent;
};
/** Source tags this plugin stamps on every `ReferentRef` it dispatches. */
export type ClickableRefsSource = 'clickable-refs.terminal' | 'clickable-refs.web';
/**
 * Build the `ReferentRef` for one detected hit.
 * @param detected - the span that was clicked.
 * @param opts - dispatch-site identity.
 * @returns the reference to dispatch.
 */
export declare function toReferentRef(detected: Pick<DetectedRef, 'kind' | 'target' | 'raw'>, opts: {
    sessionId?: SessionId | undefined;
    source: ClickableRefsSource;
}): ReferentRef;
/**
 * The minimal open-path surface this module needs, adapting
 * `ctx.remote.session.openWorkspacePath` (narrower than that Remote's own
 * request/result shape): the caller rethrows the RPC's raw failure on a
 * `!result.ok` response so this module's `not-found` downgrade below can
 * classify it by `remoteErrorOf(error)?.code`, exactly as a direct
 * `openWorkspacePath` caller would (`packages/client/ui-chat`'s own
 * `openFile`/prose-referent dispatch follow the same rethrow shape).
 */
export interface OpenPathHost {
    openPath: (path: string) => Promise<void>;
}
/** What happened once the click settled, for the calling component to render. */
export type ClickOutcome = 
/** The URL/file/dir opened (or a listener claimed the click and this module never ran its own default). */
{
    readonly kind: 'opened' | 'claimed';
}
/** Refused by the extension list; `folder` is the parent directory to offer instead. */
 | {
    readonly kind: 'refused';
    readonly folder: string;
}
/**
 * A UNC network-share path (`\\server\share\…`); never opened. Accessing
 * one on Windows triggers SMB authentication, which can leak the current
 * user's NTLM credentials to whatever host `target` names — and model text
 * (or terminal output a prompt-injected tool run produced) is untrusted
 * input, so this target is not necessarily the share the user meant to
 * reach. `path` is the exact target to offer for copy instead.
 */
 | {
    readonly kind: 'unc';
    readonly path: string;
}
/** `openPath` reported `session/path-not-found`: the span should downgrade to dead text for this render. */
 | {
    readonly kind: 'not-found';
}
/** Any other open failure; `message` is the host's own error text. */
 | {
    readonly kind: 'error';
    readonly message: string;
};
/**
 * Open one detected reference through the `referent/open` seam.
 *
 * `onDefault` — this module's own pre-existing open action — never runs when
 * a listener claims the click; the returned outcome then stays `'claimed'`,
 * and this function makes no filesystem or window call at all.
 * @param params.ctx - dispatching context (a direct user-gesture handler; see the seam's security invariant).
 * @param params.ref - the reference being opened.
 * @param params.workspaces - `openPath` for `file`/`dir` targets.
 * @param params.windowOpen - `url` opener; defaults to `window.open(url, '_blank', 'noopener,noreferrer')`.
 * @returns what happened, for the calling component to render.
 */
export declare function openReferentTarget(params: {
    readonly ctx: ClientContext;
    readonly ref: ReferentRef;
    readonly workspaces: OpenPathHost;
    readonly windowOpen?: ((url: string) => void) | undefined;
}): Promise<ClickOutcome>;
//# sourceMappingURL=referent-click.d.ts.map