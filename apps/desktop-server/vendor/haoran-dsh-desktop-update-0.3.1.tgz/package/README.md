# @haoran/dsh-desktop-update

English | [中文](README.zh.md)

Update the DeepSeek Harness desktop application itself, from inside it. An **Updates** page appears in Settings showing the running version, whether a newer one has been published, what changed in it, and how far a download has got. Beside the sidebar's **More** button, a compact status shows checking, download progress, failures, and a downloaded update; every available action opens the Updates page rather than installing directly.

## What you see, and when

| Where | When | What |
| --- | --- | --- |
| Settings → **Updates** | Always | Running version, whether a newer one is published, release notes, the last check's time, a **Check now** button, a **Download the new version** button when a newer version was found, and the download's own progress bar |
| Beside **More** in the sidebar | While checking, downloading, failed, or ready | A compact brand-blue status; **Update to latest** opens the page above, while busy states do not start a command |
| Anywhere else | Never | — |

Three product rules decide that table, and each one is deliberate:

- **An update is not part of the work you came here to do.** It waits in Settings, with the other application-wide choices, rather than interrupting a session.
- **Progress stays quiet.** Checking and downloading show a small spinner and percentage beside **More**; those busy controls do nothing when pressed.
- **The sidebar never installs.** Ready and failed states open the Updates page, where the release notes and the consequence of restarting are visible before the install button.

Pressing **Restart and install** restarts the application into the new version. **That press is the consent** — nothing asks a second time, here or in the shell.

Only one line on the page carries a version number: the one naming the version you are running. Nothing names the version being offered — neither the page, nor the sidebar button, nor its accessible name.

## Where it works, and where it does nothing

This plugin needs the loopback update service the desktop shell lends the server it starts — `DSH_DESKTOP_UPDATE_ENDPOINT` and `DSH_DESKTOP_UPDATE_TOKEN` in that one child process's environment. A `dsh web` on a server sets neither. There, `state()` answers `available: false` with phase `unsupported`, the browser half registers no page and no button, and nothing appears in Settings — the right outcome for a feature nobody there can use, rather than a page that opens onto an apology.

There is no second path. This plugin never reads an update feed, never checks a signature, never writes a file, and never restarts anything. Every one of those belongs to the shell, which is the only thing on the machine that can replace the running application.

## The contract with the shell

The shell serves four routes on a loopback origin. All four require `Authorization: Bearer <token>` with the token from the environment.

| Route | Answer |
| --- | --- |
| `GET /state` | `{ phase, currentVersion, latestVersion?, releaseNotes?, percent?, transferredBytes?, totalBytes?, reason?, checkedAt? }` |
| `POST /check` | `{ ok: true }` or `{ ok: false, error }` |
| `POST /download` | `{ ok: true }` or `{ ok: false, error }` |
| `POST /install` | `{ ok: true }` or `{ ok: false, error }` — and the application restarts into the new version immediately |

`phase` is one of `idle`, `checking`, `downloading`, `ready`, `failed`. (`unsupported` is this plugin's own sixth value for a deployment with no service at all; the shell never sends it.) A field the shell spells with a type this build does not expect is dropped rather than carried into the page; a body with no readable `phase` is refused, because the whole page is a projection of that one field.

`/check` and `/download` start work and answer; progress and the ending arrive through `/state`. `/install` may not answer at all — the application goes away while the call is in flight — and that is the expected ending, not a fault.

## Permissions / security

- **The browser never sees the endpoint or the token.** Both are read once from the process environment on the host side. The browser half reaches the host only through the harness's own `/api` Typert gateway, and this plugin registers no HTTP route of its own. A build check asserts neither variable name reaches the browser bundle.
- **A caller cannot name a version, a URL, or a file.** All four methods take no parameters at all. The version installed is the one the shell's own check found.
- **The shell owns every decision that matters** — which feed, which signature, which file, and when to restart. This plugin composes four requests and reads four answers.
- **Nothing here can fail a launch.** Every failure it can meet — no service, a service that stopped answering, a body it cannot read — becomes a sentence on the page. No exception crosses the gateway.

## Where the button sits

Two seats can hold the ready button, and which one exists depends on the build:

| Seat | Declared by | Position |
| --- | --- | --- |
| `settings.trigger.action` | A core patch in the harness checkout | Right-aligned on the settings row itself |
| `sidebar.footer.action` | `@deepseek-ai/dsh-client-ui-sidebar`, always | The sidebar foot, above the settings row |

**The choice is made from the live slot declaration ledger, not from a version check.** `ctx.slots.inject(key, …)` runs its callback once per declaration lifetime of `key` and never runs it while the key is undeclared, so injecting on the patched key *is* the detection: the callback firing means the seat exists. The fallback registers only while that has not happened and stands down the moment it does, which also covers the order the declarations arrive in — the sidebar declares its foot before the settings shell it contains can declare anything.

Both seats use the official Desktop indicator's compact brand-blue surface, 28px height, and reduced-motion-aware spinner. The seat's own `openSection` distinguishes the direct settings-row route from the sidebar-foot fallback; neither route changes the update backend or authorizes installation.

## How the button opens the page

The settings renderer (`ui-settings-general`'s `SettingsRoot`) hands `openSection(id)` to occupants of `settings.trigger.action`. That is the direct route this plugin uses in the current desktop shell; no Cordis service, command, or event is added.

When `openSection` is available, pressing the status opens Settings directly on this page and touches no DOM. The legacy fallback presses the default Settings trigger and then this page's nav row; it is only for shells without the direct opener and is not used with the account menu's `aria-haspopup="menu"` trigger.

The desktop shell uses the shared account menu in `settings.launcher`, so **More** owns Settings, Feedback, and DeepSeek sign-in. This plugin remains the only own-update status entry and continues to read `remote.desktopUpdate`; it does not expose or consume the official shell's `dshDesktop.updates` bridge.

Every failure on that path is silent and harmless: nothing found means nothing pressed, and Settings opens the way it always could.

## Configuration

| Key | Default | What it does |
| --- | --- | --- |
| `activePollMs` | `3000` | How often the page re-reads the state while it is open or a transfer is running |
| `idlePollMs` | `60000` | How often it re-reads the rest of the time; this bounds how soon the sidebar status appears for someone who never opened Settings |
| `requestTimeoutMs` | `60000` | How long the host half waits for one answer from the shell |

Both intervals are resolved on the host and carried in every view, so the browser half decides no number of its own. Every read is one loopback request that touches no network.

The protocol is not configuration and is not configurable: the two environment variable names, the four route paths, and the bearer scheme are fixed facts of the shell this plugin talks to.

## Compatibility

Requires the desktop shell's update service, which ships from `apps/desktop-shell` in the desktop repository. Built against the `0.2.2-rc.1` harness base; every `@deepseek-ai/dsh-*` peer range is `>=0.2.2-rc.1`. The Typert codecs use the `create()` factory and the status component uses the current shared icon names.

## Install

```sh
pnpm run build && pnpm pack
dsh plugin --profile desktop-shell add /absolute/path/to/haoran-dsh-desktop-update-0.3.1.tgz
```

## Out of scope

Downloading, verifying, staging, and restarting. All four are the shell's, and none of them can be done from inside a Node process the shell started. Plugin updates are a different subject with a different fence — that is `@haoran/dsh-plugin-updates`.
