/**
 * The update status beside the sidebar's More button.
 *
 * Checking and download progress use a quiet spinner, a failure offers a route
 * back to the update page, and a downloaded update keeps the existing install
 * entry. Every action opens the Settings page; none installs from the sidebar.
 * The state still comes only from this plugin's own Remote.
 *
 * @module @haoran/dsh-desktop-update/client/UpdateReadyAction
 */
import type { ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { UpdateStoreState } from './store.ts';
/** Registration-side dependencies of {@link UpdateReadyAction}. */
export interface UpdateReadyActionInjected {
    hooks: {
        /** The browser half's own store. */
        update: HostObservable<UpdateStoreState>;
    };
    /** This plugin's `settings.section` id, for a shell that hands down an opener. */
    sectionId: string;
    /** This plugin's settings nav label in the active locale, for the shell that does not. */
    navLabel: () => string;
    /** Runs the nav selection after the settings panel has rendered. */
    schedule: (run: () => void) => void;
}
/** Full component props for either sidebar action seat. */
export type UpdateReadyActionProps = PropsRuntime<'settings.trigger.action'> & PropsLocale<'desktopUpdate'> & InjectFace<UpdateReadyActionInjected>;
/**
 * Render the shared update status without exposing a target version or shell diagnostic.
 * @param props - sidebar geometry, localized copy, the update store, and a Settings opener.
 * @returns the active status, or nothing while idle or unsupported.
 */
export declare function UpdateReadyAction(props: UpdateReadyActionProps): ReactNode;
//# sourceMappingURL=UpdateReadyAction.d.ts.map