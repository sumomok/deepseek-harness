/**
 * The browser half's stylesheet, injected once as a tagged `<style>`.
 *
 * Colors, radii, and spacing come from harness theme variables. The sidebar
 * status uses the same compact brand-blue treatment as the official Desktop
 * indicator in both seats, with a reduced-motion rule for its spinner. It never
 * positions itself absolutely or assumes ownership of either edge of a shared
 * settings row.
 *
 * @module @haoran/dsh-desktop-update/client/styles
 */
/** Attribute marking this plugin's style tag, so a remount does not duplicate it. */
export declare const STYLE_TAG = "data-dsh-desktop-update";
/**
 * Put the stylesheet in the document, once.
 * @returns a disposer removing the tag.
 */
export declare function insertStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map