# @haoran/dsh-plugin-updates

English | [中文](README.zh.md)

Update the plugins you installed, from inside the DeepSeek Harness desktop application. An **Updates** tab appears in plugin settings listing what you added yourself beside the newest published version, with one button per row, a check that runs quietly at startup, a count on the tab when something is waiting, and one step to put the last update back.

Everywhere else the answer is `dsh plugin --profile <name> add <package>@latest`. That needs a terminal, a package manager on `PATH`, and the name of a profile. The desktop application's whole premise is a person who has none of those — and its installer is the only thing on the machine that ships a package manager at all.

## What it lists, and what it never lists

| Listed | Not listed |
| --- | --- |
| Packages a profile declares as its own dependencies — everything you added with `dsh plugin add`, and everything the desktop brought across from an earlier install | The plugins the application ships. The desktop seeds those into its bundle list with no dependency entry, so they are outside the updatable set by construction, and they update when the application does |

The tab also does not say which profile a package lives in. That decides where the package manager runs and is not a question you asked; the plugin works it out from the two profile manifests and the desktop's own migration record.

## What it does

| Action | What happens |
| --- | --- |
| Startup check | Once, a few seconds after launch, the newest published version of each listed package is read. Nothing is installed and nothing is shown until you open the tab, where the result becomes a count on the tab label. Turn it off with `checkOnStart: false` |
| **Check for updates** | The same read, on demand |
| **Update** | The published version's requirements are checked against the running application first. Then the application itself opens a confirmation on your screen naming the plugin and the version — and, when the requirements disagree, one sentence saying so. Only after you confirm is anything installed |
| **Restart now** | An installed update is on disk and the running application is still composed from the old copy, so the row says so and offers a restart. The application asks before restarting |
| **Undo** | The version that was there before the last update is installed again, behind the same confirmation. One update can be undone; taking the offer removes it |

## Two more groups: broken, and turned off

The desktop shell disables a plugin instead of booting it when it cannot compose, and keeps it visible instead of dropping it silently. Both groups render only when they hold something, and neither counts toward the number in the tab's own label — that number is only for a newer version waiting to be installed.

| Group | When a row appears there | Buttons |
| --- | --- | --- |
| **Broken, disabled** | The shell could not start it, for one of three reasons, each shown as one plain sentence: the package has no runnable file, the version on disk is not a valid plugin, or its own code failed while starting | **Check again** — re-checks it free of charge. **Try to repair** — reinstalls or rebuilds it, behind the application's own confirmation; this can take a minute. **Remove** — forgets it for good |
| **Disabled** | You turned it off yourself | **Enable** — turns it back on; the application may find it still broken and refuse. **Remove** — forgets it for good |

Every button leaves its row exactly as the update button does: an action that succeeds and needs a restart flips the row to "Takes effect after a restart", and one the shell refuses shows its own plain sentence under the row, with no jargon anywhere in either group.

## Where it works, and where it does nothing

This plugin needs the loopback package-manager service the desktop shell lends the server it starts — `DSH_DESKTOP_PLUGIN_ADMIN_ENDPOINT` and `DSH_DESKTOP_PLUGIN_ADMIN_TOKEN` in that one child process's environment. A `dsh web` on a server sets neither. There, every method answers `available: false`, the browser half registers no tab, and nothing appears in Settings — which is the right outcome for a feature nobody there can use, rather than a tab that opens onto an apology.

There is no second path. This plugin never looks for a package manager itself, never resolves one from `PATH`, and never fetches a registry URL. Every read and every install goes through the shell, which runs the package manager it ships — so the machine's own npm configuration, mirror, proxy, and credentials are what serve every request, exactly as they do for everything else installed on that machine.

## Permissions / security

The mutating half of this seam is deliberately not here.

- **The browser cannot name a version.** `update(name)` and `rollback()` take a package name and nothing else. The version installed is the one the host's own check found; the version a rollback returns to is the one the record holds. No specifier crosses the gateway at all.
- **The shell decides what is permissible.** It fixes the two profiles it will act in, checks the package name against that profile's own installed dependencies read from disk on every call, refuses anything but one exact published version, and runs every argument through an argument array rather than a shell.
- **Nothing installs without the person at the keyboard.** The confirmation is a native window the application draws. A page cannot paint over it and cannot answer it.
- **This plugin registers no HTTP route** and knows no token it can leak: the endpoint and the token are read once from the process environment and never leave the host half.

The rollback record holds a package name and two version strings, owner-only, under `$DSH_HOME/dsh-plugin-updates/`.

## What counts as installed

The version in the profile's own `node_modules` after the run, compared with the version that was asked for — never the package manager's exit status. `pnpm add` exits 1 with `ERR_PNPM_IGNORED_BUILDS` while installing correctly, on any profile that has not answered its build-approval question, which is every profile the desktop seeds and any plugin whose tree carries a package with an install script. Reading the status as the outcome reported a finished update as a failure and left no undo for a change that had happened. The status is still read — it goes to the host log, because it names what the package manager complained about.

## The compatibility check

Before an update is offered for confirmation, the published version's `@deepseek-ai/*` peer ranges are read and compared against what the running installation resolves. A range this build does not satisfy adds one sentence to the dialog and nothing else — it never refuses. A profile installs plugins with peers deliberately unresolved so that every plugin shares the installation's one cordis instance, which is also why a mismatch is otherwise silent until the next launch.

The comparison is ordinary semver, so while the harness itself is on a release-candidate line the sentence is common: `0.1.1-rc.2` does not satisfy `^0.1.0-rc.8`, because a range's prerelease comparator admits prereleases of its own `major.minor.patch` and no other. That is npm's own rule, it is what a strict install would have said, and it is exactly the case where a plugin built against an earlier candidate genuinely may not fit.

The sentence names no package. Which component disagrees is a support fact and goes to the host log.

## Configuration

| Key | Default | What it does |
| --- | --- | --- |
| `checkOnStart` | `true` | Read the newest published versions once, shortly after startup |
| `checkDelayMs` | `5000` | How long after startup that read happens |
| `root` | `''` | Where the rollback record is written; empty means `$DSH_HOME/dsh-plugin-updates` |

## Compatibility

Requires the desktop shell's plugin-admin service, which ships from `apps/desktop-shell` in the harness repository. `apps/desktop-shell/README.md` there states the wire protocol. Built against the `0.1.x` harness line.

## Development

A packaged application runs the pnpm staged in its own resources under its own bundled Node. A development launch ships no such copy and the shell falls back to `pnpm` on `PATH`, which is the developer's own — that fallback exists for the checkout and reaches no customer.

## Install

```sh
pnpm run build && pnpm pack
dsh plugin --profile desktop-shell add /absolute/path/to/haoran-dsh-plugin-updates-0.2.1.tgz
```

## Out of scope

Browsing and installing plugins you have not installed yet. That is a catalogue with a different list and a different fence, and it belongs in a tab of its own rather than as a second mode of this one.

## Known Limitations and Deferred Work

- One update at a time, and one undo. There is no history and no "update everything".
- An installed update takes effect at the next launch. Nothing here reloads a plugin in place.
- A plugin that installs cleanly and then misbehaves is not detected. The undo is the remedy, and it is available until the next update replaces it.

## License

MIT
