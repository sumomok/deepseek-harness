/**
 * The browser half's Typert contribution: the consumer-side mirror of
 * `../typert.ts`.
 *
 * Each descriptor must match the host manifest's invocation exactly — same id,
 * namespace, method, and parameter wire names — because the gateway matches
 * arguments by field name. The codecs are hand-written narrowings rather than a
 * schema library: this file is bundled into the browser and a validator's bytes
 * would ride into every page load for ten small calls.
 *
 * Each codec carries the `create()` factory the registry requires of every
 * strict codec. The browser gateway at `0.1.7-rc.2` never calls it — it reads a
 * result through `decode` only, and these codecs have none — so the browser does
 * not run these narrowings on what the host returns.
 *
 * @module @haoran/dsh-plugin-updates/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { RelaunchOutcome, RepairOutcome, RepairsView, UpdateOutcome, UpdatesView } from '../types.ts';
/** Narrow one view read. */
export declare function parseUpdatesView(value: unknown): UpdatesView;
/** Narrow one update or rollback outcome. */
export declare function parseUpdateOutcome(value: unknown): UpdateOutcome;
/** Narrow one restart answer. */
export declare function parseRelaunchOutcome(value: unknown): RelaunchOutcome;
/** Narrow one repairs read. */
export declare function parseRepairsView(value: unknown): RepairsView;
/** Narrow one recheck, repair, forget, or enable outcome. */
export declare function parseRepairOutcome(value: unknown): RepairOutcome;
/** The contribution `ctx.remote.$mount()` installs, mirroring `../typert.ts`. */
export declare const CONTRIBUTION: TypertRemoteContribution;
//# sourceMappingURL=contribution.d.ts.map