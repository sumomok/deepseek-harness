/**
 * Which plugins the user installed, and which directory each one lives in.
 *
 * The Loader's own inventory cannot answer this: it lists what is mounted, not
 * where a package came from or what version is on disk, and it does not
 * separate a plugin the user installed from one the application ships. Two
 * profile manifests and one marker file do answer it, and this module is the
 * only place that reads them.
 *
 * **A plugin the user installed is a `dependencies` entry.** The desktop shell
 * seeds its built-ins into `dsh.profile.bundles` and deliberately writes no
 * dependency for them — they resolve out of the installation, and a package
 * manager has nothing to install or update there. So the dependency map is
 * exactly the set this feature may act on, and every built-in is outside it by
 * construction rather than by a list this package would have to keep current.
 *
 * **A migrated plugin is updated where it lives.** The desktop profile links to
 * packages that stayed in the `web` profile, and the shell copied their version
 * specifiers into the desktop manifest as well, so a name can appear in both.
 * `web-migration.json` inside the desktop profile records exactly which names
 * came across, and a name it records that the `web` profile still declares is
 * owned by `web`: installing into the desktop profile instead would replace the
 * link with a second copy, and the `web` profile — still the one a
 * `dsh plugin --profile web` reaches — would be left behind on the old version.
 *
 * ## Cross-component dependency
 *
 * `web-migration.json` is written by `apps/desktop-shell/src/profile-seed.ts` in
 * the desktop repository and read here. The two sides share the file and nothing
 * else: this package neither writes it nor requires it, and a home without one
 * simply has no migrated names. Its format is `{ from, migrated }` and only
 * `migrated` is read; a marker that does not parse is read as no names, which
 * is the same answer as a home the migration never ran on.
 *
 * **Marker version 2 adds `defective` and `removed`.** The shell now disables a
 * package it cannot compose instead of booting it, and records which ones
 * rather than dropping them: `defective` names one it tried and could not
 * start, `removed` names one the person deliberately turned off and can turn
 * back on. Both are new arrays on the same file; a marker written before this
 * plugin read them, or missing either array, reads as no entries for it — the
 * same graceful reading `migrated` already gets. A `defective` entry of kind
 * `incompatible`, which a shell may write for a plugin the harness refused at
 * launch, is read like any other kind.
 *
 * @module @haoran/dsh-plugin-updates/profiles
 */
import type { DefectiveKind, OwningProfile } from './types.ts';
/** Directory under the harness home holding every profile. */
export declare const PROFILES_DIR = "profiles";
/** The desktop shell's record of its one-time migration out of the `web` profile. */
export declare const MIGRATION_MARKER_FILENAME = "web-migration.json";
/**
 * The profile the desktop application boots.
 *
 * The same string as `DESKTOP_PROFILE` in
 * `apps/desktop-shell/src/profile-seed.ts`, which is what creates
 * `$DSH_HOME/profiles/desktop-shell` and what the shell's plugin-admin service
 * checks a request's `profile` against. A value that drifts from the shell's
 * reads an absent directory — no installed plugins, no migration marker — and
 * every update request it composes is refused.
 */
export declare const DESKTOP_PROFILE = "desktop-shell";
/** The profile every `dsh web` shares, and the source of the desktop migration. */
export declare const WEB_PROFILE = "web";
/** One installed plugin: its name, where it lives, and what is on disk. */
export interface InstalledPlugin {
    /** The package name. */
    name: string;
    /** The profile whose directory a package manager must run in for this name. */
    profile: OwningProfile;
    /** The version on disk, or the manifest's own specifier when nothing on disk reads. */
    installed: string;
}
/**
 * The version specifiers one profile's manifest declares as its own
 * dependencies.
 * @param profileDir - the profile directory.
 * @returns name to specifier; empty when the manifest is absent or unreadable.
 */
export declare function declaredDependencies(profileDir: string): Record<string, string>;
/**
 * The names the desktop shell's migration record holds.
 * @param desktopDir - the desktop profile directory.
 * @returns the recorded names; empty for a home the migration never ran on.
 */
export declare function migratedNames(desktopDir: string): string[];
/** One defective entry as `web-migration.json` records it. */
export interface DefectiveMarkerEntry {
    /** The package name. */
    name: string;
    /** Why the shell disabled it instead of booting it. */
    kind: DefectiveKind;
    /** One English sentence for the host log; never shown in the tab. */
    detail: string;
    /** Epoch milliseconds of the shell's own finding. */
    at: number;
}
/**
 * The defective and removed entries the desktop shell's migration marker
 * holds.
 * @param desktopDir - the desktop profile directory.
 * @returns the recorded entries; empty arrays for a marker without them, a
 * marker written before this plugin read them, or a home the migration never
 * ran on.
 */
export declare function repairMarker(desktopDir: string): {
    defective: DefectiveMarkerEntry[];
    removed: string[];
};
/**
 * The names the marker holds as defective for any reason other than
 * compatibility, or as removed, merged into one set.
 *
 * A package that migrated healthy and only later became defective, or was
 * only later removed, keeps its `dependencies` entry — the migration marker
 * records a finding, it does not un-declare a dependency — so a name can be
 * both an ordinary dependency and a marker entry at once. This is the set
 * {@link Updates} in `updates.ts` leaves out entirely once the marker holds a
 * name: the defective and removed groups are that name's one home, and an
 * ordinary row for it would say the same thing twice, once correctly and once
 * as if nothing were wrong.
 *
 * An `incompatible` entry is not in this set. Its fix is installing a version
 * the running harness accepts, so the updater still checks for and installs a
 * newer version of it; it only leaves the name out of its own rows
 * ({@link markedIncompatible}).
 * @param home - the harness home.
 * @returns the merged set of names; empty for a home with nothing defective or removed.
 */
export declare function excludedNames(home: string): Set<string>;
/**
 * The names the marker holds as defective because the running harness refuses them.
 * @param home - the harness home.
 * @returns the names; empty for a marker holding none.
 */
export declare function markedIncompatible(home: string): Set<string>;
/**
 * The version of one package as it is installed for one profile.
 *
 * Resolution goes through `createRequire` from the profile directory first,
 * which is the same walk the Loader performs — profile `node_modules`, then the
 * flat fallback the installation heals — so the answer is the version that
 * would actually be imported. A package whose `exports` withholds its own
 * manifest is then read at its ordinary path, and only a package neither finds
 * falls back to the specifier the profile declared, which is a range rather
 * than a version and is labelled as one by being all there is.
 * @param profileDir - the profile directory to resolve from.
 * @param name - the package name.
 * @returns the version, or undefined when nothing on disk answers.
 */
export declare function installedVersion(profileDir: string, name: string): string | undefined;
/**
 * Where one package's own manifest is for one profile, found the way
 * {@link installedVersion} documents.
 * @param profileDir - the profile directory to resolve from.
 * @param name - the package name.
 * @returns the path of the first manifest that reads with a version, or undefined when none does.
 */
export declare function installedManifestPath(profileDir: string, name: string): string | undefined;
/**
 * Every plugin the user installed, across the two profiles the desktop shell
 * acts in.
 *
 * A name owned by `web` is left out of the desktop list even though the desktop
 * manifest declares it, so one package produces one row. Ordered by name, so
 * the list does not reshuffle between reads.
 * @param home - the harness home.
 * @returns the installed plugins.
 */
export declare function installedPlugins(home: string): InstalledPlugin[];
/**
 * The version of one package as this harness process itself resolves it.
 *
 * This is the running application's own copy, not a profile's: the peer
 * preflight compares what a published plugin asks for against what is actually
 * mounted, and that is whatever this module's own parent walk finds — the flat
 * fallback directory the installation heals on every launch.
 * @param name - the package name.
 * @param from - the module to resolve from; the caller's own by default.
 * @returns the version, or undefined when this installation does not carry it.
 */
export declare function runningVersion(name: string, from?: string): string | undefined;
//# sourceMappingURL=profiles.d.ts.map