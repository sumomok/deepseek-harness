/**
 * Whether one plugin version may run on the harness this process is, decided
 * exactly the way the harness decides it at launch.
 *
 * From `0.1.7-rc.1` on, the harness refuses at launch a plugin whose
 * `@deepseek-ai/dsh` or `@deepseek-ai/dsh-*` peer ranges its own version does
 * not satisfy, unless the profile's compatibility file grants that exact
 * `name@version` an exemption for this exact runtime. A refused plugin is left
 * out of the composition with one line on standard error, which the person
 * using the desktop application never sees: an update that installs such a
 * version makes the plugin disappear at the next restart.
 *
 * So this module does not reimplement the rule. It calls the harness's own
 * `evaluatePluginCompatibility` with the harness's own runtime version
 * (`getDshRuntimeVersion`) and the exemptions the harness reads at launch
 * (`readProfileVersionExemptions` of the `desktop-shell` profile, which is the
 * one the desktop application boots; a package that lives in the `web`
 * profile is loaded through that same boot). All three come from the
 * `@deepseek-ai/dsh-app-boot` the running harness resolves, which is why that
 * package is a peer of this plugin: a second copy inside this plugin would read
 * its own `package.json` as the runtime version.
 *
 * A manifest the harness's function throws on — a peer field that is not an
 * object of strings, or an incompatible manifest without a name or version —
 * is incompatible here, as it is at launch.
 *
 * @module @haoran/dsh-plugin-updates/compatibility
 */
import { type InstalledPlugin } from './profiles.ts';
/** The outcome of judging one manifest. */
export type Verdict = 
/** The harness would load it: every dsh peer is satisfied, or the exact version is exempted. */
{
    compatible: true;
}
/** The harness would refuse it at launch; `detail` is one English line for the host log. */
 | {
    compatible: false;
    detail: string;
};
/** Judges manifests against the running harness. */
export interface CompatibilityCheck {
    /**
     * Judge one plugin manifest.
     * @param manifest - the parsed `package.json` of one plugin version.
     * @returns whether the running harness would load it.
     */
    judge(manifest: object): Verdict;
}
/**
 * Read the exemptions the harness applies at launch.
 * @param home - the harness home.
 * @returns exact `name@version` keys mapped to the runtime versions they are allowed on.
 */
export declare function desktopExemptions(home: string): Record<string, string[]>;
/**
 * Judge one manifest with the harness's own rule.
 * @param manifest - the parsed `package.json` of one plugin version.
 * @param exemptions - exact `name@version` keys mapped to the runtime versions they are allowed on.
 * @param runtimeVersion - the running harness's version.
 * @returns the verdict.
 */
export declare function judgeManifest(manifest: object, exemptions: Readonly<Record<string, readonly string[]>>, runtimeVersion: string): Verdict;
/**
 * The check against the harness this process runs in. The exemptions are read
 * again on every judgement, so a grant made while the application runs counts
 * at the next one.
 * @param home - the harness home.
 * @param runtimeVersion - the running harness's version; the resolved `@deepseek-ai/dsh-app-boot`'s own by default.
 * @returns the check.
 */
export declare function compatibilityCheck(home: string, runtimeVersion?: string): CompatibilityCheck;
/**
 * Read one installed package's own manifest in one profile.
 * @param profileDir - the profile directory.
 * @param name - the package name.
 * @returns the parsed manifest, or undefined when nothing on disk reads.
 */
export declare function installedManifest(profileDir: string, name: string): object | undefined;
/**
 * Read the manifest of one installed plugin where it lives.
 * @param home - the harness home.
 * @param plugin - the installed plugin.
 * @returns the parsed manifest, or undefined when nothing on disk reads.
 */
export declare function installedPluginManifest(home: string, plugin: Pick<InstalledPlugin, 'name' | 'profile'>): object | undefined;
//# sourceMappingURL=compatibility.d.ts.map