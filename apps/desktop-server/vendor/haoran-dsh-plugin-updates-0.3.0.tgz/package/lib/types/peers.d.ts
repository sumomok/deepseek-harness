/**
 * The warning one update's confirmation carries about the packages the
 * harness's own compatibility check does not look at.
 *
 * A plugin is installed into a profile whose `pnpm-workspace.yaml` turns off
 * `autoInstallPeers` and does not set `strictPeerDependencies`, and its peers
 * are meant to resolve through the flat fallback directory into the running
 * installation. That arrangement is what keeps every plugin on one cordis
 * instance, and it is also why a mismatch is silent: pnpm installs the new
 * version without a word.
 *
 * The harness's `@deepseek-ai/dsh` and `@deepseek-ai/dsh-*` peers are judged by
 * `compatibility.ts` with the harness's own rule, which refuses the install.
 * What is left here is every other `@deepseek-ai/*` peer — `cordis`,
 * `schemastery`, and the like — which the harness does not check at launch.
 * For those, a range this process does not satisfy becomes one plain sentence
 * in the confirmation dialog. It is a warning, never a refusal: nothing here
 * can prove that such a range will actually break.
 *
 * Only `@deepseek-ai/*` peers are compared. Everything else a plugin declares —
 * `react`, `zod`, the packages it bundles — is either inlined into its own
 * bundle or resolved from its own install, so a range this process cannot
 * satisfy says nothing about whether the plugin will run.
 *
 * @module @haoran/dsh-plugin-updates/peers
 */
/** The scope whose peers a plugin shares with the running installation. */
export declare const HARNESS_SCOPE = "@deepseek-ai/";
/**
 * Whether one peer name is the harness's own, which `compatibility.ts` judges instead.
 * @param name - the peer package name.
 * @returns true for `@deepseek-ai/dsh` and every `@deepseek-ai/dsh-*` name.
 */
export declare function isDshPeer(name: string): boolean;
/** One peer a published version declares and this installation does not satisfy. */
export interface PeerMismatch {
    /** The peer package name. */
    name: string;
    /** The range the published version declares. */
    range: string;
    /** The version this installation resolves, or undefined when it carries none. */
    running: string | undefined;
}
/**
 * Compare one published version's declared peers against this installation.
 *
 * A peer this installation does not carry is not a mismatch: the plugin brings
 * its own copy, or nothing composes it, and either way there is no version to
 * disagree with. A range this build's version does not satisfy is one.
 * Prereleases participate in ranges (`includePrerelease`), the same reading
 * the harness gives its own peers, so a release-candidate build is not warned
 * about merely for being one.
 * @param peers - the peer ranges the published version declares.
 * @param resolve - the version this installation resolves for one package name.
 * @returns every non-harness `@deepseek-ai/*` peer whose range this installation does not satisfy.
 */
export declare function peerMismatches(peers: Record<string, string>, resolve: (name: string) => string | undefined): PeerMismatch[];
/**
 * The one sentence a mismatch puts in the confirmation dialog.
 *
 * Chinese and jargon-free, because the shell's own dialogs are Chinese and the
 * person reading it installed a plugin, not a dependency graph. It names no
 * package and no range: which internal component disagrees is a support fact,
 * and it goes to the log rather than into a modal the person has to decide on.
 * @param mismatches - what the preflight found.
 * @returns the sentence, or undefined when there is nothing to warn about.
 */
export declare function mismatchWarning(mismatches: readonly PeerMismatch[]): string | undefined;
/**
 * The line the host log carries about one preflight, naming what the dialog
 * does not.
 * @param name - the plugin being updated.
 * @param version - the version being installed.
 * @param mismatches - what the preflight found.
 * @returns the log line.
 */
export declare function mismatchDetail(name: string, version: string, mismatches: readonly PeerMismatch[]): string;
//# sourceMappingURL=peers.d.ts.map