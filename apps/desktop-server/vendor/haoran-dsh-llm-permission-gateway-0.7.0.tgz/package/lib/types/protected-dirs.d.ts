/**
 * The review rule that names the app's own directories, filled at load.
 *
 * The rule tells the review model that writing into, moving, or deleting the
 * app's installation directory, its data directory, or the desktop app's
 * settings, logs, or update download folder is never routine, and that
 * writing inside the data directory's skills folder is routine unless another
 * rule applies: writing skills is how the agent keeps what it learns. The
 * exception does not reach the two never-allow categories or the red lines. It is a review-model instruction rather than a
 * red line: `./redline.ts` guards only the locations whose change would
 * reconfigure this gate, and admits no configuration, while the wording here
 * is a `Config` field a deployment can rewrite.
 *
 * The rule template and the per-directory labels are {@link Config} fields;
 * this module checks the template's placeholders and fills them. The paths are
 * resolved once at load from the running installation, so the filled text is
 * the same for every review on a machine and the review prompt keeps one
 * identical prefix. A directory the launch does not name is left out of the
 * list rather than named as absent.
 * @module @haoran/dsh-llm-permission-gateway/protected-dirs
 */
/**
 * The environment variable the desktop shell sets on the server of a packaged
 * launch to the app's installation directory. A development launch sets none.
 * It is the name `apps/desktop-shell/src/install-dir.ts` writes, fixed on both
 * sides.
 */
export declare const INSTALL_DIR_ENV = "DSH_DESKTOP_INSTALL_DIR";
/**
 * The environment variable the desktop shell sets on the server to the
 * Electron `userData` folder, where the desktop app keeps its own settings.
 * Absent outside the desktop app.
 */
export declare const USER_DATA_DIR_ENV = "DSH_DESKTOP_USER_DATA_DIR";
/**
 * The environment variable the desktop shell sets on the server to the
 * desktop app's logs folder, which on macOS is `~/Library/Logs/…`, outside
 * `userData`. Absent outside the desktop app.
 */
export declare const LOG_DIR_ENV = "DSH_DESKTOP_LOG_DIR";
/**
 * The environment variable the desktop shell sets on the server to the folder
 * the updater downloads new versions into. Absent outside the desktop app.
 */
export declare const UPDATE_CACHE_DIR_ENV = "DSH_DESKTOP_UPDATE_CACHE_DIR";
/**
 * The user skill folder under the data directory: the `user-dsh` root
 * `@deepseek-ai/dsh-skill-filesystem` reads, which exports no constant for it.
 */
export declare const SKILLS_DIR_NAME = "skills";
/** The directories one filled rule names. */
export interface ProtectedDirectories {
    /** The installation directory, or `undefined` when the launch names none. */
    readonly installDir: string | undefined;
    /** The resolved harness home. */
    readonly dataDir: string;
    /** The desktop app's settings folder, or `undefined` when the launch names none. */
    readonly userDataDir: string | undefined;
    /** The desktop app's logs folder, or `undefined` when the launch names none. */
    readonly logDir: string | undefined;
    /** The desktop updater's download folder, or `undefined` when the launch names none. */
    readonly updateCacheDir: string | undefined;
    /** The user skill folder under {@link ProtectedDirectories.dataDir}. */
    readonly skillsDir: string;
}
/** The label each listed directory is introduced with, as {@link Config} states them. */
export interface ProtectedDirLabels {
    /** Label for {@link ProtectedDirectories.installDir}. */
    readonly installDir: string;
    /** Label for {@link ProtectedDirectories.dataDir}. */
    readonly dataDir: string;
    /** Label for {@link ProtectedDirectories.userDataDir}. */
    readonly userDataDir: string;
    /** Label for {@link ProtectedDirectories.logDir}. */
    readonly logDir: string;
    /** Label for {@link ProtectedDirectories.updateCacheDir}. */
    readonly updateCacheDir: string;
}
/** The rule template and its labels. */
export interface ProtectedDirsWording {
    /** The rule; exactly `{directories}` and `{skillsDir}`, each once. */
    readonly rule: string;
    /** One label per directory. */
    readonly labels: ProtectedDirLabels;
}
/**
 * Refuse a rule template whose placeholders are not exactly
 * `{directories}` and `{skillsDir}`, each once.
 * @param rule - the configured `protectedDirsRule`.
 * @throws {Error} when a required placeholder is missing, repeated, or an unknown one is present.
 */
export declare function checkProtectedDirsRule(rule: string): void;
/**
 * Resolve the directories for the running installation: the installation
 * directory from {@link INSTALL_DIR_ENV}, the settings folder from
 * {@link USER_DATA_DIR_ENV}, the logs folder from {@link LOG_DIR_ENV}, the
 * update download folder from {@link UPDATE_CACHE_DIR_ENV}, and the data
 * directory from `resolveDshHome()`, the resolver the server's plugins use.
 *
 * The four desktop directories are read from the environment rather than from
 * `Config` fields. They are facts of one launch with no static default; the
 * desktop's gateway row replaces this row's whole config, so a field this
 * package's row set would not reach it; and a `!!js process.env` expression in
 * the desktop row would be written into the profile as a literal path by the
 * first settings save, freezing one launch's path.
 * @param env - the environment to read; the process environment by default.
 * @returns the directories the rule names.
 */
export declare function resolveProtectedDirectories(env?: NodeJS.ProcessEnv): ProtectedDirectories;
/**
 * Fill the rule: `{directories}` becomes one `  - <label>: \`<path>\`` line per
 * named directory, in the order installation, data, settings, logs, update
 * download, and
 * `{skillsDir}` the skills folder in backticks.
 * @param wording - a rule that passed {@link checkProtectedDirsRule}, and its labels.
 * @param directories - the paths to name.
 * @returns the rule text the review prompt carries.
 */
export declare function renderProtectedDirsRule(wording: ProtectedDirsWording, directories: ProtectedDirectories): string;
//# sourceMappingURL=protected-dirs.d.ts.map