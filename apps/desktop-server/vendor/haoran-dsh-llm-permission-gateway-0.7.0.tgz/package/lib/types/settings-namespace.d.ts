/**
 * The profile entry id this plugin's bundle inserts, and the review route an
 * entry that names none is reviewed on.
 *
 * Its own module because both halves need them and only one of them can import
 * `./mode.ts`: that module reads the Loader's volatile references and the
 * commands registry, neither of which belongs in a browser bundle.
 * @module @haoran/dsh-llm-permission-gateway/settings-namespace
 */
/**
 * Id of the profile entry the bundle inserts, which is also the settings
 * namespace the browser half asks `configForms` for. The host half writes
 * through its own `ctx.fiber.entry` id instead, so a composition that renames
 * the entry still stores the choice where it belongs; only the settings page
 * reads this constant, and it does not appear for an entry under another id.
 */
export declare const GATEWAY_ENTRY_ID = "llm-permission-gateway";
/** Provider route of the review route an entry that names none is reviewed on; `judgeProvider`'s schema default. */
export declare const DEFAULT_JUDGE_PROVIDER = "deepseek-official";
/** Model id of the review route an entry that names none is reviewed on; `judgeModel`'s schema default. */
export declare const DEFAULT_JUDGE_MODEL = "deepseek-flash";
/**
 * The route a stored pair names. A half that is `''` (or only whitespace) reads
 * as not stored and takes its schema default, the same as an absent half, so
 * every stored state names a concrete route and the settings page can show it.
 * @param selection - the two fields as the entry resolves them.
 * @param selection.judgeProvider - the stored provider route, or `''`.
 * @param selection.judgeModel - the stored model id, or `''`.
 * @returns the provider and model reviews are issued on, before the host checks that an adapter serves the provider.
 */
export declare function judgeRouteOf(selection: {
    readonly judgeProvider: string;
    readonly judgeModel: string;
}): {
    provider: string;
    model: string;
};
//# sourceMappingURL=settings-namespace.d.ts.map