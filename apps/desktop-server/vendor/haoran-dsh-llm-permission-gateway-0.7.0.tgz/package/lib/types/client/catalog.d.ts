/**
 * Turning one host model catalog into what the review-model picker draws.
 *
 * The catalog's `groups` hold only providers that listed at least one model, so
 * a provider with an adapter and an empty catalog is in neither `groups` nor
 * `failures` and appears nowhere here.
 *
 * Pure functions over the catalog and the stored pair, so what the page shows —
 * which routes are offered, which are named but not selectable, and whether the
 * stored one is still being reviewed on — is decided without React.
 * @module @haoran/dsh-llm-permission-gateway/client/catalog
 */
import type { ModelCatalog } from '@deepseek-ai/dsh-api-session-controller/types';
/** The stored pair this picker is built around. */
export interface JudgeSelection {
    /** Provider route as the entry resolves it; `''` reads as the schema default. */
    readonly judgeProvider: string;
    /** Model id as the entry resolves it; `''` reads as the schema default. */
    readonly judgeModel: string;
}
/** One reasoning effort a model offers, as the effort control draws it. */
export interface JudgeEffort {
    /** Provider-owned id, written to the settings section verbatim. */
    readonly id: string;
    /** The adapter's own name for it, which is the word the composer's thinking control shows. */
    readonly name: string;
}
/** One model the picker can be set to. */
export interface JudgeChoice {
    /**
     * The `<option>` value. A JSON pair rather than a joined string: provider ids
     * and model ids both admit every character, so no separator is free, and two
     * different routes sharing one value would silently select each other.
     */
    readonly value: string;
    /** Provider route this choice writes. */
    readonly provider: string;
    /** Model id this choice writes. */
    readonly model: string;
    /** Display text. */
    readonly label: string;
    /**
     * Whether this route can think before it answers, as the catalog reports it:
     * more than one selectable reasoning effort. One effort is a route with
     * nothing to select — a deployment with thinking switched off advertises only
     * its `off` — and no `reasoning` block at all is a route that says nothing,
     * which is not a claim that it does not think.
     *
     * Only the picked model is described this way, and only to say that review on
     * it can be slower and cost more. Which effort the review is actually issued
     * under is settled by the host, out of this page's sight.
     */
    readonly mayReason: boolean;
    /**
     * The efforts this model offers, in catalog order, from the same host catalog
     * the input composer's own thinking control is built from — and carrying the
     * same two fields it reads, so a level this page has no word of its own for
     * is still shown under the name the provider stated. Empty for a model that
     * reports no `reasoning` block, and for a stored route the catalog does not
     * list: neither is a claim that the model has one effort.
     */
    readonly efforts: readonly JudgeEffort[];
}
/** One provider's selectable models. */
export interface JudgeChoiceGroup {
    /** Provider route id. */
    readonly id: string;
    /** Provider display name, the group heading. */
    readonly name: string;
    /** That provider's models, in catalog order. */
    readonly choices: readonly JudgeChoice[];
}
/** A provider named in the picker without being selectable. */
export interface JudgeUnavailableProvider {
    /** Provider route id. */
    readonly id: string;
    /** Provider display name. */
    readonly name: string;
}
/** Everything the picker draws for one catalog and one stored pair. */
export interface JudgePicker {
    /** Selectable models, grouped by provider, in catalog order. */
    readonly groups: readonly JudgeChoiceGroup[];
    /**
     * Providers whose model list could not be read: named, never selectable. The
     * provider in force is left out — it is already on the list as the
     * selected option, and an adapter that cannot list its models still serves a
     * request, so a second row calling it unavailable would contradict the first.
     */
    readonly unavailable: readonly JudgeUnavailableProvider[];
    /**
     * The route in force when the catalog does not list it, so the control still
     * names the model reviews are issued on: the pair itself, labelled
     * `provider · model`, since there is no catalog name to show.
     */
    readonly stored?: JudgeChoice;
    /**
     * The route in force: the stored pair, or the schema default where the entry
     * stores none or stores an empty half. Never absent, so the control always
     * names a concrete model.
     */
    readonly selected: JudgeChoice;
    /** Value the control is set to: {@link JudgePicker.selected}'s. */
    readonly value: string;
    /**
     * Whether the catalog vouches for the provider in force: it is among
     * `routableProviders` — the providers with at least one currently available
     * catalog model — or among `failures`, whose list failed to load and which
     * therefore has an adapter. `false` draws a line saying the model in force is
     * not in the list of available models, and says nothing about which model
     * reviews: the host does not consult the catalog, and reviews on that
     * route wherever an adapter serves its provider, a provider whose list is
     * empty included. It reads the provider rather than "the stored pair is
     * absent from `groups`", because a route serving a model it stopped
     * advertising is missing from the groups and still usable.
     */
    readonly available: boolean;
}
/**
 * The `<option>` value naming one route.
 * @param provider - the provider route id.
 * @param model - the model id.
 * @returns a value no other route produces.
 */
export declare function routeValue(provider: string, model: string): string;
/**
 * Build what the picker draws.
 * @param catalog - the host's provider-grouped catalog.
 * @param selection - the stored pair, whose halves are `''` where the user picked nothing.
 * @returns the groups, the unavailable providers, and the current value.
 */
export declare function judgePicker(catalog: ModelCatalog, selection: JudgeSelection): JudgePicker;
/**
 * Read one picked `<option>` value back as the route it writes.
 * @param picker - the picker the value came from.
 * @param value - the value the control now holds.
 * @returns the route to store, or `undefined` for a value this picker never offered.
 */
export declare function choiceOf(picker: JudgePicker, value: string): JudgeChoice | undefined;
//# sourceMappingURL=catalog.d.ts.map