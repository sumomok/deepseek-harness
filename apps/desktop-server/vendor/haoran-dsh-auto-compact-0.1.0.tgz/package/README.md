# @haoran/dsh-auto-compact

English | [中文](README.zh.md)

Compact the conversation before it runs out of room, at a point you choose. A card appears in Settings under **Plugins** with a switch and a slider: turn it on, drag it to the share of the context window you want, and from the next step on the conversation makes room for itself when it gets that full.

## What you set, and what it does

| Control | Range | What it means |
| --- | --- | --- |
| The switch | on / off | Whether the conversation is compacted on context pressure at all |
| The slider | 20%–95%, in steps of 5 | The share of the context window at which the next step compacts first |

The percentage is read the same way as the usage ring beside the message box. That ring is the one figure you have already watched climb, and the slider is where you say how far you are willing to let it climb.

One value, for everything. There is no per-conversation override and no per-model one: it is a preference about how you like to work, not a property of any one conversation.

**Turning the switch off does not turn off compaction.** It turns off compacting *early*. When a conversation will not fit at all, the harness still recovers on its own — that is its floor, and this plugin can neither raise nor lower it. What the switch decides is whether anything happens before that point.

## What it is not

It does not measure the context window, does not know when a step begins, and does not compact anything. All three belong to the agent loop. This plugin owns one switch and one percentage, and answers them live.

It does not report a compaction that went wrong, either: a failed compaction is shown by the failure card in the chat (host builds from rc.33 on).

## Where it works, and where it does nothing

The card takes the keyed seat the Settings **Plugins** page dispatches once per settings namespace it serves — the same seat the harness's own configurable-plugin cards take. A build whose settings page has no such seat never declares the key, and then this plugin registers no interface at all. Nothing is version-checked: the declaration is the detection.

The host half is unaffected by that. It registers its namespace and publishes its policy wherever it is composed; without a settings provider it simply answers the profile's own values and nothing can change them.

## The service it publishes

Under the Cordis service key `compactionPolicy`:

| Method | Answer |
| --- | --- |
| `isEnabled()` | Whether pressure-triggered compaction runs at all |
| `thresholdRatio()` | The share of the context window, 0–1, at which the next step compacts first |

Both read the settings document on every call. The agent loop reads `ctx.get('compactionPolicy')` once per step and caches nothing, so a value changed in Settings governs the very next step.

## Settings namespace

`auto-compact`, with two fields:

| Field | Type | Default |
| --- | --- | --- |
| `enabled` | boolean | `true` |
| `thresholdPercent` | whole number, 20–95 | `60` |

A section outside those bounds is refused, at the write that produced it.

## One trap

The share you set is a request, not the last word. Compaction keeps a tail of the conversation verbatim, and how long that tail is comes from the compaction plugin's own composition config — `retainRatio`, `retainTokens`, and the per-model `modelPolicies` of `@deepseek-ai/dsh-compaction-basic`. A deployment that raises those far enough can put the tail above the share you chose: 20% of the window, with a tail that will not fit under it, is a ratio the engine cannot honour.

When that happens the engine warns once and triggers on the ratio in that config instead — and **the card does not show it**. The slider still reads what you set, because what you set is still what the settings document holds. The shipped configuration never reaches this; it takes a profile that deliberately raised the retained tail.

## Configuration

Both fields of `cordis.patch.yml` are the composition layer — what someone who has never opened Settings gets. Moving the switch or the slider writes a user layer over them.

```yaml
- insert:
    - id: auto-compact
      name: '@haoran/dsh-auto-compact'
      config:
        enabled: true
        thresholdPercent: 60
```

## Install

```sh
dsh plugin --profile <name> add <path-or-tarball>
```
