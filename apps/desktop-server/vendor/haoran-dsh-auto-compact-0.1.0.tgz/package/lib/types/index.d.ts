/**
 * Compact the conversation before it runs out of room, at a point the person
 * using it chose.
 *
 * A long conversation eventually reaches the end of the model's context
 * window. What happens there is not a matter of taste — the work stops — so
 * the harness already recovers from an overflow. This plugin is about the
 * moment *before* that: at what share of the window the next step should make
 * room for itself first, and whether it should do so at all.
 *
 * That is a preference, and it belongs to the person, not to the profile.
 * Someone who wants every last token of history before anything is summarised
 * sets it high; someone who would rather never see a step interrupted sets it
 * low; someone who wants to decide each time switches it off. So this plugin
 * owns exactly two things — a switch and a percentage — and publishes them as
 * the `compactionPolicy` service the agent loop consults.
 *
 * It decides nothing else. It does not measure the window, does not know when
 * a step begins, and does not compact anything. Switching it off does not
 * disable overflow recovery: that is the harness's own floor and this plugin
 * cannot raise or lower it.
 *
 * @module @haoran/dsh-auto-compact
 */
import type { Context } from '@deepseek-ai/cordis';
import { type Config } from './config.ts';
export { Config, resolveAutoCompactConfig } from './config.ts';
export { createCompactionPolicy } from './policy.ts';
export type { CompactionPolicy } from './policy.ts';
export { AUTO_COMPACT_SETTINGS_NAMESPACE, DEFAULT_ENABLED, DEFAULT_THRESHOLD_PERCENT, THRESHOLD_MAX_PERCENT, THRESHOLD_MIN_PERCENT, THRESHOLD_STEP_PERCENT, } from './section.ts';
export type { AutoCompactSettings } from './section.ts';
export { autoCompactSettingsSchema, installAutoCompactSettings } from './settings.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "auto-compact";
/**
 * Mount the automatic-compaction policy.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map