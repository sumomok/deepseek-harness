/**
 * The `compactionPolicy` service: the two answers the agent loop asks for
 * before it starts a step.
 *
 * The seam is deliberately this small. This plugin owns no idea of what a
 * context window holds, when a step begins, or what compaction does — it owns
 * one switch and one percentage a person set, and answers them live. The
 * engine owns the measurement, the comparison, and the compaction itself.
 *
 * **Both methods read through to the settings source on every call.** The
 * engine reads `ctx.get('compactionPolicy')` once per pre-step and caches
 * nothing, so a value changed in Settings governs the very next step; a policy
 * that snapshotted its settings at mount would keep compacting on the old
 * percentage until a restart.
 *
 * @module @haoran/dsh-auto-compact/policy
 */
import type { AutoCompactSettings } from './section.ts';
/** Live automatic-compaction policy a host-plane plugin provides from user settings. */
export interface CompactionPolicy {
    /**
     * Whether pressure-triggered compaction runs at all; overflow recovery is unaffected.
     * @returns true while the pressure path may run, false to suspend it.
     */
    isEnabled(): boolean;
    /**
     * Share of the model's context window (0–1) at which the next step compacts first.
     * @returns the live threshold ratio; a value outside (0, 1], or one the retained tail
     *   would not clear, is refused and the configured ratio governs instead.
     */
    thresholdRatio(): number;
}
/**
 * The service key, declared here because this package is the only one that
 * can: the agent loop that reads it at runtime lives in the harness checkout,
 * and this plugin builds against the published packages, which do not carry
 * the declaration. Retire this block if a published `@deepseek-ai/dsh-*` ever
 * declares the key itself — two augmentations of one interface member must
 * agree exactly, and the other one would then be the authority.
 */
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Automatic-compaction policy, provided by `@haoran/dsh-auto-compact`. */
        compactionPolicy: CompactionPolicy;
    }
}
/**
 * Build the policy over a settings source.
 * @param source - thunk returning the section in force right now; the settings
 * scope while one is attached, the composition entry otherwise.
 * @returns the policy to provide under `compactionPolicy`.
 */
export declare function createCompactionPolicy(source: () => AutoCompactSettings): CompactionPolicy;
//# sourceMappingURL=policy.d.ts.map