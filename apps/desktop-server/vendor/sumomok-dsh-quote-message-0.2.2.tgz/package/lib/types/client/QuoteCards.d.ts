import type { ReactNode } from 'react';
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import { type QuoteBlockLines } from '../core/split-quotes.ts';
import type { QuoteKey } from './locales.ts';
/**
 * Render one message's quote blocks above its bubble.
 * @param props - the blocks, the header lines to drop from them, and translate.
 * @returns the quote column, or null when nothing survives the heading strip.
 */
export declare function QuoteCards({ quotes, headings, t }: {
    readonly quotes: readonly QuoteBlockLines[];
    readonly headings: readonly string[];
    readonly t: Translate<QuoteKey>;
}): ReactNode;
//# sourceMappingURL=QuoteCards.d.ts.map