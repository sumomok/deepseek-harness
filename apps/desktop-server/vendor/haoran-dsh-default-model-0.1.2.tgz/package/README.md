# @haoran/dsh-default-model

The deployment's factory default model. It ships with the desktop app, so a fresh installation opens its first session on `deepseek-v4-flash-vision-exp` and shows that model in the picker as `default`.

## What it changes

Two id-targeted overrides on top of whatever `@deepseek-ai/dsh-base` composed, and nothing else — no plugin is inserted, no runtime code is loaded.

| Entry | Change |
| --- | --- |
| `agent-default-model` | `provider: deepseek-official`, `model: deepseek-v4-flash-vision-exp` — the selection every Agent created without an explicit model starts from. |
| `llm-deepseek` | The advisory `models` catalog, with the vision row relabelled `default` and given a description. The other two factory rows are restated unchanged. |

The rename is a picker label, not an identity: `id` stays `deepseek-v4-flash-vision-exp` and that is what goes on the wire. The same popup lists a reasoning-effort level also labelled `Default`, and the picker trigger spells the selection `<model> · <effort>`, so a session on this row reads `default · Default`. `inputModalities: [text, image]` is restated for the same row because catalog rows default to `['text']`, and a vision model listed as text-only refuses image input.

## A patch-only bundle

This package has no `src/`, no `lib/`, and no entry point. That works because the harness never imports a bundle: `loadProfile` reads the bundle package's `package.json`, takes the path in `dsh.bundle.patch`, and parses that YAML file (`packages/boot/app-boot/src/profile.ts`). Resolution goes through a `package.json`-existence probe rather than `require.resolve`, so the package does not even need to export an entry. `dsh plugin add` decides a dependency is a layer by the same `dsh.bundle.patch` declaration, so a patch-only package installs and activates like any other.

The `pnpm run build` step in this workspace therefore produces nothing for this package, by design.

## Precedence

Layers, weakest first:

1. **The plugin's own schema defaults** — `deepseek-v4-flash` as the default model, the three-row factory catalog.
2. **Bundle patch layers**, in `dsh.profile.bundles` order — `@deepseek-ai/dsh-base` first, then this package. Both of the entries above are settled here.
3. **The profile's own `cordis.patch.yml`** (`$DSH_HOME/profiles/<name>/cordis.patch.yml`), applied after every bundle layer. A machine-local override belongs here.
4. **`$DSH_HOME/settings.yaml`** — the user's document, read live. Its `agent-default-model:` section is exactly what the web UI writes when someone picks a model, and from that moment this package's default no longer applies to that user. That is the intended behaviour: a factory default is what you get before you have chosen, not a choice imposed over yours.

Layers 2 and 3 are patch layers and layer 4 is a settings document; they compose differently, and the difference matters when you edit either one.

## An id-targeted patch replaces the whole `config`

`applyEntryPatches` (`vendor/include/src/index.ts` in the harness checkout) matches a patch to an entry by `id` and then assigns each of the patch's top-level keys onto that entry. `config` is one such key, so the patch's config object **replaces** the entry's config; there is no per-field merge, and any key the earlier layer set and this one omits falls back to the plugin's schema default.

Both blocks in `cordis.patch.yml` are complete values for that reason. It costs nothing here — `dsh-base` gives `llm-deepseek` no config at all, and gives `agent-default-model` the same two keys this package sets — but it is the rule any later layer has to follow too. A profile `cordis.patch.yml` that overrides `llm-deepseek` to set an `apiKeyEnv` and says nothing about `models` restores the factory catalog, including the `DeepSeek-V4-Flash-Vision-Exp` label.

Settings sections do not work this way: `$DSH_HOME/settings.yaml` deep-merges over the composition entry key by key. An `agent-default-model:` section that names only `model` keeps `provider` from this layer. Arrays are replaced whole, so an `llm-deepseek:` settings section carrying its own `models` array replaces this catalog.

## Keeping the catalog in sync

`models` is a whole-table replacement of the adapter's factory catalog — `resolveModels` reads `config.models ?? DEFAULT_MODELS` and never merges the two. When upstream adds a model to `@deepseek-ai/dsh-llm-deepseek`, it will not appear in the picker until it is added to this table as well. The current table mirrors the factory catalog of `@deepseek-ai/dsh-llm-deepseek@0.1.1-rc.2`.

Two static checks hold the table to that catalog. `tests/patch.spec.ts` reads the installed `@deepseek-ai/dsh-llm-deepseek` catalog out of its own `Config` schema and compares it row by row against this table, so an upstream row that is added, dropped, relabelled, or given a field this table does not carry fails here rather than disappearing from the picker. The same file reads `@deepseek-ai/dsh-base`'s `cordis.patch.yml` and asserts both patched ids still exist in it: an id-targeted patch whose target is gone applies to nothing and warns nowhere, so a rename upstream has to fail a test to be visible at all. Both checks are only as current as the `@deepseek-ai/dsh-base` and `@deepseek-ai/dsh-llm-deepseek` devDependencies, which are declared at the version the deployment ships and resolved by the lockfile.

Three fields are deliberately not restated. `contextWindow` falls back to the adapter's `defaultContextWindow`, and the vision row's `imagePixelBudget` and `imageMaxBytes` fall back to `DEFAULT_REQUEST_IMAGE_PIXEL_BUDGET` and `DEFAULT_REQUEST_IMAGE_MAX_BYTES`; each fallback is the same value the factory row carries, and inheriting keeps this table from pinning numbers upstream may move. The drift test compares each inherited value against the factory row, so an upstream row that stops matching its adapter default fails there rather than reaching the picker with a different capacity.

The web Models page does report the per-row context window: each row's advanced disclosure carries a `Context window` field. With nothing restated here it renders empty, showing the inherited `defaultContextWindow` as its placeholder.

## Install

Shipped with the desktop app: the tarball is vendored into the embedded server closure and the package name is seeded into the web profile's `dsh.profile.bundles` on first launch. Installing it by hand into any other profile is the ordinary path:

```sh
cd packages/default-model && pnpm pack --pack-destination ../../dist
dsh plugin --profile <name> add ../../dist/haoran-dsh-default-model-0.1.2.tgz
```

Order matters: this layer must come after `@deepseek-ai/dsh-base` in `dsh.profile.bundles`, which is where an appended layer lands.

To confirm what a profile actually composes, without booting it:

```sh
dsh --profile <name> --dump-config
```
