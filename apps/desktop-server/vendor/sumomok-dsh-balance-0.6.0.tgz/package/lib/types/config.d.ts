/**
 * Plugin configuration. Every field is changeable from `cordis.yml` and
 * validated at load; nothing here is a constant compiled into the code.
 *
 * Four fields are volatile — `prices`, `lowBalance`, `criticalBalance`, and
 * `maskBalance`, the ones the settings page edits. The page and the one-time
 * import of the removed `settings.yaml` write them into this entry's profile
 * row, and the running plugin takes them without a reload. Every other field
 * is ordinary: changing it reloads the plugin.
 *
 * The per-field schema settles types, ranges, and defaults. The rules a
 * per-field schema cannot state — a schedule declaring exactly one of `rates`
 * and `multiplier`, an `HH:MM` window, a timezone this runtime knows — are
 * enforced in the resolve steps below. {@link resolveBalanceConfig} throws at
 * load for an ordinary field; {@link resolveLiveSettings} never throws, so a
 * bad price table written into the profile keeps the plugin, and its settings
 * page, running on the last good one.
 *
 * @module @sumomok/dsh-balance/config
 */
import type { Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type GenericEndpointShape } from './generic-adapter.ts';
import { type PriceTable } from './prices.ts';
import type { BALANCE_SETTINGS_KEYS } from './settings-shape.ts';
/** Which surfaces the browser half puts up. */
export interface Surfaces {
    /** The balance and spend chip beside Settings at the sidebar foot. */
    footer?: boolean;
    /** The per-session spend line under the composer. */
    sessionSpend?: boolean;
}
/** Plugin configuration. */
export interface Config {
    /** How long a successful balance read is served before a refresh is attempted. */
    refreshMs?: number;
    /** How long a failed balance read suppresses further attempts, so a broken endpoint is not hammered per open tab. */
    retryMs?: number;
    /** Wall-clock budget for one balance request. */
    timeoutMs?: number;
    /**
     * Currency codes in descending preference. One list serves two decisions:
     * which balance row to show when the account holds several, and which price
     * list to spend against before the account's own currency is known.
     */
    currency?: string[];
    /** Balance below which the chip is tinted as a warning. Live. */
    lowBalance: Volatile<number>;
    /**
     * Balance below which the chip is tinted as critical. Live. Critical is
     * judged first, so a value above {@link Config.lowBalance} leaves no
     * warning band rather than being refused.
     */
    criticalBalance: Volatile<number>;
    /**
     * Show the footer chip's figure as dots rather than the amount. The popover
     * still carries the real numbers, so the amount is one hover away; this
     * keeps it off a screen being shared or recorded. Live.
     */
    maskBalance: Volatile<boolean>;
    /** Days of ledger rows to keep; older rows are dropped and the file rewritten at startup. */
    ledgerDays?: number;
    /**
     * IANA timezone the day and month spend boundaries are taken in. Empty means
     * the timezone the host process runs in.
     */
    timezone?: string;
    /**
     * Directory this plugin writes its ledger into. Empty means
     * `$DSH_HOME/dsh-balance`.
     */
    root?: string;
    /** Which surfaces the browser half puts up. */
    surfaces?: Surfaces;
    /**
     * The price lists spend is computed from, one per currency the provider
     * bills in. Replacing it re-prices every session; the shipped default
     * carries DeepSeek's published CNY and USD rates and the date they were
     * read. A deployment may add any currency its provider bills in. Live.
     */
    prices: Volatile<PriceTable>;
    /**
     * Candidate endpoint shapes the generic fallback adapter tries, in order,
     * for a provider with no dedicated adapter (any provider but DeepSeek). The
     * shipped default names the one-api/new-api user-quota convention and the
     * legacy OpenAI dashboard billing pair; a deployment whose gateway answers
     * neither can name its own instead.
     */
    genericEndpoints?: GenericEndpointShape[];
}
/** One of the four volatile fields, which the settings page edits. */
export type LiveField = typeof BALANCE_SETTINGS_KEYS[number];
/** The ordinary fields, which change only by reloading the plugin. */
export type OrdinaryConfig = Omit<Config, LiveField>;
/** The schema; typed by inference, because the four volatile fields take plain values as input. */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    refreshMs: z<number, number, "defined">;
    retryMs: z<number, number, "defined">;
    timeoutMs: z<number, number, "defined">;
    currency: z<string[], string[], "defined">;
    lowBalance: z<number, number, "volatile-defined">;
    criticalBalance: z<number, number, "volatile-defined">;
    maskBalance: z<boolean, boolean, "volatile-defined">;
    ledgerDays: z<number, number, "defined">;
    timezone: z<string, string, "defined">;
    root: z<string, string, "defined">;
    surfaces: z<Schemastery.ObjectS<NoInfer<{
        footer: z<boolean, boolean, "defined">;
        sessionSpend: z<boolean, boolean, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        footer: z<boolean, boolean, "defined">;
        sessionSpend: z<boolean, boolean, "defined">;
    }>>, "defined">;
    prices: z<NoInfer<PriceTable>, NoInfer<PriceTable>, "volatile-defined">;
    genericEndpoints: z<GenericEndpointShape[], GenericEndpointShape[], "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    refreshMs: z<number, number, "defined">;
    retryMs: z<number, number, "defined">;
    timeoutMs: z<number, number, "defined">;
    currency: z<string[], string[], "defined">;
    lowBalance: z<number, number, "volatile-defined">;
    criticalBalance: z<number, number, "volatile-defined">;
    maskBalance: z<boolean, boolean, "volatile-defined">;
    ledgerDays: z<number, number, "defined">;
    timezone: z<string, string, "defined">;
    root: z<string, string, "defined">;
    surfaces: z<Schemastery.ObjectS<NoInfer<{
        footer: z<boolean, boolean, "defined">;
        sessionSpend: z<boolean, boolean, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        footer: z<boolean, boolean, "defined">;
        sessionSpend: z<boolean, boolean, "defined">;
    }>>, "defined">;
    prices: z<NoInfer<PriceTable>, NoInfer<PriceTable>, "volatile-defined">;
    genericEndpoints: z<GenericEndpointShape[], GenericEndpointShape[], "defined">;
}>>, "plain">;
/** The ordinary fields after defaults and cross-field checks, with nothing left optional. */
export interface ResolvedConfig {
    refreshMs: number;
    retryMs: number;
    timeoutMs: number;
    currency: readonly string[];
    ledgerDays: number;
    /** The settled timezone; never empty. */
    timezone: string;
    /** The settled ledger directory; never empty. */
    root: string;
    footer: boolean;
    sessionSpend: boolean;
    /** Candidate endpoint shapes the generic fallback adapter tries, in order. */
    genericEndpoints: readonly GenericEndpointShape[];
}
/** The four live fields, settled. */
export interface ResolvedLiveSettings {
    /** The price table spend is computed from; always one that passed {@link resolvePriceTable}. */
    prices: PriceTable;
    lowBalance: number;
    criticalBalance: number;
    maskBalance: boolean;
}
/**
 * Settle the ordinary fields and reject a configuration this plugin cannot
 * honour. The live fields are {@link resolveLiveSettings}'s.
 * @param config - the schema-validated plugin config.
 * @param homePath - resolves a path under the harness home, for the ledger default.
 * @returns the resolved configuration.
 * @throws {Error} naming the first unusable field.
 */
export declare function resolveBalanceConfig(config: OrdinaryConfig, homePath: (...segments: string[]) => string): ResolvedConfig;
/**
 * Read the four live fields once and settle them, without throwing.
 *
 * A price table that fails {@link resolvePriceTable} is reported and the
 * previous table is kept, so the plugin stays active and its settings page
 * stays up for the fix; nothing on the host can refuse such a table before it
 * is written, and a load-time throw would take the page down with the plugin.
 * The other three fields are fully settled by the schema.
 * @param config - the plugin config holding the four live references.
 * @param previousPrices - the table to keep when the live one is unusable: the
 *   last settled table, or the shipped `DEFAULT_PRICES` at load.
 * @param report - receives the price table's rejection.
 * @returns the settled live fields.
 */
export declare function resolveLiveSettings(config: Pick<Config, LiveField>, previousPrices: PriceTable, report: (error: unknown) => void): ResolvedLiveSettings;
//# sourceMappingURL=config.d.ts.map