/**
 * Small settings-reading helpers shared by every adapter that resolves a
 * provider's connection facts from another plugin's untyped settings.
 *
 * @module @sumomok/dsh-balance/settings-util
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * The live settings of another plugin's profile entry: the entry's volatile
 * fields as `ctx.settings.describe()` lists them, unredacted.
 *
 * `describe()` reads the profile directory synchronously and lists every
 * configurable entry, so an adapter calls this once per balance read rather
 * than per field.
 * @param ctx - the plugin context.
 * @param entryId - the profile entry id (a configurable provider's `settingsNs`).
 * @returns the entry's volatile values, or `undefined` without a settings
 *   service, without an id, or while that entry is not listed (not active, or
 *   carrying no volatile field).
 */
export declare function entryValue(ctx: Context, entryId: string | undefined): unknown;
/** Read one optional string from an untyped settings section. */
export declare function optionalString(value: unknown): string | undefined;
/**
 * Walk a settings section down to one provider's profile object.
 * @param section - the entry's live values ({@link entryValue}), or `undefined` while unlisted.
 * @param path - path from the section root to the profile; empty means the whole section.
 * @returns the profile object, or `undefined` when the path does not resolve to one.
 */
export declare function profileAtPath(section: unknown, path: readonly string[]): Record<string, unknown> | undefined;
/**
 * Derive the conventional credential reference for a provider route, matching
 * the Models settings page's own derivation exactly (`ui-settings-models`):
 * a typed key with no explicit `apiKeyEnv` stores under this reference, so a
 * profile naming none must resolve to the same name here.
 * @param provider - provider route id (e.g. `anthropic`, `minimax-cn`).
 * @returns the derived reference name (e.g. `MINIMAX_CN_API_KEY`).
 */
export declare function deriveKeyRef(provider: string): string;
//# sourceMappingURL=settings-util.d.ts.map