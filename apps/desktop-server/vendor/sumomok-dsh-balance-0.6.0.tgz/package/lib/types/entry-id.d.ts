/**
 * This plugin's profile entry id, shared by the host half and the browser
 * half.
 *
 * Three names must be the same string: the id of this package's bundle row
 * (`cordis.patch.yml`), the name of this plugin's section in the removed
 * `settings.yaml` (the one-time import writes a section into the entry whose id
 * is the section name), and the id the settings page hands
 * `configForms.get()`. A profile that mounts this plugin under another id keeps
 * working on the host, but the page and the import no longer reach it.
 *
 * @module @sumomok/dsh-balance/entry-id
 */
/** The entry id, matching this plugin's own cordis short name. */
export declare const BALANCE_ENTRY_ID = "balance";
//# sourceMappingURL=entry-id.d.ts.map