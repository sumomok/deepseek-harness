/**
 * Account balance and spend for the DeepSeek Harness web GUI.
 *
 * The question this answers is the one nothing in the harness answers today:
 * *how much is left, and how much has this cost*. The balance comes from one
 * provider's own account endpoint — DeepSeek by default, or whichever
 * provider the current session's selected model belongs to, or whichever
 * provider the browser's provider picker names — read through the adapter
 * registry (`adapters.ts`): a named DeepSeek adapter, and a generic
 * best-effort fallback for any other provider `ctx.llm`'s own
 * configurable-provider directory can address. The spend ledger is
 * unaffected by which provider is shown: it stays one installation-wide
 * account, priced from the one deployment-owned price table, from usage the
 * harness already logs. No pricing page is scraped at runtime, and no number
 * is invented — a model the table does not price is reported as unpriced
 * tokens rather than as zero.
 *
 * What this plugin touches:
 *
 * - The credential seam, once per balance read, for the queried provider's API
 *   key. The key is never cached, never logged, never returned, and never put
 *   in a URL.
 * - The queried provider's own configured origin, and nothing else on the
 *   network; a same-origin fence rejects anything a resolved endpoint's own
 *   arithmetic would otherwise move off it.
 * - Its own directory under the harness home, for a numbers-only spend ledger.
 * - The session-event feed, read-only. It appends no session event of its own.
 *
 * It registers no HTTP route. The browser half reaches it only through the
 * harness's `/api` Typert gateway, and every exported method is a read.
 *
 * @module @sumomok/dsh-balance
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session';
import { type Config } from './config.ts';
import { type LedgerRow } from './ledger.ts';
import { type PriceEntry, type PriceTable } from './prices.ts';
import type { BalanceView } from './types.ts';
export { AdapterRegistry, pickableProviderRoster, providerRoster } from './adapters.ts';
export { balanceEndpoint, BalanceReader, parseAmount, parseBalanceResponse, readBalance, selectBalance } from './balance.ts';
export type { BalanceReaderOptions, BalanceRequest } from './balance.ts';
export { Config, resolveBalanceConfig, resolveLiveSettings } from './config.ts';
export type { LiveField, OrdinaryConfig, ResolvedConfig, ResolvedLiveSettings, Surfaces } from './config.ts';
export { BALANCE_ENTRY_ID } from './entry-id.ts';
export { customProviderResolver, findConfigurableEntry } from './custom-provider.ts';
export { providerResolver } from './deepseek-adapter.ts';
export { DEFAULT_PRICES } from './default-prices.ts';
export { createGenericPerform, DEFAULT_GENERIC_ENDPOINTS } from './generic-adapter.ts';
export type { GenericBalanceRequest, GenericEndpointShape, OneApiQuotaShape, OpenAiBillingShape } from './generic-adapter.ts';
export { dayKey, hostTimezone, Ledger, LEDGER_DIR, LEDGER_FILE, LEDGER_MODE, ledgerPath, parseLedgerRow } from './ledger.ts';
export type { LedgerOptions, LedgerRow } from './ledger.ts';
export { MOONSHOTAI_CN_PROVIDER_ID, MOONSHOTAI_CN_ROUTE, MOONSHOTAI_PROVIDER_ID, MOONSHOTAI_ROUTE, moonshotProviderResolver, } from './moonshot-adapter.ts';
export type { MoonshotRoute } from './moonshot-adapter.ts';
export { moonshotBalanceEndpoint, parseMoonshotBalanceResponse, readMoonshotBalance } from './moonshot-balance.ts';
export type { MoonshotBalanceRequest } from './moonshot-balance.ts';
export { compactPriceTable, costOf, DEFAULT_BASE_SCHEDULE_NAME, isSupportedTimezone, isWallClockTime, pricesFor, resolvePriceTable, resolveRates, selectPriceCurrency, wallClockAt, windowContains, } from './prices.ts';
export type { CurrencyPrices, DeepReadonly, PriceEntry, PriceRates, PriceSchedule, PriceSubject, PriceTable, PriceWindow, ReadonlyPriceTable, ResolvedPrice, ResolvedRates, TokenCounts, } from './prices.ts';
export { DEEPSEEK_ACCOUNT_PROVIDER_ID, DEEPSEEK_DISPLAY_NAME, DEEPSEEK_PROVIDER_ID, EXCLUDED_PROVIDER_IDS } from './provider-id.ts';
export type { BalanceSettings } from './settings-shape.ts';
export { BALANCE_SETTINGS_KEYS } from './settings-shape.ts';
export { AccountBalanceService } from './service.ts';
export { billingBuckets, priceStep, priceTableVersion, SESSION_SPEND_KEY, sessionSpendProjection, totalTokens, } from './session-spend.ts';
export type { PricedStep, SessionSpendState } from './session-spend.ts';
export { deriveKeyRef, entryValue, optionalString, profileAtPath } from './settings-util.ts';
export type { BalanceUiConfig, BalanceUnavailableReason, BalanceView, ProviderOption, SessionSpend, SessionSpendModel, SpendTotals, SpendView, } from './types.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "balance";
/**
 * Which currency's price list spend is computed against.
 *
 * The account's own billing currency decides it once a balance read reveals
 * one, because a CNY balance beside a USD spend total is two numbers nobody
 * can compare. Until then — and for an account whose currency the table does
 * not price — the configured preference decides. A change of currency, or
 * of the active currency's rows, re-prices everything, so listeners
 * re-register what they derived from the old list.
 */
export declare class ActivePrices {
    private table;
    private preference;
    private readonly listeners;
    private code;
    /**
     * @param table - the resolved price table.
     * @param preference - configured currency preference, most wanted first.
     */
    constructor(table: PriceTable, preference: readonly string[]);
    /** The active ISO 4217 code. */
    get currency(): string;
    /** The active currency's price list. */
    get entries(): readonly PriceEntry[];
    /**
     * Adopt the account's own billing currency when a balance read reveals it.
     * @param view - the balance read; anything but a successful one is ignored.
     */
    observe(view: BalanceView): void;
    /**
     * Subscribe to changes of the active price list: a currency switch, or a
     * live edit that changed the active currency's rows.
     * @param listener - receives the active ISO 4217 code.
     * @returns the unsubscriber.
     */
    onChange(listener: (currency: string) => void): () => void;
    /**
     * Replace the price table and currency preference a live settings edit
     * supplies fresh. Prefers to keep serving whichever currency is already
     * active — the same priority {@link observe} gives an account's own billing
     * currency — so editing, say, a USD entry's rates does not reset an account
     * already settled on CNY back to the preference list's first choice.
     * Listeners hear it when the active list's contents changed, compared by
     * {@link priceTableVersion}, so an edit that leaves them as they were (a
     * threshold, another currency's rows) re-prices nothing.
     * @param table - the freshly resolved price table.
     * @param preference - the freshly resolved currency preference.
     */
    update(table: PriceTable, preference: readonly string[]): void;
}
/**
 * Turn one logged assistant step into a ledger row.
 * @param active - the active currency selection, supplying the price list the
 * row is written in; a row records the currency it was priced in so a later
 * switch cannot fold it into another currency's total.
 * @param session - the session the step belonged to.
 * @param event - the `assistant/message` event carrying the step's usage.
 * @returns the row, or `null` when the step reported no usage.
 */
export declare function ledgerRowOf(active: ActivePrices, session: Pick<Session, 'id'>, event: SessionEvent): LedgerRow | null;
/**
 * Mount the balance and spend capability.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map