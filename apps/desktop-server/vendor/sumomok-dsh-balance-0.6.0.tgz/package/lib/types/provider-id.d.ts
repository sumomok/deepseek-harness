/**
 * The provider ids this plugin hardcodes: the routes its own named adapters
 * serve, shared between the host half (the adapter registry) and the browser
 * half (the followed-provider fallback and the top-up link table). Each is
 * fixed by the provider plugin that registers the route, not by configuration.
 *
 * Every other provider id is data — read from `ctx.llm`'s directory or from a
 * session's own model selection, never compiled in here.
 *
 * This module holds no imports on purpose: the browser half loads it, so
 * anything host-only reached from here would be inlined into the client
 * bundle.
 *
 * @module @sumomok/dsh-balance/provider-id
 */
/** The provider route `@deepseek-ai/dsh-llm-deepseek-api-key` registers (API-key billing). */
export declare const DEEPSEEK_PROVIDER_ID = "deepseek-official";
/**
 * The provider route `@deepseek-ai/dsh-llm-deepseek-account` registers: DeepSeek
 * reached with a signed-in account's token rather than an API key. The
 * balance endpoint this plugin reads takes an API key, so this route has no
 * balance here; see {@link EXCLUDED_PROVIDER_IDS}.
 */
export declare const DEEPSEEK_ACCOUNT_PROVIDER_ID = "deepseek-account";
/**
 * Provider routes this plugin never reads a balance for, whatever the
 * directory says: the account-token DeepSeek route has no API key, and the
 * generic resolver would otherwise try a key name derived from its id. The
 * picker leaves them out, the followed session never resolves to one, and a
 * read naming one answers `unconfigured` without a request.
 */
export declare const EXCLUDED_PROVIDER_IDS: ReadonlySet<string>;
/** Display name shown for {@link DEEPSEEK_PROVIDER_ID} when no directory entry names one. */
export declare const DEEPSEEK_DISPLAY_NAME = "DeepSeek";
/** Provider route id pi-ai registers for Moonshot AI's international route. */
export declare const MOONSHOTAI_PROVIDER_ID = "moonshotai";
/** Provider route id pi-ai registers for Moonshot AI's China route. */
export declare const MOONSHOTAI_CN_PROVIDER_ID = "moonshotai-cn";
/** Provider route id pi-ai registers for Kimi For Coding. */
export declare const KIMI_CODING_PROVIDER_ID = "kimi-coding";
//# sourceMappingURL=provider-id.d.ts.map