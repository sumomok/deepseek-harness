/**
 * Render guard for slot entries.
 *
 * A `list`-slot entry that throws during render abdicates its cell until the
 * page reloads, and it takes the surrounding column's render with it on the
 * way out. Balance is an ambient readout: if it cannot render, the correct
 * outcome is that it is not there, not that the sidebar is not there.
 *
 * @module @sumomok/dsh-balance/client/Guard
 */
import { Component, type ErrorInfo, type ReactNode } from 'react';
/** What the guard wraps. */
export interface GuardProps {
    /** The guarded subtree. */
    children: ReactNode;
    /**
     * What to render instead once the subtree has thrown. Nothing by default:
     * a seat whose owner cannot tell an empty occupant from a missing one —
     * the pill's leading reading is one — passes the text it would rather show.
     */
    fallback?: ReactNode;
    /** Reports the first failure once, for the browser console. */
    onError?: (error: unknown) => void;
}
interface GuardState {
    failed: boolean;
}
/** Renders nothing once its subtree has thrown. */
export declare class Guard extends Component<GuardProps, GuardState> {
    state: GuardState;
    /**
     * Move to the failed state on the next render.
     * @returns the failed state.
     */
    static getDerivedStateFromError(): GuardState;
    /**
     * Report the failure once.
     * @param error - the thrown value.
     * @param info - React's component stack.
     */
    componentDidCatch(error: unknown, info: ErrorInfo): void;
    /**
     * @returns the subtree, or the fallback once it has thrown.
     */
    render(): ReactNode;
}
export {};
//# sourceMappingURL=Guard.d.ts.map