/**
 * The `settings.section` page this plugin contributes: the price table, the
 * low/critical-balance thresholds, and whether the footer chip masks its
 * figure, read and written through this entry's config form
 * (`ctx.configForms.get('balance')`, `@deepseek-ai/dsh-client-ui-settings`).
 * These four are the plugin's volatile Config fields, so a save lands in the
 * profile row and the running host takes it without a reload.
 *
 * A saved masking switch is pushed onto the chip by this page, through the
 * injected `refresh`: the chip renders the flag the last spend read carried,
 * not this form, so nothing else would move it before the next
 * poll tick. The thresholds and the price table reach the chip on that tick
 * instead — they change a tint and an arithmetic result, not what is on a
 * screen someone is about to share.
 *
 * Adding a currency, and editing a model's time-of-day tiers, are not
 * exposed here — only an existing currency's per-model base rates are
 * editable as rows, add/remove included. A row's own schedules and timezone
 * (when it already has them) are carried through unedited on save, never
 * dropped, and summarized as read-only text: the plugin configuration
 * (`cordis.yml`, or a direct edit of the profile row) is still where a tier
 * itself is authored.
 *
 * A price table is checked here, with the host's own rules, before it is
 * written: the host takes any table the schema accepts and, when its rules
 * reject one, keeps pricing with the previous table and only logs why.
 *
 * @module @sumomok/dsh-balance/client/PriceTableSection
 */
import { type ReactNode } from 'react';
import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import { type PriceEntry, type PriceTable } from '../prices.ts';
import type { BalanceSettings } from '../settings-shape.ts';
import type { BalanceKey } from './locales.ts';
/** Props the section reads from its composed slot props. */
export interface PriceTableSectionProps {
    /** Close the settings panel; unused here — this page has no flow that leaves settings. */
    close: () => void;
    /** The config form over this plugin's own profile entry. */
    form: ConfigForm<BalanceSettings>;
    /** The framework-injected translate seat for this plugin's namespace. */
    t: TranslateNS<'balance'>;
    /**
     * Read the followed provider's balance and spend again. The masking switch
     * calls it with `force` after its own save so the chip stops showing the
     * amount without waiting for a poll tick: the flag rides on the spend read,
     * which the host answers straight off the ledger with no cache window, and
     * `force` is what keeps this read from being joined to an ordinary refresh
     * already in flight (`client/store.ts`). Its cost is the balance read
     * alongside it, which then bypasses the host's refresh window — one extra
     * provider call per flip of the switch.
     */
    refresh: (force: boolean) => void;
}
/** One save action's inline status, shown beside its own control. */
type SaveState = 'idle' | 'saving' | 'saved' | 'error';
/** @param state - one save action's status. @returns its copy key, or `undefined` while idle. */
export declare function saveStatusKey(state: SaveState): BalanceKey | undefined;
/** One price-table row being edited, as plain strings so an empty field stays representable. */
export interface DraftRow {
    model: string;
    provider: string;
    per: string;
    input: string;
    inputCacheHit: string;
    output: string;
    cacheWrite: string;
    reasoning: string;
    /** Carried through unedited; this form draws no control for it. */
    schedules: PriceEntry['schedules'];
    timezone: string;
}
/** @param entry - a price-table entry. @returns its editable draft. */
export declare function draftOf(entry: PriceEntry): DraftRow;
/** @returns a fresh row for "add model", with no schedules and the usual per-1M unit. */
export declare function blankDraft(): DraftRow;
/**
 * @param text - a form field's raw text.
 * @param fallback - value when the text is empty or not a number.
 * @returns the parsed number.
 */
export declare function numberOr(text: string, fallback: number): number;
/** @param draft - one edited row. @returns the {@link PriceEntry} it saves as. */
export declare function entryOf(draft: DraftRow): PriceEntry;
/** Why the page refuses to write a price table, in the words it shows. */
export type PriceProblem = {
    kind: 'model';
} | {
    kind: 'duplicate' | 'per' | 'negative';
    model: string;
} | {
    kind: 'other';
    detail: string;
};
/**
 * Check a price table the page is about to write. The rows this page lets a
 * person get wrong are named first, one per row in order; anything else is
 * left to the host's own resolve step and reported as `other`, whose `detail`
 * is the host's message for the browser console only.
 * @param entries - the edited currency's rows.
 * @param table - the whole table those rows will be written into.
 * @returns the first problem, or undefined when the table resolves.
 */
export declare function priceProblemOf(entries: readonly PriceEntry[], table: PriceTable): PriceProblem | undefined;
/**
 * The registered `settings.section` component.
 * @param props - composed slot props.
 * @returns the page, or a loading/unavailable placeholder before the first accepted section.
 */
export declare function PriceTableSection({ form, t, refresh }: PriceTableSectionProps): ReactNode;
export {};
//# sourceMappingURL=PriceTableSection.d.ts.map