/**
 * Copy for the card, in the two locales the harness ships.
 *
 * The Chinese is the original and the English is its translation, which is the
 * order this product is written in. No line says "token", "window",
 * "threshold", or "compaction ratio": the person reading it is deciding how
 * full a conversation should get before it is summarised, and every one of
 * those words would ask them to learn how the model is fed first.
 *
 * The percentage line names the usage ring beside the message box on purpose.
 * That ring is the one figure a person has already watched climb, and saying
 * the two are read the same way is what makes the slider mean anything.
 *
 * It says when and how deep, because both are the person's to know. The
 * compaction happens before the next reply and the work in progress carries
 * on, so a pause between two answers is explained rather than mistaken for a
 * stall. Long tool results are cut to their start and end first, then the
 * older part is summarised and the most recent part kept word for word; the
 * line names no size, because the kept part is a share of the model's room
 * that a person has no figure for.
 *
 * One name for one thing: the card's title, this line and `hintOff` all say
 * compact, never a second word for the same act.
 *
 * @module @haoran/dsh-auto-compact/client/locales
 */
/** Locale namespace this plugin owns. */
export declare const NS = "autoCompact";
/** Chinese copy (the dictionary that defines the key domain). */
export declare const zh: {
    title: string;
    switchAria: string;
    hint: string;
    hintOff: string;
    thresholdLabel: string;
    thresholdValue: string;
    readOnly: string;
    failed: string;
};
/** English copy. */
export declare const en: Record<AutoCompactKey, string>;
/** Dictionary key domain. */
export type AutoCompactKey = keyof typeof zh;
/**
 * Substitute `{name}` placeholders in one line of copy.
 * @param text - the dictionary line.
 * @param values - the values to put in, by placeholder name.
 * @returns the filled line; a placeholder with no value is left as written.
 */
export declare function fill(text: string, values: Record<string, string>): string;
//# sourceMappingURL=locales.d.ts.map