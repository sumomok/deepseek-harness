/**
 * What one person's automatic-compaction choice is, and the range it lives in.
 *
 * This module is the one home for those facts and imports nothing, because
 * both halves need them: the host half validates the entry's Config over the
 * range, and the browser half edits the same entry and draws the slider over
 * the same range. A client bundle may not reach the host half (it would pull
 * the schema library into the page), so the shared facts live below both.
 *
 * The bounds are not configuration. Above the ceiling compaction would fire
 * too late to leave room for the step it is making room for. Below the floor
 * the engine can fail to bring a conversation under the share at all: it
 * compares the next request with the share in the provider's own token count,
 * but sizes the verbatim tail it keeps in its four-characters-per-token
 * estimate, and for Chinese text that tail alone can be larger than a low
 * share ([the 0.5.1 Note](../../../.agents/notes/2026-10-02-auto-compact-pruner-and-floor.md)).
 * What a deployment does choose is the pair of values this range is entered
 * at, which are this plugin's `Config` fields.
 *
 * @module @haoran/dsh-auto-compact/section
 */
/**
 * This plugin's profile entry id. Three things must equal it: the `id` of the
 * bundle row in `cordis.patch.yml`, the entry the browser half's settings form
 * edits, and the section name rc.33 and earlier wrote into `settings.yaml`,
 * which the harness's one-time import uses as the entry id.
 */
export declare const AUTO_COMPACT_ENTRY_ID = "auto-compact";
/** One person's automatic-compaction choice. */
export interface AutoCompactSettings {
    /** Whether compaction runs on context pressure at all. */
    enabled: boolean;
    /** Share of the context window, in percent, that triggers it. */
    thresholdPercent: number;
}
/** Lowest share the slider offers, and the lowest one compaction runs at. */
export declare const THRESHOLD_MIN_PERCENT = 40;
/**
 * Lowest share an entry may store: the slider's floor before 0.5.1. An entry
 * saved below {@link THRESHOLD_MIN_PERCENT} still loads and compacts at that
 * floor, because refusing it would fail the whole entry and take the policy
 * down with it.
 */
export declare const THRESHOLD_STORED_MIN_PERCENT = 20;
/** Highest share the slider offers. */
export declare const THRESHOLD_MAX_PERCENT = 95;
/** Distance between two slider positions; the slider's rounding only, not a limit on the stored value. */
export declare const THRESHOLD_STEP_PERCENT = 5;
/** Default for the switch, which the Config schema applies while the entry stores none. */
export declare const DEFAULT_ENABLED = true;
/** Default for the share, which the Config schema applies while the entry stores none. */
export declare const DEFAULT_THRESHOLD_PERCENT = 60;
/**
 * The share compaction runs at for the one an entry stores.
 * @param stored - the stored share, in percent.
 * @returns the stored share, raised to {@link THRESHOLD_MIN_PERCENT}.
 */
export declare function effectiveThresholdPercent(stored: number): number;
//# sourceMappingURL=section.d.ts.map