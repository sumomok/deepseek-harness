/**
 * Compact the conversation before it runs out of room, at a point the person
 * using it chose.
 *
 * A long conversation eventually reaches the end of the model's context
 * window. The harness already recovers from an overflow; this plugin is about
 * the moment before that — at what share of the window the conversation makes
 * room for itself, and whether it does so at all. That is the person's
 * preference, so this plugin owns exactly two things, a switch and a
 * percentage, and it owns when: between two steps of a turn, before the next
 * model request.
 *
 * Two halves make that one behavior. The `compactionPolicy` service answers
 * `isEnabled(): false`, which turns off the harness's own between-steps
 * listener, the one that retries a failed compaction at every step; the step
 * path (`./step-compaction.ts`) compacts at the same moment instead, with a
 * per-agent, per-turn backoff and on the switch and the percentage a person
 * set. The seat answers `false` only while the step path has an engine to
 * compact with, so the two can never come apart into a composition that
 * compacts nowhere.
 *
 * Overflow recovery is untouched by both halves: that is the harness's own
 * floor and this plugin can neither raise nor lower it.
 *
 * @module @haoran/dsh-auto-compact
 */
import type { Context } from '@deepseek-ai/cordis';
import { type Config } from './config.ts';
export { Config, readAutoCompact } from './config.ts';
export { installStepCompaction, LOGGER_NAME } from './step-compaction.ts';
export type { StepCompaction } from './step-compaction.ts';
export { createCompactionPolicy } from './policy.ts';
export type { CompactionPolicy } from './policy.ts';
export { AUTO_COMPACT_ENTRY_ID, DEFAULT_ENABLED, DEFAULT_THRESHOLD_PERCENT, effectiveThresholdPercent, THRESHOLD_MAX_PERCENT, THRESHOLD_MIN_PERCENT, THRESHOLD_STEP_PERCENT, THRESHOLD_STORED_MIN_PERCENT, } from './section.ts';
export type { AutoCompactSettings } from './section.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "auto-compact";
/**
 * Mount the step compaction and the policy seat that clears the way for it.
 *
 * Both are installed together so they cannot come apart: the seat's `false`
 * closes the harness's own between-steps path, and closing it without the step
 * path installed would leave a composition that never compacts. The engine is
 * resolved per agent, because a preset publishes it behind an `isolate` realm
 * no injection can see.
 *
 * The switch and the share are read from the volatile Config on every use, so
 * a change saved in Settings reaches both halves without a remount. A stored
 * share below {@link THRESHOLD_MIN_PERCENT} is read as that floor, and one
 * warning says so each time the entry comes to hold such a share, the first at
 * mount. The settings service is told this plugin draws its own row, so no
 * generated page duplicates it.
 * @param ctx - the plugin context.
 * @param config - the schema-validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map