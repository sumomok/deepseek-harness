/**
 * When the compaction happens: between two steps of a turn, before the next
 * model request, for every agent — delegated ones included.
 *
 * The listener sits on `agent/pre-step`, the waterfall the agent loop runs
 * after the previous step's `step/end` and before the next `step/start`. No
 * model stream and no tool is in flight there, so compacting cancels nothing;
 * the turn continues on the replacement surface. The loop dispatches
 * `agent/pre-step` before each step it proposes, never after a turn's last
 * reply; a step that a later listener rejects, or whose messages are rewritten
 * to none, is not entered after all, and the summary written before it is read
 * by the next request instead.
 *
 * **The engine decides whether to compact.** The listener calls
 * `compactIfNeeded(agent, 'pressure', signal)`, which prices the next request,
 * compares it with the threshold (the live share from `compactionPolicy`,
 * capped by the engine's own headroom term), cuts every tool result over the
 * pruner's budget through the `toolResultPruner` mounted beside it, keeps the
 * retained tail, and summarizes until the conversation is under the threshold
 * or its attempts run out. This module decides only whether to ask: the switch
 * is on, the turn is not cancelled, and the agent has not already failed in
 * this turn.
 *
 * **Backoff is per agent and per turn.** The harness's own pressure listener
 * retries a failed compaction at every following step, so a summarizer that is
 * down fails once per step for as long as the turn runs. Here a failure that
 * is not a cancellation records the turn it happened in, and that agent is not
 * asked again until its next turn: at most one failed attempt, and one failure
 * notice in the conversation, per agent per turn. A cancelled attempt — Stop,
 * or the conversation closing — is not a failure and records nothing. A
 * failure of the routed model's capacity configuration is backed off the same
 * way but logged only once per agent, because it repeats until the profile
 * changes.
 *
 * **The engine is resolved per agent.** A preset publishes `compaction` behind
 * an `isolate` realm the host plane cannot see; the shipped desktop profile
 * mounts `compaction-basic` only there. `agentPresets.serviceFor` is the
 * harness's read addressing for that case and needs the agent, so nothing here
 * injects `compaction`. Agents on the same preset revision, delegated children
 * included, share one engine, which keeps its state per agent. The engine is called unwrapped
 * (`symbols.original`): `serviceFor` returns it behind a Cordis proxy whose
 * `ctx` is this plugin's host context, from which the pruner mounted beside
 * the engine in its realm cannot be found.
 *
 * Every line this module logs goes through the logger named
 * {@link LOGGER_NAME}; the host decides where that logger's lines are written.
 *
 * @module @haoran/dsh-auto-compact/step-compaction
 */
import type { Context } from '@deepseek-ai/cordis';
import type { AutoCompactSettings } from './section.ts';
/** The name of the logger every line of this plugin is written through. */
export declare const LOGGER_NAME = "auto-compact";
/** What this module gives the policy seat: whether it is covering any agent. */
export interface StepCompaction {
    /**
     * Whether a compaction engine has been reached for at least one agent.
     * @returns true once this module has resolved an engine it can compact with.
     */
    covers(): boolean;
}
/**
 * Compact before a step whenever the engine finds the conversation full enough.
 *
 * The listener always returns `next()`'s decision unchanged, whatever the
 * compaction did: the chain's other listeners still run, and the step is
 * entered or rejected exactly as it would be without this plugin.
 *
 * @param ctx - the host-plane context; its unload removes the listeners.
 * @param section - thunk returning the switch and the share in force right now.
 * @returns the coverage question the policy seat answers from.
 */
export declare function installStepCompaction(ctx: Context, section: () => AutoCompactSettings): StepCompaction;
//# sourceMappingURL=step-compaction.d.ts.map