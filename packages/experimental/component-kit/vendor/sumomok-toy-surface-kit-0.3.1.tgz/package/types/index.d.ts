/**
 * `@sumomok/toy-surface-kit` 导出面的手写类型。
 *
 * 四个原件是 Vue 2 选项对象（`@vitejs/plugin-vue2` 的 SFC 编译产物），源库无 TypeScript、
 * 无 `.d.ts`，本文件由 `src/vendor/` 里的 `props` 声明逐条推出，不是生成物：改动 vendor 树的
 * props 时必须同步改这里，`tools/gates.mjs` 的导出面门禁只钉住导出名，钉不住 props 字段。
 *
 * 后端方案（scheme / meta）驱动的配置对象一律带索引签名：字段集合由后端下发，
 * 组件闭包只读到下面列出的这些，其余原样透传，静态上枚举不全。
 */
import type Vue from 'vue';
import type { ComponentOptions } from 'vue';

/** 一行表格数据。列名与值由后端方案决定，静态上不可枚举。 */
export type ToyRow = Record<string, unknown>;

/** el-table 的插槽作用域对象（`{ row, column, $index }`），由 element-ui 构造，本包不重新声明它的字段。 */
export type ElTableScope = Record<string, unknown>;

/** `tableConfig.gridItems` 的一列。`relatedMetaAttr` 是列取值用的行字段名，其余字段控制该列的呈现。 */
export interface TableDetailGridItem {
  /** 行数据里取值的字段名；等于 `'zh_label'` 的列固定左浮，并且是名称点击事件的来源列。 */
  relatedMetaAttr: string;
  /** 列头文字。 */
  alias?: string;
  /** `String(isShow) !== '0'` 才渲染该列；传函数时按 `(scope, relatedMeta)` 逐行求值。 */
  isShow?: boolean | string | number | ((scope: ElTableScope, relatedMeta: string) => boolean);
  /** `String(isSortable) === '1'` 时该列走 `sortable="custom"`，排序由 `table-sort-change` 事件外置。 */
  isSortable?: boolean | string | number;
  /** 单元格呈现组件名：`display_tag` / `display_progress` / `display_circle` / `display_yesno`；其余值按纯文本渲染。 */
  relatedComponent?: string | null;
  /** 呈现组件的配置，逐字传给对应的 `Tc*` 列组件；字段集合随组件而异。 */
  relatedComponentObj?: Record<string, unknown> | null;
  [key: string]: unknown;
}

/** `TableDetail` 的方案配置。闭包只读 `gridItems`，其余字段随后端方案原样带过。 */
export interface TableDetailTableConfig {
  gridItems: TableDetailGridItem[];
  [key: string]: unknown;
}

/** 右侧操作栏按钮的可见性；传 `null` 隐藏整个操作栏。 */
export interface TableDetailRightOperationVisiable {
  modify?: boolean;
  delete?: boolean;
  [key: string]: unknown;
}

/** 自定义操作按钮。`key` 用于云端权限判断（`relatedMeta:key`）。 */
export interface TableDetailCustomOperation {
  label?: string;
  key?: string;
  name?: string;
  [key: string]: unknown;
}

/** 表格自定义列组件；`comp` 是 Vue 2 组件，挂载时带入 `config`、`scope` 两个 props。 */
export interface TableDetailCustomComp {
  prop: string;
  comp: ComponentOptions<Vue>;
  [key: string]: unknown;
}

/** `TableDetail` 的 props。除 `tableConfig` 外全部可选，默认值见 `src/vendor/.../TableDetail.vue`。 */
export interface TableDetailProps {
  tableConfig: TableDetailTableConfig;
  /** 源值数组，与 `displayValueList` 按 `int_id` 对应。 */
  rawValueList?: ToyRow[];
  /** 显示值数组，表格实际渲染的就是它。 */
  displayValueList?: ToyRow[];
  /** 翻译关联模型值数组。 */
  refValueList?: ToyRow[];
  /** 关联的模型英文名，随选中数据一起回传给宿主。 */
  relatedMeta?: string | null;
  /** 关联的模型中文名。 */
  relatedMetaAlias?: string | null;
  /** 隐藏所有行取值都为空的列。默认 `true`。 */
  isHideNullCol?: boolean;
  /** 单元格内容完整显示。默认 `true`。 */
  isFullDisplayCol?: boolean;
  /** 名称列可点击。默认 `false`。 */
  isNameClick?: boolean;
  /** 右侧操作栏；`null` 表示不要操作栏。默认 `{ modify: true, delete: true }`。 */
  rightOperationVisiable?: TableDetailRightOperationVisiable | null;
  /** 逐行决定「修改」按钮是否可见。 */
  modifyOpVisFn?: ((scope: ElTableScope, rawValue: ToyRow, displayValue: ToyRow) => boolean) | null;
  /** 逐行决定「删除」按钮是否可见。 */
  deleteOpVisFn?: ((scope: ElTableScope, rawValue: ToyRow, displayValue: ToyRow) => boolean) | null;
  customOperations?: TableDetailCustomOperation[] | null;
  /** 启用云端按钮权限，自定义操作按 `key` 或 `name` 校验。默认 `false`。 */
  useCloudPermission?: boolean;
  /** 云端权限判断函数，`useCloudPermission` 为 `true` 时逐个按钮调用。 */
  hasCloudPermission?: ((key: string) => boolean) | null;
  /** 选择模式；`null` 表示无选择列。默认 `'checkbox'`。 */
  selectMode?: 'checkbox' | 'radio' | null;
  /** trans 类型属性可点击。默认 `true`。 */
  isTransClick?: boolean;
  /** 脱敏显示。默认 `false`。 */
  showAsPass?: boolean;
  customComps?: TableDetailCustomComp[] | null;
  /** 逐行行内样式，返回值直接交给 el-table 的 `row-style`。 */
  rowStyle?: ((scope: ElTableScope) => Record<string, unknown> | null) | null;
  /** 禁用表内所有组件。默认 `false`。 */
  disabled?: boolean;
  /** 操作列宽度（px）；不传则按操作按钮个数算。 */
  operationColumnWidth?: number | null;
  /** 列可排序。默认 `true`。 */
  tableSortable?: boolean;
}

/** `doGetSelection()` 的返回值。 */
export interface TableDetailSelection {
  /** el-table 报出的当前选中行（显示值）。 */
  selection: ToyRow[];
  /** 最后一个选中行的基础信息；无选中时为 `null`。 */
  dataBase: { id: unknown; name: unknown; type: string | null; isbind: unknown } | null;
  /** 全部列的 `relatedMetaAttr`。 */
  source: string[];
  /** 全部列的 `alias`。 */
  sourceName: string[];
  /** 当前可见列的 `relatedMetaAttr`。 */
  sourceShow: string[];
  /** 当前可见列的 `alias`。 */
  sourceNameShow: string[];
  /** 选中行对应的源值。 */
  selectedRawValue: ToyRow[];
  /** 与 `selectedRawValue` 同值，原件同时给了两个名字。 */
  rawValueList: ToyRow[];
  /** 选中行对应的显示值。 */
  displayValueList: ToyRow[];
}

/** `TableDetail` 实例上宿主可调的方法（原件中标了 `@public` 的那些）。通过 `$refs` / `$children` 拿到实例后调用。 */
export interface TableDetailInstance extends Vue {
  /** 取表内全部数据；`displayValueList` 为空时返回 `{}`。 */
  doGetTableData(): { rawValueList: ToyRow[]; displayValueList: ToyRow[] } | Record<string, never>;
  /** 取当前选中数据。 */
  doGetSelection(): TableDetailSelection;
  /** 按 `int_id` 或 `id` 设置选中行。 */
  doSetSelection(dataList: ToyRow[]): void;
  /** 清空选中状态。 */
  doClearSelection(): void;
  /** 强制刷新列：`gridItems` 只改了顺序时列不会自动刷新。 */
  refreshColumn(): void;
}

/**
 * toy-ui 的 `TableDetail`（原库未导出，本包补上）——纯 props 进、7 个事件出、零后端的表格。
 *
 * 事件（Vue 2 选项类型不承载事件签名，逐条列在这里）：
 * - `table-selection-change(displayValueList: ToyRow[], rawValueList: ToyRow[])`
 * - `trans-cell-click({ ...cellInfo, selection: ToyRow[] })`
 * - `name-cell-click({ ...cellInfo, selection: ToyRow[] })`
 * - `table-sort-change(e: ElTableScope)`
 * - `table-operation(op: 'modify' | 'delete', scope: ElTableScope)`
 * - `table-operation-custom(scope: ElTableScope, item: TableDetailCustomOperation, rawValue: ToyRow)`
 * - `table-cell-click({ row, column, cell, event })`
 */
export declare const TableDetail: ComponentOptions<Vue>;

/** `TcFormDetail` 的一行。`label` 是属性中文名，`display` 是已格式化好的显示值。 */
export interface TcFormDetailItem {
  label: string;
  display: unknown;
  /** 属性英文名。 */
  name?: string;
  /** 原值，组件不渲染它。 */
  value?: unknown;
}

/** `TcFormDetail` 的 props。 */
export interface TcFormDetailProps {
  dataList: TcFormDetailItem[];
  /** label 列宽度。默认 `'150px'`。 */
  labelWidth?: string;
  /** 分几列显示。默认 `2`。 */
  columnNum?: number;
}

/** toy-comp 的 `TcFormDetail`——`[{label, display}]` 只读详情，零 $emit、零 slot、零后端。 */
export declare const TcFormDetail: ComponentOptions<Vue>;

/** `TcProcessBall` 的 props。逐条取自 `src/vendor/toy-comp/data/process-ball/TcProcessBall.vue` 的 `props` 声明。 */
export interface TcProcessBallProps {
  /** 球的直径，单位 px。默认 `100`。 */
  size?: number;
  /** 当前进度，直接作为球面第一行文字渲染，同时按 `0-100` 决定水位高度。默认 `0`。 */
  process?: number | string;
  /** 球面第二行文字。默认 `''`。 */
  text?: string;
  /** 球体底色，同时是水面渐变的下端色。默认 `'#00D27A'`。 */
  background?: string;
  /** 球体外发光颜色（`box-shadow`）。默认 `'#00D27A'`。 */
  borderColor?: string;
  /** 球体两侧五个装饰圆点的颜色。默认 `'#00D27A'`。 */
  pointColor?: string;
  /** 是否显示两侧装饰圆点；关掉时组件左右内边距同时归零。默认 `true`。 */
  isPointShow?: boolean;
}

/**
 * toy-comp 的 `TcProcessBall`——一行数字的指标球，纯 props 进、零 $emit、零后端。
 *
 * `process` 变化时按每步 1 的粒度动画到新值（补丁 `0005` 让这条 `setTimeout` 链在 `beforeDestroy` 停下）。
 */
export declare const TcProcessBall: ComponentOptions<Vue>;

/** `metaConfig.attributes` 的一条属性。 */
export interface TuQueryCondAdvAttribute {
  /** 属性英文名，等于条件里的 `key`。 */
  attributeEnName: string;
  /** 属性中文名，下拉里显示的文字。 */
  attributeCnName?: string;
  /** 值控件配置；`name` 决定用哪个输入控件，直连 Crud 的七个控件已被替换成禁用输入替身。 */
  relatedComponentObj?: Record<string, unknown> | null;
  /** `'1'` / `'2'` / `'3'` 时按 `attrEqEnums[].ifChange` 过滤可选匹配策略。 */
  ifChange?: string | number;
  [key: string]: unknown;
}

/** 模型配置。传了它就不会调 `getMetaInfo`，组件全程零网络。 */
export interface TuQueryCondAdvMetaConfig {
  attributes: TuQueryCondAdvAttribute[];
  [key: string]: unknown;
}

/** 匹配策略枚举项。 */
export interface TuQueryCondAdvEqEnum {
  /** 存进条件的 `op` 值，如 `'EQ'`、`'LIKE'`。 */
  value: string;
  /** 下拉里显示的文字。 */
  label: string;
  /** 限定该策略只在这些 `ifChange` 的属性上出现；不填表示不限。 */
  ifChange?: string[];
}

/** 样式配置。 */
export interface TuQueryCondAdvConfStyle {
  /** el-row 的 gutter。默认 `50`。 */
  gutter?: number;
  /** 四个 el-col 的 span。默认 `[6, 6, 6, 6]`。 */
  spanList?: number[];
  /** 是否显示 AND / OR 选择。默认 `true`。 */
  showMatchMode?: boolean;
}

/** `TuQueryCondAdv` 的 props。 */
export interface TuQueryCondAdvProps {
  /** 模型英文名。必填；不传 `metaConfig` 时组件会拿它去取模型配置，而本包里取数被替身拦成抛错。 */
  relatedMeta: string;
  /** 模型配置；不传即触发网络取数（本包内会抛错），所以宿主必须传。默认 `null`。 */
  metaConfig?: TuQueryCondAdvMetaConfig | null;
  /** 匹配策略枚举，默认给 16 条（EQ / LIKE / BETWEEN 等）。 */
  attrEqEnums?: TuQueryCondAdvEqEnum[];
  confStyle?: TuQueryCondAdvConfStyle;
}

/** 一条查询条件。 */
export interface QueryCondition {
  /** 属性英文名。 */
  key: string;
  /** 匹配策略，取自 `attrEqEnums[].value`。 */
  op: string;
  /** 条件值。`getData()` 给的是原始值，`getDataFull()` 给的是 trans 类型的完整对象。 */
  value: unknown;
}

/** `getData()` / `getDataFull()` 的返回值，已被 `Object.freeze` 冻结。 */
export interface QueryCondAdvData {
  conditions: QueryCondition[];
  matchMode: 'AND' | 'OR';
}

/** `TuQueryCondAdv` 实例上宿主可调的方法。 */
export interface TuQueryCondAdvInstance extends Vue {
  /** 取查询条件，值是原始值，直接给查询接口用。 */
  getData(): QueryCondAdvData;
  /** 取查询条件完整数据，用于回填 `setData`。 */
  getDataFull(): QueryCondAdvData;
  /** 回填查询条件。`matchMode` 不传按 `'AND'`。 */
  setData(params: { conditions?: QueryCondition[]; matchMode?: 'AND' | 'OR' }): void;
  /** 清空成一条空条件。 */
  clearData(): void;
}

/**
 * toy-ui 的 `TuQueryCondAdv`——高级查询条件编辑器，产出 `conditions:[{key,op,value}]`。
 * 传 `metaConfig` 即零网络；七个直连 Crud 的值控件已别名到禁用输入替身。组件不 `$emit`，
 * 数据靠实例方法 `getData()` / `setData()` 出入。
 */
export declare const TuQueryCondAdv: ComponentOptions<Vue>;
