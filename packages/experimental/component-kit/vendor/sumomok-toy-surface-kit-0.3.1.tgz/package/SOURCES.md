# 来源台账（SOURCES.md）

三个源库 `toy-ui` / `toy-comp` / `toy-core` 与本包同级摆在一个源根目录下，全程只读；`tools/copy-sources.mjs` 按本包所在位置的上一层定位它们，不写死任何机器路径。
拷进 `src/vendor/` 的文件保留原相对结构，所以下表每一行的路径既是它在源根下的位置，也是它在 `src/vendor/` 下的位置。
源库无 git、无版本号，所以这张表就是唯一的版本锚：源库改动后重跑 `node tools/copy-sources.mjs` 会让 sha 变化，即为需要重跑门禁的信号。

拷贝日期：2026-09-04　文件数：46　总行数：4642

| # | 路径（源根下 = `src/vendor/` 下） | 行 | 字节 | sha256 |
|---|---|---|---|---|
| 1 | `toy-comp/data/process-ball/index.js` | 3 | 80 | `11b11e021f4efd16de8bc6d70972f767374241fd06268a93c131dad27e56bb8a` |
| 2 | `toy-comp/data/process-ball/TcProcessBall.vue` | 261 | 5441 | `a31dc732d90074537513fef0eb19edc6245726ff0c20c270e5771fc1a59f48f5` |
| 3 | `toy-comp/data/table-columns/column-circle/index.js` | 3 | 83 | `abe13ceadba13669767489c6c93d9a24d4551a145ab621738a8d78caa7b5daf3` |
| 4 | `toy-comp/data/table-columns/column-circle/TcColumnCircle.vue` | 110 | 1957 | `f70fa556591f63bce53c3c28d64a5097f5555934873d7c186d41e7b601c0c9bc` |
| 5 | `toy-comp/data/table-columns/column-progress/index.js` | 3 | 89 | `aea8a4988f2638198507bc0cfdccf554372661b70c93147be370b95b9cfd488d` |
| 6 | `toy-comp/data/table-columns/column-progress/TcColumnProgress.vue` | 69 | 1619 | `c498ddc70700e8e5d3f057dd44fe841f05bc5e0bd61f745c3074cc4313f590e1` |
| 7 | `toy-comp/data/table-columns/column-tag/index.js` | 3 | 74 | `a00342236c76962c5da9c97d4daf25641fcd9d025ad3b964265a202446e837e8` |
| 8 | `toy-comp/data/table-columns/column-tag/TcColumnTag.vue` | 96 | 1654 | `bbaf8120a42a02ad0f5050d79ec3688698519a77befb06f85be0aa3518084d2b` |
| 9 | `toy-comp/data/table-columns/column-yesno/index.js` | 3 | 80 | `af3ac65d9049587ef52742d4f9ae20160721b5db81c0831373f72b7ad951bc83` |
| 10 | `toy-comp/data/table-columns/column-yesno/TcColumnYesno.vue` | 60 | 1268 | `c8ab38370f0576385ee3adff5c2b49170262437d74a2172c2b6f673af60b0eac` |
| 11 | `toy-comp/form/form-detail/index.js` | 3 | 77 | `7f23a3d7ba95cf585278524ab2bc3d52461ca299daf038869da0ab1a91e60de5` |
| 12 | `toy-comp/form/form-detail/TcFormDetail.vue` | 142 | 3212 | `4be88a07a4d5824282bc3a07e253adb179d3e91ba9b0402daef9e509541602f1` |
| 13 | `toy-comp/form/number-comp/index.js` | 3 | 77 | `54077b5051e06a2cd47e47ab14b5f17e14cb9ea09e0105fb7120b7562744c6f4` |
| 14 | `toy-comp/form/number-comp/TcNumberComp.vue` | 86 | 1846 | `3ad584f3a6ad49201dcc95446267cb0636e0c59640589c75bfc95474746b51b7` |
| 15 | `toy-comp/form/xy-comp/index.js` | 3 | 65 | `dcd227ac1a6b2dd577e7ef7e33e2478a198e9646bd8264db30c3d8d131844eaf` |
| 16 | `toy-comp/form/xy-comp/TcXyComp.vue` | 93 | 2043 | `95e22747727937e8c9e5e39a2b4beae6fd5be9c307b04363998e1a11e4edf849` |
| 17 | `toy-core/crud/compTypeUtil.js` | 198 | 6749 | `23314aeaeecce99a353c7a0670838e6bf3001d22eb921123954fa21e0a9f17db` |
| 18 | `toy-core/event/toy-map-event.js` | 49 | 1576 | `e55392e73169b1c4205546794fe89c8e55a90b2ad79ab47d7b23ead41bca1f2e` |
| 19 | `toy-core/utils/numberUtil.js` | 31 | 556 | `efcfdd3fcafcfa78346f02de9abf4ec8aedcca2b052322d15672f01723386abf` |
| 20 | `toy-core/utils/stringUtil.js` | 130 | 2495 | `28031305b3361fd366e2f88fe0d87212ad3092254a57b30d6afb4c21708651c5` |
| 21 | `toy-ui/component/common/FormEdit/component/common/InputExactFuzzy/index.js` | 3 | 86 | `5057068f7c712707c41c4422046f4d2c300fad6425590d1f0e37bf1337a9da37` |
| 22 | `toy-ui/component/common/FormEdit/component/common/InputExactFuzzy/InputExactFuzzy.vue` | 79 | 1596 | `b302a0384f02d73eef36f3b875fd1fa7634a407a9b0adde54869728845218066` |
| 23 | `toy-ui/component/common/FormEdit/component/common/SelectComp/index.js` | 3 | 71 | `79acb4c966ac47b3ce888f5c8ae8f16a65f170774467c4bdbdaa594b229f8381` |
| 24 | `toy-ui/component/common/FormEdit/component/common/SelectComp/SelectComp.vue` | 155 | 3064 | `7bba49c8181eb66ec43170fc5e718f7bc04db62f03ec7f4692e4eaa5375fb550` |
| 25 | `toy-ui/component/common/FormEdit/component/common/XyComp/index.js` | 3 | 59 | `77d89a78eb9de2713165ff52c8836563736e9ced523592c64fa5c2489eaf555d` |
| 26 | `toy-ui/component/common/FormEdit/component/common/XyComp/XyComp.vue` | 138 | 2670 | `99a63f110e5882832a2bca45d989b13022112269cab0aa62d81f877f878dff68` |
| 27 | `toy-ui/component/common/FormEdit/component/FormItemComp.vue` | 736 | 22019 | `7414e565fd62cf8b017906df2212c0b2ccb518fa65af8fb9cd0fec242725fcfa` |
| 28 | `toy-ui/component/common/FormEdit/mxins/formItem.js` | 109 | 2628 | `26cb02b2d7feddf7f03d3640bd69ae536dfdd119e972505afa941faafe9de545` |
| 29 | `toy-ui/component/common/query/QueryCondAdv/component/AttrComp/AttrComp.vue` | 266 | 7113 | `2e2a966f16ec5cce2c7e9ed82013095c372a7e060672e81edc001ba039bee241` |
| 30 | `toy-ui/component/common/query/QueryCondAdv/component/AttrComp/index.js` | 3 | 65 | `b8277a3c5ef4af7173a21177e930555694d89cb270c8b4fc4b3821ee1756065a` |
| 31 | `toy-ui/component/common/query/QueryCondAdv/index.js` | 3 | 77 | `8cb82343efaeb31f8077cf59b2e613217fd438045fcd7e490fb984846bbc7693` |
| 32 | `toy-ui/component/common/query/QueryCondAdv/QueryCondAdv.vue` | 356 | 10164 | `83b9ee4194981e743a14082c65a976b06f554b7e96115d00900ea7760c3e75e8` |
| 33 | `toy-ui/component/common/TableDetail/component/DeletePopover/DeletePopover.vue` | 75 | 1489 | `7ff1cd47092173e0cb152754668ae7822fcd05ccf6ff69b5c9df7b0d51846a33` |
| 34 | `toy-ui/component/common/TableDetail/component/DeletePopover/index.js` | 3 | 80 | `903f920aeec013cef5c53754bb2ee34957ce059cfb906c794b2323d4f279de12` |
| 35 | `toy-ui/component/common/TableDetail/component/TableDetailColumn/component/DisplayCircle.vue` | 26 | 493 | `02c2f5d873db16a37d79f0b6545fecde3fa4099d8355721746454be5a328b8eb` |
| 36 | `toy-ui/component/common/TableDetail/component/TableDetailColumn/component/DisplayColumn.vue` | 99 | 2507 | `f66ec2036e4756fe325ec6f3a8f0c049bc00d85a03d56cf3c9a3a367f8be3f7d` |
| 37 | `toy-ui/component/common/TableDetail/component/TableDetailColumn/component/DisplayColumnMixins.js` | 39 | 562 | `94f2242b10eb97f4befe0c6a83b6739f488acd01576458a3f78e64475fe122f9` |
| 38 | `toy-ui/component/common/TableDetail/component/TableDetailColumn/component/DisplayProgress.vue` | 18 | 316 | `c0e394b1a34719ba37278f1a9f560ebc12d8558318da130154da4fa983a4cc55` |
| 39 | `toy-ui/component/common/TableDetail/component/TableDetailColumn/component/DisplayTag.vue` | 26 | 481 | `60b69168702bcfe1f4703941e1e3e0a2286f381251a28527ab3708f4ada0c7c4` |
| 40 | `toy-ui/component/common/TableDetail/component/TableDetailColumn/component/DisplayYesno.vue` | 18 | 304 | `81ebff1b98c3d1f1e6d7a8b52c53d5ad039b0d830320943a859002c89a8ad2a2` |
| 41 | `toy-ui/component/common/TableDetail/component/TableDetailColumn/index.js` | 3 | 92 | `ac0475a770fac0985382b420aa63639b28958f7eb614f42a18309fd42002e260` |
| 42 | `toy-ui/component/common/TableDetail/component/TableDetailColumn/TableDetailColumn.vue` | 364 | 10455 | `528ab85df15e6add1880f0630ffd0b4c0bf75e1f4889c2ff04903c07f1865ef5` |
| 43 | `toy-ui/component/common/TableDetail/index.js` | 3 | 74 | `0ec5fdb9431817930f989b104aadff58b55b38331204600db5da5ed3e04f532e` |
| 44 | `toy-ui/component/common/TableDetail/mixins/normal.js` | 29 | 555 | `02b9758a09e42a5a30126aae4a774a5b972137a20a02b7188cd09a5323b5a62d` |
| 45 | `toy-ui/component/common/TableDetail/TableDetail.vue` | 687 | 19898 | `47f0af52a59f5de90a313f9b4fbb861ac85daf64aa50bd0b589ce496ddcf1069` |
| 46 | `toy-ui/component/common/TableDetail/utils/tableDetailUtil.js` | 49 | 1567 | `f6c4c6c22bc842d8074bb4e7873f7293f6a00257bdd302db64aeb3d98b5e879c` |
