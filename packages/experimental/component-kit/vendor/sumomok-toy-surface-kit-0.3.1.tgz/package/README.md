# @sumomok/toy-surface-kit

把三个 toy 源库（`toy-ui` / `toy-comp` / `toy-core`）里可以原样搬走的 Vue 2 组件编译成一个 tgz。
交付物只有「已编译的 Vue 组件对象 + 随 JS 注入的样式」：不含桥、不含 React、不含任何 dsh 概念。

`vue` 与 `element-ui` 由宿主提供（external），`element-ui` 必须已被宿主 `Vue.use` 注册；
`lodash` 与 `dayjs` 是本包声明的普通依赖，同样不打进产物。

## 导出

| 导出 | 来源 | 形态 |
|---|---|---|
| `TableDetail` | toy-ui `component/common/TableDetail`（原库未导出） | `tableConfig.gridItems` + `displayValueList` 进，7 个事件出 |
| `TcFormDetail` | toy-comp `form/form-detail` | `dataList: [{label, display, name, value}]` 只读详情，零事件 |
| `TcProcessBall` | toy-comp `data/process-ball` | 「一行数字」指标球：七个 props 进（`process` / `text` / `size` / 三个颜色 / 圆点开关），零事件、零 slot |
| `TuQueryCondAdv` | toy-ui `component/common/query/QueryCondAdv` | 传 `metaConfig` 即零网络；`getData()` 返回 `{conditions:[{key,op,value}], matchMode}` |

导出面的类型是手写的 `types/index.d.ts`：props 逐条从 `src/vendor/` 里的 `props` 声明推出，
后端方案驱动的配置对象（`tableConfig`、`gridItem`、`metaConfig`）带索引签名，
另外给出 `TableDetail` 的 7 个事件、两个组件的实例方法与返回值。

## 四条搬运规则

1. **源库只读。** 闭包内的文件由 `tools/copy-sources.mjs` 拷进 `src/vendor/`，保留原相对结构，
   逐文件在源根下的相对路径与 sha256 记在 `SOURCES.md`。源库无 git、无版本号，这张表就是唯一的版本锚。
   源根是本包所在目录的上一层（三个源库与本包同级），不写死在任何脚本里。
2. **对源码的改动一律是补丁文件。** `patches/*.patch` 一个补丁一个文件，第一行是一行理由，
   由 `tools/apply-patches.mjs` 按序号打到拷贝件上。
3. **桶入口一律不走。** `toy-comp` 与 `toy-core` 的桶入口被别名到 `src/shims/` 下的精选替身
   （见 `vite.config.shared.js`）。桶入口会把 `menu/**`、`iview/utils/dom.js`（全三库仅有的
   `import Vue from 'vue'` 来源）与 axios / NProgress / 整页跳转一起拖进来。
4. **身份与 token 不进组件层。** 组件不读 `localStorage` / `sessionStorage` / `document.cookie`，
   也不自带凭据调接口；数据一律由宿主经 props 传入（补丁 `0004`，门禁「源码/产物零浏览器凭据读点」）。

## 五个补丁

`patches/` 一个补丁一个文件，第一行是理由，按序号打在 `src/vendor/` 的拷贝件上；源库始终只读。

| # | 改的文件 | 改了什么 |
|---|---|---|
| `0001` | `toy-ui` `TableDetailColumn.vue` | 删掉 `cronstrue/i18n` 与它唯一的 cron 列分支（import、模板分支、方法三处一起删） |
| `0002` | `toy-ui` `DisplayColumn.vue` | 删掉 `DisplayDownload.vue` 的静态 import 与 `display_download` 分支（该文件拖 `@vue-office/{docx,excel,pptx}`） |
| `0003` | `toy-comp` `TcColumnYesno.vue` | 补上 `String(value).toUpperCase` 缺的调用括号，5 处；原式比的是函数对象，五个分支恒为 false |
| `0004` | `toy-ui` `FormItemComp.vue` | 删掉 `token: localStorage.getItem('accessToken')` 与消费它的 `:headers`（搬运规则 4） |
| `0005` | `toy-comp` `TcProcessBall.vue` | 递归 `setTimeout` 存下 id，`beforeDestroy` 里 `clearTimeout`；原件销毁后动画链继续改已销毁实例，一路跑完剩余步数 |

## 命令

```sh
pnpm install
node tools/copy-sources.mjs   # 从源库重新取一遍闭包文件（会覆盖补丁，需接着重打）
node tools/apply-patches.mjs  # 打五个补丁（要从干净的拷贝件开始，否则已打过的补丁会留下 .rej）
pnpm run build                # 出 dist/index.js（样式随 JS 注入）
pnpm run gates                # 11 类机械门禁 / 20 条断言，含四个组件的 jsdom 挂载冒烟
pnpm run probe                # 单独跑挂载探针（18 条断言，含销毁后零残留定时器）
pnpm run pack                 # 出 tgz，并对 tgz 内每个文件扫本机绝对路径
pnpm run scan-paths [tgz]     # 单独扫：不给参数扫将被打包的工作区文件，给 tgz 则解开扫
```

**随包文件不带打包机器的路径。** macOS / Linux 的家目录前缀与 Windows 盘符前缀在 tgz 的任何文件里
命中即失败（模式表是 `tools/scan-machine-paths.mjs` 的 `MACHINE_PATH_PATTERNS`，这里不复述，
复述一遍就会被自己扫出来）：打包前由门禁第 11 条扫 `npm pack --dry-run` 的清单，
打包后由 `pnpm run pack` 解开真 tgz 逐文件再扫一遍，命中就删掉刚生成的 tgz。
直接跑 `npm pack` 会绕过打包后那一遍。

宿主用 `file:` 依赖装本包，同名 tgz 覆盖会被 pnpm 静默忽略：**内容一变就升 `version` 再 `pnpm run pack`**。

## 已知限制（Known Limitations）

**`FormItemComp` 的 `el-upload` 分支仍指向宿主同源接口。** 补丁 `0004` 切掉的是凭据，
上传分支本身还在：`:action` 是 `ToyCore.core.env.getBaseURL()`（本包的 shim 给空串）拼上
`nrms-file/api/file/uploadToServer`，走到就是一个向宿主同源发的无凭据 POST。
四个导出组件的正常用法都到不了这条分支：唯一引用 `FormItemComp` 的是 `TuQueryCondAdv` 的 `AttrComp`，
它把 `relatedComponentObj` 强制改写成 `{ name: compType }`，`compType` 只在
`input` / `trans` / `select` / `number` / `date` / `datetime` / `integer` 七个值里取，
而 `compTypeUtil.getCompType` 只读这个字段（外加经纬度属性的特例，产出 `edit_x` / `edit_y`），
拿不到触发上传分支所需的 `edit_upload`。
**复查触发器：`FormEdit` 进入导出面时**——那时再定是整块删掉这条分支，还是接上宿主的上传通道。

**`TcProcessBall` 的浅色是等价实现，不是原件。** 原件在模块求值期读 `ToyCore.utils.colorUtil.tintColor`，
而 `toy-core/utils/colorUtil.js` 依赖 npm `color`，同文件顶部还静态引入 `randomcolor`——两个包都不在本包依赖里，
所以该文件不进 `src/vendor/`，`tintColor` 在 `src/shims/toy-core.js` 里按 `Color(c).alpha(0.6).rgb().toString()`
的输出格式重写。`#rgb` / `#rrggbb` / `#rrggbbaa` / `rgb()` / `rgba()` 五种写法逐字符一致（探针钉住默认色
`#00D27A → rgba(0, 210, 122, 0.6)`）；颜色关键字（`red`）与 `hsl()` 等其余写法原样返回而不转成 rgba，
球面渐变上端因此退化成与底色同色，不抛错。**复查触发器：给 kit 装 `color` 依赖时。**

**手写 `.d.ts` 没有编译期靠山。** 源库无 TypeScript，本包也不装，`pnpm run gates` 只钉得住
三份导出名单（`.d.ts`、桶入口、产物）一致，props 字段改了不会有任何报错，只能靠人同步；
实际验收场是宿主侧的类型检查。**复查触发器：给 kit 加 `typescript` devDep 时**——
那要联网 install，另议。

`tools/closure.py` 是闭包分析器：给入口和排除/别名清单，回答「静态图上到底带进来哪些文件」。
`tools/compile-all-toyui.mjs` 把 vue 2.7 的 SFC 编译器逐个跑过两个库的每个 `.vue`，
用来回答「plugin-vue2 能不能编译 toy-ui 那一半」。
