/**
 * `@sumomok/toy-crud-kit` 导出面的手写类型。
 *
 * `Crud` 是 Vue 2 选项对象（`@vitejs/plugin-vue2` 的 SFC 编译产物 + 本包一条混入），源库无 TypeScript、
 * 无 `.d.ts`，本文件由 `src/vendor/toy-ui/component/Crud/Crud.vue` 的 `props` 声明逐条推出，不是生成物：
 * vendor 树的 props 改了必须同步改这里；`tools/gates.mjs` 只钉住导出名，钉不住字段。
 *
 * 后端方案（schema）驱动的对象一律带索引签名：字段集合由后端下发，这里只列闭包读到的那些。
 */
import type Vue from 'vue';
import type { ComponentOptions } from 'vue';

/** 一行数据。列名与值由后端方案决定，静态上不可枚举。 */
export type ToyRow = Record<string, unknown>;

/** 一条查询条件；`op` 取 `EQ` / `LIKE` / `IN` / `BETWEEN` 等后端匹配策略。 */
export interface CrudCondition {
  key: string;
  op: string;
  value: unknown;
}

/** 查询排序：`{ asc: 属性名 }` 或 `{ desc: 属性名 }`，同时给时 `asc` 优先。 */
export interface CrudQuerySort {
  asc?: string | null;
  desc?: string | null;
}

/** 模型可设的 props（D3）。名单与 {@link CRUD_MODEL_SETTABLE_PROPS} 一致。 */
export interface CrudModelProps {
  /** 模型英文名，必填；宿主按与 toy.table 的 dataSource meta 相同的字符集校验。 */
  relatedMeta: string;
  /** 隐性查询条件：界面不显示、清空不清除，与用户在查询表单里填的条件合并后发给后端。默认 `[]`。 */
  conditions?: CrudCondition[];
  /** 条件关系。默认 `'AND'`。 */
  matchMode?: 'AND' | 'OR';
  /** 查询排序。默认 `{}`（后端默认序）。 */
  querySort?: CrudQuerySort;
  /** 选择列模式；`null` 不画选择列。组件默认 `'checkbox'`。 */
  selectMode?: 'checkbox' | 'radio' | null;
  /** 查询条件面板是否展开。默认 `false`。 */
  isExpandQuery?: boolean;
  /** 挂载后是否立刻查询一次。默认 `true`。 */
  isInitQuery?: boolean;
}

/** 宿主写死、模型不可设的 props（D3）。值见 {@link CRUD_READ_ONLY_PROPS}。 */
export interface CrudHostFixedProps {
  isReadOnly: true;
  type: 'default';
  urlConfig: null;
  hideButton: Readonly<Record<'add' | 'update' | 'delete' | 'imp' | 'exp' | 'gridexp' | 'expimphuge' | 'batchUpdate' | 'batchDelete' | 'labelPrint', true>>;
  hideComp: Readonly<{ menu: true; card: true }>;
}

/** 宿主自己决定、既不在模型名单也不在只读名单里的 props。 */
export interface CrudHostProps {
  /** 根节点的行内样式；组件默认 `'width:100%;height:100%'`，盒子要给出高度。 */
  myStyle?: string;
  /** 查询前是否校验必填条件。默认 `true`；为空时 toy-ui 经宿主 element-ui 的 `$message` 提示（被 `containCrud` 挪进盒子）。 */
  isQueryValidate?: boolean;
}

/** `Crud` 完整的 props。 */
export type CrudProps = CrudModelProps & CrudHostFixedProps & CrudHostProps;

/** 方案里的一列。 */
export interface CrudGridItem {
  /** 行数据里取值的字段名。 */
  relatedMetaAttr: string;
  /** 列头文字。 */
  alias?: string;
  /** `String(isShow) !== '0'` 才显示。 */
  isShow?: boolean | string | number;
  isSortable?: boolean | string | number;
  [key: string]: unknown;
}

/** `load` 事件的载荷：方案配置的深拷贝。回给模型的只有 `query.grid.gridItems` 里显示列的 `relatedMetaAttr` + `alias`（D5）。 */
export interface CrudLoadPayload {
  schemaConfig: {
    query?: { metaAlias?: string; grid?: { gridItems?: CrudGridItem[]; [key: string]: unknown }; [key: string]: unknown };
    add?: Record<string, unknown>;
    modify?: Record<string, unknown>;
  };
}

/** `query-success` / `recieve-data` 事件的载荷：后端查询接口的 `data`。回给模型的只有 `page.total`、`displayValue.length`、`page.currentPage`（D5），行永不回传。 */
export interface CrudQuerySuccessPayload {
  rawValue: ToyRow[];
  displayValue: ToyRow[];
  ref: ToyRow[];
  page: { total: number; currentPage: number; pageSize: number };
  [key: string]: unknown;
}

/** `table-cell-click` 事件的载荷：el-table 的 `cell-click` 原样透传；`column.property` 是被点列的 `relatedMetaAttr`。 */
export interface CrudTableCellClickPayload {
  row: ToyRow;
  column: { property?: string; label?: string; [key: string]: unknown };
  cell: HTMLElement | null;
  event: Event;
}

/** `Crud` 实例上宿主可调的公开方法（原件标 `@public` 的那些）。通过桥的 `instanceRef` 拿到实例后调用；只读首版只用读方法。 */
export interface CrudInstance extends Vue {
  /** 表格全部数据；无数据时返回 `{}`。 */
  doGetTableData(): { rawValueList: ToyRow[]; displayValueList: ToyRow[] } | Record<string, never>;
  /** 当前选中数据（含显示列名单 `sourceShow` / `sourceNameShow`）。没有 selection-change 事件，首版不轮询它。 */
  doGetSelection(): { selection: ToyRow[]; selectedRawValue: ToyRow[]; source: string[]; sourceName: string[]; sourceShow: string[]; sourceNameShow: string[]; [key: string]: unknown };
  /** 按 `id` / `int_id` 设置选中行。 */
  doSetSelection(dataList: ToyRow[]): void;
  /** 清空选中状态。 */
  doClearSelection(): void;
  /** 方案配置的深拷贝。 */
  doGetConfig(): { schemaConfig: CrudLoadPayload['schemaConfig'] };
  /** 方案是否通过检查；`false` 时根节点是注释，盒内有一条提示。 */
  isSchemaRight: boolean;
  /** 最近一次查询结果（冻结）；未查询时 `{}`。 */
  resultData: CrudQuerySuccessPayload | Record<string, never>;
}

/**
 * toy-ui 的 `Crud.vue` 原件 + 本包一条混入（实例的 `$notify` 换成盒内提示）。
 *
 * 事件（Vue 2 选项类型不承载事件签名，逐条列在这里；只读首版能触发的只有前六个）：
 * - `load(payload: CrudLoadPayload)` 方案加载完成
 * - `loaded()` 表格挂载完成
 * - `query-success(payload: CrudQuerySuccessPayload)` / `recieve-data(payload)` 查询成功（同一载荷发两次）
 * - `table-cell-click(payload: CrudTableCellClickPayload)` 单元格点击
 * - `btn-click-query()` / `btn-click-clear()` 查询 / 清空按钮
 * - `table-operation-custom(scope, item, rawValue)` 自定义操作（`tableCustomOperations` 未设，不会触发）
 * - `small-card-close()` / `operation-event(e)` 信息卡（`hideComp.card`，不会触发）
 * - `add-save-success(e)` / `modify-save-success(e)` / `delete-save-success(e)` 写窗口（零渲染替身，不会触发）
 *
 * 组件不能被 `Object.freeze`：Vue 2 的 `Vue.extend` 会往选项对象上写 `_Ctor`。
 */
export declare const Crud: ComponentOptions<Vue>;

/** 宿主盒的标记属性名 `data-toy-crud-box`。 */
export declare const BOX_ATTR: 'data-toy-crud-box';

/**
 * 把宿主元素收拾成 Crud 的盒子：打标记、置 `position:relative`、把请求层的进度条 / 遮罩 / toast、
 * toy-ui 经 element-ui 发出的 `$message`、以及 element-ui 追加到 body 的 poppers（下拉、日期面板、
 * 下拉菜单、行内图标的提示；盒子装得下时连同它们的定位边界一起收）都收进盒子。
 * 必须在挂载（第一次请求）之前调用。
 * @param box 桥挂载 Crud 的宿主元素。
 * @returns 注销函数。
 */
export declare function containCrud(box: HTMLElement): () => void;

/**
 * 设置 toy-core 请求层的业务基路径（axios `baseURL`）。只接受根绝对路径，规范成以 `/` 结尾。
 * 宿主还应在本包模块求值前写好 `window.$toy_env.VUE_APP_BASE_URL`（toy-core 在求值期读它一次）。
 * @param path 如 `/` 或 `/nrms-server`。
 * @returns 实际写入的路径。
 */
export declare function setBizBasePath(path: string): string;

/** 当前生效的业务基路径。 */
export declare function getBizBasePath(): string;

/** 只读首版宿主写死的 props（D3），已冻结；宿主展开在模型 props 之后。 */
export declare const CRUD_READ_ONLY_PROPS: Readonly<CrudHostFixedProps>;

/** 模型可设的 props 名单（D3）。 */
export declare const CRUD_MODEL_SETTABLE_PROPS: ReadonlyArray<keyof CrudModelProps>;

/** `DataPage` 可开关的区域名。`table` 永远在。 */
export type DataPageRegion = 'query' | 'toolbar' | 'table' | 'operate' | 'pagination' | 'infoCard' | 'addForm' | 'modifyForm';

/**
 * 工具栏按钮键。`exp` 是模板导出、`gridexp` 是表格导出，两者都只排一个后端导出任务（不下载文件）。
 *
 * 0.4.2 起不放行 `imp`（模板导入）与 `batch`（批量修改 / 批量删除）：前者把文件交给导入任务后，成败只在
 * 部署自己的任务列表页看得到；后者的两个窗口是零渲染替身，命令发出去没有界面。写它们会被 prop 校验器
 * 当场拒掉，恢复条件见 README 的已知限制。
 */
export type DataPageToolbarButton = 'add' | 'exp' | 'gridexp' | 'search' | 'clear';

/**
 * 行内操作键。0.4.0 只有 `modify`：删除确认窗口仍是零渲染替身，放一个点了没反应的图标比不放更糟，
 * 所以 `'delete'` 在名单层面就不放行，写它会被 prop 校验器拒掉（开发版 Vue 下当场报出来）。
 * 恢复条件见 README 的已知限制。
 */
export type DataPageRowOperation = 'modify';

/** 信息卡分段键（原件 `SmallCard` 的 `cardSmallComp` 取值）。本包只有 `wrong-info` 与 `attributes` 是真件。 */
export type DataPageInfoCardTab = 'wrong-info' | 'operation' | 'related-stat' | 'useage' | 'attributes';

/** 模型可设的自定义操作；点击只发 `table-operation-custom`，容器自己不做任何事。 */
export interface DataPageCustomOperation {
  /** 操作名，回传在 `table-operation-custom` 的第二个参数里。 */
  name: string;
  /** 行内显示的文字。 */
  label: string;
}

/** 模型可设的 props。名单与 {@link DATA_PAGE_MODEL_SETTABLE_PROPS} 一致。 */
export interface DataPageModelProps {
  /** 模型英文名，必填。 */
  relatedMeta: string;
  /** 隐性查询条件：界面不显示、清空不清除。默认 `[]`。 */
  conditions?: CrudCondition[];
  /** 条件关系。默认 `'AND'`。 */
  matchMode?: 'AND' | 'OR';
  /** 查询排序。默认 `{}`（后端默认序）。 */
  querySort?: CrudQuerySort;
  /** 选择列模式。默认 `'checkbox'`。 */
  selectMode?: 'checkbox' | 'radio';
  /** 挂载后是否立刻查一次。默认 `true`；容器把原件的两条首查路径归一，这条因此在任何区域组合下都作数。 */
  isInitQuery?: boolean;
  /** 行内多出来的操作。默认 `[]`（不画操作列）。 */
  customOperations?: DataPageCustomOperation[];
}

/** 布局选项。名单与 {@link DATA_PAGE_LAYOUT_PROPS} 一致；缺省值就是「全都摆出来」。 */
export interface DataPageLayoutProps {
  /** 哪些区域摆出来。默认八个全开；`table: false` 会被开发版 Vue 拒绝。 */
  regions?: Partial<Record<DataPageRegion, boolean>>;
  /** 工具栏留哪几个按钮。默认是 {@link DATA_PAGE_TOOLBAR_BUTTONS} 那五个全留。顺序由 `CrudAction.vue` 的模板写死，这条只决定显隐。 */
  toolbarButtons?: DataPageToolbarButton[];
  /** 行内留哪几个操作。默认 `['modify']`，也是 0.4.0 唯一的取值。 */
  rowOperations?: DataPageRowOperation[];
  /** 查询区是否展开。默认 `false`（折叠成一行）。 */
  queryExpanded?: boolean;
  /** 每页条数的初值，也是「清空」退回的值。默认 `20`。 */
  pageSize?: number;
  /** 每页条数下拉里的候选。默认 `[10, 20, 50, 100, 200, 500, 1000]`。 */
  pageSizes?: number[];
  /** 信息卡里渲染哪些分段。默认五段全给（其中三段是零渲染替身）。 */
  infoCardTabs?: DataPageInfoCardTab[];
}

/** 宿主自己决定的 props。 */
export interface DataPageHostProps {
  /**
   * 只读。默认 `true`：与 `Crud` 一样安全——新增 / 修改 / 删除 / 导入 / 导出全部隐藏，`isReadOnly` 传给原件。
   * 为真时盖在 `toolbarButtons` / `rowOperations` 之上，写能力只能由宿主显式关掉它来打开。
   */
  readOnly?: boolean;
  /** 根节点的行内样式；默认 `'width:100%;height:100%'`，宿主盒要给出高度。 */
  myStyle?: string;
}

/** `DataPage` 完整的 props。 */
export type DataPageProps = DataPageModelProps & DataPageLayoutProps & DataPageHostProps;

/**
 * `load` 事件的载荷。
 * `authButton` 是已解析的按钮权限：`readOnly: true` 时是只读记录（每个键都是 `false`），
 * 为假时是后端权限表那一行原样（值是 `0` / `1`，不是布尔，另带 `resclassenname` 等后端字段）。
 */
export interface DataPageLoadPayload {
  schemaConfig: CrudLoadPayload['schemaConfig'];
  authButton: Record<string, unknown>;
}

/** `info-card-open` 事件的载荷：被点那一行的资源基础数据。 */
export interface DataPageInfoCardOpenPayload {
  id: string;
  name: string;
  type: string;
}

/**
 * `export-task-created` 事件的载荷：后端刚排上的那个导出任务。
 * 三个标量，没有行、没有查询条件；文件不在这一页产生，要去部署自己的任务列表页取。
 */
export interface DataPageExportTaskPayload {
  /** `'excel'` 是模板导出（`exp`），`'grid_csv'` 是表格导出（`gridexp`）。 */
  mode: 'excel' | 'grid_csv';
  /** 从下拉里选的导出文件类型（`'csv'` / `'qrcode'`）；点按钮主体导出时是 `null`。 */
  fileType: string | null;
  /** 后端给这次导出任务的任务号。 */
  uuid: string;
}

/**
 * `access-denied` 事件的载荷：被拒的那个模型。
 * 只有模型英文名——宿主本来就知道自己传了什么，这条事件是给用户一句交代用的，不带用户信息、不带权限表。
 */
export interface DataPageAccessDeniedPayload {
  /** 被拒的模型英文名，与传进来的 `relatedMeta` 相同。 */
  meta: string;
}

/**
 * 数据页容器：`Crud.vue` 的子部件原件按它的摆法拼成一页，摆哪些由 props 决定。
 *
 * **页级权限（0.4.3）**：挂载时先取一次用户信息（toy-core 的缓存路径 `queryUserInfo(false)`），
 * `auth.resclass` 非空而其中没有 `relatedMeta` 那一行时这一页不给看——容器一条请求都不发
 * （方案、模型配置、查询一个都不取）、画一张「无权限」、根上发一条 `access-denied`。
 * `readOnly` 与 `regions` 这些 props 都绕不过这一判；`auth.resclass` 为空或不在时不设限。
 * 判定抄自视图 `toy-ui/views/ResCrud/ResCrud.vue` 的 `initAuth()`（87-99）的**意图**——
 * 原件那条检查是死代码（98 行无条件把 `isAuth` 置回 `true`），见 README。
 *
 * 事件（Vue 2 选项类型不承载事件签名，逐条列在这里；载荷里出现的行是**显示值**，与表格里看到的一致）：
 * - `load(payload: DataPageLoadPayload)` 方案加载完成，`authButton` 已解析
 * - `query-success(payload: CrudQuerySuccessPayload)` 查询成功
 * - `table-cell-click(payload: CrudTableCellClickPayload)` 单元格点击
 * - `table-selection-change(displayValueList: ToyRow[], rawValueList: ToyRow[])` 勾选变化（补丁 0008 把它从
 *   `TableDetail` 转发到 `CrudTable`，容器再发一次到根上——Vue 2 的 `$emit` 不冒泡）
 * - `table-operation-custom(scope: { $index: number, row: ToyRow }, item: DataPageCustomOperation, rawValue: ToyRow)`
 *   行内自定义操作被点
 * - `info-card-open(payload: DataPageInfoCardOpenPayload)` / `info-card-close()` 右侧信息卡开 / 关
 * - `add-save-success(e)` / `modify-save-success(e)` 新增 / 修改窗口保存成功，载荷是后端接口的返回值
 * - `export-task-created(payload: DataPageExportTaskPayload)` 模板导出 / 表格导出排上了一个后端任务
 * - `access-denied(payload: DataPageAccessDeniedPayload)` 页级权限不给看这个模型（每个实例最多一条，发出后这一页什么都不取）
 *
 * 没有删除相关的事件：0.4.0 不摆删除确认窗口，`rowOperations` 也不放行 `delete`（见 README 的已知限制）。
 *
 * 组件不能被 `Object.freeze`：Vue 2 的 `Vue.extend` 会往选项对象上写 `_Ctor`。
 */
export declare const DataPage: ComponentOptions<Vue>;

/** 模型可设的 props 名单。 */
export declare const DATA_PAGE_MODEL_SETTABLE_PROPS: ReadonlyArray<keyof DataPageModelProps>;

/** 布局选项的名单。 */
export declare const DATA_PAGE_LAYOUT_PROPS: ReadonlyArray<keyof DataPageLayoutProps>;

/** `toolbarButtons` 认的取值表，也是 prop 校验器用的那一张；宿主的目录照它列。 */
export declare const DATA_PAGE_TOOLBAR_BUTTONS: ReadonlyArray<DataPageToolbarButton>;

/** `rowOperations` 认的取值表，也是 prop 校验器用的那一张。 */
export declare const DATA_PAGE_ROW_OPERATIONS: ReadonlyArray<DataPageRowOperation>;
