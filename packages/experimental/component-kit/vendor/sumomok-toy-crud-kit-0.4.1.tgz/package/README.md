# @sumomok/toy-crud-kit

把 toy-ui 的整页组件 `component/Crud/Crud.vue` **原样**（不重写）连同它真正依赖的 toy-core 请求层编译成一个 tgz，
作为内容列的 `toy.crud` 种类挂进宿主。模型能选「看哪张表、什么条件、怎么排序、能不能勾选」，
`Crud` 这条导出永远只读：不能新增、修改、删除、导入、导出。

0.4.0 起多一条导出 `DataPage`：同一批子部件原件按 `Crud.vue` 的摆法拼成一页，**页内摆哪些区域、工具栏留哪几个按钮
由 props 决定**，写能力由宿主用 `readOnly: false` 显式打开（缺省为真，与 `Crud` 一样安全）。
它不是把 `Crud.vue` 重写了一遍：查询区、工具栏、表格、勾选栏、分页器、信息卡、新增 / 修改窗口全是原件，
本包只写了一段布局模板、一份从 `Crud.vue` 的 script 抬出来的数据流（逐段标了源行号）与一张布局选项到原件 props 的映射。
能搬走的最小单位是「一页」而不是一个个部件：部件之间本来就靠 `$refs` 与函数 prop 互相够（见「已知限制」）。

数据不经过宿主：组件用 toy-core 自己的 axios，浏览器直接带着访客的 token 请求部署后端；宿主对这个种类什么都读不到，
回给模型的只有列名与计数（见「宿主接入」）。姐妹包 `@sumomok/toy-surface-kit` 保持不动，本包与它并列在同一个 pnpm 工作区里。

`vue` 与 `element-ui` 由宿主提供（external），element-ui 必须已被宿主 `Vue.use` 注册，且 **element-ui 内部 `require('vue')`
拿到的必须与渲染本组件的是同一份 Vue**（el-table 的 store 由 element-ui 自己 require 的 Vue 建立响应式，两份 Vue 会让表格停在首帧的空表）；
`lodash` 与 `dayjs` 是本包声明的普通依赖，同样不打进产物。本包加载时不 `Vue.use` 任何东西，不改 element-ui 的 `size` / `zIndex`（门禁 + 探针钉住）。

## 导出

| 导出 | 形态 |
|---|---|
| `Crud` | toy-ui `component/Crud/Crud.vue` 原件的 Vue 2 组件对象，只多一条本包混入：实例的 `$notify` 换成盒内提示。不能 `Object.freeze`（Vue 2 会往选项对象上写 `_Ctor`）。只读：信息卡与四个写窗口对它仍是零渲染替身 |
| `DataPage` | 数据页容器（0.4.0 新增）。同一批子部件原件按 `Crud.vue` 的摆法拼成一页；区域与工具栏按钮由 props 决定，`readOnly` 缺省为真。根节点上发十条事件（见「宿主接入」） |
| `containCrud(box)` | 挂载前把宿主元素收拾成盒子：打 `data-toy-crud-box` 标记、置 `position:relative`、把请求层的进度条 `#nprogress`、遮罩 `#is-loading-full-overlay`（本包拷贝）、报错 toast（本包拷贝）、toy-ui 经 element-ui 发出的 `.el-message` 与 element-ui 追加到 body 的 poppers（0.4.1 起，盒子装得下时连同定位边界一起收）都收进盒子；返回注销函数。两条组件导出共用 |
| `setBizBasePath(path)` / `getBizBasePath()` | toy-core 请求层的业务基路径（axios `baseURL`）。只接受根绝对路径，规范成以 `/` 结尾；返回实际写入值。拒收里有承重的一道：补好尾 `/` 之后拿 WHATWG URL 解析器解一遍，`origin` 或 `pathname` 被改写就抛——`https:` 下解析器把 `\` 当 `/`，`/\host/` 会指向另一个源，`%2e%2e` 会被归一掉 |
| `CRUD_READ_ONLY_PROPS` | `Crud` 的宿主写死、模型不可设的 props（冻结对象） |
| `CRUD_MODEL_SETTABLE_PROPS` | `Crud` 的模型可设 props 名单 |
| `DATA_PAGE_MODEL_SETTABLE_PROPS` | `DataPage` 的模型可设 props 名单：`relatedMeta` / `conditions` / `matchMode` / `querySort` / `selectMode` / `isInitQuery` / `customOperations` |
| `DATA_PAGE_LAYOUT_PROPS` | `DataPage` 的布局选项名单：`regions` / `toolbarButtons` / `rowOperations` / `queryExpanded` / `pageSize` / `pageSizes` / `infoCardTabs` |
| `BOX_ATTR` | 标记属性名 `'data-toy-crud-box'` |

导出面的类型是手写的 `types/index.d.ts`：`Crud` 的 props 逐条从 `Crud.vue` 的 `props` 声明推出，
`DataPage` 的 props 与十条事件的载荷逐条写在那里，另有 `Crud` 实例上的公开读方法。

## 搬运规则

1. **源库只读。** 闭包内的文件由 `tools/copy-sources.mjs` 拷进 `src/vendor/`，保留原相对结构，逐文件的相对路径与 sha256 记在 `SOURCES.md`。
   源根从本包位置向上找到同时含三个源库的目录为止（本包在姐妹包之下一层，不能像姐妹包那样按脚本位置推）。
2. **对源码的改动一律是补丁文件。** `patches/*.patch` 一个补丁一个文件，第一行是一行理由，由 `tools/apply-patches.mjs` 按序号打到拷贝件上。
3. **toy-comp 不走桶入口，toy-core 走真实桶入口。** `toy-comp` 别名到 `src/shims/toy-comp.js`——比姐妹包加宽到 7 个组件
   （`TcAwesomeIcon` / `TcNumberComp` / `TcXyComp` / 四个 `TcColumn*`），恰好是 Crud 闭包 import 的那些；原桶会带进
   `menu/tc-*-coll-confirm/main.js` 三个文件，它们在模块求值期 `Vue.use(Element, { size: 'small', zIndex: 2000 })` 并再次 import
   element-ui 的 theme-chalk，进了产物就会改写宿主共享运行时的 element-ui 默认值。`toy-core` 别名到 `src/vendor/toy-core/index.js`
   ——Crud 要 `crudUtil` / `schema` / `config` / `log` / `mixins.user` 以及会发请求的 `service.crud`，姐妹包那个「零网络」替身装不下它。
4. **组件不自己读存储与 cookie；凭据只在 toy-core 的请求层里用，而且只从存储里取。** 这一条替换了姐妹包的「身份与 token 不进组件层」：
   本包的数据本来就是浏览器带访客 token 直连部署后端，token 必须有人读；读它的只能是 `src/vendor/toy-core/api/axios.js` 及其
   `core/token.js` / `core/login.js` / `core/config.js` / `utils/stroageUtil.js` 这一层。门禁第 11 条因此分成三段：
   toy-ui、toy-comp、本包 shims 与入口零 `localStorage` / `sessionStorage` / `document.cookie` / `accessToken` / `Authorization` 读点
   （补丁 `0004` 切掉 `FormItemComp` 里唯一的一处）；toy-core 里触碰它们的文件集合被冻结成一张八个文件的允许表，
   源库重拷后多一个或少一个都失败；整个闭包零「从地址栏取 token」的读点（补丁 `0007`）。
   末一段是承重的：宿主控制台不是这个部署的登录页，地址里的 `?token=` 只可能来自别人给访客的一条链接，而原件的 `getToken()` 认它，
   还用 `setToken()` 把它写进 `accessToken`——正是宿主登录闸读的那个键。这样「谁能碰凭据、凭据从哪来」都是可机械核对的名单，而不是一句承诺。

## 两张替换表（构建期按解析后的路径顶替）

`vite.config.shared.js` 里两张表，都由 `vendorReplacementPlugin` 在 resolveId 阶段按解析后的 vendor 路径匹配——
不匹配导入方写下的字符串，同一说明符在别处再出现也不会替错文件。插件**只改道 `src/vendor/` 之下的导入方**，
而 `src/data-page/DataPage.vue` 不在那里：同一个原件因此可以「`Crud.vue` 拿替身、容器拿真件」。

**`VENDOR_REPLACEMENTS`：谁都拿不到原件**（既不拷贝也不求值，`tools/compute-closure.mjs` 把它们当剪枝点）。

| 组 | 被顶替的原件 | 替身 | 为什么 |
|---|---|---|---|
| 永不渲染的子树 | `Crud/component/CrudMenu`、`common/query/QueryStatistic`、`common/modify/{SaveResultRealbatchDialog, ModifyRealbatchDialog}` | `DeadSubtreeStub.vue`（渲染成注释节点） | 两条导出都不摆左侧菜单、统计查询、删除结果窗口与批量修改窗口，但 `Crud.vue` 静态 import 它们。顶掉之后它们在构建层面不存在，也一并切掉 vuedraggable / @antv/g2 / html2canvas / qiankun |
| 直连取数的值控件 | `TransComp`、`TransMulti`、`AutoNaming`、`OdmTemplate`、`SelectCron`、`AreasComp`、`LinesComp` | `DisabledInputStub.vue`（与姐妹包相同） | 七个控件各自静态闭包直连 `ToyCore.service.crud`；其中 `TransComp` 的「+」会打开关联模型的新增窗口（写路径），`TransMulti` 拖进第二个 Crud（`CrudSelect`） |
| 信息卡里的重子组件 | `SmallCard/component/{resStat, resUseage, resOperation, serviceOperation, eventOperation}.vue` | `DeadSubtreeStub.vue` | `resStat` 要 `vue-count-to`（工作区未装）；后三个在模板里 `require('../image/empty.png')`（webpack 写法）并经 `OperationMicro` 取 toy-comp 桶里本包替身没有的成员；`resUseage` 与它们同属重展示页。卡头、异常信息与关键属性是真件 |
| webpack `require.context` | `common/modify/builder/index.js` | `src/shims/modify-builder.js`（**真实现**） | 原件的两个子模块共四处 `require.context`，vite 不实现。替身用 `import.meta.glob(..., { eager: true })` 扫同样的四个目录，键同样是「文件名大写」，所以 `builder/add/formItemFooter/floor_num.vue` 这类定制表尾真的会出现在对应模型的新增窗口里（探针钉住） |
| 会越界到 body 的 toy-core 模块 | `toy-core/eleui/loading.js`、`toy-core/eleui/message.js` | `toy-core-loading.js` / `toy-core-message.js`（本包拷贝，同一调用面，落在登记的盒子里） | 原件把遮罩与 toast 追加到 `document.body` |
| eval 面 | `toy-core/crud/tableRenderUtil.js` | 调用即抛错 | 原件用 `eval` 求值后端配置的行列颜色表达式；闭包无调用点，只被桶入口带进来 |
| 字体 | `toy-comp/basic/awesome-icon/font-awesome-4.7.0/css/font-awesome.min.css` | 空样式表 | 1.0 MB 字体；图标只出现在被隐藏的导入 / 导出按钮上 |

**`CRUD_ONLY_REPLACEMENTS`：只有 `Crud.vue` 拿替身。**

| 被顶替的原件（对 `Crud.vue`） | `DataPage` 拿到的 | 为什么分开 |
|---|---|---|
| `SmallCard/index.js` | 真件 | `Crud` 的只读语义靠「信息卡与写窗口在构建层面不存在」承载（0.2.x 的探针把 `dialogVisible` 置真也开不出窗口），这一条不因为容器要用真件而松掉 |
| `common/modify/ModifySingleDialog/index.js` | 真件（连 `ModifySingle` → `FormEdit` 子树） | 同上。容器里这两棵子树是否摆出来由 `regions` 决定，能不能写由 `readOnly` 决定 |

这两个原件因此**要**进 `src/vendor/`（容器要 import 它们），门禁第 9 条分两段核对：上表的键一个都不在 vendor 里，下表的键一个都不能少。

另有三个只在模块求值期被 toy-core 桶入口带到、两条导出的路径上永不调用的 npm 库别名到调用即抛错的替身（`src/shims/npm/`）：
`konva/lib/*`（~500 KB）、`svg.js`、`import-html-entry`。

## 十个补丁

| # | 改的文件 | 改了什么 |
|---|---|---|
| `0001` | toy-ui `TableDetailColumn.vue` | 删掉 `cronstrue/i18n` 与它唯一的 cron 列分支（与姐妹包相同） |
| `0002` | toy-ui `DisplayColumn.vue` | 删掉 `DisplayDownload.vue` 的静态 import 与 `display_download` 分支（该文件拖 `@vue-office/*`；与姐妹包相同） |
| `0003` | toy-comp `TcColumnYesno.vue` | 补上 `String(value).toUpperCase` 缺的调用括号，5 处（与姐妹包相同） |
| `0004` | toy-ui `FormItemComp.vue` | 删掉 `token: localStorage.getItem('accessToken')` 与消费它的 `:headers`（搬运规则 4；与姐妹包相同） |
| `0005` | toy-core `crud/crudUtil.js` | 删掉 `getAuthButton` 里的 `console.log(userInfo)`：每次方案初始化都把当前用户的完整信息（含权限表）打到控制台 |
| `0006` | toy-core `api/service/log/index.js` | `frontEventLog` 返回的 Promise 没有任何调用点消费，日志接口一失败就是一次 `unhandledrejection`；吞掉拒绝 |
| `0007` | toy-core `core/token.js` | 删掉 `getToken` / `getToken4a` 从地址栏取 token 的两处分支：`getToken()` 认 `?token=Bearer …` 并 `setToken()` 写进 `accessToken`，任何一条带参数的链接都能改写访客存着的凭据（搬运规则 4；门禁第 11 条第三段 + 探针钉住）。`core/config.js` 里 `isUrlToken: true` 那个默认值随之没有了消费者，留着不动 |
| `0008` | toy-ui `CrudTable.vue` | 补上 `table-selection-change` 的转发。`TableDetail` 在勾选（:520）与单选（:509）两处都发这个事件，`CrudTable` 不接也不发，勾选变化到不了页面；容器要把它当根事件发给宿主（`Crud` 不受影响：它本来就没有这条事件的消费者） |
| `0009` | toy-ui `SmallCard.vue` | 两处：删掉 `initContentJs` 里 `eval(方案下发的 contentJs)` 这条后端代码求值路径（与被替身顶掉的 `tableRenderUtil` 同一类，门禁第 6 条要求产物零 `eval`）；给写死的分段表加一条 `compFilter` 过滤 prop（缺省 `null` = 原行为），`DataPage` 的 `infoCardTabs` 才有落点 |
| `0010` | toy-ui `CrudPagination.vue` | 每页条数与候选表从写死改成两条 prop（`pageSizeDef` 缺省 20、`pageSizes` 缺省原来那七个值），「清空」退回 `pageSizeDef`。原件一条 prop 都没有，`DataPage` 的 `pageSize` / `pageSizes` 只能落在这里；不传时与原行为逐字节相同，`Crud` 因此不变 |

`0008` / `0009` / `0010` 是 0.4.0 放出真件后机械上必须的三处：分别对应「勾选事件断在中间那一层」「产物零 eval」「分页器没有任何 prop」。

探查阶段发现的四个原件缺陷里，第三、第四个已是补丁 `0005` / `0006`；前两个在只读首版的路径上到不了，不改只记：
`Crud/utils/crudCloudPermission.js` 调的 `ToyCore.axios.get` 不存在（`ToyCore.axios` 只有 `getUrl` 等包装），抛出的 TypeError 被
自己的 `try/catch` 吞掉后返回空表——只有 `useCloudPermission: true` 才会走到，首版固定为 `false`；`Crud.vue` 的 `getCustomMode()`
调的 `crudService.getCustomerMode` 在 `service.crud` 上不存在（在 `service.schema` 上）——该方法没有任何调用点。
**复查触发器：`useCloudPermission` 或定制模板进入导出面时。**

## 命令

```sh
pnpm install                     # 在工作区根目录执行；本包是工作区成员
node tools/compute-closure.mjs   # 用 closure.py 按本包的别名 / 替换 / 补丁剪枝算闭包，写 tools/closure-files.txt
node tools/copy-sources.mjs      # 清空 src/vendor 后从源库重新取一遍闭包文件（会覆盖补丁，需接着重打）
node tools/apply-patches.mjs     # 打十个补丁（要从干净的拷贝件开始）
pnpm run build                   # 出 dist/index.js（样式随 JS 注入，全部规则限定在 [data-toy-crud-box] 之下），并写 BUNDLED.json / THIRD-PARTY-LICENSES.txt
pnpm run build:measure           # 量测构建：样式落成 measure/style.css 供门禁第 13 条逐条复核
pnpm run gates                   # 15 类机械门禁（20 行），含两个 jsdom 挂载探针（40 + 32 条断言）
pnpm run probe                   # 单独跑 Crud 的挂载探针
pnpm run probe:data-page         # 单独跑 DataPage 的挂载探针
pnpm run probe:browser           # 浏览器探针：盒子对照矩阵 + 检查表 + popper 的两条边界 + 两份 Vue 的对照，写 probe/browser/RESULT.md
                                 # （要一份现成的 playwright：TOY_PLAYWRIGHT=…/node_modules/playwright/index.js）
pnpm run pack                    # 出 tgz，并对 tgz 内每个文件扫本机绝对路径
```

宿主用 `file:` 依赖装本包，同名 tgz 覆盖会被 pnpm 静默忽略：**内容一变就升 `version` 再 `pnpm run pack`**。

## 宿主接入

顺序固定：写基路径 → 收纳盒子 → 审批 → 挂载。

1. **基路径（D7）。** toy-core 在模块求值期 `axios.create({ baseURL: getBaseURL() })` 一次性读 `window.$toy_env.VUE_APP_BASE_URL`
   （缺省 `/nrms-server/`）。宿主的 `bizBasePath` 配置（根绝对路径，缺省 `/`）要在本包模块求值前写进 `window.$toy_env`；
   求值后再调 `setBizBasePath()` 同样生效——它同时改写 `window.$toy_env` 与已建实例的 `defaults.baseURL`。
2. **盒子（D6）。** 桥挂载前 `const release = containCrud(hostDiv)`，`hostDiv` 就是桥往里追加占位节点的那个元素（Crud 根节点成为它的直接子节点）。
   卸载后调 `release()`；盒子届时可以已经离开文档，在途请求照常结束。盒子这一侧有两条**硬要求**，都由浏览器探针逐条量出来
   （`probe/browser/RESULT.md` 的对照矩阵，1440×900 视口、32rem 高的盒子）：
   - **挂载点要解得出确定的高度。** 组件默认 `myStyle: 'width:100%;height:100%'`，这个百分比要有东西可解：
     桥往里追加占位节点的那个元素给 `height:100%` 时 `.crud` 512px、表体 313px；改成 `height:auto` 时 `.crud` 塌到 259px、
     表体塌到 60px，20 行数据全挤在那一条里（**不报错、照样能用**，所以只能靠量）。
   - **element-ui 与本包产物必须共用同一份 Vue。** 产物把 `vue` / `element-ui` 当 external，由宿主提供；宿主若让
     `Vue.use(ElementUI)` 装进 A 份、el-table 内部的列注册与 `nextTick` 走 B 份，表头会停在空的 `<thead><tr></tr></thead>`，
     element-ui 的 `TableLayout.updateElsHeight` 在 `headerHeight < 2` 时用 `Vue.nextTick` 重排自己，**主线程被这条自我重排占死**
     （页面此后不发任何请求，连 CDP 都不回应）。本包的浏览器探针就栽在这上面一整天，成因与复现见 `probe/browser/README.md`。

   盒子的**定位、写死的块尺寸、裁切都不是必要条件**：`position:static` / `overflow:visible` / 百分比高度 / 挂载后才给宽度，
   四种变体逐一量过，页面照样画出 20 行（`containCrud` 自己会把 `position:static` 的盒子提成 `relative`，`src/contain.js` 第 68 行）。
   盒子的高度还决定 poppers 收不收得进来：装得下就连同定位边界一起收进盒子，装不下就留在 body 上（见已知限制）。
3. **审批（D4）。** 由宿主在挂载前走审批缝；本包不做审批、不知道会话。拒绝即不挂载，什么都不画。
4. **props（D3）。** `{ ...模型可设的七个, ...CRUD_READ_ONLY_PROPS }`。模型可设：`relatedMeta`（必填）、`conditions`、`matchMode`、
   `querySort`、`selectMode`、`isExpandQuery`、`isInitQuery`；宿主写死：`isReadOnly: true`、`type: 'default'`、`urlConfig: null`、
   `hideButton` 十个写 / 导出键全真、`hideComp: { menu, card }`；`crudUrl` 取默认，`tableCustomOperations` /
   `tableCustomComps` / `queryFormCustomComps` / `rowStyle` / `smallCardBeforeOpen` 不设。探针证明：画出的动作按钮只有「查询」「清空」（另有分页器的
   `btn-prev` / `btn-next` 两个只有图标的按钮），表格无操作列，把 `dialogVisible.*` 置真也没有窗口。
5. **回给模型的（D5）。** `load` 事件：`schemaConfig.query.grid.gridItems` 里 `isShow !== '0'` 的列的 `relatedMetaAttr` + `alias`；
   `query-success`：`page.total`、`displayValue.length`、`page.currentPage`——行永不回传；`table-cell-click`：`row`（显示值）与
   `column.property`（被点列的 attr），宿主按显示列裁成显示值。`Crud` 没有 selection-change 事件，只读首版不轮询 `doGetSelection()`。

### 挂 `DataPage`

前三步（基路径、盒子、审批）与上面逐字相同，盒子与 `containCrud` 两条导出共用。第四、五步换成：

4. **props。** 三组，缺省值就是「全都摆出来、什么都不能写」：
   - **模型可设**（`DATA_PAGE_MODEL_SETTABLE_PROPS`）：`relatedMeta`（必填）、`conditions`（缺省 `[]`）、
     `matchMode`（`'AND'`）、`querySort`（`{}`）、`selectMode`（`'checkbox'`）、`isInitQuery`（`true`）、
     `customOperations`（`[]`；每项只认 `{ name, label }` 两个字段，原件还认的 `icon` / `tooltip` / `key` 一律不放行）。
   - **布局选项**（`DATA_PAGE_LAYOUT_PROPS`，缺省全开）：`regions`（八个区域 `query` / `toolbar` / `table` / `operate` /
     `pagination` / `infoCard` / `addForm` / `modifyForm`，`table` 不可关）、`toolbarButtons`（`add` / `imp` / `exp` /
     `gridexp` / `batch` / `search` / `clear`）、`rowOperations`（0.4.0 起只认 `modify`）、`queryExpanded`（缺省 `false` = 折叠成一行）、
     `pageSize`（20）、`pageSizes`（`[10,20,50,100,200,500,1000]`）、`infoCardTabs`（信息卡分段）。
     每条都有 Vue prop 校验器：取值不在名单里、区域表里出现不认识的键、`table: false`、`customOperations` 缺 `name` / `label`，
     在宿主的开发版 Vue 下都会当场报出来（Vue 2 的校验器只在非 production 构建里跑）。
   - **宿主决定**：`readOnly`（**缺省 `true`**）、`myStyle`（缺省 `'width:100%;height:100%'`）。
   `readOnly` 为真时把与 `CRUD_READ_ONLY_PROPS.hideButton` 逐键相同的那张表盖在 `toolbarButtons` / `rowOperations` 的解析结果之上，
   并把 `isReadOnly` 传给原件（`authButton` 整表取只读值），新增 / 修改窗口即使在 `regions` 里也不渲染。
   **写能力只能由宿主显式 `readOnly: false` 打开，容器不替谁做这个决定。**
5. **根事件十条。** 桥只能在它挂载的那个组件上挂监听器，而 Vue 2 的 `$emit` 不冒泡，所以这十条都发在 `DataPage` 根上：

   | 事件 | 载荷 |
   |---|---|
   | `load` | `{ schemaConfig, authButton }`。`authButton` 是**已解析**的按钮权限（`readOnly` 为真时是全 `false` 的只读记录，为假时是后端权限表那一行原样，值是 `0` / `1`）。顺序是承重的：`authButton` 在发这条事件之前就定下来 |
   | `query-success` | 后端查询接口的 `data`（`rawValue` / `displayValue` / `ref` / `page`）。回给模型的仍只该是 `page.total`、`displayValue.length`、`page.currentPage` |
   | `table-cell-click` | el-table 的 `cell-click` 原样透传：`{ row, column, cell, event }`，`column.property` 是被点列的 attr |
   | `table-selection-change` | `(displayValueList, rawValueList)` 两张表，勾选与单选都会发（补丁 `0008` 把它从 `TableDetail` 转发到 `CrudTable`，容器再发一次到根上） |
   | `table-operation-custom` | `(scope, item, rawValue)`：`item` 就是 `customOperations` 里的那一项。容器自己不做任何事 |
   | `info-card-open` / `info-card-close` | 开：`{ id, name, type }`（被点那一行）；关：无载荷 |
   | `add-save-success` / `modify-save-success` | 后端保存接口的返回值。发出后容器自己会重查一次 |

   **没有删除相关的事件**：0.4.0 不摆删除确认窗口，`rowOperations` 也不放行 `delete`（见已知限制）。

## 已知限制（Known Limitations）

**请求层会整页跳转（D8，记录不修）。** `toy-core/api/axios.js` 的请求拦截器在存储里没有 token 时、响应拦截器在 HTTP 401 或业务码 3 时
调 `redirectLogin()`（`window.location.href = 登录地址`）。只在同源部署且宿主的登录闸保持 token 新鲜时可接受；探针在 token 在场时钉住零跳转。

**只读是对表里的数据说的：每次查询都会往后端写一条审计记录。** `Crud.vue` 查询成功后调 `crudEventLog(relatedMeta, 'query', queryParams)`，
请求层带着访客的 token POST `<基路径>/nrms-resourcehistory/api/log/frontevent/`，写下一条记在访客名下的记录：`app_enname` 是宿主页面的
pathname，`event_title` 是「查询」，`resclassenname` 是表名，`event_data` 里是这次查询的参数——宿主传下来的隐藏 `conditions` 也在其中。
补丁 `0006` 只吞掉这个请求失败时的拒绝，不阻止它发出。**复查触发器：部署不愿意让控制台里的查询进他们的审计流水时**——那时要在挂载前顶掉
`ToyCore.core.log` 的这个出口。

**同屏多个块共用两个单例。** nprogress 与请求遮罩都是模块级单例，落在最后一次 `containCrud` 的盒子里，注销后退回上一个（一个都不剩时进度条退回 `body`，没有样式、不可见——nprogress 只认选择器且对选不到的父元素不判空，这一步是卸载后在途请求不抛错的前提；探针钉住）；
请求层不知道是哪个块发起的请求。

**必填查询条件为空时的提示走宿主的 element-ui。** `QueryCondition` 用 `this.$message.warning()`（element-ui，挂到 body），
`containCrud` 用 MutationObserver 把新落到 body 的 `.el-message` / `.el-notification` 挪进盒子并改成绝对定位；
这依赖宿主页面上的 element-ui toast 都来自本包的块（宿主自己的 UI 不是 element-ui）。

**trans / 多选 / 自动命名 / 编码模板 / cron / 区域 / 线路七种值控件是禁用输入框。** 方案里这类属性的查询条件输入框不可编辑，
显示「该控件在本环境不可用」。**复查触发器：需要按关联属性过滤时**——那时要么接上 `TransComp`（连同它的写路径「+」按钮一起审），要么由宿主传候选值。

**图标没有字体。** `TcAwesomeIcon` 渲染成空的 `<i class="fa fa-*">`；本包不带 font-awesome。`Crud` 上没有任何可见的图标位。

**能搬走的最小单位是「一页」，不是一个个部件。** 拼装探针（`spike-parts/`，不入库）逐条量过：部件之间本来就靠 `$refs` 互相够——
查询条件从 `$refs.crudQueryCom.getData()` 来、页码从 `$refs.crudPagination.getData()` 来、选中行与列名从 `$refs.crudTable.getData()` 来、
刷新信息卡要 `$refs.crudSmallCard.refreshData()`；`CrudAction` 还声明了一条必填的 `crudRef`，顺着它取 `crudRef.$refs.crudTable.getData()`；
`SmallCard` 用函数 prop `refreshParentFn` 回调父页。所以 `DataPage` 是一个「内部摆法可配」的容器，而不是一堆可以自由组合的零件；
`controller.js` 因此做成混入（抄来的方法一字不改地成立），而不是外部 store。

**`crudRef` 的两条 Vue 警告（已绕开，记录）。** 拼装探针照抄原件写 `:crud-ref="this"`，Vue 2.7 的开发期渲染代理观察这个 props 值时
会报 `Property "__ob__" must be accessed with "$data"` 与 `"__v_isRef" is not defined` 两条警告（出自这条绑定本身，不出自拼装）。
容器改成传 `Object.freeze({ $refs: this.$refs })`：冻结对象不可扩展，Vue 的 observe 直接跳过，两条警告随之消失，
`CrudAction` 顺着它取选中行的那条路不变（`$refs` 是同一个对象）。**原件 `Crud.vue` 里那条绑定没动。**

**不提供删除（0.4.0 起）。** 删除确认窗口（`SaveResultRealbatchDialog`）在两条导出上都仍是零渲染替身：行内那个图标点下去
只把内部的 `dialogVisible.crudDeleteVisible` 置真，没有窗口会打开。放一个点了没反应的图标比不放更糟，所以
`rowOperations` 在名单层面只认 `modify`，写 `'delete'` 会被 prop 校验器当场拒掉，事件表里也没有删除那一条。
**恢复条件：删除窗口从替身表里放出来、它的批量删除接口审过**——那时把 `'delete'` 加回 `DATA_PAGE_ROW_OPERATIONS`，
`resolveHideButton` 的映射（`delete: !rows.has('delete')`）与 `Crud.vue` 1642-1651 那段 `delete-save-success` 一起回来。

**`toolbarButtons` 只决定显隐，不决定先后。** 按钮顺序写死在 `CrudAction.vue` 的模板里（新增 / 模板导入 / 模板导出 / 表格导出 / 批量 ｜ 查询 / 清空），
不重写那份模板就换不了；本包不重写原件，所以这条 prop 是一张「留哪几个」的名单，传进去的先后被忽略。

**信息卡只有两段是真件。** `wrong-info`（异常信息）与 `attributes`（关键属性）是原件；`operation` / `related-stat` / `useage` 与
服务 / 事件两个操作面是零渲染替身（见替换表）。`infoCardTabs` 是一层过滤：它只能从方案下发（或默认）的那张分段表里减，减不出新的段。

**poppers 由 `containCrud` 收进盒子，收不下的那些仍留在 body 上（0.4.1 改）。** 窗口本身 `append-to-body=false` +
`dialog-absolute` + `dialog-max`，铺满宿主盒、不越界（浏览器探针量到 `.el-dialog` 1440×512 @(0,0) 与宿主盒逐像素相同，
落到 body 上的窗口 0 个）；但 element-ui 的 `el-select` / `el-date-picker` 缺省把下拉挂到 `document.body`
（`popper-append-to-body` 默认真）。0.4.0 量到的是：下拉 110×252 @(993,513)、宿主盒 1440×512 @(0,0)，**下沿比盒子低 253px**——
盒子的 `overflow: hidden` 管不到 body 的子节点，所以这一截既不会被裁掉，也不会被推出视口（贴着视口底时 element-ui 自己会向上翻），
但它画在宿主页面上，盖住盒子下面的东西。

0.4.1 起 `containCrud` 的观察器把这类 popper 收进盒子，并把 element-ui 内置 popper.js 的 `boundariesElement`
从 `viewport` 换成盒子本身。**两件事必须一起做**：只收不换边界，下拉仍按视口摆，进了 `overflow:hidden` 的盒子反而被裁掉；
只换边界不收，那份 popper.js（0.6 分支）用 `getOffsetRect(boundariesElement)` 取边界，拿的是相对盒子自己 `offsetParent`
的 `offsetTop/offsetLeft`，而 popper 的坐标相对 `documentElement`，两套坐标只在盒子的 `offsetParent` 恰好是文档时才重合。
收进盒子之后 `getOffsetParent(popper) === box`，popper.js 走 `{0, 0, clientWidth, clientHeight}` 那一支，边界与坐标同在盒子里：
放不下就翻到参照物上方，还放不下就贴着盒子的边。探针量到的三档：盒子在视口顶时 `top-start`、越出盒子 0px；
盒子贴着视口底（下沿离视口底 8px）时仍是 `top-start`、越出盒子 0px、越出视口 0px；盒子只有 224px（装不下 252px 的下拉）时**不收**，
父节点仍是 body、整段可见——收进一个裁切的盒子会少掉一截，留在 body 上至少是全的。

**两类不收**：`el-tooltip__popper`（表格单元格的溢出提示）的 popper 元素不是组件根节点，`__vue__` 上没有 popper.js 实例，
拿不到就不动它；宿主自己页面上的 poppers 参照物不在盒子里，观察器按 `box.contains(referenceElm)` 一眼分开。
**复查触发器：element-ui 大版本变了，或盒子矮到装不下页内的某张面板时**——前者会让 `popperJS._options` 这条路走不通
（走不通就整体退回 0.4.0 的行为，不会画错），后者在探针里是第三档那条检查。

**闭包带着整个 toy-core。** 真实桶入口把 gis / mobile / uavServer / 微应用 / 水印等 107 个文件一起带进来，闭包 193 个文件 / 25,814 行
（toy-core 107、toy-ui 72、toy-comp 14）——0.2.3 是 177 个文件 / 23,775 行，0.4.0 多出来的 16 个全是 toy-ui：
信息卡 6（`SmallCard` + `CardContent` + 异常信息 + 关键属性 + `initData` 混入 + 桶）、新增 / 修改窗口 8、定制表尾 1、弹框混入 2 里的其中若干。
**新增 npm 说明符零个**：这 16 个文件没有引进任何新的裸规格（`tools/compute-closure.mjs` 的输出逐条打印裸规格，与 0.2.3 的名单一致）。
随之打进产物的 npm 库仍是 40 个（直接的 axios、nprogress、localforage、qs、crc-32、crypto-js、
mitt、json5、array-to-tree、ua-parser-js、resize-observer-polyfill、coordtransform、color、randomcolor、`dayjs/plugin/isBetween`，
连同它们的传递依赖）——完整名单、版本与条款见随包的 `BUNDLED.json`，许可证正文见随包的 `THIRD-PARTY-LICENSES.txt`，两份都由 `pnpm run build`
从 rollup 的模块图上生成，门禁第 15 条钉住「每个内联库都有条款和正文」。产物 `dist/index.js` 957,731 字节 / gzip -9 后 241,929 字节
（0.2.3 是 878,120 / 222,021，+9.1% / +9.0%）；其中样式 30,004 字节 / gzip 5,488 字节、191 条规则（0.2.3 是 18,762 / 3,687 / 127），
全部以 `[data-toy-crud-box]` 开头（`html` / `body` / `:root` 变成盒子本身，
nprogress 加在盒子上的 `.nprogress-custom-parent` 接在盒子本身上）。tgz 约 289 KB（17 个文件：产物、类型、三份台账与十个补丁；台账 `MEASUREMENTS.json` 与探针结果表不在其中）。
**这两个数不是宿主要下载的全部**：`lodash` 与 `dayjs` 是 external，由宿主装、打进宿主自己的包——`lodash` 4.18.1 自带的构建
545,945 字节 / gzip 96,961 字节，`dayjs` 1.11.23 的 `dayjs.min.js` 7,161 字节 / gzip 3,047 字节。宿主的第三方声明要把这两个也算上
（`MEASUREMENTS.json` 的 `external` / `external_sizes`）。
**复查触发器：产物超过 1 MB 时**——那时按需替换 crypto-js（只有 token 加密开关打开才用到）与 ua-parser-js。

**TransComp 仍是禁用输入框（这次重新审过，结论不变）。** 放出信息卡与写窗口之后，`TransComp` 是唯一还挡在「按关联属性过滤 / 填关联值」
前面的控件，但它的闭包有三处过不了本包的线：`import { getScrollContainer } from 'element-ui/src/utils/dom'`（深进一个**外置**包的源码目录，
产物里会多一份 element-ui 的 dom 工具，而不是用宿主注册的那一份）；三个 `() => import()` 动态子件
（`TransPlusDialog` / `TransCascadeDialog` / `../modify/ModifySingleDialog`），在 `formats: ['es']` 的库构建里会切出独立块，
与门禁第 5 条「dist 只有 index.js 一个文件」冲突；而 `TransPlusDialog` 里又 `() => import('../../../../Crud')` **回头拉整个 `Crud`**，
`TransCascadeDialog` 再拖进 `TransCascade` 与 `CustomMade/CommonNeSelect` 两棵新子树。三条都不是改一行能绕开的，**保持替身**。
**复查触发器：需要按关联属性过滤时**——那时先审 `TransComp` 的「+」写路径与这三处。

**构建不是逐字节可复现的。** 同一份源码连着构建三次，会出现 401 / 401 / 398 两种模块数与两份不同的产物；差异只在 esbuild 压缩后的
局部符号名（`FormItemComp.vue` 把 `DisabledInputStub.vue` 同时静态与动态 import，vite 每次构建都会报这条警告）。
功能上没有差别，门禁与探针跑的都是当次的产物；但这意味着「重跑一次构建就能对出同一个 sha256」不成立，
tgz 的 sha256 只对得上那一次打包。

**手写 `.d.ts` 没有编译期靠山。** 门禁只钉三份导出名单一致，props 字段改了不会报错；实际验收场是宿主侧的类型检查。

**门禁里的探针是 jsdom 与假后端，浏览器那一份要另跑。** `probe/backend.mjs` 是能过 `schemaCheckUp` 的最小方案加几行数据（三个模型：`probe_device`、
方案为空的 `probe_missing`、带定制表尾的 `floor_num`）；el-table 在 jsdom 下画得出 `tr` 画不出 `td`，列的正确性断言落在 store 的列定义上。
`probe/render.mjs`（`Crud`，40 条断言）与 `probe/data-page.mjs`（`DataPage`，32 条断言）都在门禁里跑。
真浏览器那一份（`probe/browser/`，chromium + 同一个假后端）量的是 jsdom 给不出的几何与交互——折叠高度、窗口铺满宿主盒、
翻页不刷新页面、popper 收在哪、盒子的对照矩阵——它需要一份现成的 playwright，所以**不在门禁里**；结果表在仓库的 `probe/browser/RESULT.md`（不随 tgz 走，tgz 里只有产物、类型、三份台账与十个补丁）。
真机验收仍在宿主侧。

**浏览器探针的 26 条检查里有 2 条没跑。** 24 条通过；没跑的两条是「落到 body 上的 `.el-message` 被挪进盒子」
（提示只活 3 秒、逐次跑时有时无，不放会抖的断言，改由 jsdom 探针钉「body 上零越界节点」）与「行内『删除』打开删除确认窗口」
（0.4.0 起就不放行）。这一页曾经整页跑不完，根因是探针自己的 dev server 把 Vue 打了两份（2026-09-18 定位并修好）：
成因、复现与「宿主必须共用同一份 Vue」这条接入要求都在 `probe/browser/README.md`。
**复查触发器：宿主报告块挂上去之后整页卡住时**——先按那一页的两份 Vue 对照量一遍。
