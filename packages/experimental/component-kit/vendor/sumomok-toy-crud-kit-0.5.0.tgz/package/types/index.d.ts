/**
 * `@sumomok/toy-crud-kit` 导出面的手写类型。
 *
 * `Crud` 是 Vue 2 选项对象（`@vitejs/plugin-vue2` 的 SFC 编译产物 + 本包一条混入），源库无 TypeScript、
 * 无 `.d.ts`，本文件由 `src/vendor/toy-ui/component/Crud/Crud.vue` 的 `props` 声明逐条推出，不是生成物：
 * vendor 树的 props 改了必须同步改这里；`tools/gates.mjs` 只钉住导出名，钉不住字段。
 *
 * 后端方案（schema）驱动的对象一律带索引签名：字段集合由后端下发，这里只列闭包读到的那些。
 */
import type Vue from 'vue';
import type { ComponentOptions } from 'vue';

/** 一行数据。列名与值由后端方案决定，静态上不可枚举。 */
export type ToyRow = Record<string, unknown>;

/** 一条查询条件；`op` 取 `EQ` / `LIKE` / `IN` / `BETWEEN` 等后端匹配策略。 */
export interface CrudCondition {
  key: string;
  op: string;
  value: unknown;
}

/** 查询排序：`{ asc: 属性名 }` 或 `{ desc: 属性名 }`，同时给时 `asc` 优先。 */
export interface CrudQuerySort {
  asc?: string | null;
  desc?: string | null;
}

/** 模型可设的 props（D3）。名单与 {@link CRUD_MODEL_SETTABLE_PROPS} 一致。 */
export interface CrudModelProps {
  /** 模型英文名，必填；宿主按与 toy.table 的 dataSource meta 相同的字符集校验。 */
  relatedMeta: string;
  /** 隐性查询条件：界面不显示、清空不清除，与用户在查询表单里填的条件合并后发给后端。默认 `[]`。 */
  conditions?: CrudCondition[];
  /** 条件关系。默认 `'AND'`。 */
  matchMode?: 'AND' | 'OR';
  /** 查询排序。默认 `{}`（后端默认序）。 */
  querySort?: CrudQuerySort;
  /** 选择列模式；`null` 不画选择列。组件默认 `'checkbox'`。 */
  selectMode?: 'checkbox' | 'radio' | null;
  /** 查询条件面板是否展开。默认 `false`。 */
  isExpandQuery?: boolean;
  /** 挂载后是否立刻查询一次。默认 `true`。 */
  isInitQuery?: boolean;
}

/** 宿主写死、模型不可设的 props（D3）。值见 {@link CRUD_READ_ONLY_PROPS}。 */
export interface CrudHostFixedProps {
  isReadOnly: true;
  type: 'default';
  urlConfig: null;
  hideButton: Readonly<Record<'add' | 'update' | 'delete' | 'imp' | 'exp' | 'gridexp' | 'expimphuge' | 'batchUpdate' | 'batchDelete' | 'labelPrint', true>>;
  hideComp: Readonly<{ menu: true; card: true }>;
}

/** 宿主自己决定、既不在模型名单也不在只读名单里的 props。 */
export interface CrudHostProps {
  /** 根节点的行内样式；组件默认 `'width:100%;height:100%'`，盒子要给出高度。 */
  myStyle?: string;
  /** 查询前是否校验必填条件。默认 `true`；为空时 toy-ui 经宿主 element-ui 的 `$message` 提示（被 `containCrud` 挪进盒子）。 */
  isQueryValidate?: boolean;
}

/** `Crud` 完整的 props。 */
export type CrudProps = CrudModelProps & CrudHostFixedProps & CrudHostProps;

/** 方案里的一列。 */
export interface CrudGridItem {
  /** 行数据里取值的字段名。 */
  relatedMetaAttr: string;
  /** 列头文字。 */
  alias?: string;
  /** `String(isShow) !== '0'` 才显示。 */
  isShow?: boolean | string | number;
  isSortable?: boolean | string | number;
  [key: string]: unknown;
}

/** `load` 事件的载荷：方案配置的深拷贝。回给模型的只有 `query.grid.gridItems` 里显示列的 `relatedMetaAttr` + `alias`（D5）。 */
export interface CrudLoadPayload {
  schemaConfig: {
    query?: { metaAlias?: string; grid?: { gridItems?: CrudGridItem[]; [key: string]: unknown }; [key: string]: unknown };
    add?: Record<string, unknown>;
    modify?: Record<string, unknown>;
  };
}

/** `query-success` / `recieve-data` 事件的载荷：后端查询接口的 `data`。回给模型的只有 `page.total`、`displayValue.length`、`page.currentPage`（D5），行永不回传。 */
export interface CrudQuerySuccessPayload {
  rawValue: ToyRow[];
  displayValue: ToyRow[];
  ref: ToyRow[];
  page: { total: number; currentPage: number; pageSize: number };
  [key: string]: unknown;
}

/** `table-cell-click` 事件的载荷：el-table 的 `cell-click` 原样透传；`column.property` 是被点列的 `relatedMetaAttr`。 */
export interface CrudTableCellClickPayload {
  row: ToyRow;
  column: { property?: string; label?: string; [key: string]: unknown };
  cell: HTMLElement | null;
  event: Event;
}

/** `Crud` 实例上宿主可调的公开方法（原件标 `@public` 的那些）。通过桥的 `instanceRef` 拿到实例后调用；只读首版只用读方法。 */
export interface CrudInstance extends Vue {
  /** 表格全部数据；无数据时返回 `{}`。 */
  doGetTableData(): { rawValueList: ToyRow[]; displayValueList: ToyRow[] } | Record<string, never>;
  /** 当前选中数据（含显示列名单 `sourceShow` / `sourceNameShow`）。没有 selection-change 事件，首版不轮询它。 */
  doGetSelection(): { selection: ToyRow[]; selectedRawValue: ToyRow[]; source: string[]; sourceName: string[]; sourceShow: string[]; sourceNameShow: string[]; [key: string]: unknown };
  /** 按 `id` / `int_id` 设置选中行。 */
  doSetSelection(dataList: ToyRow[]): void;
  /** 清空选中状态。 */
  doClearSelection(): void;
  /** 方案配置的深拷贝。 */
  doGetConfig(): { schemaConfig: CrudLoadPayload['schemaConfig'] };
  /** 方案是否通过检查；`false` 时根节点是注释，盒内有一条提示。 */
  isSchemaRight: boolean;
  /** 最近一次查询结果（冻结）；未查询时 `{}`。 */
  resultData: CrudQuerySuccessPayload | Record<string, never>;
}

/**
 * toy-ui 的 `Crud.vue` 原件 + 本包一条混入（实例的 `$notify` 换成盒内提示）。
 *
 * 事件（Vue 2 选项类型不承载事件签名，逐条列在这里；只读首版能触发的只有前六个）：
 * - `load(payload: CrudLoadPayload)` 方案加载完成
 * - `loaded()` 表格挂载完成
 * - `query-success(payload: CrudQuerySuccessPayload)` / `recieve-data(payload)` 查询成功（同一载荷发两次）
 * - `table-cell-click(payload: CrudTableCellClickPayload)` 单元格点击
 * - `btn-click-query()` / `btn-click-clear()` 查询 / 清空按钮
 * - `table-operation-custom(scope, item, rawValue)` 自定义操作（`tableCustomOperations` 未设，不会触发）
 * - `small-card-close()` / `operation-event(e)` 信息卡（`hideComp.card`，不会触发）
 * - `add-save-success(e)` / `modify-save-success(e)` / `delete-save-success(e)` 写窗口（零渲染替身，不会触发）
 *
 * 组件不能被 `Object.freeze`：Vue 2 的 `Vue.extend` 会往选项对象上写 `_Ctor`。
 */
export declare const Crud: ComponentOptions<Vue>;

/** 宿主盒的标记属性名 `data-toy-crud-box`。 */
export declare const BOX_ATTR: 'data-toy-crud-box';

/**
 * 把宿主元素收拾成 Crud 的盒子：打标记、置 `position:relative`、把请求层的进度条 / 遮罩 / toast、
 * toy-ui 经 element-ui 发出的 `$message`、以及 element-ui 追加到 body 的 poppers（下拉、日期面板、
 * 下拉菜单、行内图标的提示；盒子装得下时连同它们的定位边界一起收）都收进盒子。
 * 必须在挂载（第一次请求）之前调用。
 * @param box 桥挂载 Crud 的宿主元素。
 * @returns 注销函数。
 */
export declare function containCrud(box: HTMLElement): () => void;

/**
 * 设置 toy-core 请求层的业务基路径（axios `baseURL`）。只接受根绝对路径，规范成以 `/` 结尾。
 * 宿主还应在本包模块求值前写好 `window.$toy_env.VUE_APP_BASE_URL`（toy-core 在求值期读它一次）。
 * @param path 如 `/` 或 `/nrms-server`。
 * @returns 实际写入的路径。
 */
export declare function setBizBasePath(path: string): string;

/** 当前生效的业务基路径。 */
export declare function getBizBasePath(): string;

/** 只读首版宿主写死的 props（D3），已冻结；宿主展开在模型 props 之后。 */
export declare const CRUD_READ_ONLY_PROPS: Readonly<CrudHostFixedProps>;

/** 模型可设的 props 名单（D3）。 */
export declare const CRUD_MODEL_SETTABLE_PROPS: ReadonlyArray<keyof CrudModelProps>;

/** `DataPage` 可开关的区域名。`table` 永远在。 */
export type DataPageRegion = 'query' | 'toolbar' | 'table' | 'operate' | 'pagination' | 'infoCard' | 'addForm' | 'modifyForm';

/**
 * 工具栏按钮键。`exp` 是模板导出、`gridexp` 是表格导出，两者都只排一个后端导出任务（不下载文件）；
 * `batch` 是批量下拉（批量修改 / 批量删除，0.5.0），两个窗口收在盒子里。
 *
 * 0.4.2 起不放行 `imp`（模板导入）：文件交给导入任务后，成败只在部署自己的任务列表页看得到。写它会被
 * prop 校验器当场拒掉，恢复条件见 README 的已知限制。
 */
export type DataPageToolbarButton = 'add' | 'exp' | 'gridexp' | 'batch' | 'search' | 'clear';

/**
 * 行内操作键：`modify`（修改图标）与 `delete`（删除图标，0.5.0）。删除先弹原件的气泡确认，确认后删除窗口
 * 在盒子里执行并画出结果；请求带的 `deleteGisResource` 见 {@link DataPageDeleteGisResource}。
 */
export type DataPageRowOperation = 'modify' | 'delete';

/** 信息卡分段键（原件 `SmallCard` 的 `cardSmallComp` 取值）。本包只有 `wrong-info` 与 `attributes` 是真件。 */
export type DataPageInfoCardTab = 'wrong-info' | 'operation' | 'related-stat' | 'useage' | 'attributes';

/** 模型可设的自定义操作；点击只发 `table-operation-custom`，容器自己不做任何事。 */
export interface DataPageCustomOperation {
  /** 操作名，回传在 `table-operation-custom` 的第二个参数里。 */
  name: string;
  /** 行内显示的文字。 */
  label: string;
}

/** 模型可设的 props。名单与 {@link DATA_PAGE_MODEL_SETTABLE_PROPS} 一致。 */
export interface DataPageModelProps {
  /** 模型英文名，必填。 */
  relatedMeta: string;
  /** 隐性查询条件：界面不显示、清空不清除。默认 `[]`。 */
  conditions?: CrudCondition[];
  /** 条件关系。默认 `'AND'`。 */
  matchMode?: 'AND' | 'OR';
  /** 查询排序。默认 `{}`（后端默认序）。 */
  querySort?: CrudQuerySort;
  /** 选择列模式。默认 `'checkbox'`。 */
  selectMode?: 'checkbox' | 'radio';
  /** 挂载后是否立刻查一次。默认 `true`；容器把原件的两条首查路径归一，这条因此在任何区域组合下都作数。 */
  isInitQuery?: boolean;
  /** 行内多出来的操作。默认 `[]`（不画操作列）。 */
  customOperations?: DataPageCustomOperation[];
}

/** 布局选项。名单与 {@link DATA_PAGE_LAYOUT_PROPS} 一致；缺省值就是「全都摆出来」。 */
export interface DataPageLayoutProps {
  /** 哪些区域摆出来。默认八个全开；`table: false` 会被开发版 Vue 拒绝。 */
  regions?: Partial<Record<DataPageRegion, boolean>>;
  /** 工具栏留哪几个按钮。默认是 {@link DATA_PAGE_TOOLBAR_BUTTONS} 那六个全留（0.5.0 起含 `batch`）。顺序由 `CrudAction.vue` 的模板写死，这条只决定显隐。 */
  toolbarButtons?: DataPageToolbarButton[];
  /** 行内留哪几个操作。默认 `['modify', 'delete']`（0.5.0 起含 `delete`）。 */
  rowOperations?: DataPageRowOperation[];
  /** 查询区是否展开。默认 `false`（折叠成一行）。 */
  queryExpanded?: boolean;
  /** 每页条数的初值，也是「清空」退回的值。默认 `20`。 */
  pageSize?: number;
  /** 每页条数下拉里的候选。默认 `[10, 20, 50, 100, 200, 500, 1000]`。 */
  pageSizes?: number[];
  /** 信息卡里渲染哪些分段。默认五段全给（其中三段是零渲染替身）。 */
  infoCardTabs?: DataPageInfoCardTab[];
  /**
   * 名称与关联列的链接能不能点（0.5.0，只能由视图设）。点了照常发 `info-card-open`；卡画不画仍只看 `regions.infoCard`。
   * 视图把卡放在页外（另一个块接 `info-card-open`）时写 `true`、`regions.infoCard` 写 `false`。默认 `false`（0.4.x 的行为：
   * 链接只在卡画在页内时能点）。
   */
  infoCardLinks?: boolean;
}

/** `abilities` 的键（0.4.5）。取值表见 {@link DATA_PAGE_ABILITY_KEYS}。 */
export type DataPageAbilityKey = 'create' | 'update' | 'delete' | 'import' | 'export';

/**
 * 宿主按登录的这个人的权限算出来的能力表（0.4.5）。闭合的五个键，每个都可不写，值是布尔：
 * - `create: false` 拿掉工具栏「新增」（`add`）；
 * - `update: false` 拿掉行内修改图标（`modify`）与批量下拉里的「批量修改」；
 * - `delete: false` 拿掉行内删除图标（`delete`）与批量下拉里的「批量删除」；
 * - `export: false` 拿掉「模板导出」（`exp`）与「表格导出」（`gridexp`）；
 * - `import: false` 对应的模板导入本来就不在名单里，写了只是把规则写全。
 *
 * 为 `true` 或不写 = 布局说了算；**只能拿掉、不能添上**布局没列的入口。一个入口画得出来，当且仅当
 * 布局列了它、`readOnly` 不盖掉它、`abilities` 没有为它写 `false`。不认识的键、不是布尔的值逐个忽略
 * （开发版 Vue 下报一条 prop 校验警告）。改这条 prop 之后入口随之增减，不重挂、不重查。
 */
export type DataPageAbilities = Partial<Record<DataPageAbilityKey, boolean>>;

/**
 * 删除时怎么处理这条记录绑定的空间资源（0.5.0），后端删除接口的枚举：
 * - `1` 强制删除空间资源数据（原件的缺省；绑定的空间资源随之被删）；
 * - `2` 只删资源数据并清空绑定关系；
 * - `3` 有绑定的空间资源时提示出来、不删（本包的缺省）。
 * 取值表见 {@link DATA_PAGE_DELETE_GIS_RESOURCE_VALUES}。
 */
export type DataPageDeleteGisResource = 1 | 2 | 3;

/** 宿主自己决定的 props。 */
export interface DataPageHostProps {
  /**
   * 只读。默认 `true`：与 `Crud` 一样安全——新增 / 修改 / 删除 / 导入 / 导出全部隐藏，`isReadOnly` 传给原件。
   * 为真时盖在 `toolbarButtons` / `rowOperations` 之上，写能力只能由宿主显式关掉它来打开。
   */
  readOnly?: boolean;
  /**
   * 宿主按登录的这个人的权限算出来的能力表（0.4.5）；不传就是 0.4.4 的行为（布局说了算）。
   * 由宿主算、不给模型设：它不在 {@link DATA_PAGE_MODEL_SETTABLE_PROPS} 里。
   */
  abilities?: DataPageAbilities;
  /**
   * 删除接口带的 `deleteGisResource`（0.5.0）：行内删除与批量删除都按它发，请求地址的查询串与请求体里各一份。
   * 默认 `3`；不在取值表里的值（开发版 Vue 下报一条 prop 校验警告）同样按 `3` 发，不退回原件的 `1`。
   * 与 `readOnly` 同类，是视图决定的写入语义，不在 {@link DATA_PAGE_LAYOUT_PROPS} 里。
   */
  deleteGisResource?: DataPageDeleteGisResource;
  /** 根节点的行内样式；默认 `'width:100%;height:100%'`，宿主盒要给出高度。 */
  myStyle?: string;
}

/** `DataPage` 完整的 props。 */
export type DataPageProps = DataPageModelProps & DataPageLayoutProps & DataPageHostProps;

/**
 * `load` 事件的载荷。
 * `authButton` 是已解析的按钮权限：`readOnly: true` 时是只读记录（每个键都是 `false`），
 * 为假时是后端权限表那一行原样（值是 `0` / `1`，不是布尔，另带 `resclassenname` 等后端字段）。
 */
export interface DataPageLoadPayload {
  schemaConfig: CrudLoadPayload['schemaConfig'];
  authButton: Record<string, unknown>;
}

/**
 * `info-card-open` 事件的载荷：被点那一行的资源基础数据。`type` 是被点那一格所指的模型，点关联列时是关联模型。
 * `id` 是行里 `int_id` 的原值，类型由后端决定；宿主发布给别的块之前转成字符串。
 */
export interface DataPageInfoCardOpenPayload {
  id: string | number;
  name: string;
  type: string;
}

/**
 * `form-open` 事件的载荷（0.5.0）：这一页当前在编辑什么。按「新增」时只有 `mode` 与 `type`（本页的表）；
 * 按行内「修改」（或信息卡的修改入口）时带被点那一行的 `id` 与 `name`，`type` 是那一行自己的表（信息卡那条路上
 * 可能是关联表）。不带序号：同一行再按一次，值相同。`readOnly` 或能力表拿掉了入口时不发。
 */
export interface DataPageFormOpenPayload {
  mode: 'add' | 'modify';
  type: string;
  /** 只在 `modify` 时有；类型同 {@link DataPageInfoCardOpenPayload.id}，宿主发布前转字符串。 */
  id?: string | number;
  /** 只在 `modify` 且那一行有名称时有。 */
  name?: string;
}

/**
 * `delete-save-success` 事件的载荷（0.5.0）：至少删掉一条时才发（一条都没删掉时不发）。
 * `deleted` 每项只含这张表最近一次报出的列（{@link reportedColumns}）里、这张表已加载的方案（表格列与新增 / 修改表单，
 * 含表单页加载的那几份）都没有标成脱敏（`showAsPass`）的那些——任一份标了就去掉，按方案标记判、不看此刻是否打码；
 * 值只留字符串、有限数与布尔。这张表没有登记过列时每项都是 `{}`。
 */
export interface DataPageDeleteSavedPayload {
  /** 模型英文名。 */
  meta: string;
  /** 删掉的记录 id（转成字符串），宿主据此撤回仍指着它们的状态。 */
  ids: string[];
  /** 删掉的记录，裁过。 */
  deleted: Array<Record<string, string | number | boolean>>;
  /** 没删掉的条数。 */
  failed: number;
}

/**
 * `batch-modify-save-success` 事件的载荷（0.5.0）：批量修改全部成功时才发（部分成功时不发，表格也不刷新，与原件相同）。
 * `modified` 每项按 {@link DataPageDeleteSavedPayload} 的 `deleted` 同一规则裁过；`attrs` 只有改的属性名，不带值。
 */
export interface DataPageBatchModifySavedPayload {
  /** 模型英文名。 */
  meta: string;
  /** 改成功的记录，裁过。 */
  modified: Array<Record<string, string | number | boolean>>;
  /** 勾选修改的属性名。 */
  attrs: string[];
}

/**
 * `export-task-created` 事件的载荷：后端刚排上的那个导出任务。
 * 三个标量，没有行、没有查询条件；文件不在这一页产生，要去部署自己的任务列表页取。
 */
export interface DataPageExportTaskPayload {
  /** `'excel'` 是模板导出（`exp`），`'grid_csv'` 是表格导出（`gridexp`）。 */
  mode: 'excel' | 'grid_csv';
  /** 从下拉里选的导出文件类型（`'csv'` / `'qrcode'`）；点按钮主体导出时是 `null`。 */
  fileType: string | null;
  /** 后端给这次导出任务的任务号。 */
  uuid: string;
}

/**
 * `access-denied` 事件的载荷：被拒的那个模型与被拒的原因。
 * 只有模型英文名与一个枚举——宿主本来就知道自己传了什么，这条事件是给用户一句交代用的，
 * 不带用户信息、不带权限表。
 */
export interface DataPageAccessDeniedPayload {
  /** 被拒的模型英文名，与传进来的 `relatedMeta` 相同。 */
  meta: string;
  /**
   * 为什么不给看（0.4.4 新增）：
   * - `'no-row'`：权限表拿到了，里面没有这个模型那一行；
   * - `'no-rights-table'`：权限表根本拿不到（用户信息接口答了 4xx 或业务码不是 0，或者答里没有 `auth.resclass`）。
   */
  reason: 'no-row' | 'no-rights-table';
}

/**
 * `auth-failed` 事件的载荷：请求层判定身份不通过（0.4.4 新增）。
 * 原件在这条路上整页跳部署的登录界面，本包一个字节的地址都不改（补丁 0013 / 0015），只发这条事件
 * 并在盒子里画一条提示。一次挂载里最多一条，直到这一页又有一次成功的请求为止。
 */
export interface DataPageAuthFailedPayload {
  /** HTTP 状态码（401 或业务码 3 那一次的状态码）；请求层因为取不到凭据而没发请求时是 `0`。 */
  status: number;
  /** 后端的业务码，答里没有时不带这个字段。 */
  code?: number | string;
}

/**
 * 数据页容器：`Crud.vue` 的子部件原件按它的摆法拼成一页，摆哪些由 props 决定。
 *
 * **页级权限（0.4.3，0.4.4 加了「判不出来」那一档）**：挂载时先取一次用户信息（toy-core 的缓存路径
 * `queryUserInfo(false)`），判不通过时容器一条请求都不发（方案、模型配置、查询一个都不取）、
 * 画一张「无权限」、根上发一条 `access-denied`。两种不给看：`auth.resclass` 非空而其中没有
 * `relatedMeta` 那一行（`reason: 'no-row'`）、权限表根本拿不到（`reason: 'no-rights-table'`，
 * 接口 4xx / 业务码不是 0 / 答里没有 `auth.resclass`）。`auth.resclass` 是一张**在场的空表**时不设限。
 * 后端一个字都没答（断网、超时、5xx）不算不给看：那时同样一条请求都不发，但画的是一条取数失败的提示，
 * 没有「无权限」、也没有 `access-denied`。
 * `readOnly` 与 `regions` 这些 props 都绕不过这一判。
 * 判定抄自视图 `toy-ui/views/ResCrud/ResCrud.vue` 的 `initAuth()`（87-99）的**意图**——
 * 原件那条检查是死代码（98 行无条件把 `isAuth` 置回 `true`），见 README。
 *
 * **宿主能力表（0.4.5）**：`abilities` 只拿掉布局列了的入口、不添；一个入口画得出来，当且仅当布局列了它、
 * `readOnly` 不盖掉它、`abilities` 没有为它写 `false`（见 {@link DataPageAbilities}）。
 *
 * 事件（Vue 2 选项类型不承载事件签名，逐条列在这里；载荷里出现的行是**显示值**，与表格里看到的一致）：
 * - `load(payload: DataPageLoadPayload)` 方案加载完成，`authButton` 已解析
 * - `query-success(payload: CrudQuerySuccessPayload)` 查询成功
 * - `table-cell-click(payload: CrudTableCellClickPayload)` 单元格点击
 * - `table-selection-change(displayValueList: ToyRow[], rawValueList: ToyRow[])` 勾选变化（补丁 0008 把它从
 *   `TableDetail` 转发到 `CrudTable`，容器再发一次到根上——Vue 2 的 `$emit` 不冒泡）
 * - `table-operation-custom(scope: { $index: number, row: ToyRow }, item: DataPageCustomOperation, rawValue: ToyRow)`
 *   行内自定义操作被点
 * - `info-card-open(payload: DataPageInfoCardOpenPayload)` 点名称 / 关联链接（卡画在页内，或视图写了 `infoCardLinks`）
 * - `info-card-close()` 卡从开着变成关着（0.5.0 起）：关卡、清空、翻页三种都发；查询不发（查询刷新开着的卡）
 * - `form-open(payload: DataPageFormOpenPayload)` 按「新增」或行内「修改」（0.5.0）；一次点击一条，`readOnly` 或能力表拿掉入口时不发
 * - `add-save-success(e)` / `modify-save-success(e)` 新增 / 修改窗口保存成功，载荷是后端接口的返回值
 * - `delete-save-success(payload: DataPageDeleteSavedPayload)` 删除窗口至少删掉一条（0.5.0）
 * - `batch-modify-save-success(payload: DataPageBatchModifySavedPayload)` 批量修改全部成功（0.5.0）
 * - `export-task-created(payload: DataPageExportTaskPayload)` 模板导出 / 表格导出排上了一个后端任务
 * - `access-denied(payload: DataPageAccessDeniedPayload)` 页级权限不给看这个模型（每个实例最多一条，发出后这一页什么都不取）
 * - `auth-failed(payload: DataPageAuthFailedPayload)` 请求层判定身份不通过（一次挂载最多一条，直到这一页又有一次成功的请求）
 *
 * 保存成功（新增、修改、删除、批量修改）之后，同表的每个数据页都重查一次、显示这张表记录的信息卡块（{@link InfoCard}）重取一次：
 * 经 {@link notifyRecordSaved} 的通知，不经宿主。
 *
 * 实例方法见 {@link DataPageInstance}（0.4.6 的 `doDescribeElement`）。
 *
 * 组件不能被 `Object.freeze`：Vue 2 的 `Vue.extend` 会往选项对象上写 `_Ctor`。
 */
export declare const DataPage: ComponentOptions<Vue>;

/**
 * `doDescribeElement` 描述里的区域（0.4.6）：八个布局区域，加上 `'noAuth'`（页级权限不给看时整页那张「无权限」）
 * 与 `'page'`（这一页之内、不在任何区域里的空白处）。
 */
export type DataPagePointRegion = DataPageRegion | 'noAuth' | 'page';

/** 描述里的一列：属性名（el-table 列的 `property`，即方案里的 `relatedMetaAttr`）与表头文字。 */
export interface DataPagePointColumn {
  /** 属性名；只带 `/^[A-Za-z_][\w-]*$/` 且不长于 64 的。 */
  key: string;
  /** 表头文字（el-table 列的 `label`），至多 24 个 UTF-16 码元；没有时是 `key`。 */
  label: string;
}

/**
 * 描述里的一行：el-table 绑定到被指那一格的**那一行对象本身**里、**画出来的列**的值。
 * 键按页面自己的列序（固定列在前），至多 {@link DATA_PAGE_DESCRIBE_LIMITS}`.columns`（20）个；
 * 值一律是字符串：字符串截到 40 个 UTF-16 码元（超长时前 39 个加一个 `…`，不拆代理对），有限数与布尔写成字符串，
 * 空值、对象、数组不带。方案里不显示的列（`isShow: '0'`）、没画成列的字段（如 `int_id`）、别的行一概不在。
 */
export type DataPagePointRow = Readonly<Record<string, string>>;

/** 描述里的一个表单项或信息卡属性：属性名与显示名（至多 24 个码元）。 */
export interface DataPagePointField {
  key: string;
  label: string;
}

/** 行内操作：原件的修改 / 删除图标（删除 0.5.0），或者模型给的自定义操作（`name` 与 `label` 取自 `customOperations`）。 */
export type DataPagePointOperation =
  | { kind: 'row'; key: DataPageRowOperation }
  | { kind: 'custom'; name: string; label: string };

/**
 * `doDescribeElement` 的描述（0.4.6）：按 `part` 区分的闭合联合。
 *
 * 除 `element` 以外全是纯数据（字符串与由字符串组成的对象），`JSON.stringify` 得到的就是全部内容；
 * `element` 是**不可枚举**字段，`JSON.stringify`、展开与 `Object.keys` 都看不见它。
 * 不带凭据、不带 HTML、不带别的行、不带不显示的列；值都截过。
 */
export type DataPagePoint = (
  /** 区域里的空白处（含分页器、左下角勾选栏、「无权限」、表格里没有落到格子上的地方）。 */
  | { region: DataPagePointRegion; part: 'area' }
  /**
   * 工具栏按钮：`button` 是 {@link DATA_PAGE_TOOLBAR_BUTTONS} 里的键，`label` 是按钮上的字。批量按钮（0.5.0）只有图标，
   * `label` 是键名 `'batch'`；它的下拉菜单项是 popper，指它们得到 `null`。
   */
  | { region: 'toolbar'; part: 'button'; button: DataPageToolbarButton; label: string }
  /** 表头格。 */
  | { region: 'table'; part: 'header'; column: DataPagePointColumn }
  /** 表体格：列与这一格所在的那一行。 */
  | { region: 'table'; part: 'cell'; column: DataPagePointColumn; row: DataPagePointRow }
  /** 一行里不属于任何画出来的列的地方（选择框那一格）。 */
  | { region: 'table'; part: 'row'; row: DataPagePointRow }
  /** 行内操作图标 / 链接，连同它所在的那一行。删除图标的气泡确认是 popper，指它得到 `null`。 */
  | { region: 'table'; part: 'rowOperation'; operation: DataPagePointOperation; row: DataPagePointRow }
  /** 查询区、新增窗口、修改窗口里的一个表单项，或者信息卡里的一条关键属性。 */
  | { region: 'query' | 'addForm' | 'modifyForm' | 'infoCard'; part: 'field'; field: DataPagePointField }
) & {
  /** 被指的那一部分本身（格子、表头、按钮、图标、表单项、属性条、区域根节点）；不可枚举，宿主拿它画框、判它还在不在。 */
  readonly element: Element;
};

/** `doDescribeElement` 描述守的上限（0.4.6，已冻结）；与宿主报告单元格点击的那组数相同。 */
export declare const DATA_PAGE_DESCRIBE_LIMITS: Readonly<{
  /** 一行最多带几列。 */
  columns: 20;
  /** 单元格值最长几个 UTF-16 码元。 */
  cellLength: 40;
  /** 显示名最长几个 UTF-16 码元。 */
  labelLength: 24;
  /** 属性名最长几个字符（更长的整个不带）。 */
  keyLength: 64;
}>;

/** `DataPage` 实例上宿主可调的公开方法（0.4.6）。通过桥的 `instanceRef` 拿到实例后调用。 */
export interface DataPageInstance extends Vue {
  /**
   * 「这一点下面是什么」：把这一页子树里的一个元素说成一份有界描述。只读——不发事件、不发请求、不改状态。
   * 行与列读自 Element-UI 自己的数据（`ElTableRow` 的 `row` prop、el-table 的列表），不按 DOM 文字或位置猜。
   * @param element 被指的元素（通常是指针下最深的那个）。
   * @returns 描述；元素不在这一页的子树里时 `null`——包括 `containCrud` 收进盒子、但不在这一页根节点之下的下拉、面板与提示。
   *   方案还没判完或没通过（根节点是注释）时同样是 `null`。
   */
  doDescribeElement(element: Element): DataPagePoint | null;
}

/** `FormPage` 的 props（0.5.0）。没有 `readOnly`：只有视图放得了表单页，写进视图就是作者的决定。 */
export interface FormPageProps {
  /** 表单编辑的表（模型英文名）。写入只认它。 */
  relatedMeta: string;
  /**
   * 打开请求：数据页 `form-open` 的载荷（宿主绑定的 `editing`），只读。不给时一条请求都不发、根节点是空的；
   * 不合法（模式不在两值里、`type` 不是非空串、修改没有 `id`）或 `type` 与 `relatedMeta` 不一致时同样不读、不写，
   * 原因画在盒子里。键（模式、表名、`id`）不变时宿主再给一个新对象，表单不重载。
   */
  request?: DataPageFormOpenPayload;
  /** 宿主的能力表：`create: false` 时新增模式不画「确定」，`update: false` 时修改模式不画；写之前再核一次。 */
  abilities?: DataPageAbilities;
  /** 根节点的行内样式；宿主盒要给出高度。 */
  myStyle?: string;
}

/**
 * `form-saved` 事件的载荷（0.5.0）：表单页保存成功。`record` 只含写进去的显示值里、在表单里、并且在这张表
 * 最近一次报出的列（{@link reportedColumns}）里的那些，再去掉这份表单方案或这张表已加载的别的方案（数据页的表格列与
 * 新增 / 修改表单）标成脱敏（`showAsPass`）的——按方案标记判，新增模式屏幕上不打码的字段也去掉；值只留字符串、
 * 有限数与布尔。这张表没有登记过列时是 `{}`。
 */
export interface FormPageSavedPayload {
  mode: 'add' | 'modify';
  /** 模型英文名，与 `relatedMeta` 相同。 */
  meta: string;
  /** 保存的记录，裁过。 */
  record: Record<string, string | number | boolean>;
}

/**
 * 表单页（0.5.0）：不带 el-dialog 的新增 / 修改块，`request` 绑数据页的 `form-open`。
 *
 * 写到哪张表只认自己的 `relatedMeta`：`request.type` 不一致时不读（修改模式不按 `id` 取这一行）、不写；
 * 写之前再核一次表名、模式、`id` 与能力表，不一致时不发写请求。打开前判一次页级权限（与 {@link DataPage} 同一判；
 * 判出给看或不给看之后这张表不再判，判不出时下一次打开再判）。保存成功后发 `form-saved`、经 {@link notifyRecordSaved}
 * 通知同表的数据页，再重挂表单：新增回到空白，修改重新载入这一行。「取消」同样重挂：修改丢掉没保存的改动，新增清空。
 *
 * 事件：`form-saved(payload: FormPageSavedPayload)`。
 */
export declare const FormPage: ComponentOptions<Vue>;

/**
 * `InfoCard` 要显示的那条记录（0.5.0）：数据页 `info-card-open` 的载荷（宿主绑定的 `opened`），名称可以没有。
 * `type` 是那条记录自己的表，点关联列打开时是关联表。
 */
export type InfoCardRecord = Omit<DataPageInfoCardOpenPayload, 'name'> & { name?: string };

/** `InfoCard` 的 props（0.5.0）。 */
export interface InfoCardProps {
  /** 要显示的记录，只读。不给或不完整（没有 `id`、`type` 不是非空串）时不画卡、零请求。 */
  record?: InfoCardRecord;
  /** 信息卡里渲染哪些分段，与 `DataPage` 的 `infoCardTabs` 同一张名单。 */
  infoCardTabs?: DataPageInfoCardTab[];
  /** 根节点的行内样式；宿主盒要给出高度（卡自带 360px 的宽与最小宽）。 */
  myStyle?: string;
}

/**
 * 信息卡块（0.5.0）：`record` 绑数据页的 `info-card-open`，显示那一条记录的信息卡；卡头不画关闭按钮。
 * 键（`type` + `id`）变了才换卡：宿主对同一条记录再给一个新对象时不重取、不重发事件。这条记录的表有记录保存成功时
 * 经 {@link notifyRecordSaved} 的通知重取。不判页级权限（页内信息卡按关联列打开关联表的记录时同样不判）。
 *
 * 事件：
 * - `info-card-open(payload: InfoCardRecord)` 换了一条记录（名称不是字符串时不带 `name`）
 * - `info-card-close()` `record` 撤回（或不完整）时，原来显示着卡才发
 */
export declare const InfoCard: ComponentOptions<Vue>;

/** 模型可设的 props 名单。 */
export declare const DATA_PAGE_MODEL_SETTABLE_PROPS: ReadonlyArray<keyof DataPageModelProps>;

/** 布局选项的名单。 */
export declare const DATA_PAGE_LAYOUT_PROPS: ReadonlyArray<keyof DataPageLayoutProps>;

/** `toolbarButtons` 认的取值表，也是 prop 校验器用的那一张；宿主的目录照它列。 */
export declare const DATA_PAGE_TOOLBAR_BUTTONS: ReadonlyArray<DataPageToolbarButton>;

/** `rowOperations` 认的取值表，也是 prop 校验器用的那一张。 */
export declare const DATA_PAGE_ROW_OPERATIONS: ReadonlyArray<DataPageRowOperation>;

/** `deleteGisResource` 认的取值表（0.5.0，已冻结）：`[1, 2, 3]`，也是 prop 校验器用的那一张；宿主的目录照它钉枚举。 */
export declare const DATA_PAGE_DELETE_GIS_RESOURCE_VALUES: ReadonlyArray<DataPageDeleteGisResource>;

/** `abilities` 认的五个键（0.4.5），也是 prop 校验器用的那一张：`create` / `update` / `delete` / `import` / `export`。 */
export declare const DATA_PAGE_ABILITY_KEYS: ReadonlyArray<DataPageAbilityKey>;

/**
 * 订阅一张表的「有记录保存了」（0.5.0）。本包的块保存成功后按表名通知，同表的数据页重查、信息卡重取都走这里，
 * 不经宿主绑定。状态是模块级的：同一个客户端 bundle 里本包只能有一份。通知同步、按订阅顺序调用；监听器抛错不拦住
 * 后面的监听器，错误由 {@link notifyRecordSaved} 在调完之后抛出。
 * @param meta 表名（模型英文名），非空字符串；不是时抛 `TypeError`。
 * @param fn 监听器，收到表名。
 * @returns 注销函数，可重复调用。
 */
export declare function onRecordSaved(meta: string, fn: (meta: string) => void): () => void;

/**
 * 通知一张表的全部订阅者：这张表有记录新增、修改、删除或批量修改成功了（0.5.0）。没有订阅者时什么都不做。
 * 每个订阅者都调到；有订阅者抛错时，全部调完之后抛出第一个错误（后面再抛的不再抛出）。
 * @param meta 表名。
 */
export declare function notifyRecordSaved(meta: string): void;

/**
 * 登记一张表最近一次报出的列（0.5.0）。数据页在发 `load` 时自己登记（显示列，`isShow` 不为 `'0'`）；
 * 宿主报出去的列更窄时，可以在 `load` 的监听器里用那一份覆盖。后一次整份替换前一次；非字符串与空串丢掉，去重。
 * 回报保存结果（删除、批量修改、表单页保存）时，记录只带这些列里、这张表已加载的方案（表格列与新增 / 修改表单）
 * 都没有标成脱敏的那些。
 * @param meta 表名，非空字符串；不是时抛 `TypeError`。
 * @param columns 属性名，按画出来的顺序；不是数组时抛 `TypeError`。
 */
export declare function noteReportedColumns(meta: string, columns: readonly string[]): void;

/**
 * 一张表最近一次报出的列（0.5.0）。
 * @param meta 表名。
 * @returns 冻结的属性名数组；这张表还没有登记过时 `undefined`。
 */
export declare function reportedColumns(meta: string): readonly string[] | undefined;
