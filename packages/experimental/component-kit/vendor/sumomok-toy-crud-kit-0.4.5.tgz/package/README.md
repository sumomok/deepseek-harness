# @sumomok/toy-crud-kit

把 toy-ui 的整页组件 `component/Crud/Crud.vue` **原样**（不重写）连同它真正依赖的 toy-core 请求层编译成一个 tgz，
作为内容列的 `toy.crud` 种类挂进宿主。模型能选「看哪张表、什么条件、怎么排序、能不能勾选」，
`Crud` 这条导出永远只读：不能新增、修改、删除、导入、导出。

0.4.0 起多一条导出 `DataPage`：同一批子部件原件按 `Crud.vue` 的摆法拼成一页，**页内摆哪些区域、工具栏留哪几个按钮
由 props 决定**，写能力由宿主用 `readOnly: false` 显式打开（缺省为真，与 `Crud` 一样安全）。
0.4.3 起它还判一次**页级权限**：用户信息的 `auth.resclass` 里没有这张表那一行时，这一页一条请求都不发，
盒子里画的是原件那张「无权限」，根上发一条 `access-denied`（判定抄自视图 `ResCrud.vue` 的意图，见「已知限制」）。
0.4.4 把这一判补全成「**判不出权限就不给看**」：权限表根本取不到（用户信息接口答 4xx、业务码不是 0、
或者答里没有 `auth.resclass`）时同样一条请求都不发、同样画那张「无权限」，`access-denied` 多一个 `reason`。
同一版还钉死了另一件事：**本包一个字节的地址都不改**——请求层原件在没有凭据 / HTTP 401 / 业务码 3 时
`window.location.href = 登录地址`，把宿主的顶层窗口整个换掉；七个补丁把这条路与产物里其余每一处整页跳转
都换成了一条 `auth-failed` 事件加一张盒内提示，门禁第 16 条钉住「产物零整页跳转」。
0.4.5 多一条宿主 prop `abilities`：宿主按登录的这个人的权限算出 `{ create?, update?, delete?, import?, export? }`
传进来，某个键为 `false` 时对应的入口不画，即使布局列了它；**只能拿掉、不能添上**，不传就是 0.4.4 的行为。

它不是把 `Crud.vue` 重写了一遍：查询区、工具栏、表格、勾选栏、分页器、信息卡、新增 / 修改窗口全是原件，
本包只写了一段布局模板、一份从 `Crud.vue` 的 script 抬出来的数据流（逐段标了源行号）、一张布局选项到原件 props 的映射，
外加页级权限那一判（`src/data-page/page-access.js`，抄自视图 `ResCrud.vue` 87-99 的意图）。
能搬走的最小单位是「一页」而不是一个个部件：部件之间本来就靠 `$refs` 与函数 prop 互相够（见「已知限制」）。

数据不经过宿主：组件用 toy-core 自己的 axios，浏览器直接带着访客的 token 请求部署后端；宿主对这个种类什么都读不到，
回给模型的只有列名与计数（见「宿主接入」）。姐妹包 `@sumomok/toy-surface-kit` 保持不动，本包与它并列在同一个 pnpm 工作区里。

`vue` 与 `element-ui` 由宿主提供（external），element-ui 必须已被宿主 `Vue.use` 注册，且 **element-ui 内部 `require('vue')`
拿到的必须与渲染本组件的是同一份 Vue**（el-table 的 store 由 element-ui 自己 require 的 Vue 建立响应式，两份 Vue 会让表格停在首帧的空表）；
`lodash` 与 `dayjs` 是本包声明的普通依赖，同样不打进产物。本包加载时不 `Vue.use` 任何东西，不改 element-ui 的 `size` / `zIndex`（门禁 + 探针钉住）。

## 导出

| 导出 | 形态 |
|---|---|
| `Crud` | toy-ui `component/Crud/Crud.vue` 原件的 Vue 2 组件对象，只多一条本包混入：实例的 `$notify` 换成盒内提示。不能 `Object.freeze`（Vue 2 会往选项对象上写 `_Ctor`）。只读：信息卡与四个写窗口对它仍是零渲染替身 |
| `DataPage` | 数据页容器（0.4.0 新增）。同一批子部件原件按 `Crud.vue` 的摆法拼成一页；区域与工具栏按钮由 props 决定，`readOnly` 缺省为真；页级权限（0.4.3，0.4.4 补上「权限表取不到」那一档）不给看的模型一条请求都不发；宿主能力表 `abilities`（0.4.5）只拿掉入口、不添。根节点上发十三条事件（见「宿主接入」） |
| `containCrud(box)` | 挂载前把宿主元素收拾成盒子：打 `data-toy-crud-box` 标记、置 `position:relative`、把请求层的进度条 `#nprogress`、遮罩 `#is-loading-full-overlay`（本包拷贝）、报错 toast（本包拷贝）、toy-ui 经 element-ui 发出的 `.el-message` 与 element-ui 追加到 body 的 poppers（0.4.1 起下拉与日期面板，0.4.2 起再加下拉菜单与行内图标的提示；盒子装得下时连同定位边界一起收）都收进盒子；返回注销函数。两条组件导出共用 |
| `setBizBasePath(path)` / `getBizBasePath()` | toy-core 请求层的业务基路径（axios `baseURL`）。只接受根绝对路径，规范成以 `/` 结尾；返回实际写入值。拒收里有承重的一道：补好尾 `/` 之后拿 WHATWG URL 解析器解一遍，`origin` 或 `pathname` 被改写就抛——`https:` 下解析器把 `\` 当 `/`，`/\host/` 会指向另一个源，`%2e%2e` 会被归一掉 |
| `CRUD_READ_ONLY_PROPS` | `Crud` 的宿主写死、模型不可设的 props（冻结对象） |
| `CRUD_MODEL_SETTABLE_PROPS` | `Crud` 的模型可设 props 名单 |
| `DATA_PAGE_MODEL_SETTABLE_PROPS` | `DataPage` 的模型可设 props 名单：`relatedMeta` / `conditions` / `matchMode` / `querySort` / `selectMode` / `isInitQuery` / `customOperations` |
| `DATA_PAGE_LAYOUT_PROPS` | `DataPage` 的布局选项名单：`regions` / `toolbarButtons` / `rowOperations` / `queryExpanded` / `pageSize` / `pageSizes` / `infoCardTabs` |
| `DATA_PAGE_TOOLBAR_BUTTONS` | `toolbarButtons` 认的取值表（0.4.2 新增导出）：`add` / `exp` / `gridexp` / `search` / `clear`。就是 prop 校验器用的那一张，宿主的目录照它列 |
| `DATA_PAGE_ROW_OPERATIONS` | `rowOperations` 认的取值表（0.4.2 新增导出）：只有 `modify` |
| `DATA_PAGE_ABILITY_KEYS` | `abilities` 认的五个键（0.4.5 新增导出）：`create` / `update` / `delete` / `import` / `export`。就是 prop 校验器用的那一张，宿主的权限映射照它列 |
| `BOX_ATTR` | 标记属性名 `'data-toy-crud-box'` |

导出面的类型是手写的 `types/index.d.ts`：`Crud` 的 props 逐条从 `Crud.vue` 的 `props` 声明推出，
`DataPage` 的 props 与十三条事件的载荷逐条写在那里，另有 `Crud` 实例上的公开读方法。

## 搬运规则

1. **源库只读。** 闭包内的文件由 `tools/copy-sources.mjs` 拷进 `src/vendor/`，保留原相对结构，逐文件的相对路径与 sha256 记在 `SOURCES.md`。
   源根从本包位置向上找到同时含三个源库的目录为止（本包在姐妹包之下一层，不能像姐妹包那样按脚本位置推）。
2. **对源码的改动一律是补丁文件。** `patches/*.patch` 一个补丁一个文件，第一行是一行理由，由 `tools/apply-patches.mjs` 按序号打到拷贝件上。
3. **toy-comp 不走桶入口，toy-core 走真实桶入口。** `toy-comp` 别名到 `src/shims/toy-comp.js`——比姐妹包加宽到 7 个组件
   （`TcAwesomeIcon` / `TcNumberComp` / `TcXyComp` / 四个 `TcColumn*`），恰好是 Crud 闭包 import 的那些；原桶会带进
   `menu/tc-*-coll-confirm/main.js` 三个文件，它们在模块求值期 `Vue.use(Element, { size: 'small', zIndex: 2000 })` 并再次 import
   element-ui 的 theme-chalk，进了产物就会改写宿主共享运行时的 element-ui 默认值。`toy-core` 别名到 `src/vendor/toy-core/index.js`
   ——Crud 要 `crudUtil` / `schema` / `config` / `log` / `mixins.user` 以及会发请求的 `service.crud`，姐妹包那个「零网络」替身装不下它。
4. **组件不自己读存储与 cookie；凭据只在 toy-core 的请求层里用，而且只从存储里取。** 这一条替换了姐妹包的「身份与 token 不进组件层」：
   本包的数据本来就是浏览器带访客 token 直连部署后端，token 必须有人读；读它的只能是 `src/vendor/toy-core/api/axios.js` 及其
   `core/token.js` / `core/login.js` / `core/config.js` / `utils/stroageUtil.js` 这一层。门禁第 11 条因此分成三段：
   toy-ui、toy-comp、本包 shims 与入口零 `localStorage` / `sessionStorage` / `document.cookie` / `accessToken` / `Authorization` 读点
   （补丁 `0004` 切掉 `FormItemComp` 里唯一的一处）；toy-core 里触碰它们的文件集合被冻结成一张八个文件的允许表，
   源库重拷后多一个或少一个都失败；整个闭包零「从地址栏取 token」的读点（补丁 `0007`）。
   末一段是承重的：宿主控制台不是这个部署的登录页，地址里的 `?token=` 只可能来自别人给访客的一条链接，而原件的 `getToken()` 认它，
   还用 `setToken()` 把它写进 `accessToken`——正是宿主登录闸读的那个键。这样「谁能碰凭据、凭据从哪来」都是可机械核对的名单，而不是一句承诺。

## 两张替换表（构建期按解析后的路径顶替）

`vite.config.shared.js` 里两张表，都由 `vendorReplacementPlugin` 在 resolveId 阶段按解析后的 vendor 路径匹配——
不匹配导入方写下的字符串，同一说明符在别处再出现也不会替错文件。插件**只改道 `src/vendor/` 之下的导入方**，
而 `src/data-page/DataPage.vue` 不在那里：同一个原件因此可以「`Crud.vue` 拿替身、容器拿真件」。

**`VENDOR_REPLACEMENTS`：谁都拿不到原件**（既不拷贝也不求值，`tools/compute-closure.mjs` 把它们当剪枝点）。

| 组 | 被顶替的原件 | 替身 | 为什么 |
|---|---|---|---|
| 永不渲染的子树 | `Crud/component/CrudMenu`、`common/query/QueryStatistic`、`common/modify/{SaveResultRealbatchDialog, ModifyRealbatchDialog}` | `DeadSubtreeStub.vue`（渲染成注释节点） | 两条导出都不摆左侧菜单、统计查询、删除结果窗口与批量修改窗口，但 `Crud.vue` 静态 import 它们。顶掉之后它们在构建层面不存在，也一并切掉 vuedraggable / @antv/g2 / html2canvas / qiankun |
| 直连取数的值控件 | `TransComp`、`TransMulti`、`AutoNaming`、`OdmTemplate`、`SelectCron`、`AreasComp`、`LinesComp` | `DisabledInputStub.vue`（与姐妹包相同） | 七个控件各自静态闭包直连 `ToyCore.service.crud`；其中 `TransComp` 的「+」会打开关联模型的新增窗口（写路径），`TransMulti` 拖进第二个 Crud（`CrudSelect`） |
| 信息卡里的重子组件 | `SmallCard/component/{resStat, resUseage, resOperation, serviceOperation, eventOperation}.vue` | `DeadSubtreeStub.vue` | `resStat` 要 `vue-count-to`（工作区未装）；后三个在模板里 `require('../image/empty.png')`（webpack 写法）并经 `OperationMicro` 取 toy-comp 桶里本包替身没有的成员；`resUseage` 与它们同属重展示页。卡头、异常信息与关键属性是真件 |
| webpack `require.context` | `common/modify/builder/index.js` | `src/shims/modify-builder.js`（**真实现**） | 原件的两个子模块共四处 `require.context`，vite 不实现。替身用 `import.meta.glob(..., { eager: true })` 扫同样的四个目录，键同样是「文件名大写」，所以 `builder/add/formItemFooter/floor_num.vue` 这类定制表尾真的会出现在对应模型的新增窗口里（探针钉住） |
| 会越界到 body 的 toy-core 模块 | `toy-core/eleui/loading.js`、`toy-core/eleui/message.js` | `toy-core-loading.js` / `toy-core-message.js`（本包拷贝，同一调用面，落在登记的盒子里） | 原件把遮罩与 toast 追加到 `document.body` |
| eval 面 | `toy-core/crud/tableRenderUtil.js` | 调用即抛错 | 原件用 `eval` 求值后端配置的行列颜色表达式；闭包无调用点，只被桶入口带进来 |
| 字体 | `toy-comp/basic/awesome-icon/font-awesome-4.7.0/css/font-awesome.min.css` | 空样式表 | 1.0 MB 字体；图标只出现在被隐藏的导入 / 导出按钮上 |

**`CRUD_ONLY_REPLACEMENTS`：只有 `Crud.vue` 拿替身。**

| 被顶替的原件（对 `Crud.vue`） | `DataPage` 拿到的 | 为什么分开 |
|---|---|---|
| `SmallCard/index.js` | 真件 | `Crud` 的只读语义靠「信息卡与写窗口在构建层面不存在」承载（0.2.x 的探针把 `dialogVisible` 置真也开不出窗口），这一条不因为容器要用真件而松掉 |
| `common/modify/ModifySingleDialog/index.js` | 真件（连 `ModifySingle` → `FormEdit` 子树） | 同上。容器里这两棵子树是否摆出来由 `regions` 决定，能不能写由 `readOnly` 决定 |

这两个原件因此**要**进 `src/vendor/`（容器要 import 它们），门禁第 9 条分两段核对：上表的键一个都不在 vendor 里，下表的键一个都不能少。

另有三个只在模块求值期被 toy-core 桶入口带到、两条导出的路径上永不调用的 npm 库别名到调用即抛错的替身（`src/shims/npm/`）：
`konva/lib/*`（~500 KB）、`svg.js`、`import-html-entry`。

## 工具栏与行内操作：一张按下去会发生什么的表

`readOnly: false` 时 `CrudAction` 能画出的按钮与 `TableDetail` 能画出的行内图标，逐个量过（浏览器探针，
0.4.1 的产物与 0.4.2 的产物各跑一遍）。**按下去没有下文的一律不进名单**——`toolbarButtons` / `rowOperations`
的 prop 校验器当场拒掉它们，宿主写了会在开发版 Vue 下报出来。

| 键 | 界面上的字 | 背后的原件 | toy-core 服务 | 请求 | 0.4.1 按下去 | 0.4.2 |
|---|---|---|---|---|---|---|
| `add` | 新增 | `ModifySingleDialog`（真件） | `service.crud.saveDataSingle` | `POST <基路径>/nrms-datamanagement/api/resources/<模型>` | 开真窗口 | 放行，不变 |
| `exp` | 模板导出 | `ActionTempExp`（`mode='excel'`） | `service.expimp.taskTempexp` | `POST <基路径>/nrms-expimp/api/impexp/expBySchema` | **抛** `this.crudRef.getQueryParams is not a function`，零请求 | 放行：排一个导出任务 |
| `gridexp` | 表格导出 | `ActionTempExp`（`mode='grid_csv'`） | `service.expimp.taskGridexp` | `POST <基路径>/nrms-expimp/api/impexp/exp-by-grid` | **抛**（同上），零请求 | 放行：排一个导出任务 |
| `imp` | 模板导入 | `ActionTempImp`（`el-upload`，真件） | `service.expimp.taskTempimp` | `POST <基路径>/nrms-expimp/api/impexp/imp`（`FormData`） | 打开系统选文件框、上传，然后 `this.$router.push` 抛（宿主页面上没有 vue-router） | **不放行** |
| `batch` → 批量修改 | 批量修改 | `ModifyRealbatchDialog` = 零渲染替身 | — | 只有一条审计日志 `POST .../api/log/frontevent/` | 什么都不发生 | **不放行** |
| `batch` → 批量删除 | 批量删除 | `SaveResultRealbatchDialog` = 零渲染替身 | — | 同上 | 内部 `dialogVisible.crudDeleteVisible` 置真，没有窗口 | **不放行** |
| `search` / `clear` | 查询 / 清空 | `CrudAction` 自己的两个按钮 | `service.crud.queryDataByWhere` | `POST <基路径>/nrms-datamanagement/api/resources/<模型>/_search` | 真查询 / 真清空 | 放行，不变 |
| 行内 `modify` | 修改（图标） | `ModifySingleDialog`（真件） | `service.crud.modifyDataSingle` | `PUT <基路径>/nrms-datamanagement/api/resources/<模型>/<id>` | 开真窗口并带出该行 | 放行，不变 |
| 行内 `delete` | 删除（图标） | `SaveResultRealbatchDialog` = 零渲染替身 | — | — | 0.4.0 起就不放行 | 不放行 |

**没有一个按钮会下载文件。** 两个导出按钮把导出排成后端的一个**任务**（返回的是任务号 `uuid`），文件随后在
部署自己的任务列表页（`/resmgt/task-main-page`）里取；本包不带那一页。toy-core 里真正会下载的三个出口
（`downImpAddTemp` / `downCustomTemp` / `downSelectTemp`，都是 `window.open(带 __token__ 的地址)`）只被
`CrudMenu`（本包的零渲染替身）与 `task/TaskStatusDialog`（不在闭包里）调用，本包的两条导出都够不到它们。
`toy-core/api/service/ffile` 里另有一个 `downloadFile`（blob + `<a download>` + `link.click()`，在宿主页面里
是能用的写法，但被 `sandbox` 的 iframe 挡住，除非带 `allow-downloads`），它按文件 id 下载，而导出任务的返回值
里没有文件 id——**要在这一页取到导出的文件，得先把任务状态面搬进来**（见「不提供导入与批量」的恢复条件）。

`exp`（模板导出）只在方案里有修改方案时才画得出来：`ActionTempExp` 的三个分支都看 `templateConfig.modify`，
表为空时这个组件渲染成一个注释节点。这是原件的行为，本包不改。

## 十九个补丁

| # | 改的文件 | 改了什么 |
|---|---|---|
| `0001` | toy-ui `TableDetailColumn.vue` | 删掉 `cronstrue/i18n` 与它唯一的 cron 列分支（与姐妹包相同） |
| `0002` | toy-ui `DisplayColumn.vue` | 删掉 `DisplayDownload.vue` 的静态 import 与 `display_download` 分支（该文件拖 `@vue-office/*`；与姐妹包相同） |
| `0003` | toy-comp `TcColumnYesno.vue` | 补上 `String(value).toUpperCase` 缺的调用括号，5 处（与姐妹包相同） |
| `0004` | toy-ui `FormItemComp.vue` | 删掉 `token: localStorage.getItem('accessToken')` 与消费它的 `:headers`（搬运规则 4；与姐妹包相同） |
| `0005` | toy-core `crud/crudUtil.js` | 删掉 `getAuthButton` 里的 `console.log(userInfo)`：每次方案初始化都把当前用户的完整信息（含权限表）打到控制台 |
| `0006` | toy-core `api/service/log/index.js` | `frontEventLog` 返回的 Promise 没有任何调用点消费，日志接口一失败就是一次 `unhandledrejection`；吞掉拒绝 |
| `0007` | toy-core `core/token.js` | 删掉 `getToken` / `getToken4a` 从地址栏取 token 的两处分支：`getToken()` 认 `?token=Bearer …` 并 `setToken()` 写进 `accessToken`，任何一条带参数的链接都能改写访客存着的凭据（搬运规则 4；门禁第 11 条第三段 + 探针钉住）。`core/config.js` 里 `isUrlToken: true` 那个默认值随之没有了消费者，留着不动 |
| `0008` | toy-ui `CrudTable.vue` | 补上 `table-selection-change` 的转发。`TableDetail` 在勾选（:520）与单选（:509）两处都发这个事件，`CrudTable` 不接也不发，勾选变化到不了页面；容器要把它当根事件发给宿主（`Crud` 不受影响：它本来就没有这条事件的消费者） |
| `0009` | toy-ui `SmallCard.vue` | 两处：删掉 `initContentJs` 里 `eval(方案下发的 contentJs)` 这条后端代码求值路径（与被替身顶掉的 `tableRenderUtil` 同一类，门禁第 6 条要求产物零 `eval`）；给写死的分段表加一条 `compFilter` 过滤 prop（缺省 `null` = 原行为），`DataPage` 的 `infoCardTabs` 才有落点 |
| `0010` | toy-ui `CrudPagination.vue` | 每页条数与候选表从写死改成两条 prop（`pageSizeDef` 缺省 20、`pageSizes` 缺省原来那七个值），「清空」退回 `pageSizeDef`。原件一条 prop 都没有，`DataPage` 的 `pageSize` / `pageSizes` 只能落在这里；不传时与原行为逐字节相同，`Crud` 因此不变 |
| `0011` | toy-ui `ActionTempExp.vue` | 两处：导出任务排上之后不再 `this.$router.push('/resmgt/task-main-page')`，改发一条 `exp-task`（宿主页面上没有 vue-router，`this.$router` 是 `undefined`，原件在这里必抛）；`getQueryParams()` 因必填条件未填返回 `null` 时收手（原件接着往 `null` 上写字段）。事件载荷里的 `fileType` 只收字符串——从拆分按钮主体点进来时原件传的是一个 `MouseEvent` |
| `0012` | toy-ui `CrudAction.vue` | 把两个 `ActionTempExp` 的 `exp-task` 转发到自己身上：Vue 2 的 `$emit` 不冒泡，`0011` 发出的事件到不了页面这一层 |
| `0013` | toy-core `core/login.js` | `redirectLogin()` 不再 `window.location.href = 登录地址`，改成通知监听器（新增导出 `onAuthFailure(listener)`，返回注销函数；载荷 `{ status, code? }`）。请求层的三处与 `core/user.js` 的一处都走它，所以这一个补丁把四条路一起换掉。`getLoginUrl()` 原样留着（没有调用点了） |
| `0014` | toy-core `core/user.js` | `searchUserInfo` 取用户信息失败时不再弹 toast、不再删访客凭据、不再 5 秒后跳登录界面，错误原样抛给调用方。原件把「后端答了但拒绝」与「根本没有答」都吞成 `undefined`，接着在 `undefined` 上读 `.code`，抛出的是一条与失败原因无关的 `TypeError`——页级权限那一判要的正是这两者的分别 |
| `0015` | toy-core `api/axios.js` | 三处：HTTP 401 与业务码 3 不再删访客凭据（宿主的登录闸读的就是那一条，删了等于把访客从宿主系统里也踢出去）；两处改为带上业务码调 `redirectLogin(status, sessionTimeout, code)`；请求带 `__silent__` 时不弹报错 toast（与原件自己的 `__isLoading__` 同一种写法） |
| `0016` | toy-core `api/service/login/index.js` | 取用户信息那一条请求带上 `__silent__`：它的成败由页面画成状态（这一页给不给看），不再弹一条「用户没有资源权限!」的红 toast——拒绝是状态，不是报错 |
| `0017` | toy-core `mixins/user.js` | `initUserInfo` 接住 `queryUserInfo` 的拒绝（`0014` 之后它会抛）：这个混入只是把用户信息放进 `data`，再抛一次就是一条没有人消费的 Promise 拒绝 |
| `0018` | toy-core `core/router.js` | 菜单无权限时不再整页跳部署的 401 页面，改成报一条身份不通过。本包没有 vue-router，这条守卫没有调用点——改它是为了产物里一处整页跳转都不留 |
| `0019` | toy-core `mobile/core/plugins.js` | 移动端 `startApp` 在没有原生桥时不再整页跳到目标地址，改成调用即抛错。同样没有调用点，同样是为了产物里零整页跳转 |

`0008` / `0009` / `0010` 是 0.4.0 放出真件后机械上必须的三处：分别对应「勾选事件断在中间那一层」「产物零 eval」「分页器没有任何 prop」。
`0011` / `0012` 是 0.4.2 放出导出后必须的两处：分别对应「跳一个不存在的页面」与「事件到不了页面」。
`0013`–`0019` 是 0.4.4 的一组，全部指向同一件事：**这个包画在宿主页面里，所以它不能改地址、不能动访客的凭据、
也不能把一次拒绝说成一次报错**。前五个在真实路径上（现场那次事故就走这条路），后两个是产物里仅剩的两处
整页跳转、都没有调用点——改掉它们，门禁第 16 条才能从「这几条路我看过了」变成「产物里一处都没有」。

探查阶段发现的四个原件缺陷里，第三、第四个已是补丁 `0005` / `0006`；前两个在只读首版的路径上到不了，不改只记：
`Crud/utils/crudCloudPermission.js` 调的 `ToyCore.axios.get` 不存在（`ToyCore.axios` 只有 `getUrl` 等包装），抛出的 TypeError 被
自己的 `try/catch` 吞掉后返回空表——只有 `useCloudPermission: true` 才会走到，首版固定为 `false`；`Crud.vue` 的 `getCustomMode()`
调的 `crudService.getCustomerMode` 在 `service.crud` 上不存在（在 `service.schema` 上）——该方法没有任何调用点。
**复查触发器：`useCloudPermission` 或定制模板进入导出面时。**

## 命令

```sh
pnpm install                     # 在工作区根目录执行；本包是工作区成员
node tools/compute-closure.mjs   # 用 closure.py 按本包的别名 / 替换 / 补丁剪枝算闭包，写 tools/closure-files.txt
node tools/copy-sources.mjs      # 清空 src/vendor 后从源库重新取一遍闭包文件（会覆盖补丁，需接着重打）
node tools/apply-patches.mjs     # 打十九个补丁（要从干净的拷贝件开始）
pnpm run build                   # 出 dist/index.js（样式随 JS 注入，全部规则限定在 [data-toy-crud-box] 之下），并写 BUNDLED.json / THIRD-PARTY-LICENSES.txt
pnpm run build:measure           # 量测构建：样式落成 measure/style.css 供门禁第 13 条逐条复核
pnpm run gates                   # 16 类机械门禁（21 行），含两个 jsdom 挂载探针（40 + 59 条断言）
pnpm run probe                   # 单独跑 Crud 的挂载探针
pnpm run probe:data-page         # 单独跑 DataPage 的挂载探针
pnpm run probe:browser           # 浏览器探针：盒子对照矩阵 + 检查表 + popper 的两条边界 + 两份 Vue 的对照，写 probe/browser/RESULT.md
                                 # （要一份现成的 playwright：TOY_PLAYWRIGHT=…/node_modules/playwright/index.js）
pnpm run pack                    # 出 tgz，并对 tgz 内每个文件扫本机绝对路径
```

宿主用 `file:` 依赖装本包，同名 tgz 覆盖会被 pnpm 静默忽略：**内容一变就升 `version` 再 `pnpm run pack`**。

## 宿主接入

顺序固定：写基路径 → 收纳盒子 → 审批 → 挂载。

1. **基路径（D7）。** toy-core 在模块求值期 `axios.create({ baseURL: getBaseURL() })` 一次性读 `window.$toy_env.VUE_APP_BASE_URL`
   （缺省 `/nrms-server/`）。宿主的 `bizBasePath` 配置（根绝对路径，缺省 `/`）要在本包模块求值前写进 `window.$toy_env`；
   求值后再调 `setBizBasePath()` 同样生效——它同时改写 `window.$toy_env` 与已建实例的 `defaults.baseURL`。
2. **盒子（D6）。** 桥挂载前 `const release = containCrud(hostDiv)`，`hostDiv` 就是桥往里追加占位节点的那个元素（Crud 根节点成为它的直接子节点）。
   卸载后调 `release()`；盒子届时可以已经离开文档，在途请求照常结束。盒子这一侧有两条**硬要求**，都由浏览器探针逐条量出来
   （`probe/browser/RESULT.md` 的对照矩阵，1440×900 视口、32rem 高的盒子）：
   - **挂载点要解得出确定的高度。** 组件默认 `myStyle: 'width:100%;height:100%'`，这个百分比要有东西可解：
     桥往里追加占位节点的那个元素给 `height:100%` 时 `.crud` 512px、表体 313px；改成 `height:auto` 时 `.crud` 塌到 259px、
     表体塌到 60px，20 行数据全挤在那一条里（**不报错、照样能用**，所以只能靠量）。
   - **element-ui 与本包产物必须共用同一份 Vue。** 产物把 `vue` / `element-ui` 当 external，由宿主提供；宿主若让
     `Vue.use(ElementUI)` 装进 A 份、el-table 内部的列注册与 `nextTick` 走 B 份，表头会停在空的 `<thead><tr></tr></thead>`，
     element-ui 的 `TableLayout.updateElsHeight` 在 `headerHeight < 2` 时用 `Vue.nextTick` 重排自己，**主线程被这条自我重排占死**
     （页面此后不发任何请求，连 CDP 都不回应）。本包的浏览器探针就栽在这上面一整天，成因与复现见 `probe/browser/README.md`。

   盒子的**定位、写死的块尺寸、裁切都不是必要条件**：`position:static` / `overflow:visible` / 百分比高度 / 挂载后才给宽度，
   四种变体逐一量过，页面照样画出 20 行（`containCrud` 自己会把 `position:static` 的盒子提成 `relative`，`src/contain.js` 第 68 行）。
   盒子的高度还决定 poppers 收不收得进来：装得下就连同定位边界一起收进盒子，装不下就留在 body 上（见已知限制）。
3. **审批（D4）。** 由宿主在挂载前走审批缝；本包不做审批、不知道会话。拒绝即不挂载，什么都不画。
4. **props（D3）。** `{ ...模型可设的七个, ...CRUD_READ_ONLY_PROPS }`。模型可设：`relatedMeta`（必填）、`conditions`、`matchMode`、
   `querySort`、`selectMode`、`isExpandQuery`、`isInitQuery`；宿主写死：`isReadOnly: true`、`type: 'default'`、`urlConfig: null`、
   `hideButton` 十个写 / 导出键全真、`hideComp: { menu, card }`；`crudUrl` 取默认，`tableCustomOperations` /
   `tableCustomComps` / `queryFormCustomComps` / `rowStyle` / `smallCardBeforeOpen` 不设。探针证明：画出的动作按钮只有「查询」「清空」（另有分页器的
   `btn-prev` / `btn-next` 两个只有图标的按钮），表格无操作列，把 `dialogVisible.*` 置真也没有窗口。
5. **回给模型的（D5）。** `load` 事件：`schemaConfig.query.grid.gridItems` 里 `isShow !== '0'` 的列的 `relatedMetaAttr` + `alias`；
   `query-success`：`page.total`、`displayValue.length`、`page.currentPage`——行永不回传；`table-cell-click`：`row`（显示值）与
   `column.property`（被点列的 attr），宿主按显示列裁成显示值。`Crud` 没有 selection-change 事件，只读首版不轮询 `doGetSelection()`。

### 挂 `DataPage`

前三步（基路径、盒子、审批）与上面逐字相同，盒子与 `containCrud` 两条导出共用。第四、五步换成：

4. **props。** 三组，缺省值就是「全都摆出来、什么都不能写」：
   - **模型可设**（`DATA_PAGE_MODEL_SETTABLE_PROPS`）：`relatedMeta`（必填）、`conditions`（缺省 `[]`）、
     `matchMode`（`'AND'`）、`querySort`（`{}`）、`selectMode`（`'checkbox'`）、`isInitQuery`（`true`）、
     `customOperations`（`[]`；每项只认 `{ name, label }` 两个字段，原件还认的 `icon` / `tooltip` / `key` 一律不放行）。
   - **布局选项**（`DATA_PAGE_LAYOUT_PROPS`，缺省全开）：`regions`（八个区域 `query` / `toolbar` / `table` / `operate` /
     `pagination` / `infoCard` / `addForm` / `modifyForm`，`table` 不可关）、`toolbarButtons`（0.4.2 起只认
     `add` / `exp` / `gridexp` / `search` / `clear`，见上面那张表）、`rowOperations`（0.4.0 起只认 `modify`）、`queryExpanded`（缺省 `false` = 折叠成一行）、
     `pageSize`（20）、`pageSizes`（`[10,20,50,100,200,500,1000]`）、`infoCardTabs`（信息卡分段）。
     每条都有 Vue prop 校验器：取值不在名单里、区域表里出现不认识的键、`table: false`、`customOperations` 缺 `name` / `label`，
     在宿主的开发版 Vue 下都会当场报出来（Vue 2 的校验器只在非 production 构建里跑）。
   - **宿主决定**：`readOnly`（**缺省 `true`**）、`abilities`（0.4.5，缺省不传，见本步最后一条）、`myStyle`（缺省 `'width:100%;height:100%'`）。
   `readOnly` 为真时把与 `CRUD_READ_ONLY_PROPS.hideButton` 逐键相同的那张表盖在 `toolbarButtons` / `rowOperations` 的解析结果之上，
   并把 `isReadOnly` 传给原件（`authButton` 整表取只读值），新增 / 修改窗口即使在 `regions` 里也不渲染。
   **写能力只能由宿主显式 `readOnly: false` 打开，容器不替谁做这个决定。**
   - **宿主的能力表 `abilities`**（0.4.5，缺省不传）：宿主按登录的这个人的权限算出来的一张闭合的表，五个键都可不写，值是布尔。
     某个键为 `false` 时拿掉对应的入口，即使布局列了它：

     | 键 | 为 `false` 时拿掉 |
     |---|---|
     | `create` | 工具栏「新增」（`add`） |
     | `update` | 行内修改图标（`modify`）。本容器没有卡内的修改入口（信息卡的操作面板是零渲染替身），`handleOperationEvent` 的 `common_update` 那条路同样守着这一键 |
     | `export` | 「模板导出」（`exp`）与「表格导出」（`gridexp`） |
     | `delete` | 行内删除——本来就不在名单里（见已知限制「不提供删除」），写它只是把规则写全 |
     | `import` | 「模板导入」（`imp`）——本来就不在名单里（见已知限制「不提供导入与批量」），同上 |

     为 `true` 或不写那个键 = 布局说了算。**只能拿掉、不能添上**：布局没列的入口，能力表全写 `true` 也画不出来。
     一个入口画得出来，当且仅当 **布局列了它 ∧ `readOnly` 不盖掉它 ∧ `abilities` 没有为它写 `false`**；三层都只会置隐，
     谁的先后都不改变结果。不认识的键、不是布尔的值（`'false'`、`null`）逐个忽略，其余键照常生效；开发版 Vue 下
     prop 校验器报一条警告，生产版什么都不报。**改这条 prop 之后入口随之增减**：同一个实例、不重挂、不重查。
     `abilities` 不改 `load` 载荷里的 `authButton`（那是后端权限表的记录，见已知限制），也不碰查询 / 清空。
     它是宿主的 prop，不在 `DATA_PAGE_MODEL_SETTABLE_PROPS` 里：**权限由宿主算，不给模型设**。
5. **根事件十三条。** 桥只能在它挂载的那个组件上挂监听器，而 Vue 2 的 `$emit` 不冒泡，所以这些都发在 `DataPage` 根上：

   | 事件 | 载荷 |
   |---|---|
   | `load` | `{ schemaConfig, authButton }`。`authButton` 是**已解析**的按钮权限（`readOnly` 为真时是全 `false` 的只读记录，为假时是后端权限表那一行原样，值是 `0` / `1`）。顺序是承重的：`authButton` 在发这条事件之前就定下来 |
   | `query-success` | 后端查询接口的 `data`（`rawValue` / `displayValue` / `ref` / `page`）。回给模型的仍只该是 `page.total`、`displayValue.length`、`page.currentPage` |
   | `table-cell-click` | el-table 的 `cell-click` 原样透传：`{ row, column, cell, event }`，`column.property` 是被点列的 attr |
   | `table-selection-change` | `(displayValueList, rawValueList)` 两张表，勾选与单选都会发（补丁 `0008` 把它从 `TableDetail` 转发到 `CrudTable`，容器再发一次到根上） |
   | `table-operation-custom` | `(scope, item, rawValue)`：`item` 就是 `customOperations` 里的那一项。容器自己不做任何事 |
   | `info-card-open` / `info-card-close` | 开：`{ id, name, type }`（被点那一行）；关：无载荷 |
   | `add-save-success` / `modify-save-success` | 后端保存接口的返回值。发出后容器自己会重查一次 |
   | `export-task-created` | `{ mode, fileType, uuid }` 三个标量（0.4.2 新增）：`mode` 是 `'excel'`（模板导出）或 `'grid_csv'`（表格导出），`fileType` 是下拉里选的 `'csv'` / `'qrcode'`（点按钮主体时为 `null`），`uuid` 是后端给这次导出任务的任务号。载荷里没有行、没有查询条件；文件不在这一页产生 |
   | `access-denied` | `{ meta, reason }`（0.4.3 新增，`reason` 是 0.4.4 加的）：页级权限不给看这个模型。`reason` 只有两个取值——`'no-row'`（权限表拿到了，里面没有这张表那一行）与 `'no-rights-table'`（权限表根本拿不到）。每个实例最多一条，发出时这一页一条请求都没发过，之后也不会发。载荷里只有模型英文名与这个枚举——宿主本来就知道自己传了什么，这条事件是给用户一句交代用的 |
   | `auth-failed` | `{ status, code? }`（0.4.4 新增）：请求层判定身份不通过（HTTP 401、业务码 3，或者干脆取不到凭据——那时 `status` 是 `0`）。**发这条事件的同时一个字节的地址都没改**：原件在这条路上跳部署的登录界面，补丁 `0013` / `0015` 把它换成了这条事件加一张盒内提示。一次挂载最多一条，直到这一页又有一次成功的请求（`load` / `query-success`）为止 |

   **没有删除相关的事件**：0.4.0 不摆删除确认窗口，`rowOperations` 也不放行 `delete`（见已知限制）。

6. **页级权限（0.4.3，0.4.4 补全）。** 容器挂载时先取一次用户信息（toy-core 的缓存路径 `queryUserInfo(false)`，缓存里那份
   与当前凭据对得上就一个请求都不发），按 `auth.resclass` 判这个模型给不给这位访客看。三种结果，**后两种都是一条数据请求都不发**：

   | 用户信息 | 结果 | 画什么 | 事件 |
   |---|---|---|---|
   | `auth.resclass` 是一张**在场的表**，里面有 `relatedMeta` 那一行 | 给看 | 照常这一页 | `load` / `query-success` |
   | `auth.resclass` 是一张**在场的空表**（`[]`） | 给看（不设限） | 照常这一页 | 同上 |
   | 表在场、里面没有这一行 | 不给看 | 原件那张「无权限」 | `access-denied` `{ meta, reason: 'no-row' }` |
   | 用户信息接口答 4xx、业务码不是 0，或者答里没有 `auth.resclass` | 不给看 | 同上 | `access-denied` `{ meta, reason: 'no-rights-table' }` |
   | 后端一个字都没答（断网、超时、5xx） | 判不出来 | 盒内一条「取不到访问权限，这一页没有取数」（与方案取不到时同一条路） | 无 |

   **在场的空表与不在场不是一回事**，0.4.4 靠这条分界把现场那个缺陷补上：空表是「答过了，一行都没有」，
   toy-core 自己那几处读它的地方（`core/auth.js:26`、`crud/crudUtil.js:76`、`crud/schemaAuth.js:67`）都写成
   `_.get(userInfo, 'auth.resclass', [])`，两者在它们眼里一样，所以本包只在页级这一判上把它们分开：
   空表沿用原件 `ResCrud.vue:92` 的 `if (!_.isEmpty(resclassList))`＝不设限，不在场则是「判不出权限」＝不给看。
   `readOnly`、`regions` 这些 props 在这条路上没有落点，谁都绕不过这一判。

   **拒绝是一种状态，不是一次报错**：取用户信息那一条请求带着 `__silent__`（补丁 `0016`），所以后端那句
   「用户没有资源权限!」不会变成一条红色的报错 toast，页面上只有那张「无权限」。
   存储里连凭据都没有时也是这一档（`queryUserInfo` 取不到凭据直接回 `{}`）：零请求、`no-rights-table`、
   那张「无权限」——原件在这时由请求拦截器整页跳登录界面。

   **用户信息那一条答 401 时两条信号都会发**：请求层按 401 报一条 `auth-failed`（它不知道这是谁发的请求），
   页级判定按 4xx 判成不给看——画出来的是那张「无权限」，宿主同时知道「这是身份的问题，不是这张表的问题」。

   **宿主拿到 `access-denied` 之后要做的两件事**：给用户一句话（`no-row` 是「这张表不在你的权限里」，
   `no-rights-table` 是「取不到你的权限，先确认账号开通了没有」），以及回给模型一条有界的说明——
   载荷里只有模型英文名与那个枚举，回传它们就够，别把用户信息或权限表带回去。

## 本包不改地址：整页跳转的逐处清单（0.4.4）

0.4.3 之前这一条是「已知限制（D8，记录不修）」。现场把它变成了事故：一个没有资源权限的账号打开这一页，
用户信息接口答 HTTP 400 / `code: 1` / `msg: 用户没有资源权限!`，请求层随后把**宿主的顶层窗口**换成了部署的登录页
（`…/toy-login/#/?redirect=…&httpstatus=401`），页面上先闪过一条红 toast，那张「无权限」一次都没画出来。
成因是两条叠在一起：`core/user.js` 的 `searchUserInfo` 把失败吞掉、5 秒后 `removeToken()` + `redirectLogin(401,0)`；
而它吞掉之后又在 `undefined` 上读 `.code`，抛出的 `TypeError` 让容器的 `created` 停在半路，页级那一判一个结果都没写下。

0.4.4 起：**本包一个字节的地址都不改**。下面是闭包里每一处会离开本页的写法，逐处给出落点与结论；
产物里现在 `location.href =` / `location.assign(` / `location.replace(` / `top.location =` 一处都没有（门禁第 16 条）。

| 位置（`src/vendor/` 之下） | 写法 | 够得到吗 | 怎么办的 |
|---|---|---|---|
| `toy-core/core/login.js:73` | `window.location.href = loginUrl`（`redirectLogin`） | **够得到**，四条路都汇到这里 | 补丁 `0013`：改成通知监听器；`DataPage` 在 `created` 里登记，收到就发 `auth-failed` 并在盒子里画一条提示 |
| `toy-core/api/axios.js:105` | 请求拦截器取不到凭据 → `redirectLogin()` | **够得到**（存储里没有凭据时每条请求都走这里） | 同上一行的通知；`status` 记成 `0`（没有 HTTP 往返） |
| `toy-core/api/axios.js:202` | 响应拦截器业务码 3 → `removeToken()` + `redirectLogin(status, …)` | **够得到** | 补丁 `0015`：不再删凭据（宿主登录闸读的就是那一条），改成带业务码的通知 |
| `toy-core/api/axios.js:212` | 响应拦截器 HTTP 401 → `removeToken()` + `redirectLogin(status, …)` | **够得到** | 同上 |
| `toy-core/core/user.js:78` | 取用户信息失败 → 5 秒后 `removeToken()` + `redirectLogin(401,0)` | **够得到**（现场走的就是这条） | 补丁 `0014`：整段去掉，错误原样抛给页面；toast 也一并去掉（改由 `0016` 的 `__silent__` 与页面自己的状态承担） |
| `toy-core/core/login.js:46` | `getLoginUrl()` 读 `window.location.origin` / `pathname` 拼登录地址 | 读地址，不改地址 | 留着（`0013` 之后没有调用点） |
| `toy-core/core/router.js:59` | `window.location.href = '/toy-proxy/toy-redirect/page-error/?code=401…'`（`isToRouteAuth`） | 够不到：只被 `beforeEach` 全局守卫调用，本包没有 vue-router，两条导出都不注册守卫 | 补丁 `0018`：仍改成一条身份不通过的通知——为的是产物里一处整页跳转都不留 |
| `toy-core/core/router.js:94,133` | 守卫里没有凭据 → `redirectLogin()` | 同上，够不到 | 随 `0013` 一起变成通知 |
| `toy-core/mobile/core/plugins.js:359` | `window.location.href = url`（`startApp` 没有原生桥时的退路） | 够不到：整个 `mobile` 分支只被 toy-core 桶入口带进闭包，两条导出一个调用点都没有 | 补丁 `0019`：调用即抛错 |
| `toy-core/mobile/core/init.js:67`、`mobile/core/router.js:34` | `redirectLogin()` | 同上，够不到 | 随 `0013` 一起变成通知 |
| `toy-core/core/auth.js:90,107` | `thisRef.$router.push('/vault/vault-apply' \| '/vault/vault-check-sum')`（金库权限） | 够不到：`checkOperAuth` 第一行 `if (!isVaultAuth()) return true`，而 `getLocalConfig('auth.vault.enable')` 在本包里永远是 `undefined`（`setLocalConfig` 的三个调用点都在 toy-core 的 init 里，两条导出都不走 init） | 不动。**复查触发器：要接金库权限时** |
| `toy-ui/…/ActionTempImp.vue:80` | 导入任务排上之后 `this.$router.push('/resmgt/task-main-page')` | 够不到：`toolbarButtons` 名单层面就不放行 `imp`，这个组件连画都不画 | 不动（`imp` 恢复时连同这一处一起改，见「不提供导入与批量」） |
| `toy-ui/…/CrudAction.vue:347` | `window.open(标签打印地址)` | 够不到：只在批量下拉的 `label-printer` 命令里，而批量按钮不在 `toolbarButtons` 名单里 | 不动。新开一个标签页不换掉宿主页面，与本节说的「跳转」不是一回事 |
| `toy-core/api/service/expimp/index.js:26,40,163` | `window.open(带凭据的下载地址)` | 够不到：只被 `CrudMenu`（零渲染替身）与不在闭包里的任务状态面调用 | 不动，同上 |
| `toy-core/utils/openWinUtil.js:34,93,166` 与 `:115` 的 `router.push` | `window.open` / 路由跳转的通用工具 | 够不到：闭包里没有任何 import（`utils/index.js` 的桶把它带进来而已） | 不动，同上 |
| `toy-core/utils/routerUtil.js:27` | `$router.push`（刷新当前路由） | 够不到：同上，零 import | 不动 |
| `toy-ui/…/XyComp.vue:124` | 把 `$router` 放进 `$toybus` 事件的载荷里交给地图 | 够不到：`XyComp` 只在有 `$toybus` 时发事件，本包没有装 toy 的事件总线；而且它传的是引用，不是跳转 | 不动 |

**没有 `window.top` / `window.parent` / `top.location` 的写点**：整个闭包里一处都没有（门禁第 16 条连它们一起扫）。
现场看到的「顶层窗口被换掉」是 `location.href` 本身——组件就画在宿主的顶层文档里，没有 iframe 隔着。

**身份不通过时宿主要做什么。** `auth-failed` 的载荷只有 `{ status, code? }`。本包不知道宿主的登录闸长什么样，
所以它只负责「不跳转 + 说出来」：宿主收到之后可以刷新自己的凭据再重挂这一块，或者给用户一句话。
**同屏多块时每一块都会收到同一条**——请求层不知道是哪一块发起的请求（与 nprogress、遮罩那两个单例同一个原因）。
`Crud` 那条导出不发这个事件（它没有这一段容器代码）：对它来说这条路的结果就是「什么都不发生」，页面停在原地。

## 已知限制（Known Limitations）

**只读是对表里的数据说的：每次查询都会往后端写一条审计记录。** `Crud.vue` 查询成功后调 `crudEventLog(relatedMeta, 'query', queryParams)`，
请求层带着访客的 token POST `<基路径>/nrms-resourcehistory/api/log/frontevent/`，写下一条记在访客名下的记录：`app_enname` 是宿主页面的
pathname，`event_title` 是「查询」，`resclassenname` 是表名，`event_data` 里是这次查询的参数——宿主传下来的隐藏 `conditions` 也在其中。
补丁 `0006` 只吞掉这个请求失败时的拒绝，不阻止它发出。**复查触发器：部署不愿意让控制台里的查询进他们的审计流水时**——那时要在挂载前顶掉
`ToyCore.core.log` 的这个出口。

**同屏多个块共用两个单例。** nprogress 与请求遮罩都是模块级单例，落在最后一次 `containCrud` 的盒子里，注销后退回上一个（一个都不剩时进度条退回 `body`，没有样式、不可见——nprogress 只认选择器且对选不到的父元素不判空，这一步是卸载后在途请求不抛错的前提；探针钉住）；
请求层不知道是哪个块发起的请求。

**必填查询条件为空时的提示走宿主的 element-ui。** `QueryCondition` 用 `this.$message.warning()`（element-ui，挂到 body），
`containCrud` 用 MutationObserver 把新落到 body 的 `.el-message` / `.el-notification` 挪进盒子并改成绝对定位；
这依赖宿主页面上的 element-ui toast 都来自本包的块（宿主自己的 UI 不是 element-ui）。

**trans / 多选 / 自动命名 / 编码模板 / cron / 区域 / 线路七种值控件是禁用输入框。** 方案里这类属性的查询条件输入框不可编辑，
显示「该控件在本环境不可用」。**复查触发器：需要按关联属性过滤时**——那时要么接上 `TransComp`（连同它的写路径「+」按钮一起审），要么由宿主传候选值。

**图标没有字体。** `TcAwesomeIcon` 渲染成空的 `<i class="fa fa-*">`；本包不带 font-awesome。`Crud` 上没有任何可见的图标位。

**能搬走的最小单位是「一页」，不是一个个部件。** 拼装探针（`spike-parts/`，不入库）逐条量过：部件之间本来就靠 `$refs` 互相够——
查询条件从 `$refs.crudQueryCom.getData()` 来、页码从 `$refs.crudPagination.getData()` 来、选中行与列名从 `$refs.crudTable.getData()` 来、
刷新信息卡要 `$refs.crudSmallCard.refreshData()`；`CrudAction` 还声明了一条必填的 `crudRef`，顺着它取 `crudRef.$refs.crudTable.getData()`；
`SmallCard` 用函数 prop `refreshParentFn` 回调父页。所以 `DataPage` 是一个「内部摆法可配」的容器，而不是一堆可以自由组合的零件；
`controller.js` 因此做成混入（抄来的方法一字不改地成立），而不是外部 store。

**`crudRef` 的两条 Vue 警告（已绕开，记录）。** 拼装探针照抄原件写 `:crud-ref="this"`，Vue 2.7 的开发期渲染代理观察这个 props 值时
会报 `Property "__ob__" must be accessed with "$data"` 与 `"__v_isRef" is not defined` 两条警告（出自这条绑定本身，不出自拼装）。
容器改成传 `Object.freeze({ $refs: this.$refs })`：冻结对象不可扩展，Vue 的 observe 直接跳过，两条警告随之消失，
`CrudAction` 顺着它取选中行的那条路不变（`$refs` 是同一个对象）。**原件 `Crud.vue` 里那条绑定没动。**

**页级权限：实现的是视图的意图，不是它的行为（0.4.3）。** 判定抄自 `toy-ui/views/ResCrud/ResCrud.vue` 的 `initAuth()`
（`ResCrud.vue:87-99`）：`userInfo.auth.resclass` 非空、而其中没有当前模型那一行时 `isAuth = false`（`:95`），
模板改画一张「无权限」（`:16-21`，样式 `:224-238`），`initData()` 也会在开头收手（`:102-104`）。
**源库里这条检查一行都没生效**，两处各自都足以让它失效：`initAuth()` 最后一行无条件 `this.isAuth = true;`（`:98`）把 `:95`
刚置下的 `false` 盖掉；`created()` 又是先 `await this.initData()`（`:72`）再 `initAuth()`（`:73`），所以 `initData()` 那条
`if (!this.isAuth) return` 在首次渲染时看到的一定是初值 `true`（`:48`）。源库那一侧**删掉 `ResCrud.vue:98` 这一行**
这条检查就活过来（要让 `initData()` 的收手也一起生效，再把 `:72` 与 `:73` 对调）。本包不改源库——`ResCrud.vue` 是视图，
不在闭包里，一个字节都没拷；判定重写在 `src/data-page/page-access.js`，落点在 `DataPage.vue` 的 `created`。
与原件有意不同的三处：原件把「无权限」叠在照常取数的 `Crud` 之上，本包判不通过时一个子部件都不摆、一条请求都不发，
那张「无权限」就是整页；原件对外没有任何信号，本包发一条 `access-denied`，宿主才有话对用户说；原件只认「表里没有这一行」
一种不给看，本包（0.4.4）把「权限表根本取不到」也算进去——**判不出权限就不给看**，两者靠 `reason` 分开。

**取用户信息这一次会发两遍（0.4.3 起，记录不修）。** 容器的页级判定走 `queryUserInfo(false)`，而 toy-core 的
`mixins/user`（`controller.js` 带着它，原件 `Crud.vue` 也带着）在 `created` 里发同样的一次调用；缓存对得上时两次都不发请求，
对不上时后端会收到两条一样的 `GET /nrms-auth/api/auth/userinfo`（探针里量到的就是 2 条）。这与原件里
「视图判权限 + 子组件取用户信息」的两次调用逐条相同，toy-core 没有在途去重，本包不替它加。

**`auth.userinfo.button.visible === false` 不放宽页级这一判。** 原件只在 `Crud.vue` 的 `initAuthButton()`
（`Crud.vue:1169-1176`）读这条配置，把**一页之内的按钮**整表置真；页级那一条（`ResCrud.vue:87-99`）一个字都没提它——
放宽按钮不是放宽这一页本身。何况本包里这条配置永远读不出值：`getLocalConfig()` 的那份默认配置只有 `loginUrl` /
`isUrlToken` / `arcgisApiUrl` / `fileServiceBaseUrl` / `baiduStaticImageUrl` 五条（`toy-core/core/config.js:10-21`），
写它的 `setLocalConfig()` 只有 `core/init.js:39,70` 与 `mobile/core/init.js:74` 三个调用点，两条导出都不走 toy-core 的 init。

**模型权限表在这个容器里不决定按钮。** `CrudAction` 与 `CrudTable` 只在 `useCloudPermission: true` 时才把 `authButton`
叠进按钮显隐（`CrudAction.vue:209-239`、`CrudTable.vue:207-235`），而容器固定 `useCloudPermission: false`——显隐全由
`hideButton`（即 `readOnly` / `toolbarButtons` / `rowOperations`）决定，`load` 载荷里的 `authButton` 只是记录。
`auth.resclass` 那一行真正还起作用的是列权限（`schemaAuth.getAuthColumns` 读它的 `columns`）与脱敏（`getShowAsPass`）。
**所以页级这一判是这个容器里唯一挡得住「这张表不在你的权限里」的东西。**

**按人收窄按钮走 `abilities`，不走原件的 `useCloudPermission`（0.4.5）。** 打开 `useCloudPermission` 等于让
`CrudAction` / `CrudTable` 读 `authButton` 那一行的权限布尔（`add` / `update` / `search` / `exp` / `imp` …）；
而现场的真后端对**每一个账号**给的这几个值都是 `null`——`search` / `exp` / `imp` 连管理员也是 `null`——
打开它这一页就连查询按钮都不画了。所以容器仍固定 `useCloudPermission: false`，按人收窄的决定交给宿主：
宿主用自己的规则（例如一个 `may(model, op)`）算出 `abilities` 传进来，容器只按它拿掉入口。

**不提供删除（0.4.0 起）。** 删除确认窗口（`SaveResultRealbatchDialog`）在两条导出上都仍是零渲染替身：行内那个图标点下去
只把内部的 `dialogVisible.crudDeleteVisible` 置真，没有窗口会打开。放一个点了没反应的图标比不放更糟，所以
`rowOperations` 在名单层面只认 `modify`，写 `'delete'` 会被 prop 校验器当场拒掉，事件表里也没有删除那一条。
**恢复条件：删除窗口从替身表里放出来、它的批量删除接口审过**——那时把 `'delete'` 加回 `DATA_PAGE_ROW_OPERATIONS`，
`resolveHideButton` 的映射（`delete: !rows.has('delete')`）与 `Crud.vue` 1642-1651 那段 `delete-save-success` 一起回来。
`abilities.delete`（0.4.5）因此眼下只是把规则写全：它为 `false` 时置隐的 `delete` / `batchDelete` 两个键本来就是隐藏的；
恢复条件到了之后，它为 `false` 时照样拿掉行内删除。

**导出是排任务，不是下载（0.4.2）。** 模板导出与表格导出各自 `POST` 一次导出接口，后端回一个任务号；
页面上只会出现原件那条提示「生成导出任务成功，请在任务列表中查看导出结果！」（落在盒子里），
外加根上一条 `export-task-created`。**文件要去部署自己的任务列表页取**，本包不带那一页，
所以宿主如果要给用户一条去处，得自己用这条事件的 `uuid` 拼。导出的范围是原件定的：没勾行时用当前查询条件
（表格导出还带上当前显示的列），勾了行就换成 `int_id IN 选中的那些`（浏览器探针逐条量过）。
**复查触发器：需要在这一页直接拿到导出的文件时**——那时要把 `toy-ui/component/task/TaskStatusDialog` 那棵子树
连同 `service.expimp.getExpImpStatus` 一起审进闭包（文件本身由 `toy-core/api/service/ffile` 的 `downloadFile`
取：blob + `<a download>` + `click()`，在宿主页面里成立，但带 `sandbox` 的 iframe 里要 `allow-downloads`）。

**不提供导入与批量（0.4.2 起）。** 理由与删除同一条：按下去到不了任何界面。
- **模板导入**（`imp`）：`ActionTempImp` 会打开系统选文件框、把 xlsx 交给导入任务接口，随后原件跳部署的任务列表页。
  导入一次改的是整表数据，而成败、失败在第几行、要不要回滚，在这一页一个字都看不到。
  **恢复条件：任务状态面搬进闭包、导入结果能在盒子里看到**——那时把 `'imp'` 加回 `DATA_PAGE_TOOLBAR_BUTTONS`。
- **批量修改 / 批量删除**（`batch`）：两个窗口（`ModifyRealbatchDialog` / `SaveResultRealbatchDialog`）在两条导出上
  都是零渲染替身，命令发出去只写一条审计日志。**恢复条件：这两个窗口从 `VENDOR_REPLACEMENTS` 里放出来、
  批量接口审过**。

两条的映射都留在 `resolveHideButton` 里写成 `!toolbar.has(键)`（而不是写死 `true`），恢复时只改那一张名单。
`abilities.import` 同理只是把规则写全（0.4.5）：`imp` 本来就是隐藏的；恢复条件到了之后，它为 `false` 时照样拿掉那个按钮。

**`toolbarButtons` 只决定显隐，不决定先后。** 按钮顺序写死在 `CrudAction.vue` 的模板里（新增 / 模板导入 / 模板导出 / 表格导出 / 批量 ｜ 查询 / 清空），
不重写那份模板就换不了；本包不重写原件，所以这条 prop 是一张「留哪几个」的名单，传进去的先后被忽略。

**信息卡只有两段是真件。** `wrong-info`（异常信息）与 `attributes`（关键属性）是原件；`operation` / `related-stat` / `useage` 与
服务 / 事件两个操作面是零渲染替身（见替换表）。`infoCardTabs` 是一层过滤：它只能从方案下发（或默认）的那张分段表里减，减不出新的段。

**poppers 由 `containCrud` 收进盒子，收不下的那些仍留在 body 上（0.4.1 改）。** 窗口本身 `append-to-body=false` +
`dialog-absolute` + `dialog-max`，铺满宿主盒、不越界（浏览器探针量到 `.el-dialog` 1440×512 @(0,0) 与宿主盒逐像素相同，
落到 body 上的窗口 0 个）；但 element-ui 的 `el-select` / `el-date-picker` 缺省把下拉挂到 `document.body`
（`popper-append-to-body` 默认真）。0.4.0 量到的是：下拉 110×252 @(993,513)、宿主盒 1440×512 @(0,0)，**下沿比盒子低 253px**——
盒子的 `overflow: hidden` 管不到 body 的子节点，所以这一截既不会被裁掉，也不会被推出视口（贴着视口底时 element-ui 自己会向上翻），
但它画在宿主页面上，盖住盒子下面的东西。

0.4.1 起 `containCrud` 的观察器把这类 popper 收进盒子，并把 element-ui 内置 popper.js 的 `boundariesElement`
从 `viewport` 换成盒子本身。**两件事必须一起做**：只收不换边界，下拉仍按视口摆，进了 `overflow:hidden` 的盒子反而被裁掉；
只换边界不收，那份 popper.js（0.6 分支）用 `getOffsetRect(boundariesElement)` 取边界，拿的是相对盒子自己 `offsetParent`
的 `offsetTop/offsetLeft`，而 popper 的坐标相对 `documentElement`，两套坐标只在盒子的 `offsetParent` 恰好是文档时才重合。
收进盒子之后 `getOffsetParent(popper) === box`，popper.js 走 `{0, 0, clientWidth, clientHeight}` 那一支，边界与坐标同在盒子里：
放不下就翻到参照物上方，还放不下就贴着盒子的边。探针量到的三档（每页条数那张 110×252 的下拉）：盒子在视口顶时 `top-start`、越出盒子 0px；
盒子贴着视口底（下沿离视口底 8px）时仍是 `top-start`、越出盒子 0px、越出视口 0px；盒子只有 224px（装不下 252px 的下拉）时**不收**，
父节点仍是 body、整段可见——收进一个裁切的盒子会少掉一截，留在 body 上至少是全的。
440×343 的日期面板在同样三档里量到同样的结论（第三档里它比 224px 的盒子高 119px，不收）。

**0.4.2 把「从节点找到它的 popper.js」补全成三条路**，页内四类 popper 因此全收（各自的量值见 `probe/browser/RESULT.md`）：

| popper | 从节点怎么够到 popper.js | 量到的落点 |
|---|---|---|
| `el-select` 的下拉（每页条数、查询区与表单里的下拉） | popper 就是组件自己的根节点，`node.__vue__` 一步到位 | 收进盒子，边界是盒子 |
| `el-dropdown` 的菜单（表格导出的拆分按钮） | 外面裹着一层 `<transition>`：它是抽象组件、`$el` 与被裹的组件同一个节点，而 Vue 2 的 `_update` 后写的是它。抽象组件不进 `$children`，但自己的 `$parent` 照样指着声明它的组件，所以沿 `$parent` 往上找、只要还是同一个 `$el` 就继续 | 收进盒子 |
| `el-date-picker` 的面板 | 面板由 `new Vue(panel).$mount()` 另起的实例渲染，`__vue__` 是那个实例、连 `$parent` 都没有，而 popper.js 在 `el-date-picker` 身上：只能反过来从盒子那棵组件树上找 `popperElm === node` 的那个组件（`ownerInBox`） | 收进盒子；铺满盒子的新增 / 修改窗口打开时，面板 `z-index` 2008 > 窗口 2006，面板中心处 `elementFromPoint` 命中的是面板自己 |
| `el-tooltip__popper`（行内图标的提示） | 同上：popper 由 `el-tooltip` 自己另起的 Vue 实例渲染 | 收进盒子（0.4.1 还留在 body 上） |

`ownerInBox` 从盒子的子元素往下找到最近的带 `__vue__` 的元素，再按 `$children` 走那棵组件树，只在前两条路都够不到时才走；
没有 `__vue__` 的节点直接跳过。**本包闭包里没有 `el-cascader`**：级联类的控件（`TransComp` / `TransCascade` / `AreasComp` /
`LinesComp`）全是禁用输入框替身，一个级联面板都画不出来，所以这一类没有可量的落点。

**仍然不收的一类**：宿主自己页面上的 poppers——它们的参照物不在盒子里，观察器按 `box.contains(referenceElm)` 一眼分开。
**复查触发器：element-ui 大版本变了，或盒子矮到装不下页内的某张面板时**——前者会让 `popperJS._options` 这条路走不通
（走不通就整体退回 0.4.0 的行为，不会画错），后者在探针里是第三档那两条检查。

**闭包带着整个 toy-core。** 真实桶入口把 gis / mobile / uavServer / 微应用 / 水印等 107 个文件一起带进来，闭包 193 个文件 / 25,792 行
（toy-core 107、toy-ui 72、toy-comp 14）——0.2.3 是 177 个文件 / 23,775 行，0.4.0 多出来的 16 个全是 toy-ui：
信息卡 6（`SmallCard` + `CardContent` + 异常信息 + 关键属性 + `initData` 混入 + 桶）、新增 / 修改窗口 8、定制表尾 1、弹框混入 2 里的其中若干。
0.4.2 的闭包与 0.4.1 逐文件相同：补丁 `0011` / `0012` 改的是本来就在闭包里的 `ActionTempExp.vue` 与 `CrudAction.vue`。
0.4.3 的闭包与 0.4.2 逐文件相同：页级权限那一判写在本包自己的 `src/data-page/page-access.js` 里，没有新的补丁，也没有新拷进来的源库文件。
0.4.4 的闭包也与它们逐文件相同，行数少了 22（七个补丁净删的行，`0014` 去掉的那段吞错误 + 跳转最多）：改的七个文件本来就在闭包里。
**新增 npm 说明符零个**：这 16 个文件没有引进任何新的裸规格（`tools/compute-closure.mjs` 的输出逐条打印裸规格，与 0.2.3 的名单一致）。
随之打进产物的 npm 库仍是 40 个（直接的 axios、nprogress、localforage、qs、crc-32、crypto-js、
mitt、json5、array-to-tree、ua-parser-js、resize-observer-polyfill、coordtransform、color、randomcolor、`dayjs/plugin/isBetween`，
连同它们的传递依赖）——完整名单、版本与条款见随包的 `BUNDLED.json`，许可证正文见随包的 `THIRD-PARTY-LICENSES.txt`，两份都由 `pnpm run build`
从 rollup 的模块图上生成，门禁第 15 条钉住「每个内联库都有条款和正文」。产物 `dist/index.js` 965,088 字节 / gzip -9 后 244,637 字节
（0.4.3 是 961,842 / 243,467，+3,246 / +1,170 = +0.34% / +0.48%，来自身份不通过那条路与页级权限的第二档；
0.4.2 是 960,074 / 242,835；0.2.3 是 878,120 / 222,021）；其中样式 30,690 字节 / gzip 5,768 字节、192 条规则
（与 0.4.3 逐字节相同——0.4.4 一条 CSS 规则都没加，那两条新状态一条用原件的 `.no-auth`、一条用本包已有的盒内提示；
0.4.2 是 30,004 / 5,489 / 191，0.2.3 是 18,762 / 3,687 / 127），
全部以 `[data-toy-crud-box]` 开头（`html` / `body` / `:root` 变成盒子本身，
nprogress 加在盒子上的 `.nprogress-custom-parent` 接在盒子本身上）。tgz 约 308 KB（26 个文件：产物、类型、三份台账与十九个补丁；台账 `MEASUREMENTS.json` 与探针结果表不在其中）。
**这两个数不是宿主要下载的全部**：`lodash` 与 `dayjs` 是 external，由宿主装、打进宿主自己的包——`lodash` 4.18.1 自带的构建
545,945 字节 / gzip 96,961 字节，`dayjs` 1.11.23 的 `dayjs.min.js` 7,161 字节 / gzip 3,047 字节。宿主的第三方声明要把这两个也算上
（`MEASUREMENTS.json` 的 `external` / `external_sizes`）。
**复查触发器：产物超过 1 MB 时**——那时按需替换 crypto-js（只有 token 加密开关打开才用到）与 ua-parser-js。

**TransComp 仍是禁用输入框（这次重新审过，结论不变）。** 放出信息卡与写窗口之后，`TransComp` 是唯一还挡在「按关联属性过滤 / 填关联值」
前面的控件，但它的闭包有三处过不了本包的线：`import { getScrollContainer } from 'element-ui/src/utils/dom'`（深进一个**外置**包的源码目录，
产物里会多一份 element-ui 的 dom 工具，而不是用宿主注册的那一份）；三个 `() => import()` 动态子件
（`TransPlusDialog` / `TransCascadeDialog` / `../modify/ModifySingleDialog`），在 `formats: ['es']` 的库构建里会切出独立块，
与门禁第 5 条「dist 只有 index.js 一个文件」冲突；而 `TransPlusDialog` 里又 `() => import('../../../../Crud')` **回头拉整个 `Crud`**，
`TransCascadeDialog` 再拖进 `TransCascade` 与 `CustomMade/CommonNeSelect` 两棵新子树。三条都不是改一行能绕开的，**保持替身**。
**复查触发器：需要按关联属性过滤时**——那时先审 `TransComp` 的「+」写路径与这三处。

**构建不是逐字节可复现的。** 同一份源码连着构建三次，会出现 401 / 401 / 398 两种模块数与两份不同的产物；差异只在 esbuild 压缩后的
局部符号名（`FormItemComp.vue` 把 `DisabledInputStub.vue` 同时静态与动态 import，vite 每次构建都会报这条警告）。
功能上没有差别，门禁与探针跑的都是当次的产物；但这意味着「重跑一次构建就能对出同一个 sha256」不成立，
tgz 的 sha256 只对得上那一次打包。

**手写 `.d.ts` 没有编译期靠山。** 门禁只钉三份导出名单一致，props 字段改了不会报错；实际验收场是宿主侧的类型检查。

**门禁里的探针是 jsdom 与假后端，浏览器那一份要另跑。** `probe/backend.mjs` 是能过 `schemaCheckUp` 的最小方案加几行数据（四个模型：`probe_device`、
方案为空的 `probe_missing`、带定制表尾的 `floor_num`、方案齐全但**不在用户信息权限表里**的 `probe_locked`）；el-table 在 jsdom 下画得出 `tr` 画不出 `td`，列的正确性断言落在 store 的列定义上。
`probe/render.mjs`（`Crud`，40 条断言）与 `probe/data-page.mjs`（`DataPage`，59 条断言）都在门禁里跑。
假后端有两个开关（`backend.mjs` 的 `control`）：用户信息接口可以答 400（现场那一条）或者干脆不答（状态码 0 = 网络失败，
`jsdom-host.mjs` 把它变成 XHR 的 error 事件），查询接口可以答 401。跳转在 jsdom 里表现为一条 jsdomError，
探针把它们收在 `navigations` 里；`location.assign` / `replace` 在 jsdom 里是实例上不可改写的自有属性，钉不了替身，
所以探针最后**故意跳两次**、要求两次都被记下来——否则前面每一条「零跳转」只说明探测器瞎了。
假后端的表单项里有两个是为 popper 放的：`state` 是 `edit_select`（`el-select`）、`install_date` 是 `edit_date`（`el-date-picker`），
两者的下拉与面板都由 element-ui 追加到 body，正是浏览器探针的观察点；`install_date` 只在表单里、不在模型属性表里，
所以显示列与信息卡的属性页一条不变。
真浏览器那一份（`probe/browser/`，chromium + 同一个假后端）量的是 jsdom 给不出的几何与交互——折叠高度、窗口铺满宿主盒、
翻页不刷新页面、导出按下去发出了什么、四类 popper 收在哪、不给看的模型画出了什么、盒子的对照矩阵——它需要一份现成的 playwright，所以**不在门禁里**；结果表在仓库的 `probe/browser/RESULT.md`（不随 tgz 走，tgz 里只有产物、类型、三份台账与十九个补丁）。
真机验收仍在宿主侧。

**浏览器探针的结果表停在 0.4.3，0.4.4 是另跑的一次（记录）。** `probe/browser/verify.mjs` 要 playwright，本机没有，
所以 0.4.4 没有重跑它，`RESULT.md` 里的 41 条仍是 0.4.3 那一次的数——**它不覆盖 0.4.4 的两档**。
0.4.4 的浏览器一侧是拿同一个页面（`probe/browser/index.html` + `main.js` + `stub-backend.mjs`）用无头 Chrome
另跑的一次，页面为此多了三个开关：`?userinfo=400`（假后端按 cookie 对用户信息接口答 HTTP 400 / `code: 1` /
`msg: 用户没有资源权限!`，并且不预写缓存）、`?search=401`、`?bg=dark`（深色宿主）；页面底下多了一块读数，
把 `location.href`（挂载前 / 此刻）、根事件、这一页发过的请求都画在页面上，所以截图自己就是证据。
量到的：`?userinfo=400` 在浅色与深色宿主下都画出那张「无权限」（深色宿主下仍是深色字——盒子那条
`color: #303133` 是宿主写下的，`.no-auth` 的底是半透明的白，不钉这条就是白底白字），地址挂载前后逐字节相同，
这一页只发出两条 `GET /nrms-auth/api/auth/userinfo`（页级判定与 `mixins/user` 各一条）、零报错 toast、
根上一条 `access-denied {"meta":"probe_device","reason":"no-rights-table"}`；`?search=401` 则是页面留在原地
（表格画着「暂无数据」）、盒内一条「没有通过身份校验…（HTTP 401，业务码 1）」、根上一条
`auth-failed {"status":401,"code":1}`、地址同样一个字节没变。
**待办：把这三个开关写进 `verify.mjs` 的检查表**，下次有 playwright 时连同 `RESULT.md` 一起补齐。
0.4.5 同样是另跑的一次：页面多一个开关 `?abilities=create:false,export:false`（键:布尔，逗号分隔），无头 Chrome 1440×900、
同一个假后端，`?write=1` 时工具栏是「新增 / 模板导出 / 表格导出 / 查询 / 清空」、每行一个修改图标（20 个）；
加上 `abilities=create:false,export:false` 后工具栏只剩「查询 / 清空」、修改图标仍是 20 个；`abilities=update:false`
时五个按钮都在、修改图标 0 个。三页都是一条 `load` + 一条 `query-success`、零 Vue 警告。这个开关同样还没写进 `verify.mjs`。

**浏览器探针的 41 条检查里有 2 条没跑。** 39 条通过；没跑的两条是「落到 body 上的 `.el-message` 被挪进盒子」
（提示只活 3 秒、逐次跑时有时无，不放会抖的断言，改由 jsdom 探针钉「body 上零越界节点」）与「行内『删除』打开删除确认窗口」
（0.4.0 起就不放行）。这一页曾经整页跑不完，根因是探针自己的 dev server 把 Vue 打了两份（2026-09-18 定位并修好）：
成因、复现与「宿主必须共用同一份 Vue」这条接入要求都在 `probe/browser/README.md`。
**复查触发器：宿主报告块挂上去之后整页卡住时**——先按那一页的两份 Vue 对照量一遍。
