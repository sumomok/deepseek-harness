# @sumomok/toy-crud-kit

把 toy-ui 的整页组件 `component/Crud/Crud.vue` **原样**（不重写）连同它真正依赖的 toy-core 请求层编译成一个 tgz，
作为内容列的 `toy.crud` 种类挂进宿主。首版只读：模型能选「看哪张表、什么条件、怎么排序、能不能勾选」，
不能新增、修改、删除、导入、导出。

数据不经过宿主：组件用 toy-core 自己的 axios，浏览器直接带着访客的 token 请求部署后端；宿主对这个种类什么都读不到，
回给模型的只有列名与计数（见「宿主接入」）。姐妹包 `@sumomok/toy-surface-kit` 保持不动，本包与它并列在同一个 pnpm 工作区里。

`vue` 与 `element-ui` 由宿主提供（external），element-ui 必须已被宿主 `Vue.use` 注册，且 **element-ui 内部 `require('vue')`
拿到的必须与渲染本组件的是同一份 Vue**（el-table 的 store 由 element-ui 自己 require 的 Vue 建立响应式，两份 Vue 会让表格停在首帧的空表）；
`lodash` 与 `dayjs` 是本包声明的普通依赖，同样不打进产物。本包加载时不 `Vue.use` 任何东西，不改 element-ui 的 `size` / `zIndex`（门禁 + 探针钉住）。

## 导出

| 导出 | 形态 |
|---|---|
| `Crud` | toy-ui `component/Crud/Crud.vue` 原件的 Vue 2 组件对象，只多一条本包混入：实例的 `$notify` 换成盒内提示。不能 `Object.freeze`（Vue 2 会往选项对象上写 `_Ctor`） |
| `containCrud(box)` | 挂载前把宿主元素收拾成盒子：打 `data-toy-crud-box` 标记、置 `position:relative`、把请求层的进度条 `#nprogress`、遮罩 `#is-loading-full-overlay`（本包拷贝）、报错 toast（本包拷贝）与 toy-ui 经 element-ui 发出的 `.el-message` 都收进盒子；返回注销函数 |
| `setBizBasePath(path)` / `getBizBasePath()` | toy-core 请求层的业务基路径（axios `baseURL`）。只接受根绝对路径，规范成以 `/` 结尾；返回实际写入值。拒收里有承重的一道：补好尾 `/` 之后拿 WHATWG URL 解析器解一遍，`origin` 或 `pathname` 被改写就抛——`https:` 下解析器把 `\` 当 `/`，`/\host/` 会指向另一个源，`%2e%2e` 会被归一掉 |
| `CRUD_READ_ONLY_PROPS` | 宿主写死、模型不可设的 props（冻结对象） |
| `CRUD_MODEL_SETTABLE_PROPS` | 模型可设的 props 名单 |
| `BOX_ATTR` | 标记属性名 `'data-toy-crud-box'` |

导出面的类型是手写的 `types/index.d.ts`：props 逐条从 `Crud.vue` 的 `props` 声明推出，另给出七个事件的载荷与实例上的公开读方法。

## 搬运规则

1. **源库只读。** 闭包内的文件由 `tools/copy-sources.mjs` 拷进 `src/vendor/`，保留原相对结构，逐文件的相对路径与 sha256 记在 `SOURCES.md`。
   源根从本包位置向上找到同时含三个源库的目录为止（本包在姐妹包之下一层，不能像姐妹包那样按脚本位置推）。
2. **对源码的改动一律是补丁文件。** `patches/*.patch` 一个补丁一个文件，第一行是一行理由，由 `tools/apply-patches.mjs` 按序号打到拷贝件上。
3. **toy-comp 不走桶入口，toy-core 走真实桶入口。** `toy-comp` 别名到 `src/shims/toy-comp.js`——比姐妹包加宽到 7 个组件
   （`TcAwesomeIcon` / `TcNumberComp` / `TcXyComp` / 四个 `TcColumn*`），恰好是 Crud 闭包 import 的那些；原桶会带进
   `menu/tc-*-coll-confirm/main.js` 三个文件，它们在模块求值期 `Vue.use(Element, { size: 'small', zIndex: 2000 })` 并再次 import
   element-ui 的 theme-chalk，进了产物就会改写宿主共享运行时的 element-ui 默认值。`toy-core` 别名到 `src/vendor/toy-core/index.js`
   ——Crud 要 `crudUtil` / `schema` / `config` / `log` / `mixins.user` 以及会发请求的 `service.crud`，姐妹包那个「零网络」替身装不下它。
4. **组件不自己读存储与 cookie；凭据只在 toy-core 的请求层里用，而且只从存储里取。** 这一条替换了姐妹包的「身份与 token 不进组件层」：
   本包的数据本来就是浏览器带访客 token 直连部署后端，token 必须有人读；读它的只能是 `src/vendor/toy-core/api/axios.js` 及其
   `core/token.js` / `core/login.js` / `core/config.js` / `utils/stroageUtil.js` 这一层。门禁第 11 条因此分成三段：
   toy-ui、toy-comp、本包 shims 与入口零 `localStorage` / `sessionStorage` / `document.cookie` / `accessToken` / `Authorization` 读点
   （补丁 `0004` 切掉 `FormItemComp` 里唯一的一处）；toy-core 里触碰它们的文件集合被冻结成一张八个文件的允许表，
   源库重拷后多一个或少一个都失败；整个闭包零「从地址栏取 token」的读点（补丁 `0007`）。
   末一段是承重的：宿主控制台不是这个部署的登录页，地址里的 `?token=` 只可能来自别人给访客的一条链接，而原件的 `getToken()` 认它，
   还用 `setToken()` 把它写进 `accessToken`——正是宿主登录闸读的那个键。这样「谁能碰凭据、凭据从哪来」都是可机械核对的名单，而不是一句承诺。

## 替换表（构建期按解析后的路径顶替，不拷贝原件）

`vite.config.shared.js` 的 `VENDOR_REPLACEMENTS`，由 `vendorReplacementPlugin` 在 resolveId 阶段按解析后的 vendor 路径匹配——
不匹配导入方写下的字符串，同一说明符在别处再出现也不会替错文件。被顶替的原件不进 `src/vendor/`（`tools/compute-closure.mjs` 把它们当作剪枝点）。

| 组 | 被顶替的原件 | 替身 | 为什么 |
|---|---|---|---|
| 永不渲染的子树 | `Crud/component/CrudMenu`、`SmallCard`、`common/query/QueryStatistic`、`common/modify/{ModifySingleDialog, SaveResultRealbatchDialog, ModifyRealbatchDialog}` | `DeadSubtreeStub.vue`（渲染成注释节点） | 只读首版 `hideComp.menu / card` 为真、写窗口的 `dialogVisible.*` 永远为假，但 Crud.vue 静态 import 它们。顶掉之后写窗口在构建层面不存在（探针把 `dialogVisible` 置真也开不出窗口），也一并切掉 vuedraggable / vue-count-to / @antv/g2 / html2canvas / qiankun 与六个 webpack `require.context` 调用点 |
| 直连取数的值控件 | `TransComp`、`TransMulti`、`AutoNaming`、`OdmTemplate`、`SelectCron`、`AreasComp`、`LinesComp` | `DisabledInputStub.vue`（与姐妹包相同） | 七个控件各自静态闭包直连 `ToyCore.service.crud`；其中 `TransComp` 的「+」会打开关联模型的新增窗口（写路径），`TransMulti` 拖进第二个 Crud（`CrudSelect`） |
| 会越界到 body 的 toy-core 模块 | `toy-core/eleui/loading.js`、`toy-core/eleui/message.js` | `toy-core-loading.js` / `toy-core-message.js`（本包拷贝，同一调用面，落在登记的盒子里） | 原件把遮罩与 toast 追加到 `document.body` |
| eval 面 | `toy-core/crud/tableRenderUtil.js` | 调用即抛错 | 原件用 `eval` 求值后端配置的行列颜色表达式；Crud 只读闭包无调用点，只被桶入口带进来 |
| 字体 | `toy-comp/basic/awesome-icon/font-awesome-4.7.0/css/font-awesome.min.css` | 空样式表 | 1.0 MB 字体；图标只出现在被隐藏的导入 / 导出按钮上 |

另有三个只在模块求值期被 toy-core 桶入口带到、Crud 只读路径上永不调用的 npm 库别名到调用即抛错的替身（`src/shims/npm/`）：
`konva/lib/*`（~500 KB）、`svg.js`、`import-html-entry`。

## 七个补丁

| # | 改的文件 | 改了什么 |
|---|---|---|
| `0001` | toy-ui `TableDetailColumn.vue` | 删掉 `cronstrue/i18n` 与它唯一的 cron 列分支（与姐妹包相同） |
| `0002` | toy-ui `DisplayColumn.vue` | 删掉 `DisplayDownload.vue` 的静态 import 与 `display_download` 分支（该文件拖 `@vue-office/*`；与姐妹包相同） |
| `0003` | toy-comp `TcColumnYesno.vue` | 补上 `String(value).toUpperCase` 缺的调用括号，5 处（与姐妹包相同） |
| `0004` | toy-ui `FormItemComp.vue` | 删掉 `token: localStorage.getItem('accessToken')` 与消费它的 `:headers`（搬运规则 4；与姐妹包相同） |
| `0005` | toy-core `crud/crudUtil.js` | 删掉 `getAuthButton` 里的 `console.log(userInfo)`：每次方案初始化都把当前用户的完整信息（含权限表）打到控制台 |
| `0006` | toy-core `api/service/log/index.js` | `frontEventLog` 返回的 Promise 没有任何调用点消费，日志接口一失败就是一次 `unhandledrejection`；吞掉拒绝 |
| `0007` | toy-core `core/token.js` | 删掉 `getToken` / `getToken4a` 从地址栏取 token 的两处分支：`getToken()` 认 `?token=Bearer …` 并 `setToken()` 写进 `accessToken`，任何一条带参数的链接都能改写访客存着的凭据（搬运规则 4；门禁第 11 条第三段 + 探针钉住）。`core/config.js` 里 `isUrlToken: true` 那个默认值随之没有了消费者，留着不动 |

探查阶段发现的四个原件缺陷里，第三、第四个已是补丁 `0005` / `0006`；前两个在只读首版的路径上到不了，不改只记：
`Crud/utils/crudCloudPermission.js` 调的 `ToyCore.axios.get` 不存在（`ToyCore.axios` 只有 `getUrl` 等包装），抛出的 TypeError 被
自己的 `try/catch` 吞掉后返回空表——只有 `useCloudPermission: true` 才会走到，首版固定为 `false`；`Crud.vue` 的 `getCustomMode()`
调的 `crudService.getCustomerMode` 在 `service.crud` 上不存在（在 `service.schema` 上）——该方法没有任何调用点。
**复查触发器：`useCloudPermission` 或定制模板进入导出面时。**

## 命令

```sh
pnpm install                     # 在工作区根目录执行；本包是工作区成员
node tools/compute-closure.mjs   # 用 closure.py 按本包的别名 / 替换 / 补丁剪枝算闭包，写 tools/closure-files.txt
node tools/copy-sources.mjs      # 清空 src/vendor 后从源库重新取一遍闭包文件（会覆盖补丁，需接着重打）
node tools/apply-patches.mjs     # 打七个补丁（要从干净的拷贝件开始）
pnpm run build                   # 出 dist/index.js（样式随 JS 注入，全部规则限定在 [data-toy-crud-box] 之下），并写 BUNDLED.json / THIRD-PARTY-LICENSES.txt
pnpm run build:measure           # 量测构建：样式落成 measure/style.css 供门禁第 13 条逐条复核
pnpm run gates                   # 15 类机械门禁（18 行），含 jsdom 三次挂载冒烟（40 条断言）
pnpm run probe                   # 单独跑挂载探针
pnpm run pack                    # 出 tgz，并对 tgz 内每个文件扫本机绝对路径
```

宿主用 `file:` 依赖装本包，同名 tgz 覆盖会被 pnpm 静默忽略：**内容一变就升 `version` 再 `pnpm run pack`**。

## 宿主接入

顺序固定：写基路径 → 收纳盒子 → 审批 → 挂载。

1. **基路径（D7）。** toy-core 在模块求值期 `axios.create({ baseURL: getBaseURL() })` 一次性读 `window.$toy_env.VUE_APP_BASE_URL`
   （缺省 `/nrms-server/`）。宿主的 `bizBasePath` 配置（根绝对路径，缺省 `/`）要在本包模块求值前写进 `window.$toy_env`；
   求值后再调 `setBizBasePath()` 同样生效——它同时改写 `window.$toy_env` 与已建实例的 `defaults.baseURL`。
2. **盒子（D6）。** 桥挂载前 `const release = containCrud(hostDiv)`，`hostDiv` 就是桥往里追加占位节点的那个元素（Crud 根节点成为它的直接子节点）。
   盒子要有高度（组件默认 `myStyle: 'width:100%;height:100%'`）。卸载后调 `release()`；盒子届时可以已经离开文档，在途请求照常结束。
3. **审批（D4）。** 由宿主在挂载前走审批缝；本包不做审批、不知道会话。拒绝即不挂载，什么都不画。
4. **props（D3）。** `{ ...模型可设的七个, ...CRUD_READ_ONLY_PROPS }`。模型可设：`relatedMeta`（必填）、`conditions`、`matchMode`、
   `querySort`、`selectMode`、`isExpandQuery`、`isInitQuery`；宿主写死：`isReadOnly: true`、`type: 'default'`、`urlConfig: null`、
   `hideButton` 十个写 / 导出键全真、`hideComp: { menu, card }`；`crudUrl` 取默认，`tableCustomOperations` /
   `tableCustomComps` / `queryFormCustomComps` / `rowStyle` / `smallCardBeforeOpen` 不设。探针证明：画出的动作按钮只有「查询」「清空」（另有分页器的
   `btn-prev` / `btn-next` 两个只有图标的按钮），表格无操作列，把 `dialogVisible.*` 置真也没有窗口。
5. **回给模型的（D5）。** `load` 事件：`schemaConfig.query.grid.gridItems` 里 `isShow !== '0'` 的列的 `relatedMetaAttr` + `alias`；
   `query-success`：`page.total`、`displayValue.length`、`page.currentPage`——行永不回传；`table-cell-click`：`row`（显示值）与
   `column.property`（被点列的 attr），宿主按显示列裁成显示值。组件没有 selection-change 事件，首版不轮询 `doGetSelection()`。

## 已知限制（Known Limitations）

**请求层会整页跳转（D8，记录不修）。** `toy-core/api/axios.js` 的请求拦截器在存储里没有 token 时、响应拦截器在 HTTP 401 或业务码 3 时
调 `redirectLogin()`（`window.location.href = 登录地址`）。只在同源部署且宿主的登录闸保持 token 新鲜时可接受；探针在 token 在场时钉住零跳转。

**只读是对表里的数据说的：每次查询都会往后端写一条审计记录。** `Crud.vue` 查询成功后调 `crudEventLog(relatedMeta, 'query', queryParams)`，
请求层带着访客的 token POST `<基路径>/nrms-resourcehistory/api/log/frontevent/`，写下一条记在访客名下的记录：`app_enname` 是宿主页面的
pathname，`event_title` 是「查询」，`resclassenname` 是表名，`event_data` 里是这次查询的参数——宿主传下来的隐藏 `conditions` 也在其中。
补丁 `0006` 只吞掉这个请求失败时的拒绝，不阻止它发出。**复查触发器：部署不愿意让控制台里的查询进他们的审计流水时**——那时要在挂载前顶掉
`ToyCore.core.log` 的这个出口。

**同屏多个块共用两个单例。** nprogress 与请求遮罩都是模块级单例，落在最后一次 `containCrud` 的盒子里，注销后退回上一个（一个都不剩时进度条退回 `body`，没有样式、不可见——nprogress 只认选择器且对选不到的父元素不判空，这一步是卸载后在途请求不抛错的前提；探针钉住）；
请求层不知道是哪个块发起的请求。

**必填查询条件为空时的提示走宿主的 element-ui。** `QueryCondition` 用 `this.$message.warning()`（element-ui，挂到 body），
`containCrud` 用 MutationObserver 把新落到 body 的 `.el-message` / `.el-notification` 挪进盒子并改成绝对定位；
这依赖宿主页面上的 element-ui toast 都来自本包的块（宿主自己的 UI 不是 element-ui）。

**trans / 多选 / 自动命名 / 编码模板 / cron / 区域 / 线路七种值控件是禁用输入框。** 方案里这类属性的查询条件输入框不可编辑，
显示「该控件在本环境不可用」。**复查触发器：需要按关联属性过滤时**——那时要么接上 `TransComp`（连同它的写路径「+」按钮一起审），要么由宿主传候选值。

**图标没有字体。** `TcAwesomeIcon` 渲染成空的 `<i class="fa fa-*">`；本包不带 font-awesome。首版没有任何可见的图标位。

**只读闭包带着整个 toy-core。** 真实桶入口把 gis / mobile / uavServer / 微应用 / 水印等 107 个文件一起带进来，闭包 177 个文件 / 23,775 行
（toy-core 107、toy-ui 56、toy-comp 14）。随之打进产物的 npm 库有 40 个（直接的 axios、nprogress、localforage、qs、crc-32、crypto-js、
mitt、json5、array-to-tree、ua-parser-js、resize-observer-polyfill、coordtransform、color、randomcolor、`dayjs/plugin/isBetween`，
连同它们的传递依赖）——完整名单、版本与条款见随包的 `BUNDLED.json`，许可证正文见随包的 `THIRD-PARTY-LICENSES.txt`，两份都由 `pnpm run build`
从 rollup 的模块图上生成，门禁第 15 条钉住「每个内联库都有条款和正文」。产物 `dist/index.js` 878,120 字节 / gzip -9 后 222,021 字节；
其中样式 18,762 字节 / gzip 3,687 字节、127 条规则，全部以 `[data-toy-crud-box]` 开头（`html` / `body` / `:root` 变成盒子本身，
nprogress 加在盒子上的 `.nprogress-custom-parent` 接在盒子本身上）。tgz 约 256 KB（14 个文件）。
**这两个数不是宿主要下载的全部**：`lodash` 与 `dayjs` 是 external，由宿主装、打进宿主自己的包——`lodash` 4.18.1 自带的构建
545,945 字节 / gzip 96,961 字节，`dayjs` 1.11.23 的 `dayjs.min.js` 7,161 字节 / gzip 3,047 字节。宿主的第三方声明要把这两个也算上
（`MEASUREMENTS.json` 的 `external` / `external_sizes`）。
**复查触发器：产物超过 1 MB 时**——那时按需替换 crypto-js（只有 token 加密开关打开才用到）与 ua-parser-js。

**构建不是逐字节可复现的。** 同一份源码连着构建三次，会出现 401 / 401 / 398 两种模块数与两份不同的产物；差异只在 esbuild 压缩后的
局部符号名（`FormItemComp.vue` 把 `DisabledInputStub.vue` 同时静态与动态 import，vite 每次构建都会报这条警告）。
功能上没有差别，门禁与探针跑的都是当次的产物；但这意味着「重跑一次构建就能对出同一个 sha256」不成立，
tgz 的 sha256 只对得上那一次打包。

**手写 `.d.ts` 没有编译期靠山。** 门禁只钉三份导出名单一致，props 字段改了不会报错；实际验收场是宿主侧的类型检查。

**探针是 jsdom 与假后端，不是浏览器。** `probe/backend.mjs` 是能过 `schemaCheckUp` 的最小方案加三行数据；el-table 在 jsdom 下画得出 `tr` 画不出 `td`，
列的正确性断言落在 store 的列定义上。真机验收在宿主侧。
