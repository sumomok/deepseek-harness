/**
 * `@sumomok/toy-crud-kit` 导出面的手写类型。
 *
 * `Crud` 是 Vue 2 选项对象（`@vitejs/plugin-vue2` 的 SFC 编译产物 + 本包一条混入），源库无 TypeScript、
 * 无 `.d.ts`，本文件由 `src/vendor/toy-ui/component/Crud/Crud.vue` 的 `props` 声明逐条推出，不是生成物：
 * vendor 树的 props 改了必须同步改这里；`tools/gates.mjs` 只钉住导出名，钉不住字段。
 *
 * 后端方案（schema）驱动的对象一律带索引签名：字段集合由后端下发，这里只列闭包读到的那些。
 */
import type Vue from 'vue';
import type { ComponentOptions } from 'vue';

/** 一行数据。列名与值由后端方案决定，静态上不可枚举。 */
export type ToyRow = Record<string, unknown>;

/** 一条查询条件；`op` 取 `EQ` / `LIKE` / `IN` / `BETWEEN` 等后端匹配策略。 */
export interface CrudCondition {
  key: string;
  op: string;
  value: unknown;
}

/** 查询排序：`{ asc: 属性名 }` 或 `{ desc: 属性名 }`，同时给时 `asc` 优先。 */
export interface CrudQuerySort {
  asc?: string | null;
  desc?: string | null;
}

/** 模型可设的 props（D3）。名单与 {@link CRUD_MODEL_SETTABLE_PROPS} 一致。 */
export interface CrudModelProps {
  /** 模型英文名，必填；宿主按与 toy.table 的 dataSource meta 相同的字符集校验。 */
  relatedMeta: string;
  /** 隐性查询条件：界面不显示、清空不清除，与用户在查询表单里填的条件合并后发给后端。默认 `[]`。 */
  conditions?: CrudCondition[];
  /** 条件关系。默认 `'AND'`。 */
  matchMode?: 'AND' | 'OR';
  /** 查询排序。默认 `{}`（后端默认序）。 */
  querySort?: CrudQuerySort;
  /** 选择列模式；`null` 不画选择列。组件默认 `'checkbox'`。 */
  selectMode?: 'checkbox' | 'radio' | null;
  /** 查询条件面板是否展开。默认 `false`。 */
  isExpandQuery?: boolean;
  /** 挂载后是否立刻查询一次。默认 `true`。 */
  isInitQuery?: boolean;
}

/** 宿主写死、模型不可设的 props（D3）。值见 {@link CRUD_READ_ONLY_PROPS}。 */
export interface CrudHostFixedProps {
  isReadOnly: true;
  type: 'default';
  urlConfig: null;
  hideButton: Readonly<Record<'add' | 'update' | 'delete' | 'imp' | 'exp' | 'gridexp' | 'expimphuge' | 'batchUpdate' | 'batchDelete' | 'labelPrint', true>>;
  hideComp: Readonly<{ menu: true; card: true }>;
}

/** 宿主自己决定、既不在模型名单也不在只读名单里的 props。 */
export interface CrudHostProps {
  /** 根节点的行内样式；组件默认 `'width:100%;height:100%'`，盒子要给出高度。 */
  myStyle?: string;
  /** 查询前是否校验必填条件。默认 `true`；为空时 toy-ui 经宿主 element-ui 的 `$message` 提示（被 `containCrud` 挪进盒子）。 */
  isQueryValidate?: boolean;
}

/** `Crud` 完整的 props。 */
export type CrudProps = CrudModelProps & CrudHostFixedProps & CrudHostProps;

/** 方案里的一列。 */
export interface CrudGridItem {
  /** 行数据里取值的字段名。 */
  relatedMetaAttr: string;
  /** 列头文字。 */
  alias?: string;
  /** `String(isShow) !== '0'` 才显示。 */
  isShow?: boolean | string | number;
  isSortable?: boolean | string | number;
  [key: string]: unknown;
}

/** `load` 事件的载荷：方案配置的深拷贝。回给模型的只有 `query.grid.gridItems` 里显示列的 `relatedMetaAttr` + `alias`（D5）。 */
export interface CrudLoadPayload {
  schemaConfig: {
    query?: { metaAlias?: string; grid?: { gridItems?: CrudGridItem[]; [key: string]: unknown }; [key: string]: unknown };
    add?: Record<string, unknown>;
    modify?: Record<string, unknown>;
  };
}

/** `query-success` / `recieve-data` 事件的载荷：后端查询接口的 `data`。回给模型的只有 `page.total`、`displayValue.length`、`page.currentPage`（D5），行永不回传。 */
export interface CrudQuerySuccessPayload {
  rawValue: ToyRow[];
  displayValue: ToyRow[];
  ref: ToyRow[];
  page: { total: number; currentPage: number; pageSize: number };
  [key: string]: unknown;
}

/** `table-cell-click` 事件的载荷：el-table 的 `cell-click` 原样透传；`column.property` 是被点列的 `relatedMetaAttr`。 */
export interface CrudTableCellClickPayload {
  row: ToyRow;
  column: { property?: string; label?: string; [key: string]: unknown };
  cell: HTMLElement | null;
  event: Event;
}

/** `Crud` 实例上宿主可调的公开方法（原件标 `@public` 的那些）。通过桥的 `instanceRef` 拿到实例后调用；只读首版只用读方法。 */
export interface CrudInstance extends Vue {
  /** 表格全部数据；无数据时返回 `{}`。 */
  doGetTableData(): { rawValueList: ToyRow[]; displayValueList: ToyRow[] } | Record<string, never>;
  /** 当前选中数据（含显示列名单 `sourceShow` / `sourceNameShow`）。没有 selection-change 事件，首版不轮询它。 */
  doGetSelection(): { selection: ToyRow[]; selectedRawValue: ToyRow[]; source: string[]; sourceName: string[]; sourceShow: string[]; sourceNameShow: string[]; [key: string]: unknown };
  /** 按 `id` / `int_id` 设置选中行。 */
  doSetSelection(dataList: ToyRow[]): void;
  /** 清空选中状态。 */
  doClearSelection(): void;
  /** 方案配置的深拷贝。 */
  doGetConfig(): { schemaConfig: CrudLoadPayload['schemaConfig'] };
  /** 方案是否通过检查；`false` 时根节点是注释，盒内有一条提示。 */
  isSchemaRight: boolean;
  /** 最近一次查询结果（冻结）；未查询时 `{}`。 */
  resultData: CrudQuerySuccessPayload | Record<string, never>;
}

/**
 * toy-ui 的 `Crud.vue` 原件 + 本包一条混入（实例的 `$notify` 换成盒内提示）。
 *
 * 事件（Vue 2 选项类型不承载事件签名，逐条列在这里；只读首版能触发的只有前六个）：
 * - `load(payload: CrudLoadPayload)` 方案加载完成
 * - `loaded()` 表格挂载完成
 * - `query-success(payload: CrudQuerySuccessPayload)` / `recieve-data(payload)` 查询成功（同一载荷发两次）
 * - `table-cell-click(payload: CrudTableCellClickPayload)` 单元格点击
 * - `btn-click-query()` / `btn-click-clear()` 查询 / 清空按钮
 * - `table-operation-custom(scope, item, rawValue)` 自定义操作（`tableCustomOperations` 未设，不会触发）
 * - `small-card-close()` / `operation-event(e)` 信息卡（`hideComp.card`，不会触发）
 * - `add-save-success(e)` / `modify-save-success(e)` / `delete-save-success(e)` 写窗口（零渲染替身，不会触发）
 *
 * 组件不能被 `Object.freeze`：Vue 2 的 `Vue.extend` 会往选项对象上写 `_Ctor`。
 */
export declare const Crud: ComponentOptions<Vue>;

/** 宿主盒的标记属性名 `data-toy-crud-box`。 */
export declare const BOX_ATTR: 'data-toy-crud-box';

/**
 * 把宿主元素收拾成 Crud 的盒子：打标记、置 `position:relative`、把请求层的进度条 / 遮罩 / toast 与
 * toy-ui 经 element-ui 发出的 `$message` 都收进盒子。必须在挂载（第一次请求）之前调用。
 * @param box 桥挂载 Crud 的宿主元素。
 * @returns 注销函数。
 */
export declare function containCrud(box: HTMLElement): () => void;

/**
 * 设置 toy-core 请求层的业务基路径（axios `baseURL`）。只接受根绝对路径，规范成以 `/` 结尾。
 * 宿主还应在本包模块求值前写好 `window.$toy_env.VUE_APP_BASE_URL`（toy-core 在求值期读它一次）。
 * @param path 如 `/` 或 `/nrms-server`。
 * @returns 实际写入的路径。
 */
export declare function setBizBasePath(path: string): string;

/** 当前生效的业务基路径。 */
export declare function getBizBasePath(): string;

/** 只读首版宿主写死的 props（D3），已冻结；宿主展开在模型 props 之后。 */
export declare const CRUD_READ_ONLY_PROPS: Readonly<CrudHostFixedProps>;

/** 模型可设的 props 名单（D3）。 */
export declare const CRUD_MODEL_SETTABLE_PROPS: ReadonlyArray<keyof CrudModelProps>;
