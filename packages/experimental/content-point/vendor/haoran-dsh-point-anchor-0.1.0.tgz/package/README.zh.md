# @haoran/dsh-point-anchor

[English](README.md) | 中文

对「指针在控制台内容栏里指着什么」的唯一一份描述，由三个必须逐字节一致的程序共用：控制台的「指着问」插件，把用户指的一处变成记进日志的提示引用；北冥壳的拾取脚本，FDE 用它在客户的在线系统上拾取同一处；FDE 插件，把拾取到的各处写进技能并导出。同一处在技能的 `anchors.md` 里和控制台的模型文本里是同一条**锚点行**，模型按原文逐字匹配两边。

内部包：不是插件（没有 bundle 层、没有 locale），不发布到 npm。使用方 vendor 它的 `pnpm pack` 包。

## 入口

| 导入 | 运行环境 | 内容 |
| --- | --- | --- |
| `@haoran/dsh-point-anchor` | 任意 | 类型、格式号与上限、锚点行（`anchorKey`、`parseAnchor`、`parseAnchorKey`）、保留名字的角色（`NAMED_ROLES`、`ITEM_NAMED_ROLES`）、mark 保留类型的角色（`INTERACTIVE_ROLES`）与 mark 过滤（`keptMarkToken`）、名字警告（`NAME_WARNINGS`、`parseNameWarnings`）、标签与显示行、模型文本（`renderPointText`、`renderUnreadablePoint`）、提示引用的写与读（`toPromptReference`、`parsePointData`）。不含 DOM 类型。 |
| `@haoran/dsh-point-anchor/page` | 浏览器 | `describeElement` 与 `resolvePointTarget`、拾取器（`createPicker`）、拾取时从页面读出的警告（`nameWarnings(anchor, picked, env, index?)`，`index` 是这次拾取描述时用的框架索引，省略时重新遍历一次）、页面标记、`DOM_CONTRACT`（从控制台读的每个属性和类名）、`contentFrameCopy`（复制来的命名遍历）。内联 `dom-accessibility-api`。 |
| `@haoran/dsh-point-anchor/pick-script` | Node（壳主进程） | `PICK_SCRIPT`（一个自包含的 IIFE 字符串）、`PICK_SCRIPT_SHA256`、`PICK_CANCEL_SCRIPT`、`PICK_SCRIPT_FORMATS`、`POINT_ANCHOR_VERSION`、`parsePickResult`。不含 DOM 类型。 |
| `@haoran/dsh-point-anchor/pack` | Node 或浏览器 | `SKILL.md` 与 `anchors.md` 的写出、`.dshpack` 格式 1 的写出、导出检查、保留名字清单及其确认（`listKeptNames`、`checkConfirmedNames`）、组织交付请求（`exportDshpack`、`exportDelivery`）。内联 `fflate`。不含 DOM 类型。 |
| `@haoran/dsh-point-anchor/fixtures/*` | — | 锚点行黄金样例（`anchor-keys.json`）与命名语料：`naming/*.html`，每个探针应得的描述在 `*.expected.json` 里。 |

`lib/page.js`、`lib/pack.js`、`lib/pick-script.js` 以 `./index.js` 导入中立入口，不各内联一份。`PICK_SCRIPT` 是注入页面的文本，是一个 IIFE，自带打包进去的一份 `/page` 源码和中立入口。

## 谁用什么

- **「指着问」插件（控制台）。** 加载期间用 `writePageMarker(document)` 写标记并保留其撤销函数。对一次指认，调用 `describeElement(target, { purpose: 'reference', isVisible, isClickable })`，或运行 `createPicker(document, { purpose: 'reference' })`，再用 `toPromptReference(result.point, source)` 得到附件的 `data` 与标签。宿主侧用 `parsePointData` 读日志里的 `data`，用 `renderPointText(data)` 生成模型文本；本版本读不了的 `data` 用 `renderUnreadablePoint(problem)`。模型文本里的锚点行就是原样的 `anchorKey(data.anchor)`。
- **北冥壳。** 只注入 `PICK_SCRIPT`，绝不注入调用方给的脚本；在视图主框架的主世界里执行一次（`executeJavaScript`），让它的 promise 与导航、视图销毁、超时赛跑；交出去之前先过 `parsePickResult`；锚点引出警告时，通过的拾取结果带 `warnings`。`PICK_CANCEL_SCRIPT` 结束正在进行的拾取。与 FDE 插件握手时报 `POINT_ANCHOR_VERSION` 和 `PICK_SCRIPT_FORMATS`。`PICK_SCRIPT` 只存在于构建产物 `lib/pick-script.js`；从源码导入该模块会抛错。
- **FDE 插件。** 草稿里把每次拾取的 `warnings` 和它的锚点存在一起；用拾取到的锚点和讲解组 `ExportSkill`，每个条目带上它那次拾取的 `warnings`；`checkExport` 报出全部问题。导出前把 `listKeptNames(skills)` 给 FDE 看（锚点行保留的每个名字，连同锚点行和警告，有警告的排前面），再把 FDE 确认过的清单作为 `confirmedNames` 传入：`exportDshpack(skills, set, { reservedNames, confirmedNames })` 写文件出口，`exportDelivery(skills, meta, { reservedNames, confirmedNames })` 生成 `POST /v1/delivery/skill-packs` 的请求体，其中的文件与前者字节相同；清单与导出保留的名字不一致时两者都拒绝。
- **产品侧等价测试。** 把 `fixtures/naming/*.html` 装进真实 Chromium 控制台，调用拾取脚本打包的同一个 `describeElement`，与 `*.expected.json` 比对；`contentFrameCopy` 是复制来的 `collect` / `itemName` 遍历（来自 deepseek-harness `6822829a2f`），用来与产品自己的那份比对。

## 锚点行

每个锚点一行：种类，然后按固定顺序写 `字段=值`，没有的字段不写。

| 种类 | 字段顺序 |
| --- | --- |
| `data-page` | `model region part button column operation field` |
| `frame` | `page column role name mark nth in` |
| `picture` | `page tag mark nth in` |
| `nav` | `nav id` |

匹配 `[A-Za-z0-9_.:-]+` 的值直接写；其他值写成 `JSON.stringify` 的结果，再把其中每个 C1 控制字符、DEL、格式字符、U+2028、U+2029 和反引号换成小写的 `\uXXXX` 转义，所以锚点行总是一行可见文字，能放进 Markdown 代码片段。格式字符是 Unicode 17.0 的 Cf，按码点写死；清洗标签也用同样写死的码点表，所以 Unicode 版本不同的引擎写出同一行。`nth` 写成不带前导零的十进制整数。`parseAnchorKey` 只接受规范行（`anchorKey(parse(line)) === line`），一行最多 8192 个 UTF-8 字节。

```
data-page model=layerInfo region=table part=header column=layerName
frame page=controls role=button name="查询" in=form
frame page=tables column="操作" role=button name="编辑" in=main
frame page=layers column="所属地图主题" role=link mark=theme-link in=main
frame page=row-values column="附件" role=link name="详情" nth=2 in=main
frame page=users role=link mark=user-link in=list
frame page=users role=heading mark=title nth=1 in=main
picture page=drawings tag=canvas mark=trend-chart nth=3 in=section
nav nav=view id=space-layer
```

### 原系统页面上一处靠什么指认

规则只看页面结构，从不看数据，出自 org-plugin 2026-10-05 的决定（fde-plugin.md §4）：同一个元素，不论页面加载了几行、打开的是哪条记录，都得到同一条锚点行，只有按钮、链接、菜单项保留的名字例外，控件显示记录的值时这个名字就是记录的；没有任何规则拿一行的名字和另一行比。

- **重复项**指角色为 `listitem`（`ul`、`ol` 的 `li` 也在内）、`row`（所有 `<tr>`，布局表格的也算）、`treeitem`、`option` 的元素，以及 `feed` 里的 `article`。被某个重复项包着的一处在项里；在读作表格的表格（`<table>`、`role="table"`、`grid`、`treegrid`；标了 `role="presentation"` 的表格不算）里的一处在格子里。
- **格子里和项里的控件**只有 `button`、`link` 和菜单项（`menuitem`、`menuitemcheckbox`、`menuitemradio`）保留可访问名：只有部分行才有的操作（如「审核」）必须有自己的锚点行，只按位置指认的话，那个位置上是哪个操作就成了哪个；同一个 class 的操作链接和按钮一样常按行不同。Element UI 画成不带 href 的 `<a>` 的 `el-link`，读取器读作可点处，在这里和别处都算链接。显示记录标题的链接也保留这个标题，由名字警告和 FDE 的确认兜底。这类控件只在同一格或同一项里有同角色、同名字（没有名字时同 mark）的兄弟时才带 `nth`。**格子或项里只有一个的链接**（读取器的 `cellControls` 在那里只找到它一个；读取器命名的树节点里不算图标，页面没给角色的可点处不算、读它里面的控件；格子里有列表项或嵌套表格的行包着它时在那一项里数）不带名字，带 mark，不带序号：写成 `column`（或 `in`）、`role=link` 和它的 mark，因为页面把值画成链接的列（主题、父级，有的行为空）否则会带上记录、随记录变。按钮或菜单项不论旁边有没有别的控件都保留名字，只在没有名字时带 mark。别的控件（勾选框、输入框、可点处、图标）都不带名字，带它的 mark 和 `nth`，即它在这一格或这一项里同角色、同 mark 的控件中的序号，不论有没有第二个。
- **图标**（`role=icon`）是读取器在表格的格子里或重复项里读作那里的一个控件的元素，它画成图标的样子：没有角色，里面没有元素、也没有自己的文字，有可作 mark 的 class 词元或精灵图符号，并且画出了图形——`svg`、带 ARIA 未定义角色的 `img`、用背景或遮罩画出的图片，或 `::before`、`::after` 生成的字形或图片：私用区字符（图标字体画 Element UI 的 `el-icon-*` 就是这样）、`url()`、`image-set()` 或渐变。生成的文字（空值画的 `--`、一个 `✓`）不算画出图形，装着控件的 `svg` 按里面的控件读。光标不起作用，所以操作列的每个命令不论页面在它上面画不画指针，每一行都是 `role=icon`；在读取器读它的格子或项里，`svg` 图标是 `role=icon`，从不是绘图。格子和项以外，这样的元素什么都不是，页面让它可点时是可点处。
- **重复项本身**（列表项、布局行、树节点、选项）带角色、mark 和所在区域，不带序号：它在各项里排第几取决于数据。在表格里指着一行、没指着格子时，同样是 `role=row`。读取器打成一行的树节点（收起的，或没有子节点的），里面的控件按展开时的节点那样指认，所以节点上的「删除」不论节点展开与否都是同一条锚点行。读取器命名的节点里、控件以外的绘图两种状态下都是在节点里计数的绘图，因为读取器在那里不读图标；可点列表项里不是图标的绘图也一样，不论项里装没装着控件。读取器命名的节点里页面没给角色的可点处，或图标字体的字形（如展开图标），两种状态下都算节点本身，因为读取器在那里两者都不给出；这种可点处里面的控件算节点的控件，因为 Element UI 给节点显示的那一行 `el-tree-node__content` 画了指针光标，行上的按钮、链接、输入项都继承它；那里不带 href 的 `el-link` 在展开、收起、叶子三种状态下都是节点里的链接，和项里的任何控件一样指认，它里面的绘图也一样。
- **不可交互的一处**（标题、图片、`status`、`alert`、`figure`、绘图）不带名字，带角色（绘图带标签名）、mark、所在区域和 `nth`，即它在所在项里（不在项里时在所在区域里）同角色、同 mark 的各处（绘图按同标签名、同 mark）中的序号。详情页的标题「张三的道路工程」、图片的「张三的头像」都不进锚点。
- **格子和项以外的可交互控件**保留可访问名：`button`、`link`（包括不带 href 的 `el-link`）、菜单项、`tab`、`checkbox`、`radio`、`switch`、`slider`，以及按标签取名的输入项（`textbox`、`searchbox`、`combobox`、`spinbutton`、`listbox`）。没有名字时带 mark，不带序号。
- **页面没给角色的可点处**（`clickable`）在哪里都不保留名字：它的名字就是它显示的全部文字，画成 `div` 的卡片上就是一整条记录。它带 mark 和序号，不论里面装没装着别的项。
- 浏览器可能从字段（输入框、下拉框、数字框、滑块或进度条；`<input type="password">` 只在它的 `role` 的第一个词是其中一种时才算；页面设为可编辑的元素也算，即它的文档开着 design mode，或它自己或往上最近一个带 `contenteditable` 的元素的值不是 `false`）读出名字的控件，在哪里都不保留名字，因为名字里带着字段的值，改带 mark 和序号：按内容取名的角色里面装着的字段（「数量 5」），它的某个 label、或画在它前面给它取名的 `label` 里除它自己以外装着的字段（「其他 张三的备注」），或者它的 `aria-labelledby` 指向的元素本身是、或里面装着的字段（「查询 李四」）。一个元素装着它里面的元素（`<slot>` 装着分配给它的内容，什么都没分配时装着它自己的子元素）、它自己和它装着的每个元素的 label，以及它自己或它装着的元素用 `aria-owns`、`aria-labelledby` 指向的每个元素，连同这些元素各自装着的。
- `nth` 按文档顺序从 1 数，只在带着同一个保留名字（没有时同一个 mark）的同角色各处之间数，在格子里就在这一格里数（这一格里有列表项或嵌套表格的行包着它时，在那一项里数），否则在最近的项里数，否则在读取器打出的最近容器里数（区域，或树节点、菜单项、装着别的项的可点处这三种 `in` 会跳过的容器），从不跨行、跨项。格子或项里只有一个的链接不带序号。表头行里的控件和别的行一样指认。
- 名字、mark、序号、列都区分不出的一处按 `nameless` 拒绝：没有 class 的项，项里唯一一个没有名字也没有 class 的按钮，或者列表项里唯一一个没有 class 的链接。

显示文字跟着锚点行走：一处显示它保留的名字，没有时显示列名，再没有就什么都不显示（这时标签是它的角色加「（没有名字）」），所以 `anchors.md` 和模型文本里印不出锚点行去掉的名字。`NAMED_ROLES` 是 frame 锚点可以带名字的角色的唯一清单，`ITEM_NAMED_ROLES`（按钮、链接和各种菜单项）是其中带 `column` 时还能带名字的那些；`parseAnchor` 拒绝别的角色带名字、带 `column` 时第二张清单以外的角色带名字、任何角色名字和 mark 同时出现，也拒绝格子带名字或 mark；导出检查拒绝显示文字用保留名字和列以外的东西称呼一处的条目，以及锚点带着描述器会去掉的名字的条目（`dropped-name`）。

锚点从不携带：格子或行里的数据、区域的名字、上面规则去掉的名字、Element UI 的 `el-table_<n>_column_<m>` 标记（只用来把表体格子和表头配对）、原系统的 URL。区域指除树节点、菜单项、装着别的项的可点处这三种本身也是控件的容器以外的所有容器，所以对话框、分区、表单、列表和整张表都是区域。区域自己的锚点带它的类型，并把 class 词元写成 `mark`，没有剩下的 class 词元时按 `nameless` 拒绝；`in` 写一处所在区域的类型，跳过这三种，所以树节点里的控件不论节点展开与否都是 `in=tree`。对话框标题、分区标签和表格标题（caption）锚点行和显示文字都不带，因为它们可能是一条记录的（「编辑用户：张三」），也可能是页面的。

格子按列和角色指认，从不按格子里的内容。只有页面声明的表头行给出列：`<thead>` 的第一行，或者每一格都声明自己是列头（`scope="col"`、`scope="colgroup"`、`role="columnheader"`）的第一行；这一行只显示一格时也不算，它是标题：在装数据的行以上，没有东西能把一列宽的表和宽表上方的记录标题区分开，所以一列宽的表，不论各行显示什么，哪一格都没有列。全是普通 `<th>` 的第一行可能是记录的标题，也可能是键值表的标签，所以没有声明表头行的表，哪一格都没有列。画成一张的表里，表体格子的列是表头行里覆盖的列与它完全相同的那一格，按 HTML 的表格模型排布：上面跨行的格子把它后面的格子推到它们画在的那一列，别的行跨了什么（展开的明细行、画成一个合并格的记录）都不挪动这一行，所以格子的列不取决于显示了哪些记录。跨列的格子，以及表头格比它跨更多列的格子，不在任何一列里。表体行里的表头格（`<th scope="row">` 或 `role="rowheader"`，里面常是记录名）和别的表体格一样，按表头行取列名，角色写 `rowheader`。既不是表头行也不是数据行的行（标题行、`<tfoot>` 的行、`<thead>` 第一行以下的行、Element UI 的合计行）不在任何一列里。Element UI 把固定列在主表和每个固定侧各画一份，除显示的那一份外都标上 `is-hidden`；格子的表头取没有这个 class 的那一份。

所有 `mark`（区域的、整张表的、控件的、项的、绘图的）都是读取器在元素那一行打出的 mark：按页面里的顺序排的 class 词元；`svg` 的第一个 `use` 指向一个符号时，后面再加上这个符号 id，除非已经有一个 class 词元就是它（`<svg class="svg-icon"><use href="#icon-edit">` 是 `svg-icon icon-edit`，没有 class 时是 `icon-edit`）。锚点从中去掉 `keptMarkToken(token, role, symbol)` 按这一处的角色（绘图按标签名）丢弃的词元：含十进制数字的，但图标或 `svg` 绘图的 mark 结尾的符号 id 除外，它指的是这个图形而不是记录（去掉数字的话，精灵图的 `icon-xinzeng1` 和 `icon-bianji2` 会让两个图标的 mark 相同）；以 `is-`、`has-`、`status-`、`state-` 开头的；按连续的 `-`、`_` 切成单词后（不分大小写）有一个单词是 `active`、`current`、`selected`、`checked`、`hover`、`focus`、`focused`、`disabled`、`expanded`、`collapsed`、`open`、`opened`、`closed`、`striped`、`highlight`、`highlighted`、`loading` 之一的；以及这一处不是可交互控件（`INTERACTIVE_ROLES`：按钮、链接、菜单项、标签页、勾选框、单选框、开关、图标）时，写类型的词元：整个词元是 `success`、`warning`、`danger`、`error`、`primary`、`info` 之一的，或以 `--` 加其中之一结尾的（`el-tag--success`）。这些词元带着记录的编号、日期、挂载计数、记录的状态，或页面、指针当时的状态：`user-dialog-1024`、`order-20261001`、`status-approved`、`state-open`、Element UI 的 `is-fullscreen`，表格行的 `current-row`、`hover-row`、`expanded`、`el-table__row--striped`，状态标签的 `el-tag--success`，下拉选项的 `selected` 和 `hover`，页码的 `active`，Vue Router 的 `router-link-active`。拾取时指针就在被拾取的地方上方，所以悬停词元每次拾取时都在页面上。可交互控件保留类型：只有图标的「通过」（`el-button--success`）和「删除」（`el-button--danger`）常常只靠它区分。在别的单词中间含有类型词的词元不算写类型，在哪里都保留：`el-icon-warning` 指一个图标，`user-info`、`info-card` 指页面的一部分，页面自己用单横线写的 class（Bootstrap 的 `btn-success`、`label-danger`，`warning-text`，Element UI row-class-name 的 `success-row`）也都留下。别的词元都保留：`el-dialog`、`el-table__expand-icon`、`el-button--mini`、`el-dropdown-menu__item--divided`。所以 `<div role="dialog" class="el-dialog is-fullscreen user-dialog-1024">` 是 `role=dialog mark=el-dialog`，`<button class="el-button el-button--danger is-circle">` 是 `role=button mark="el-button el-button--danger"`，`<table class="detail-table order-20261001">` 是 `role=table mark=detail-table`，一个词元都不剩的地方按没有 class 处理。控制台的指一下和 FDE 的拾取用同一种算法算 mark；导出检查拒绝含按锚点的角色或绘图标签名应丢弃的词元的 mark（`mark-token`），并把图标或 `svg` 绘图的 mark 的最后一个词元当作符号 id。

### 保留的名字、它们的警告和 FDE 的确认

锚点行保留的名字在拾取时检查。名字和页面当时显示的某段数据文字重叠（任一方包含另一方）时，得到 `name-in-data`；含十进制数字时得到 `name-digits`，和 `column-digits` 对列的警告一样。数据文字指 `<thead>` 以外的表格格子、重复项、标题、描述列表的值（`<dd>`）里的每一段文字，以及一处数据文字段合起来的整段：在详情页上，标题和描述列表的值装的就是记录。这些地方里按钮和链接的文字也算，拾取的控件自己的文字也算，因为页面把记录的值画成按钮和画成文字一样常见（Element UI 用 `el-button type="text"` 画的名称列）。一段文字外面最近的重复项至少有一个页面显示的兄弟项（数父元素下页面显示的各项时把这一项自己也算在内，至少要有两项，即自己加一个兄弟；表格行的兄弟是同一表体里的行），并且这些项每一个都有一段完全相同的文字时，这段文字是页面结构，不是数据：每行都有的「编辑」「删除」没有警告，只在待审行显示的「审核」、名称列的「张三」有警告。一处的整段文字在去掉结构文字之后再拼。没有这样的兄弟时（只有一项的列表、只有一行的表），分不出结构和数据，每段文字都算数据。别处的名字，只要有的行显示、有的行不显示，也有警告（「删除」只在部分行出现时工具栏的「删除」）；每行都显示的没有。比较时两边都去掉空白，两段文字中较短的至少两个码点（`DATA_TEXT_MIN_CODE_POINTS`）：单个字（「删」「张」「1」）是普通词语的一部分，两个字是最短的常见记录值（两个字的中文人名）的长度。页面隐藏的文字和绘图里的文字不读。页面文字只在为锚点拾取的那一下点击时读，悬停时不读，控制台的引用也不读；离开页面的只有警告类型：它们在 `PickResult.warnings` 和 `AnchorEntry.warnings` 里传递，从不进锚点行、显示行和 `anchors.md`。导出把它们作为警告再报一次（`name-in-data`、`name-digits`）。

在表体格子或重复项里拾取的链接，不论有没有名字，它所在的地方同时有两种控件写法时得到 `mixed-cell-controls`：格子的情形，页面显示的表体行里这一列的格子，既有只含一个链接的，又有含两个以上控件的；项里的控件，页面在这一项的父元素下显示的各项，既有只含一个链接的，又有含两个以上控件的。项没有列，所以它所在的那一串兄弟项就当作一列，每一项整个当作一格；格子里列表项或嵌套表格的行里的控件，按那一项算。一列的格子指同一张表里带同一个 Element UI 列标记的格子，没有列标记时指按 HTML 表格模型覆盖的列完全相同的格子。页面隐藏的行和项不读，表头行里的控件不报。只有一个的链接不带名字，和别的控件在一起的链接带名字，所以同一个操作在两种行里锚点行不同，FDE 要在两种行上各拾取一次；那里的按钮、菜单项和图标在两种行里是同一条锚点行，不报这个警告。这个警告和别的警告一样随拾取结果传递、导出时再报一次，在 `listKeptNames` 里跟着保留的名字列出。

两个出口写任何东西之前，`listKeptNames(skills)` 列出锚点行保留的每个名字，连同所属技能、锚点行和警告，有警告的排前面；列名和 mark 不是名字。`exportDshpack` 和 `exportDelivery` 接收 `confirmedNames`，即 FDE 确认过的清单；保留的名字有一个不在清单里、清单里有导出不保留的名字、或者同一个名字出现两次时，拒绝导出（`unconfirmed-names`）。

一次引用的模型文本（描述格式 1）：

```
用户在内容栏里指着「列「图层名称」」。
锚点：`data-page model=layerInfo region=table part=header column=layerName`
显示：侧栏「图层管理」 · 数据页「图层管理」 · 列「图层名称」
这一行：layerName="道路" status="启用"（还有 3 列没带）
```

## 格式

两个格式号，各管一处。`DESCRIBE_FORMAT`（1）管 `PointDescription` 以及由它生成的模型文本，中文标签也在内。`ANCHOR_FORMAT`（1）管锚点字段、锚点行、`anchors.md` 的排版和固定的 `SKILL.md` 正文；技能用整数 `metadata.pack.anchorFormat` 声明它。

规则：一个格式号，一旦有带着它的包发布，就永远指同一套规则；改变已有值的输出，就要用下一个号。两张读取列表留住旧号的条件不同：

- `ANCHOR_FORMATS_READ`：格式 N 留在列表里的条件是，N 能锚定的每一处，本版本仍描述成 N 给出的同一条锚点行。后来的格式可以加种类；新可选字段只能出现在 N 锚定不了的地方。给 N 能锚定的地方填上新字段，或者改了某个字段的写法，只能作为把 N 移出列表的破坏性变更来做。skill-pack 按这张列表决定包能否激活，拾取脚本按它决定能否拾取，所以它决定包里的锚点行还能不能和控制台的对上。这张列表只增不改（fde-plugin.md §4）：从中删掉一个号，会让已经下发的这个格式的包全部停用，属于破坏性变更，由主会话决定并写进升级指南。
- `DESCRIBE_FORMATS_READ`：格式 N 留在列表里的条件是，本版本把 N 的每个值（连同模型文本）都逐字节渲染成 N 当时的样子，因为读它的一方是从会话日志里重放 `PromptReference.data`。

列表之外格式的引用或拾取结果会被拒绝，并写明它声明的格式和本版本读的格式。

拾取脚本在拾取前检查控制台的标记，即 `documentElement` 上的 `data-dsh-point="describe=1 anchors=1"`：没有标记得 `no-reader`，标记里没有脚本所写的锚点格式得 `format-mismatch`。

## 拾取

拾取进行时，拾取到达的每个文档的 window 上都有一个捕获阶段、非 passive 的监听器，取消并截停 `pointerdown`、`pointerup`、`mousedown`、`mouseup`、`click`、`dblclick`、`auxclick`、`contextmenu`、`touchstart`、`touchend`、`selectstart`、`dragstart`，以及 `keydown`、`keypress`、`keyup` 上的 Enter 与空格。拾取在可信的 `click`（一次按压的最后一个事件）上取；页面脚本派发的 click 照样吞掉，但不会被当成拾取。在拾取监听的文档里按 Escape 取消。指针移动照常放行，悬停菜单仍会展开。拾取结束后，监听器仍取消默认动作并阻止传播，直到连续 400 ms 没有吞下可信事件、也没有按着的按压或激活键为止（页面脚本派发的事件既不按住也不延长它），并且最晚在拾取结束 3 s 后移除（`PICK_GUARD_LIMIT_MS`），不管还有什么按着：双击的第二下碰不到页面，拾取在按着时被结束（Escape、abort、`PICK_CANCEL_SCRIPT`）的那次按压，只要在这 3 s 内松开，也碰不到页面。按得更久的按压或激活键，松开时会传到页面：超过上限还按着的按压，松开后补全的 click 会执行，键的抬起处理也会执行。3 s 比拾取结束时正常会按着的任何按压都长（一次点击、为了弹出右键菜单按住半秒的触摸、按 Escape 后稍慢松开的鼠标键），又短到松开丢失、控制台的点击和 Enter、空格都没反应时，用户再试第二、三次就恢复。只要按下过的指针还有一个没松开，按压就算按着：每个指针按它的 id 算，鼠标按它事件里报的按键算，触摸按屏上还剩的触点算；所以第二根手指、笔按着时鼠标按下又松开，都不会结束按压。拾取从控制台文档出发，在每个到达的文档里沿普通 DOM 和任意层级的每个 open shadow root，到达页面能读取的每个 `iframe`、`frame`、`object` 的文档，以及页面能读取的每个 `embed` 的文档：它返回的 SVG 文档，或者窗口为它列出的框架里的文档。其余的 `iframe` 和 `frame`、其余每个带 window 的 `object`，以及每个可能装着页面读不到的文档的 `embed`，上面都盖一层遮罩：shadow root 里不返回 SVG 文档的每个 `embed`（窗口不列出 shadow root 里的元素装着的框架），以及在窗口列出了一个跨源框架、而这个框架不由任何 `iframe`、`frame`、`object` 装着的文档里，每个没有装着页面能读取的框架的 `embed`（这种框架不说明是哪个 `embed` 装着它）。点在遮罩上按 `unreadable-frame` 拒绝。遮罩只挡指针：焦点在盖了遮罩的框架里时，Enter、空格和 Escape 都会传到那个框架的页面，在那里按 Escape 也不会结束拾取（见已知限制）。不带 window 的 `object` 和其余的 `embed`（插件、后备内容，以及 `type` 或 URL 指明图片类型、Chromium 不用框架直接画出的图片）算它们所在文档的一部分；没有指明图片类型的 `embed` 在它自己的框架里显示图片，这个框架的文档和别的框架的文档一样处理。读取器只进入 iframe 和 open shadow root，所以经 `frame`、`object` 或 `embed` 到达的文档里的点击照样吞掉，并按 `unreadable-frame` 拒绝，悬停时在最外层的这种元素上画出这个拒绝。拾取期间加进来的框架，在拾取跟踪的文档或 open shadow root 里下一次增删元素的变动或下一次加载时挂上监听器或盖上遮罩；换了文档的框架、页面新挂的 shadow root、后来才带上或不再带着 window 的 `object`、后来才显示页面的 `embed`，在下一个动画帧拾取重新枚举时跟上。不再被任何容器装着的文档（框架换掉的文档，或框架跳到别的源之前显示的文档）在这次检查时撤下监听器。跨源的窗口会拒绝撤销，监听器就留在原处，什么也不做；撤销被拒绝也不会挡住拾取结束，不会挡住其他监听器撤下。closed shadow root 里的框架既不监听也不盖遮罩（见已知限制）。覆盖层放在封闭的 shadow root 里，通过 CSSOM 设样式。

不能给出锚点的地方按原因拒绝（`outside-content`、`unsupported-component`、`popup`、`kit-too-old`、`not-ready`、`unknown-point`、`unknown-model`、`unreadable-frame`、`no-column`、`nameless`、`too-large`、`nav-unidentified`、`failed`）；作为引用时，没有锚点的地方仍会被描述，并带上 `unanchored`。

## `.dshpack` 归档

与控制台 skill-pack 读写的格式 1 一致（deepseek-harness `a9e2680281`）：先放 `pack-delivery.json`，再按 UTF-16 码元顺序放每个 `packs/<pack>/<path>` 文件，DEFLATE 级别 6，修改时间 `1980-01-01T12:00:00`，SHA-256 摘要走 WebCrypto。同样的包在 fflate 0.8.3 下与 skill-pack 的 `buildPackArchive` 字节相同。skill-pack 的 `validatePacks` 拒绝的包名和路径，写入方都拒绝：不是单个目录名的包名；跑出所在包的路径；扩展名不是 `.md .yml .yaml .png .jpg .jpeg .gif .webp` 的文件；包名或路径的某一段含孤立的 UTF-16 代理项、或超过 255 个 UTF-8 字节的；两个包名、或同一个包里两个路径，按 skill-pack 的折叠方式（NFC，再小写、大写、小写，再 NFC，所以 `ß` 和 `ss` 是同一个）折叠后相同的；同一个包里一个路径这样折叠后是另一个路径的目录的。此外包名和路径里的反斜杠在所有平台上都拒绝。导出检查对视图路径套用同样的路径规则，按控制台的读取上限检查归档里的条目（连同清单共 512 项、单个文件 4 MiB，调用方可传目标自己的上限；写出的归档由 `exportDshpack` 按第三个上限检查，总共 32 MiB），要求归档集合的 id 与版本非空，要求每个技能的 `metadata.pack.version` 是精确的语义化版本号，`metadata.pack.platform` 只接受 `V`、`>=V`、`>=V <W`、`^V`、`~V` 五种写法（V、W 是不带构建元数据的精确版本号）。skill-pack 的 `semver.validRange` 接受这五种中的每一种；它还接受别的写法（`>=0.2`、`||` 并集），导出检查一律拒绝，免得写出一个 skill-pack 会让整套包不激活的范围。导出检查对技能名也套用同样的包名规则。对组织出口来说，这不保证控制台的组织包接收放行：它把包目录命名为 `<name>@<version>`，版本是组织清单给这个包的、导出时不知道的版本，并把整个目录名限制在 255 个 UTF-8 字节以内。

**一个归档就是全集。** 控制台的交付目录只放一个，安装时它没带的包全部下线，所以 `exportDshpack` 要传站点的全部技能，而不是只传有改动的。

## 已知限制

- **名字只在同一引擎下相同。** 原系统页面的名字来自浏览器在实时布局上计算的可访问名称。同一元素在相同的引擎、视口、媒体查询、字体和缩放下名字相同；壳在 Chromium 里拾取，控制台若在别的引擎里看，或在会隐藏或露出别的文字的宽度下看，名字可能不同，锚点行就对不上。数据页锚点不受这些影响。
- **框架内的导航不在身份里。** frame 锚点的 `page` 是控制台的页面编号，从不写原系统的 URL；在同一个内容框架页里走到的两个画面共用一套名字。
- **同一列表的各项共用一条锚点行。** 重复项不带序号，项里的勾选框和没有名字的控件按 mark 和它在项里的序号指认，所以列表每一项里的同一个控件是同一条锚点行：树的每个节点都是带 mark 的 `role=treeitem`；Element UI 2 的 `el-dropdown-menu`（画成没有角色的 `li`）每一个选项都是同一条锚点行；用户列表里每一行的勾选框也都一样。在一个入口上拾取的讲解，会被指着任何别的入口的点对上，讲一个入口通向哪里也分不出是哪个入口；这样的列表，FDE 要把各项合在一起讲。没有剩下 class 词元的列表项、选项、树节点按 `nameless` 拒绝。
- **格子里和项里按钮、链接、菜单项的名字会保留**（格子或项里只有一个的链接除外）。这样只有部分行才有的操作就有自己的锚点行；名字本身是记录的（写着人名「张三」、项目「张三的道路工程」或电话号码的按钮或链接）也一样保留，它的锚点行每行都不同。拾取时，格子里和项里保留的名字，除非每个兄弟行或兄弟项都显示同样的文字，都警告 `name-in-data`；含数字的警告 `name-digits`；导出只接受 FDE 确认过的保留名字清单。只加载了一行或一项时，分不出「编辑」和「张三」，两者都警告；加载的每一行都显示同样的记录值（每行的「在职」）时，它读作结构，没有警告；这些由 FDE 分辨。导出检查看不到页面，只能查格子不带名字、带名字的角色在那里是保留名字的角色、原系统页面上一处的显示目标不带锚点行去掉的东西。
- **一列里有的行只有一个控件、有的行有两个以上时，同一个链接操作有两条锚点行。** 格子或项里只有一个的链接不带名字、带 mark，和别的控件在一起时带名字：只有「详情」的行是 `role=link mark=op-link`，有「详情」和「删除」的行是 `role=link name="详情"`。在一种行上拾取的讲解，在另一种行上对不上；FDE 要在两种行上各拾取一次，拾取能同时看到两种行时会警告（`mixed-cell-controls`）。按钮或菜单项在两种行上都保留名字、不带 mark，只有一条锚点行。
- **格子里只有一个的链接指认的是列，不是记录。** 格子或项里只有一个的链接不带名字，所以一列里同一 class 的链接不论显示什么都是同一条锚点行：主题链接「道路主题」和「水系主题」都是 `column="所属地图主题" role=link mark=theme-link`。在一条记录的链接上拾取的讲解，会被指着这一列任何别的记录的链接的点对上。
- **格子或项里挨着菜单项、标签页或滑块的链接算只有一个。** 读取器的 `cellControls` 计入 `button`、`link`、输入项（`textbox`、`searchbox`、`combobox`、`spinbutton`、`listbox`、`checkbox`、`radio`、`switch`）、页面给了名字的 `progressbar` 或 `meter`、图标和页面没给角色的可点处，别的角色的控件都不计入，菜单项、`tab`、`slider` 都在内。格子或项里挨着这种控件的链接按只有一个读：不带名字，所在格子或项算只含一个链接，所以在每一项都有 `role=menuitem` 的「停用」和链接「启用」的列表里，链接是 `role=link mark=op-link`，不出 `mixed-cell-controls`。在读取器打成一行的树节点里（收起的，或没有子节点的），这种控件就是节点本身，而在展开的节点里按它自己那一行指认。
- **表头没有文字的勾选列按 `no-column` 拒绝。** Element UI 的多选列表头只有一个勾选框、没有文字，很多页面也这样，它的勾选框没有列。
- **按指针样式认出的控件随控件状态变。** 页面没给角色的可点处（`clickable`），以及读作链接的不带 href 的 Element UI `el-link`，都靠指针是手形认出；页面在某种状态下去掉手形时就指认成别处：显示为当前页的页码、禁用的控件、选中的页签。页面按记录禁用的 `el-link`（`is-disabled`、`cursor: not-allowed`）在那里不是控件，指着它得到所在格子（`role=cell`），同一行里它旁边的链接就成了格子里唯一的链接，不带名字，并得到 `mixed-cell-controls`。
- **结构文字按拾取时的页面判断。** 一段文字是页面用语还是记录的值，按点击那一刻页面显示的行和项判断；它只决定警告，从不影响锚点行，同一个名字在一页记录上有警告、在另一页上可能没有。
- **展开的明细行算兄弟行。** Element UI 的 `type="expand"` 展开一行后，表体多出一行装明细，这一行没有每行都有的「编辑」「删除」，所以展开期间它们读作数据，得到 `name-in-data`；这只会多报，不会漏报。
- **没有声明表头行的表，里面什么都不命名。** 它的格子和格里的控件都按 `no-column` 拒绝。Element UI 的 `el-descriptions` 这类键值表（横排竖排都一样）、表头是一行普通 `<th>` 而没写 `scope="col"` 的老式表格（这样的一行是记录的标题还是一行字段标签，分不出来），以及所有一列宽的表都在内（不论各行显示什么，它的表头行只显示一格，读作标题）。表格的标题行、表尾行、`<thead>` 第一行以下的行和 Element UI 的合计行也这样拒绝，跨列的格子和表头格比它跨更多列的格子也一样。
- **同类区域共用一条锚点行。** 区域按类型和 class 词元指认，所以同一页上两个 Element UI 对话框都是 `role=dialog mark=el-dialog in=main`，全屏的那种也一样，没有剩下 class 词元的区域没有锚点。它在显示行和模型文本里的标签是类型加「（没有名字）」。在一个对话框上拾取的讲解，会被指着另一个对话框的点对上。
- **格子和项以外的无名控件可能共用一条锚点行。** 那里有角色、没有名字的可交互控件（只有图标的按钮）按 mark 保留下来的 class 词元指认、不带序号，所以 class 只差被 mark 过滤丢弃的词元、或完全相同的两处是同一条锚点行：装着 `el-icon-edit` 和 `el-icon-delete` 的两个 Element UI 图标按钮 `<button class="el-button el-button--mini">` 都是 `role=button mark="el-button el-button--mini"`。在其中一个上拾取的讲解，会被指着另一个的点对上。在格子里或项里，这样的按钮彼此之间带序号；页面没给角色的可点处在哪里都带序号。
- **页面对辅助技术隐藏的绘图和图标不计数。** 读取器跳过标了 `aria-hidden="true"` 的元素（vue-element-admin 的 `svg-icon` 就是）。这样的图标不是所在格子或项的控件，指着它时指认的是格子、项，在项里的 `svg` 则是绘图。`nth` 只数读取器看得到的绘图，所以隐藏的绘图在同标签名、同 mark 的可见绘图加上它自己之中计数：同一项或同一区域里两个同 mark 的 `aria-hidden` 绘图都带 `nth=1`，排在它们后面、不是图标的同 mark 可见绘图是读取器数到的第一个，也带 `nth=1`，三者共用一条锚点行。
- **重复项里的绘图是图标。** 列表项或表格行里带 class、没有角色的 `svg` 图表按读取器的读法是 `role=icon`，按 mark 在项的图标中计数，不在绘图中计数。
- **可点列表项里的图标取决于项里有没有控件。** 页面让它可点的列表项，没装控件时读取器把它读成一个可点处，装着控件时读成装着这些控件的区域，只在后一种情况下读其中的图标：那里的 `svg` 图标前一种是绘图、后一种是 `role=icon`，图标字体画的字形前一种是这个项本身。不是图标的绘图（如 `canvas`）两种情况下都是绘图。
- **图标按拾取那一刻页面怎么画来读。** 字形画在一个空叶子外面那个元素的伪元素上时不算图标：叶子自己什么都没画，外面那个元素里装着元素。样式表还没加载完时不画字形，加载完之前它的图标读作可点处或什么都不是。
- **mark 词元全被 mark 过滤去掉的图标不带 mark。** 读取器按它打出的词元认图标，这一步在锚点从图标的 mark 里去掉 `keptMarkToken` 对 `role=icon` 去掉的词元之前：含十进制数字的、以 `is-`、`has-`、`status-` 或 `state-` 开头的、含它列出的状态词（如 `active`、`open`、`selected`）的。`svg` 指向的精灵图符号只保留数字，前缀规则和状态词规则照样去掉它，和 class 词元一样。所以格子里画了字形的 `<i class="g1">` 或 `<i class="is-active">`，以及那里的 `<svg><use href="#icon-folder-open">`，都是不带 mark 的 `role=icon`，只靠它们在那里不剩词元的图标中的序号区分：`column="操作" role=icon nth=1`。
- **私用区以外的字形不算图标。** 伪元素显示 `✓`、`✗` 这类普通 Unicode 符号时，按页面生成的文字读，和空值画的 `--` 一样，所以只画这种符号的叶子不是图标，指着它得到它所在的格子或项。
- **导出检查把图标或 `svg` 绘图的 mark 的最后一个词元当作精灵图符号。** 它看不到页面，所以手写的这类锚点最后一个 class 词元含数字也能通过。重复了符号 id 的 class 词元仍是 class 词元，会因含数字被去掉：`<svg class="svg-icon icon-xinzeng1"><use href="#icon-xinzeng1">` 的 mark 是 `svg-icon`。
- **格子和项以外同名的保留名控件共用一条锚点行。** 同一个工具栏里的两个「查看」按钮都是 `role=button name="查看" in=toolbar`。序号能把它们分开，但在格子和项以外，同样的序号会把画成 `div` 的列表里的卡片也数进去，随记录变；在一个上拾取的讲解，会被指着另一个的点对上。
- **页面加减兄弟时序号会变。** `nth` 数的是一格、一项或一个区域里同角色、同 mark 的各处，所以页面在前面多显示一个同角色、同 mark 的东西时，标题、图片、绘图、可点处或格子里没有名字的控件的序号会加一。没有 class 的标题、图片、绘图排在画成 `div`、没有结构标明是重复项的列表后面时，序号随列表条数变：画成 `div` 的评论后面没有 class 的「附件」标题，只有部分记录才画的图表，只有部分行才有的图标。这时锚点对不上，或者对错：格子里只有图标、没有名字的按钮 class 和类型都相同，待审行显示「审核」「编辑」「删除」、别的行显示「编辑」「删除」时，待审行的「编辑」是 `nth=2`，别的行的是 `nth=1`，所以在别的行的「编辑」上拾取的讲解，会被指着待审行「审核」的点对上，在待审行的「编辑」上拾取的讲解，会被指着别的行「删除」的点对上。页面给每个操作不同的 class 或类型就能分开；有名字的按钮、链接、菜单项保留名字，不受影响。
- **页面按记录绑定的类型或状态会改变锚点行。** 可交互控件的 mark 保留类型，所以页面按记录画成 `el-button--success`、另一条记录画成 `el-button--danger` 的状态按钮，每种记录状态一条锚点行；页面自己写记录状态的词（`approved`、`row-pending`）留在所有 mark 里，锚点行就随记录不同。可交互控件以外，类型只在整个词元或结尾的 `--` 修饰时离开 mark，所以一条记录画成 `el-tag--success`、另一条画成 `el-tag--danger` 的标签是同一条锚点行；页面按记录状态用单横线写的 class 留在每一处的 mark 里（Bootstrap 的 `label-success` 与 `label-danger`，标签上的 `btn-success`，Element UI row-class-name 的 `success-row`），页面按记录状态画的图标 class 也一样（状态列的 `el-icon-success` 与 `el-icon-error`）：锚点行随记录变。
- **表头文字按页面显示的写。** `column` 是表头行的文字，表头行里的按钮保留名字。表头显示计数（「待审批 (12)」）、日期或人名（排班表的列），或者表头按钮显示当前筛选值时，这些会进锚点和显示行，一变锚点就对不上。导出检查对含十进制数字的列给出警告（`column-digits`）；列不在 FDE 确认的保留名字清单里。
- **页面自己更早注册的监听器先跑。** 页面在拾取开始前挂在自己 window 上的捕获监听器能看到拾取期间的事件，它怎么处理由页面决定。
- **拾取器自己的空档。** 页面自己跳转的框架、拾取期间页面新挂的 shadow root 里的框架、后来才带上 window 的 `object`、后来才显示页面的 `embed`，到下一次检查之前，大约有一个动画帧既没有监听器也没有遮罩。松开没有传到拾取监听的任何窗口的按压（触摸在页面已移除的元素上结束、指针在这些窗口之外或在换了文档的框架上松开），会让监听器一直留到之后同一类指针的一次按压结束、这一类指针一个都不剩为止（那一次按压什么也碰不到），或者留到拾取结束 3 s 后；在此之前，控制台和页面上的点击、Enter、空格都没反应。收不到抬起的激活键，会让监听器一直留到拾取结束后的第一次按压（那一次什么也碰不到）、拾取监听的某个窗口失去焦点或文档被隐藏、松开 Meta（macOS 上的 Chromium 在按着 Cmd 时松开的键不发抬起事件，Cmd+Enter 之后就是这样），或者过了这 3 s。这几件事在键还按着时发生，也同样结束保护：这个键之后不再重复按下、又在监听器移除后才松开时，它的抬起会传到页面，Vue 的 `@keyup.enter` 这类处理会执行。两次点击间隔不到 400 ms 时，监听器会一直留着，最长到拾取结束 3 s 后，所以对着没反应的控件一下接一下地点，它最多 3 s 没反应。拾取结束 3 s 后还按着的按压（按 Escape 后一直没松开的鼠标键），松开时会传到页面，补全的 click 会执行。
- **closed shadow root 里的框架不受保护。** 页面脚本找不到 closed shadow root：宿主的 `shadowRoot` 是 `null`，Chromium 的 `window.frames` 也不列出任何 shadow root 里的 iframe，不论 open 还是 closed。所以拾取既不监听其中的框架，也不给它盖遮罩：拾取进行中，在那里按下、松开、点击都会传到页面，也不算拾取；聚焦在那里的控件上按 Enter 或空格也会传到页面；焦点在那里时按 Escape 同样传到页面，不会结束拾取。
- **遮罩下的框架里，获得焦点的控件仍会收到 Enter、空格和 Escape。** 遮罩只挡指针，按键送到获得焦点的文档。拾取盖了遮罩的框架里获得焦点的控件，不论是拾取开始前就聚焦的，还是拾取中按 Tab 走到的，拾取进行中按 Enter 或空格都会像没有拾取时一样触发；在那里按 Escape 会传到那个页面，不会结束拾取。
- **有些 `embed` 不管显示什么都会盖遮罩。** 窗口不列出 shadow root 里的元素装着的框架，跨源框架也不说明是哪个 `embed` 装着它。所以 shadow root 里不返回 SVG 文档的 `embed`，以及在窗口列出了一个不由任何 `iframe`、`frame`、`object` 装着的跨源框架的文档里、每个没有装着页面能读取的框架的 `embed`，即使显示的是图片或拾取能读取的页面也会盖遮罩，点在上面按 `unreadable-frame` 拒绝。
- **拾取空闲时占用的主线程时间与页面大小成正比。** 页面新挂 shadow root 不会产生任何变动通知，所以拾取每个动画帧都要走遍它到达的每个文档的每个元素，逐个查看是否挂着 open shadow root。在开发机上的无头 Chromium 里测得，80,000 个元素的页面上，拾取空闲时这要占每帧约 4 ms，即每秒约 250 ms 的脚本时间；页面越小，开销按比例越小。
- **保留名由调用方给。** 文件出口看不到目标控制台；除合同固定的 `manifest` 和 `trials`，目标控制台库技能占用的名字要从站点记录里作为 `reservedNames` 传入。漏掉的名字只能在安装时由 skill-pack 的同名规则发现。
- **保留的名字和标题可能带业务数据。** 锚点行和显示文字带格子和项以外的可交互控件的名字，以及各处按钮、链接和菜单项的名字。页面用没有角色或标签标明的结构重复记录时（画成 `div` 的卡片、描述列表里指向负责人的链接、面包屑的当前一项、按记录取名的标签页或折叠面板、按人取名的一组勾选框、页头上登录用户的名字），这些名字是记录的或人的，锚点行随记录变。这样的名字与页面显示的格子、项、标题或 `<dd>` 重叠时，拾取会警告；页面别处都不显示的名字（如登录用户的名字）没有警告。标签页、折叠面板的标题和一组勾选框的标签不算数据文字：从结构上分不出按记录取名的标签页和固定的「基本信息」，把它们算作数据，每个标签页、面板标题和勾选框都会因自己的文字警告；结构文字的规则也帮不上，因为兄弟标签页的文字本来就各不相同。`shown` 还带切换栏和侧栏的标题（agent 放的页面上是 agent 写的标题）。这些都会进模型文本和 `anchors.md`。导出检查对 `shown.page` 和 `shown.nav` 只要求是清理过的、不超过 64 个码点的显示文字：只有原系统页面上一处的 `shown.target` 会和它的锚点保留的东西比对，锚点里也没有存标题的字段（frame 锚点的 `page` 是控制台的页面编号），所以标题里的记录名字进 `anchors.md` 时既没有警告，也没有人确认。把记录的名字挡在导出的技能外，靠的是警告和 FDE 对每个保留名字的确认；控制台的指一下没有人确认。
- **open shadow root 里的字段可能进入读取器自己算出的名字。** 读取器的遍历给大多数控件用名字计算得出的名字，但有些名字由它按页面显示的文字自己算，读这些文字时会进入 open shadow root：菜单项与不带 href 的 `el-link`，名字按它的 `aria-labelledby` 指向的元素算，没有时按它显示的文字算；`role` 第一个词不是名字计算认识的角色的控件，名字按它显示的文字算；名字计算算不出名字的字段（输入框、下拉框、数字框、勾选框、单选框、开关），名字按画在它前面的 `label` 算，不论页面把这个 `label` 和哪个控件关联。不让字段值进入保留名字的检查跟着名字计算走，名字计算不读 shadow root，所以在这几条路上，open shadow root 里的字段会进入保留的名字、锚点行和 `shown.target`：菜单项「编辑」装着一个元素、它的 open shadow root 里有显示「张三的备注」的可编辑区域时，保留「编辑 张三的备注」；勾选框前面画的 `label`「备注」装着一个元素、它的 open shadow root 里有页面写入同样文字的 `textarea` 时，勾选框保留「备注 张三的备注」，带出的是页面写进去的文字，不是用户在那里输入的内容。同样的标记放在普通 DOM 里时，字段的值不会进入锚点。
- **只靠 CSS 设为可编辑的元素按页面文字读。** 不让字段值进入保留名字的检查，只在元素的文档开着 design mode、或它自己或往上最近一个带 `contenteditable` 的元素这样说时，才把它当作可编辑。页面只用非标准的 `-webkit-user-modify: read-write` 设为可编辑的元素两样都不是：Chromium 允许用户在里面输入，它的 `isContentEditable` 却是 false，所以用户在那里输入的内容会进入经过它读出的每个名字（装着它的按钮或菜单项、label 装着它的勾选框、`aria-labelledby` 指向它或指向装着它的元素的控件、前面画的 `label` 装着它的字段），连同锚点行和 `shown.target`。
- **控制台的指一下不做名字警告。** 只在 FDE 为锚点拾取时才读页面文字做警告。控制台的引用描述的是访客在自己会话里指的东西，不导出，它的名字也没有人确认。
- **刚好低于上限的锚点行，FDE 拾取能拿到锚点，控制台的指一下却永远带不上。** 拾取只在锚点行超过 `POINT_LIMITS.anchorKeyBytes`（8192 个 UTF-8 字节）时才按 `too-large` 拒绝；`toPromptReference` 却把整份引用数据的 `JSON.stringify`（锚点对象连同 `v`、`anchorFormat`、`what`、`shown`）限制在 `POINT_LIMITS.dataBytes` 以内，也是 8192，行里的列全部去掉后带着锚点仍超出时，就去掉锚点、写 `unanchored: 'too-large'`。锚点行比 8192 字节少出的部分放不下其余数据（最多 950 个字节，其中 768 个是 `shown.page`、`shown.nav`、`shown.target`，每个最多 64 个码点、256 个 UTF-8 字节）时，FDE 拾取得到锚点，控制台对同一处的引用却不带锚点，在那里拾取的讲解永远匹配不上。大约 1600 个 class 词元的 mark 会到这个长度；名字会被读取器截到 200 个 UTF-16 码元，到不了。
- **按记录取名的分区只在记录给它名字时才是区域。** `<section>` 有可访问名时才是区域，所以用记录标题（`aria-labelledby`）取名的分区，在标题为空的记录上不是区域，里面所有东西的 `in` 从 `section` 变成外面那个区域的类型。
- **数据页读取依赖 kit 0.4.6 和产品的 DOM。** 它需要 toy-crud-kit 0.4.6 的 `doDescribeElement`，通过 `.toy-data-page` 上 Vue 2 的 `__vue__` 找实例，并拒绝被移进 `[data-toy-crud-box]` 的弹出层。侧栏条目需要产品写的 `data-server-sidebar-nav-entry` 属性，否则按 `nav-unidentified` 拒绝。

## 第三方代码

本包没有运行时依赖：`dom-accessibility-api` 0.5.16（内联进 `lib/page.js` 与 `PICK_SCRIPT`）和 `fflate` 0.8.3（内联进 `lib/pack.js`）在 `devDependencies` 里精确钉版本，并列在 `BUNDLED.json` 里；内联的库与它不一致时构建失败。`src/page/content-frame/` 复制自 deepseek-harness `6822829a2f`。三份许可证正文都在 `THIRD-PARTY-LICENSES.txt` 里。

## 构建与测试

```sh
pnpm --filter @haoran/dsh-point-anchor run build   # node build.mjs：tsc -b、拾取脚本、四个 esbuild 产物
pnpm --filter @haoran/dsh-point-anchor run test
cd packages/point-anchor && pnpm pack --pack-destination <dir>
```

本包有自己的 `build.mjs`，并列在根 `tsdown.config.ts` 的 `workspace.exclude` 里。`lib/` 存在时 `tests/build.spec.ts` 检查构建产物，其中包括一个 NodeNext 使用方，在没有 DOM 类型的情况下对中立入口、`/pack`、`/pick-script` 做类型检查，还检查 `lib/pick-script.js` 里的拾取脚本就是当前源码打包出的那一份，所以改了拾取脚本打包进去的源码、重新构建之前它会失败。`tests/frame.spec.ts` 把命名语料的每一页与它的 `*.expected.json` 比对，文件缺失也算失败；只有 `POINT_ANCHOR_UPDATE_FIXTURES=1` 会按当前构建重写它们。`tests/pick-script-corpus.spec.ts` 还会去掉语料各页自己的 `[data-pointer]` 和 `[data-hidden]` 两条规则再拾取，要求与 `*.expected.json` 的比对恰好找出由这两条规则决定的那些探针，所以比对没找出差异时，确实比对过。
