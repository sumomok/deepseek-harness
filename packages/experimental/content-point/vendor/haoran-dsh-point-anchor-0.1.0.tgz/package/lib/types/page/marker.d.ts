/**
 * The marker the console's point-at-it plugin writes on its page while it is
 * loaded, `data-dsh-point="describe=1 anchors=1"` on `documentElement`: the
 * describe format it writes and the anchor formats whose key lines it renders.
 * The pick script reads it before picking, so an anchor is picked only on a
 * console that produces the same key line for the same element.
 *
 * The page can write anything here; the marker is a compatibility check, not
 * an authority.
 * @module @haoran/dsh-point-anchor/page/marker
 */
/** The marker as one document carries it. */
export type PageMarker = {
    readonly state: 'absent';
} | {
    readonly state: 'malformed';
    readonly raw: string;
} | {
    readonly state: 'present';
    readonly describe: number;
    readonly anchors: readonly number[];
};
/**
 * The marker value this build writes.
 * @returns `describe=<DESCRIBE_FORMAT> anchors=<ANCHOR_FORMATS_READ joined by commas>`.
 */
export declare function pageMarkerValue(): string;
/**
 * Write this build's marker on a document, for as long as the caller is loaded.
 * @param doc - the console document.
 * @returns the disposer, which removes the marker unless something else has rewritten it since.
 */
export declare function writePageMarker(doc: Document): () => void;
/**
 * Read the marker of a document.
 * @param doc - the console document.
 * @returns the marker's formats, or that there is none, or the raw value it could not read.
 */
export declare function readPageMarker(doc: Document): PageMarker;
//# sourceMappingURL=marker.d.ts.map