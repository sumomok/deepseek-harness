/**
 * The picker: hover to see what a click would name, click to name it, Escape
 * to stop. While picking, no press, release, click, touch, selection or drag
 * start, and no Enter, Space or Escape, reaches a document the picker listens
 * on; pointer movement and every other key pass through, so an arrow key still
 * changes a focused slider or number field.
 *
 * The FDE picks on a customer's live system under a real account, where a
 * click on 删除 deletes. So for as long as a pick runs, a capture-phase
 * listener on the window of every document the pick reaches cancels the
 * default action of, and stops, every event that activates something —
 * pointer and mouse presses and releases, clicks, double, auxiliary and
 * context clicks, touches, selection and drag starts, and the Enter and Space
 * keys that activate a focused control (Space does so on key up). The pick is
 * taken on a trusted `click`, the last event of a press, so no event of the
 * press is left to reach the page; a click a page script dispatches is
 * swallowed like any other and never taken. Pointer movement passes through:
 * hover menus still open, which is how the FDE reaches what they hold.
 *
 * The pick reaches the console document and, from each document it reaches,
 * through the light DOM and every open shadow root at any depth, the document
 * of each `iframe`, `frame` and `object` this page may read, and of each
 * `embed` this page may read: the SVG document it returns, or the document of
 * the frame its window lists for it. A document this page may not read
 * receives its events before any listener here sees them, so a transparent
 * shield is laid in the overlay over every other `iframe` and `frame`, every
 * other `object` holding a window, and every `embed` that may hold such a
 * document: every `embed` in a shadow root that returns no SVG document, since
 * a window lists no frame held in a shadow root, and, in a document whose
 * window lists a frame of another origin that no `iframe`, `frame` or `object`
 * holds, every `embed` holding no frame this page may read, since such a frame
 * does not say which `embed` holds it. A click on a shield is refused as
 * `unreadable-frame`. An `object` holding no window and every other `embed` —
 * one showing a plugin, fallback content, or an image whose `type` or URL
 * names an image type, which Chromium draws without a frame — are part of the
 * document around them; an `embed` naming no image type shows an image in a
 * frame of its own, held like any other frame's document. A shield stops the
 * pointer only, and a key goes to the focused document: Enter, Space and
 * Escape with focus inside a shielded frame reach that frame's page, and
 * Escape there does not end the pick. A page script cannot find a closed
 * shadow root, so a frame inside one is neither listened on nor shielded: a
 * press there, its release and its click reach the page and take no pick, and
 * Enter, Space and Escape with focus there reach the page too, Escape without
 * ending the pick.
 *
 * The reader enters iframes and open shadow roots, and no `frame`, `object` or
 * `embed`. A click in a document the pick reaches through one of those is
 * swallowed and refused as `unreadable-frame`, and hovering there draws that
 * refusal over the outermost such element.
 *
 * - Frames are followed as they change: a frame added later gets its listeners
 *   or its shield on the next mutation that adds or removes an element, or the
 *   next load, in a document or an open shadow root the pick follows. Once an
 *   animation frame the pick enumerates what it reaches again, visiting every
 *   element of every document it reaches, which catches what those miss — a
 *   frame whose document is replaced (the page navigating itself), a shadow
 *   root the page attaches, an `object` that comes to hold a window or stops
 *   holding one, an `embed` that comes to show a page — and leaves about one
 *   frame between such a change and its listeners or shield. A document no
 *   container holds any more — one a frame replaced, or the one it showed
 *   before going to another origin — loses its listeners at that check. A
 *   window of another origin refuses their removal, which leaves them where
 *   they are, doing nothing; a refused removal never keeps the pick from
 *   ending or any other listener from coming down.
 * - The listeners outlive the pick, still cancelling default actions and
 *   stopping propagation but no longer stopping other listeners on the same
 *   window, until {@link PICK_TAIL_GUARD_MS} has passed with no trusted event
 *   swallowed and no press or activation key held, and never longer than
 *   {@link PICK_GUARD_LIMIT_MS} after the pick ends. So the second click of a
 *   double click reaches nothing, a press the pick ended under — Escape, an
 *   abort, a cancel — reaches nothing when it is released within the limit,
 *   and a picker started in that time still receives its own events. Clicks
 *   closer together than the tail guard keep the listeners up for as long as
 *   they come, up to the limit. Only trusted events count, so a page
 *   dispatching its own clicks cannot keep the listeners up.
 * - Once the limit passes, nothing a press or a key does is cancelled: a press
 *   or an activation key held past it has its release reach the page, and the
 *   click a held press completes runs.
 * - A press is held while any pointer that went down is still down, each
 *   pointer by its id, the mouse by the buttons its events report and touches
 *   by the touches still on the surface: a second finger, or a mouse pressed
 *   and released while a pen is down, ends nothing. A pointer whose release
 *   never arrives holds the listeners until a later press of the same kind of
 *   pointer ends with none of that kind left down, or until the limit.
 * - An activation key is held from its key down to its key up. One whose key
 *   up never arrives holds the listeners until the first press after the pick
 *   ends, a window they listen on loses focus or its document is hidden, Meta
 *   is released — Chromium on macOS sends no key up for a key released while
 *   Meta is held, as after Cmd+Enter — or the limit passes. These end the hold
 *   of a key still down too: a key that repeats its key down holds the
 *   listeners again, and the key up of one that does not reaches the page once
 *   they are gone.
 * - A listener the page registered on its own window in the capture phase
 *   before the pick started runs before these and sees the events; what it
 *   does with them is the page's.
 *
 * The overlay lives in a closed shadow root on the console document's
 * `documentElement`, styled through the CSSOM so a page's style policy cannot
 * block it, and never receives a pointer event outside the shields.
 * @module @haoran/dsh-point-anchor/page/picker
 */
import type { DescribeRefusal, LabelWords, NameWarning, PointDescription } from '../index.ts';
import type { DescribePurpose } from './describe.ts';
import type { FrameEnv } from './frame.ts';
/** Every event a pick cancels and stops. */
export declare const PICK_SWALLOWED_EVENTS: readonly ["pointerdown", "pointerup", "mousedown", "mouseup", "click", "dblclick", "auxclick", "contextmenu", "touchstart", "touchend", "selectstart", "dragstart"];
/** How long the listeners outlive a pick, in milliseconds, counted from its end or from the last trusted event they swallowed after it, whichever is later, and never while a press or an activation key is held; {@link PICK_GUARD_LIMIT_MS} bounds it. */
export declare const PICK_TAIL_GUARD_MS = 400;
/**
 * The longest the listeners outlive a pick, in milliseconds, counted from its
 * end: once it passes they are removed, whatever press or activation key they
 * still count as held and however recently they swallowed an event, and the
 * release of a press held longer reaches the page.
 *
 * Three seconds is longer than any press a pick ends under in ordinary use — a
 * click, a touch held about half a second for a context menu, a mouse button
 * released a moment after Escape — and short enough that a console whose
 * clicks, Enter and Space go nowhere because a release never reached a window
 * the pick listens on works again within a user's second or third try.
 */
export declare const PICK_GUARD_LIMIT_MS = 3000;
/** How the picker runs. */
export interface PickerOptions extends FrameEnv {
    /** What the description is for. */
    readonly purpose: DescribePurpose;
    /** The words the tooltip states a place in. */
    readonly words?: Partial<LabelWords>;
    /** The words the tooltip states a refusal in. */
    readonly refusalWords?: Partial<Record<DescribeRefusal, string>>;
}
/**
 * How one pick ended. A pick for an anchor carries the warnings of its anchor
 * — of the name it keeps, and of the controls around a control in a cell or an
 * item — read off the page at the click; a pick for a reference carries none.
 */
export type PickOutcome = {
    readonly kind: 'picked';
    readonly point: PointDescription;
    readonly element: Element;
    readonly warnings: readonly NameWarning[];
} | {
    readonly kind: 'refused';
    readonly reason: DescribeRefusal;
    readonly detail?: string;
} | {
    readonly kind: 'cancelled';
};
/** One picker, good for one pick. */
export interface Picker {
    /**
     * Start picking. Calling it again returns the same pick.
     * @param signal - ends the pick as cancelled when aborted.
     * @returns how the pick ended.
     */
    start(signal?: AbortSignal): Promise<PickOutcome>;
    /** End the pick as cancelled; does nothing once it has ended. */
    cancel(): void;
}
/**
 * Create a picker over one console document.
 * @param doc - the console document; the overlay is drawn in it, and the pick listens on it and on the documents it reaches from it, and shields the `iframe`, `frame`, `object` and `embed` elements the module header lists; a frame inside a closed shadow root is neither listened on nor shielded.
 * @param options - the purpose, the injections, and the tooltip words.
 * @returns the picker.
 */
export declare function createPicker(doc: Document, options: PickerOptions): Picker;
//# sourceMappingURL=picker.d.ts.map