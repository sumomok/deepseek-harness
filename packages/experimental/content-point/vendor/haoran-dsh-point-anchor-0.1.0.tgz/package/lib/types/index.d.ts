/**
 * `@haoran/dsh-point-anchor`: one description of what a pointer is on in the
 * console's content column, shared by the console's point-at-it plugin, the
 * Beiming shell's pick script, and the FDE plugin, so that the same element
 * gives the same key line on every side.
 *
 * This entry is neutral — no DOM, no Node built-in — and is what each host
 * calls in Node: the formats, the anchor key line and its strict reads, the
 * `PromptReference.data` object and the model text rendered from it. The DOM
 * half is `/page`, the injected script is `/pick-script`, and the skill-pack
 * writers are `/pack`.
 * @module @haoran/dsh-point-anchor
 */
export { ANCHOR_FORMAT, ANCHOR_FORMAT_METADATA_PATH, ANCHOR_FORMATS_READ, ANCHORS_FILE, DESCRIBE_FORMAT, DESCRIBE_FORMATS_READ, POINT_ANCHOR_VERSION, POINT_LIMITS, } from './formats.ts';
export { anchorKey, CELL_ROLES, DATA_PAGE_FIELD_REGIONS, DATA_PAGE_PARTS, DATA_PAGE_REGIONS, DATA_PAGE_TOOLBAR_BUTTONS, INTERACTIVE_ROLES, ITEM_NAMED_ROLES, keptMarkToken, NAMED_ROLES, parseAnchor, parseAnchorKey, PICTURE_TAGS, PROPERTY_NAME, } from './anchor.ts';
export { chipLabel, displayLine, renderPointText, renderUnreadablePoint, UNANCHORED_WORDS, ZH_LABEL_WORDS } from './label.ts';
export type { LabelSubject, LabelWords } from './label.ts';
export { currentFormats, describesAnchor, parsePointData, parseShown, parseWhat, SHOWN_CODE_POINTS, toPromptReference } from './reference.ts';
export type { PointDataParsed } from './reference.ts';
export { DESCRIBE_REFUSALS, REFUSAL_WORDS } from './refusal.ts';
export type { DescribeRefusal } from './refusal.ts';
export { codePoints, keyValue, quoteJson, sanitizeLabel, utf8Bytes } from './text.ts';
export { holdsDigit, NAME_WARNINGS, parseNameWarnings } from './warning.ts';
export type { NameWarning } from './warning.ts';
export type { Anchor, DataPageAnchor, DataPageFieldRegion, DataPagePart, DataPageRegion, DataPageToolbarButton, FrameAnchor, NavAnchor, Parsed, PictureAnchor, PictureTag, PointData, PointDescription, PointReference, Shown, Unanchored, What, } from './types.ts';
//# sourceMappingURL=index.d.ts.map