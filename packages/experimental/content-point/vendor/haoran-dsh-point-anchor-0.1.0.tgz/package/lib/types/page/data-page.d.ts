/**
 * A DataPage describes itself: this asks the toy-crud-kit instance already on
 * the page (`doDescribeElement`, kit 0.4.6) and imports neither kit, Vue, nor
 * Element UI.
 *
 * The instance is found from the DOM — the console's bridge passes no instance
 * reference out — by reading Vue 2's `__vue__` on the `.toy-data-page` root and
 * walking down `$children` to the component named `ToyDataPage`, which finds it
 * whether `__vue__` names the bridge's root instance or the page itself. Kit
 * documents `instanceRef` as the way to its instance, not this, and the class
 * and the name are kit 0.4.6's.
 *
 * Kit's types are handwritten and a page can rewrite anything in the main
 * world, so the answer is held to kit 0.4.6's closed union and refused,
 * naming the part, when it is anything else.
 * @module @haoran/dsh-point-anchor/page/data-page
 */
import type { DataPageAnchor, DataPageFieldRegion, DataPageRegion, DataPageToolbarButton, DescribeRefusal } from '../index.ts';
/** A column or field of a kit point. */
interface KitNamed {
    /** The property name. */
    readonly key: string;
    /** The display name. */
    readonly label: string;
}
/** Kit 0.4.6's `DataPagePoint`, without its element. */
export type KitPoint = {
    readonly region: DataPageRegion;
    readonly part: 'area';
} | {
    readonly region: 'toolbar';
    readonly part: 'button';
    readonly button: DataPageToolbarButton;
    readonly label: string;
} | {
    readonly region: 'table';
    readonly part: 'header';
    readonly column: KitNamed;
} | {
    readonly region: 'table';
    readonly part: 'cell';
    readonly column: KitNamed;
    readonly row: readonly (readonly [string, string])[];
} | {
    readonly region: 'table';
    readonly part: 'row';
    readonly row: readonly (readonly [string, string])[];
} | {
    readonly region: 'table';
    readonly part: 'rowOperation';
    readonly operation: {
        readonly kind: 'row';
        readonly key: 'modify';
    } | {
        readonly kind: 'custom';
        readonly name: string;
        readonly label: string;
    };
    readonly row: readonly (readonly [string, string])[];
} | {
    readonly region: DataPageFieldRegion;
    readonly part: 'field';
    readonly field: KitNamed;
};
/** What one DataPage said about one element. */
export type DataPageAnswer = {
    readonly ok: true;
    readonly model: string;
    readonly point: KitPoint;
    readonly highlight: Element;
} | {
    readonly ok: false;
    readonly reason: DescribeRefusal;
    readonly detail?: string;
    readonly highlight?: Element;
};
/**
 * Hold one kit answer to kit 0.4.6's closed union.
 * @param value - what `doDescribeElement` returned, already known not to be null.
 * @returns the point, without its element.
 */
export declare function readKitPoint(value: unknown): KitPoint;
/**
 * Ask the DataPage around an element what the element is.
 * @param target - the element under the pointer.
 * @returns the page's model and validated point, or the refusal; `popup` and
 *   `unsupported-component` are the caller's to decide, since only it knows
 *   the element is in the content column.
 */
export declare function askDataPage(target: Element): DataPageAnswer;
/**
 * The anchor of a validated point: the model and the point's structural fields.
 * @param model - the DataPage's `relatedMeta`.
 * @param point - the point.
 * @returns the anchor, fields in key-line order.
 */
export declare function dataPageAnchor(model: string, point: KitPoint): DataPageAnchor;
/** The display name of kit's own modify operation, which kit gives no label. */
export declare const MODIFY_OPERATION_LABEL = "\u4FEE\u6539";
/**
 * The display name of what a point names.
 * @param point - the point.
 * @returns the name, or undefined for an area or a row.
 */
export declare function dataPageTarget(point: KitPoint): string | undefined;
export {};
//# sourceMappingURL=data-page.d.ts.map