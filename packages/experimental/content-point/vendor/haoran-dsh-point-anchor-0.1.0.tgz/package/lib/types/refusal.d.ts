/**
 * Why a place cannot be described, in one closed list shared by the page
 * describer, the picker, and the pick script's result.
 * @module @haoran/dsh-point-anchor/refusal
 */
/**
 * Every reason `/page`'s `describeElement` refuses a place:
 *
 * - `outside-content`: neither in the content column nor on a sidebar entry.
 * - `unsupported-component`: in the content column, on a component or column
 *   kind with no describer here; content-frame naming is never used for it.
 * - `popup`: in a DataPage's popup box — a dropdown, a date panel, a tooltip —
 *   but not under the page itself.
 * - `kit-too-old`: the DataPage has no `doDescribeElement` (kit before 0.4.6).
 * - `not-ready`: the DataPage answered `null`.
 * - `unknown-point`: the DataPage answered something outside kit 0.4.6's
 *   closed union.
 * - `unknown-model`: the DataPage's `relatedMeta` is not a property name.
 * - `unreadable-frame`: in a frame this page may not read.
 * - `no-column`: a table cell or a control in one whose column cannot be told.
 * - `nameless`: a place that neither a name, a mark, a position nor a column
 *   tells apart, such as a list item without a class.
 * - `too-large`: an anchor over the key-line bound.
 * - `nav-unidentified`: a sidebar entry that does not carry its entry id.
 * - `failed`: the describer threw; `detail` says what.
 */
export declare const DESCRIBE_REFUSALS: readonly ["outside-content", "unsupported-component", "popup", "kit-too-old", "not-ready", "unknown-point", "unknown-model", "unreadable-frame", "no-column", "nameless", "too-large", "nav-unidentified", "failed"];
/** One reason a place cannot be described. */
export type DescribeRefusal = typeof DESCRIBE_REFUSALS[number];
/** The default words the picker's tooltip states a refusal in. */
export declare const REFUSAL_WORDS: Readonly<Record<DescribeRefusal, string>>;
//# sourceMappingURL=refusal.d.ts.map