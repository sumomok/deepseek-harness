/**
 * The checks both exits run before anything leaves the FDE's machine, so a
 * refusal is seen at export rather than at install or upload.
 *
 * The organization backend and skill-pack stay the authority: the backend owns
 * the secret scan, name conflicts, and its own version-number rule, and this
 * catches the semantic-version-shaped numbers; the file exit cannot see the
 * target console, so the names that console's library skills take arrive as
 * `reservedNames` from the site record, and a name missing there is found only
 * by skill-pack's own same-name rule after install.
 *
 * Which names an anchor keeps is decided from the page's structure where the
 * page is; an export holds no page. What the export checks is what an entry
 * can show on its own: a name only on a role an anchor keeps one for (beside
 * a `column`, only a button's, a link's or a menu item's), display text naming
 * a place by its kept name or its column and by nothing its anchor leaves out,
 * since `anchors.md` prints that text, a mark holding only tokens
 * `keptMarkToken` keeps for the anchor's role or tag, its last token read as
 * the sprite symbol id the describer may add after the class tokens, and
 * warnings that agree
 * with the name. Whether the FDE confirmed every kept name is
 * `checkConfirmedNames`'s question.
 * @module @haoran/dsh-point-anchor/pack/check
 */
import type { ExportSkill } from './skill.ts';
import type { DshpackLimits, DshpackSet } from './dshpack.ts';
/** A skill name as the console's skill registry and the organization contract accept one. */
export declare const SKILL_NAME: RegExp;
/** The names the organization contract reserves for its own `/v1/me/skills/` paths, always added to the caller's list. */
export declare const FIXED_RESERVED_NAMES: readonly string[];
/** The organization contract's bounds on one delivery. */
export declare const DELIVERY_LIMITS: Readonly<{
    skills: 50;
    filesPerSkill: 64;
    bytesPerSkill: 2097152;
    version: 64;
    title: 200;
    note: 2000;
}>;
/** Every rule a violation can name. */
export type ExportRule = 'skill-count' | 'skill-name' | 'duplicate-skill' | 'reserved-name' | 'description' | 'when-to-use' | 'version-in-text' | 'pack-version' | 'platform' | 'no-anchors' | 'anchor' | 'dropped-name' | 'column-digits' | 'name-in-data' | 'name-digits' | 'mixed-cell-controls' | 'mark-token' | 'duplicate-anchor' | 'explanation' | 'unconfirmed-names' | 'file-count' | 'skill-bytes' | 'path' | 'extension' | 'case-conflict' | 'file-directory-conflict' | 'not-nfc' | 'body-long' | 'delivery-meta' | 'dshpack-set' | 'dshpack-entries' | 'dshpack-file-bytes' | 'dshpack-bytes';
/** One finding of {@link checkExport}. An `error` stops the export; a `warning` is shown and does not. */
export interface ExportViolation {
    /** Whether the export may go ahead. */
    readonly severity: 'error' | 'warning';
    /** The rule. */
    readonly rule: ExportRule;
    /** The skill it concerns. */
    readonly skill?: string;
    /** The skill-relative path it concerns. */
    readonly path?: string;
    /** What was found. */
    readonly detail?: string;
}
/** The organization request's own fields. */
export interface DeliveryMeta {
    /** The pack to add a version to; a new pack when omitted. */
    readonly packId?: string;
    /** The version this delivery creates. */
    readonly version: string;
    /** The pack's title. */
    readonly title: string;
    /** A note for the reviewer. */
    readonly note?: string;
}
/** Which exit a check is for, and what that exit needs. */
export type ExportTarget = {
    readonly kind: 'file';
    readonly set: DshpackSet;
    readonly limits?: Partial<DshpackLimits>;
} | {
    readonly kind: 'organization';
    readonly meta: DeliveryMeta;
};
/** What {@link checkExport} is told beyond the skills. */
export interface ExportCheckOptions {
    /** The exit. */
    readonly target: ExportTarget;
    /**
     * Names no exported skill may take: for the organization exit, the backend's
     * list; for the file exit, the target console's library-skill names from the
     * site record. `manifest` and `trials` are always added.
     */
    readonly reservedNames: readonly string[];
}
/**
 * The read limits a file-exit check uses: skill-pack's defaults, overridden by the target's.
 * @param target - the exit.
 * @returns the limits.
 */
export declare function dshpackLimits(target: Extract<ExportTarget, {
    kind: 'file';
}>): DshpackLimits;
/**
 * Check a set of skills for one exit. Every rule is checked and every finding
 * reported, so the FDE sees the whole list at once.
 *
 * Both exits: at least one and at most 50 skills; a valid, unique, unreserved
 * name of at most 255 bytes; a description and `whenToUse` without control or
 * format characters; an exact `pack.version`; a `platform`, when one is given,
 * in one of the spellings `V`, `>=V`, `>=V <W`, `^V`, `~V`; at least one
 * anchor, each `parseAnchor` accepts and its `what` describes, a name only
 * on a role in `NAMED_ROLES` (in `ITEM_NAMED_ROLES` beside a `column`), no
 * mark with a token `keptMarkToken` drops for its role or tag (its last
 * token read as a sprite symbol id), the display text of an
 * original-system place showing its anchor's kept name, else its column, else
 * nothing, warnings `parseNameWarnings` accepts, and no key line twice in one
 * skill; non-empty explanations; at most 64 files and 2 MiB
 * per skill; view paths that stay inside the skill, end in `.yml`/`.yaml`, are
 * in NFC, have no segment holding a lone surrogate or over 255 bytes of UTF-8,
 * and that, folded by `collisionKey`, equal no other path of the skill, lie
 * under none, and have none under them. A
 * version-number-shaped run in a description, `whenToUse`, or the body is an
 * error for the organization exit, whose backend refuses it, and a warning for
 * the file exit; a body over 8192 characters is a warning, and so is a frame
 * anchor whose column holds a decimal digit, since a header that shows a
 * count or a date stops matching once the data changes, and each warning an
 * entry carries (`name-in-data`, `name-digits`, `mixed-cell-controls`).
 *
 * The organization exit also checks the request's `version` (1–64 characters),
 * `title` (1–200) and `note` (at most 2000). The 255-byte name bound does not
 * guarantee a console's organization intake, which names a pack's directory
 * `<name>@<version>`, with the version the organization's manifest gives the
 * pack and the export does not know, and holds that whole string to 255
 * bytes of UTF-8. The file exit also checks the set identity and the
 * archive's read limits — the entry count with the manifest, and each file's
 * size; the archive's own size is known only once it is written, and
 * `exportDshpack` checks it there.
 * @param skills - every skill of the export.
 * @param options - the exit and the reserved names.
 * @returns every finding, in skill order; empty when there is none.
 */
export declare function checkExport(skills: readonly ExportSkill[], options: ExportCheckOptions): readonly ExportViolation[];
/**
 * Whether a check found anything that stops the export.
 * @param violations - the findings.
 * @returns true when one of them is an error.
 */
export declare function hasErrors(violations: readonly ExportViolation[]): boolean;
//# sourceMappingURL=check.d.ts.map