/**
 * The words a pointed-at place is written in: the attachment-row label, the
 * display line, and the model text the console host appends for a reference.
 *
 * The Chinese words in {@link ZH_LABEL_WORDS}, the display line, and the model
 * text are part of describe format 1 — the model text is logged, and the
 * display line is written into `anchors.md` — so changing one of them takes a
 * new format number. A caller may pass its own {@link LabelWords} for the
 * attachment-row label, which is user interface and never logged as text.
 * @module @haoran/dsh-point-anchor/label
 */
import type { DataPageRegion, PointData, Shown, Unanchored, What } from './types.ts';
/** The words one label is written in. Each template receives an already-cleaned name. */
export interface LabelWords {
    /** A DataPage region's name, for a point on the region itself. */
    readonly regions: Readonly<Record<DataPageRegion, string>>;
    /** A role's or container type's name; a role missing here is written as {@link LabelWords.role}. */
    readonly roles: Readonly<Record<string, string>>;
    /** The name of a role {@link LabelWords.roles} does not list. */
    readonly role: string;
    /** A column header. */
    readonly header: (name: string) => string;
    /** A table cell, by its column. */
    readonly cell: (column: string) => string;
    /** A DataPage row outside any drawn column. */
    readonly row: string;
    /** A row operation. */
    readonly operation: (name: string) => string;
    /** A toolbar button. */
    readonly button: (name: string) => string;
    /** A form item or info-card attribute. */
    readonly field: (name: string) => string;
    /** A named control or region on an original-system page. */
    readonly control: (role: string, name: string) => string;
    /** A control or region with no name. */
    readonly nameless: (role: string) => string;
    /** A drawing. */
    readonly picture: string;
    /** A sidebar entry. */
    readonly nav: (title: string) => string;
    /** A sidebar entry that shows no text, such as an icon in a collapsed sidebar. */
    readonly untitledNav: string;
}
/** The words of describe format 1. */
export declare const ZH_LABEL_WORDS: LabelWords;
/** The two fields a label is computed from. */
export interface LabelSubject {
    /** What kind of place it is. */
    readonly what: What;
    /** The display text around it. */
    readonly shown: Shown;
}
/**
 * The label of one place: the attachment-row text, the heading of its section
 * in `anchors.md`, and the quoted name in the model text.
 * @param subject - what the place is and what it is called.
 * @param words - the words to write it in; describe format 1's Chinese when omitted.
 * @returns a label of 1–64 code points with no control, format, or unpaired surrogate character.
 */
export declare function chipLabel(subject: LabelSubject, words?: Partial<LabelWords>): string;
/**
 * The display line of one place: the sidebar entry, the content-column entry,
 * and the place's label, joined by ` · `. It is for people, and for the line of
 * model text that repeats it; nothing matches on it.
 * @param subject - what the place is and what it is called.
 * @returns the line, without a line break.
 */
export declare function displayLine(subject: LabelSubject): string;
/** Why a place has no anchor, in the words of describe format 1. */
export declare const UNANCHORED_WORDS: Readonly<Record<Unanchored, string>>;
/**
 * The model text for one reference: what the user pointed at, its key line
 * written verbatim inside a code span, the display line, and for a DataPage
 * cell its row. The console host appends this as a logged message; the key
 * line in it is what a skill's `anchors.md` is matched against, and the display
 * line is only for reading.
 *
 * ```
 * 用户在内容栏里指着「列「图层名称」」。
 * 锚点：`data-page model=layerInfo region=table part=header column=layerName`
 * 显示：侧栏「图层管理」 · 数据页「图层管理」 · 列「图层名称」
 * 这一行：layerName="道路" status="启用"（还有 3 列没带）
 * ```
 *
 * The anchor line reads `锚点：没有（…）` for a place without one, and the row
 * line appears only when the description carries a row or left columns out.
 * Lines are joined by `\n` with no trailing line break.
 * @param data - a description that `parsePointData` accepted.
 * @returns the text.
 */
export declare function renderPointText(data: PointData): string;
/**
 * The model text for a logged reference this build cannot read, naming the
 * format the reference states and the formats this build reads.
 * @param problem - the stated format, when the reference states a readable one, and the formats read.
 * @returns the text.
 */
export declare function renderUnreadablePoint(problem: {
    readonly stated?: number;
    readonly reads: readonly number[];
}): string;
//# sourceMappingURL=label.d.ts.map