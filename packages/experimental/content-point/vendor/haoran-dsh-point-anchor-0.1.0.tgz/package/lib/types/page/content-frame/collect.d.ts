/**
 * One walk of the page, in document order, turning elements into the items a
 * listing renders. The walk enters open shadow roots and same-origin frames, so
 * a page built as a frame inside a frame reads as one document.
 *
 * Two rules keep the result a structure rather than a data dump: a table is
 * collected as its shape (header, one sample row, a row count) and never as its
 * rows, and an element that carries a name of its own — a control, a heading, a
 * click target with nothing inside it — ends the descent, because its
 * accessible name already says what is inside it. An element that both offers
 * something and holds something — a card the page makes clickable, a tree node
 * over the nodes under it — prints its row and is read into all the same.
 *
 * An element drawn the way an icon is — no role, nothing inside it, a mark to
 * be named by, and a picture it draws — is a control of the table cell or the
 * repeated item holding it, whatever cursor the page draws over it, and is
 * nothing anywhere else.
 *
 * Copied from deepseek-harness `packages/experimental/content-frame/src/client/access/collect.ts`
 * at 6822829a2f, Copyright (c) 2026 DeepSeek, MIT License (see THIRD-PARTY-LICENSES.txt).
 * Only this paragraph, the module tag, and the export list at the end of the
 * file, which names the walk's internals the pointer resolution reuses, differ
 * from the source.
 * @module @haoran/dsh-point-anchor/page/content-frame/collect
 */
import { type ComputedStyleOf } from './dom.ts';
import type { CellControl, Item, RowCell, SnapshotOptions } from './model.ts';
/** Every element that reads as a table. */
declare const TABLE_SELECTOR = "table, [role~=\"table\"], [role~=\"grid\"], [role~=\"treegrid\"]";
/** Everything one walk shares from its first element to its last. */
interface Walk {
    /** The read's options. */
    readonly options: SnapshotOptions;
    /** Injected visibility. */
    readonly isVisible: (el: Element) => boolean;
    /** Injected clickability, defaulted. */
    readonly isClickable: (el: Element) => boolean;
    /** Injected computed style, defaulted. */
    readonly computedStyle: ComputedStyleOf;
    /** The element the read asked for, which tops whatever the page nests it in. */
    readonly scope: Element | undefined;
    /** The document the read started from, which bounds the search for the item around an icon. */
    readonly root: Document;
    /** The items collected so far, in document order. */
    readonly items: Item[];
}
/**
 * Every control inside one table cell, in document order. Each is named the way
 * a row of its own would name it, so the icon a page makes clickable is
 * answered with what the page wrote on it and a click target holding text with
 * the text it shows.
 *
 * A drawing {@link isIconShape} accepts is read for the controls drawn inside
 * it first, and is an icon only where it holds none: a link drawn as a slice
 * of a chart is what the reader can operate there, whatever class the chart
 * carries.
 * @param el - the cell, or an element inside it.
 * @param walk - the walk in progress.
 * @param found - the controls collected so far, appended in place.
 * @param labelled - whether a `label` naming a control holds `el`.
 */
declare function cellControls(el: Element, walk: Walk, found: CellControl[], labelled?: boolean): void;
/**
 * Read one cell: what it says, and the controls it offers. A cell that holds
 * both says both — a status beside the button that changes it is what the
 * column is for.
 *
 * The sample is cut here rather than where it is printed, because what the
 * sample is for is saying which controls the column offers: cutting the line
 * afterwards would cut those off the end of a cell whose text runs long, and
 * the reader would take the column for one that offers nothing. The text gives
 * way to the controls, and a list of controls longer than the whole allowance
 * is cut inside its brackets rather than printed whole — a row of buttons named
 * a sentence each would otherwise spend the sample line on one column.
 * @param cell - the cell element.
 * @param walk - the walk in progress.
 * @returns the cell.
 */
declare function readCell(cell: Element, walk: Walk): RowCell;
/**
 * True for the role of an element the walk reads as a table, which is what
 * {@link TABLE_SELECTOR} matches candidates for and this decides.
 * @param role - the element's role.
 * @returns whether the element is read as a table.
 */
declare function isTableRole(role: string | null): boolean;
/** Which rows of one table head its columns and which hold its data. */
interface TableShape {
    /** The row heading the columns, absent for a table that heads none. */
    readonly headRow: Element | undefined;
    /** Every row holding data, without the header, the foot, and the hidden ones. */
    readonly dataRows: readonly Element[];
}
/**
 * Sort one table's rows into its header and its data.
 *
 * A `thead` of several rows heads the table by its first row alone, so a table
 * that spreads its column names over a grouping row and a leaf row reports the
 * grouping row as its header; the leaf names reach the reader only in the rows
 * themselves.
 * @param el - the table element.
 * @param walk - the walk in progress.
 * @returns the table's shape.
 */
declare function tableShape(el: Element, walk: Walk): TableShape;
/**
 * The name the page wrote for an element, which outranks anything it shows: a
 * menu item drawn as an icon says what it is nowhere else. Only what the label
 * itself carries counts — the text of the label attribute, or what each element
 * the page points at is called, in the order it points at them. An empty label,
 * and one pointing at nothing the page has, name nothing at all and leave the
 * element to be named by what it shows.
 *
 * A reference is looked up in the tree the element itself lives in, because
 * that is where the page wrote it: an id inside an open shadow root names the
 * element in that root, and never the one the surrounding page happens to give
 * the same id.
 *
 * A reference to the element itself, to what it holds, or to what holds it, is
 * no label. The page has pointed at the very text the row is being named from,
 * and following it would carry every button hanging off a tree node into that
 * node's name — the reading the ladder below this exists to prevent.
 *
 * An element pointed at is read whether or not the reader can see it: a page
 * that names a node by a run of text it draws nowhere still named it, which is
 * how ARIA defines the reference. What that element is called comes first and
 * its text second, so a page pointing at an icon is answered with the icon's
 * own label rather than with nothing.
 * @param el - the element to name.
 * @returns the written name, empty when the page wrote none.
 */
declare function declaredName(el: Element): string;
/** One element's name, and the label the page drew in front of it to say so. */
interface NamedItem {
    /** The name a row prints for the element. */
    readonly name: string;
    /** The `label` element the name was read off, when it was read off one. */
    readonly label: Element | undefined;
}
/**
 * What one element is called under one role.
 *
 * The whole ladder, in one place: what the element declares, what its contents
 * say for the roles ARIA names that way, the word written inside a box the page
 * labelled nowhere else, and failing all of those the `label` the page drew in
 * front of it. Every row the listing prints comes through here, and so does the
 * check a step's target is held to — a name computed two ways is a page the
 * model can read and the seat will not act on.
 * @param el - the element to name.
 * @param role - the role it prints.
 * @param walk - the walk in progress, for the injections and its caches.
 * @returns the name, and the label it came off.
 */
declare function namedAs(el: Element, role: string, walk: Walk): NamedItem;
/**
 * The state a pass over the page carries: the read's own injections, defaulted
 * once, and the items collected so far.
 *
 * A single-element caller builds one too, from the document the read that
 * printed the element started from. Nothing a name is made of comes out of the
 * items collected so far, and the item around an icon is looked for up to that
 * document, so a fresh one names an element exactly as the pass that printed it
 * did.
 * @param options - the read's options.
 * @param scope - the element the read asked for, when it asked for one.
 * @param root - the document the read starts from.
 * @returns the walk.
 */
declare function newWalk(options: SnapshotOptions, scope: Element | undefined, root: Document): Walk;
/**
 * What a listing calls one element, computed for that element alone.
 *
 * The one name in the package: a listing prints this, and a step's target is
 * checked against this. The model copies a name out of a listing and the seat
 * asks the page whether that element is still called that, so two computations
 * of it would refuse every step naming an element the two disagree about —
 * which is how a console's own query box, printed with the word written inside
 * it, became a target no step could ever hit.
 *
 * What the pass knows and this does not is where the element stands, and
 * position decides whether a row is printed rather than what it says: an
 * element inside a `label` that names a control, one that wraps a single
 * control and nothing else, or one the pass never reaches prints no row and
 * carries no ref, so no step can name it and no answer here is asked for.
 *
 * An icon a repeated item holds — an element {@link isIconShape} accepts that
 * {@link heldByItem} finds an item around, up to `root` — is the exception: a
 * markup read gives every element a ref, and a read scoped at the icon or at an
 * element around it prints a row for it inside such a `label` too. It is named
 * by what the page wrote on it wherever it stands, and every read that prints a
 * row for it prints that name.
 * @param el - the element to name.
 * @param options - the read's own options, for the injections it is computed under.
 * @param root - the document the read that printed the element started from.
 * @returns the name, empty for an element a listing would print without one.
 */
export declare function itemName(el: Element, options: SnapshotOptions, root: Document): string;
/**
 * Walk the page once.
 * @param root - the root document.
 * @param options - the read's options.
 * @param scope - the element to read, or undefined for the whole page.
 * @returns every collected item, in document order.
 */
export declare function collect(root: Document, options: SnapshotOptions, scope: Element | undefined): Item[];
export { cellControls, declaredName, isTableRole, namedAs, newWalk, readCell, TABLE_SELECTOR, tableShape };
export type { NamedItem, TableShape, Walk };
//# sourceMappingURL=collect.d.ts.map