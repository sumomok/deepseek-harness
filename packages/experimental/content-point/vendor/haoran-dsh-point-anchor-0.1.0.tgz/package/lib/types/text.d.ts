/**
 * The two string transformations every output of this package goes through:
 * cleaning display text into a label, and writing a value into a key line.
 *
 * The Beiming shell, the console host, and a customer's browser run different
 * engines with different Unicode versions, and must clean and escape the same
 * text the same way. So every character class here is a fixed list of code
 * points — control characters, the format characters Unicode 17.0 lists, and
 * the white space ECMAScript's `\s` matches under Unicode 17.0 — rather than
 * `\p{…}`, `\s` or `trim()`, whose sets follow the engine's Unicode data; and
 * nothing uses `normalize`, `Intl`, `localeCompare`, or a locale-sensitive case
 * mapping.
 * @module @haoran/dsh-point-anchor/text
 */
/**
 * Clean display text into a label: whitespace runs (line breaks included)
 * become one space, control characters, format characters and unpaired
 * surrogate halves are removed, the ends are trimmed, and text longer than
 * `maxCodePoints` keeps its first `maxCodePoints - 1` code points plus `…`.
 * The result satisfies the console's prompt-reference label rule whenever it is
 * non-empty and `maxCodePoints` is at most 64.
 * @param text - raw display text.
 * @param maxCodePoints - the longest result, in code points, the ellipsis included; at least 1.
 * @returns the label, empty when nothing visible is left.
 */
export declare function sanitizeLabel(text: string, maxCodePoints: number): string;
/**
 * Count the code points of a string.
 * @param text - the string.
 * @returns how many code points it holds.
 */
export declare function codePoints(text: string): number;
/**
 * Measure a string's UTF-8 encoding.
 * @param text - the string.
 * @returns its UTF-8 length in bytes.
 */
export declare function utf8Bytes(text: string): number;
/**
 * Write one string as a JSON string literal in which every character of
 * {@link ESCAPED_IN_KEY} is a `\uXXXX` escape in lowercase hexadecimal — the
 * form `JSON.stringify` already uses for an unpaired surrogate — so the result
 * is one visible line that JSON parses back to the same string.
 * @param value - the string.
 * @returns the literal.
 */
export declare function quoteJson(value: string): string;
/**
 * Write one value into a key line: as it stands when it is made only of ASCII
 * letters, digits, and `_ . : -`, and as {@link quoteJson} writes it otherwise.
 * @param value - the value, non-empty.
 * @returns the written value.
 */
export declare function keyValue(value: string): string;
/**
 * Whether a string can be written bare in a key line.
 * @param value - the string.
 * @returns true when {@link keyValue} writes it as it stands.
 */
export declare function isBareValue(value: string): boolean;
//# sourceMappingURL=text.d.ts.map