/** Roles that describe a field the user fills in. */
export declare const FIELD_ROLES: ReadonlySet<string>;
/**
 * Roles that hold a checked state. A menu item that checks or picks is one of
 * these: a reader who cannot see whether it is on clicks it again and turns it
 * off.
 */
export declare const CHECKED_ROLES: ReadonlySet<string>;
/** Roles that report a quantity the page sets, rather than one the user fills in. */
export declare const QUANTITY_ROLES: ReadonlySet<string>;
/**
 * The roles WAI-ARIA 1.2 §5.2.8.5 names from the text the element holds. A row
 * whose name was computed for a role the walk did not read is named from the
 * page instead, and only for these: a role named some other way says nothing
 * about the text under it.
 *
 * The list follows the specification's own table, the abstract role it names
 * included, so a later ARIA version means adding the roles it defines here.
 * Eleven of the members never reach the fallback that consults this list. Six —
 * `cell`, `columnheader`, `gridcell`, `row`, `rowheader`, and `tooltip` — reach
 * the walk through the table and the structure it reads; four — `treeitem`,
 * `menuitem`, `menuitemcheckbox`, and `menuitemradio` — are the node roles,
 * named by the ladder a node is named on before this list is consulted; and
 * `sectionhead` is abstract and reaches nothing. What a page writes those on is
 * read as a table, read as a node, or read through, and never named from its
 * contents here.
 */
export declare const NAME_FROM_CONTENT_ROLES: ReadonlySet<string>;
/** The role a snapshot gives a role-less element the page makes clickable. */
export declare const CLICKABLE_ROLE = "clickable";
/**
 * The role a snapshot gives an element {@link isIconShape} accepts where a
 * table cell or a repeated item holds it; see {@link heldByItem}.
 */
export declare const ICON_ROLE = "icon";
/**
 * The class tokens an element holds, in the order it holds them, separated by
 * one space, and empty for an element carrying no class. This is the string a
 * markup tree prints as `{class: …}`; the mark a listing row prints is
 * {@link rowMark}, which starts from it.
 *
 * Whole and uncut, because a row's mark is that row's identity: a read prints
 * it, a step naming that row carries it back, and the seat recomputes it and
 * compares the two character for character. A cut would leave the seat
 * comparing a mark against a shortened copy of itself.
 *
 * Nothing is read out of the tokens. They are the page's own spelling, printed
 * as they stand, and what they mean is for whoever knows the application.
 * @param el - the element to mark.
 * @returns the tokens, or the empty string for an element carrying no class.
 */
export declare function elementMark(el: Element): string;
/**
 * The mark a row carries for something the page offers and names nowhere:
 * {@link elementMark}, and for an `svg` whose first `use` points at a symbol,
 * those tokens followed by the symbol id, one space between them. A sprite
 * sheet draws every command with the same class and writes which command it is
 * only in the reference, so `<svg class="svg-icon"><use href="#icon-edit">`
 * is marked `svg-icon icon-edit` and `<svg><use href="#icon-edit">` is marked
 * `icon-edit`. A symbol id the class already holds as a whole token is not
 * added again.
 *
 * The listing prints this and the seat checks a step's `mark` against it, or
 * against the {@link elementMark} a markup tree prints for the same element,
 * so each comparison is of one string computed one way.
 * @param el - the element to mark.
 * @returns the mark, or the empty string for an element carrying neither.
 */
export declare function rowMark(el: Element): string;
/**
 * The roles of the things a page offers to act on, the click target it declares
 * no role for and the icon included. What a row under one of these says is what
 * the model can point a step at, so a row printing one of them and no name is a
 * row it cannot use.
 */
export declare const OFFERED_ROLES: ReadonlySet<string>;
/**
 * True for an element that is itself one of a run of items a page repeats: a
 * `<tr>` whatever role the page gives it, a list item, a row, a tree node, an
 * option, and an article of a feed.
 * @param el - the element to classify.
 * @returns whether the element is a repeated item.
 */
export declare function isRepeatedItem(el: Element): boolean;
/**
 * True for an element some repeated item holds, through shadow roots and frames
 * up to the document a read started from; see {@link isRepeatedItem}.
 * @param el - the element.
 * @param root - the document the read started from.
 * @returns whether a repeated item encloses the element.
 */
export declare function heldByItem(el: Element, root: Document): boolean;
/** The two pseudo-elements a page writes generated content into, which is where an icon font draws its glyph. */
export type GeneratedPseudo = '::before' | '::after';
/** The one read the walk makes of a computed style. */
export type StyleRead = Pick<CSSStyleDeclaration, 'getPropertyValue'>;
/**
 * The computed style of an element, or of one of its {@link GeneratedPseudo}s,
 * as `window.getComputedStyle` answers it.
 */
export type ComputedStyleOf = (el: Element, pseudo?: GeneratedPseudo) => StyleRead;
/**
 * The computed style a read uses where it injects none: the one the window an
 * element is drawn in computes.
 * @param el - the element.
 * @param pseudo - one of its generated-content pseudo-elements, or the element itself when omitted.
 * @returns the computed style.
 */
export declare function computedStyleOf(el: Element, pseudo?: GeneratedPseudo): CSSStyleDeclaration;
/**
 * True for an element drawn the way an icon is: no role, no element inside it
 * and no text of its own, a {@link rowMark} to be named by, and a picture it
 * draws (see {@link drawsPicture}). An `svg` is one drawing whatever shapes it
 * is built from, so what it holds is neither its children nor its text here.
 *
 * An `img` meets the first condition only where the page wrote a role ARIA
 * does not define, which reads as no role: HTML gives every other `img` the
 * role `img`, or `presentation` for an empty `alt`, and it is read by that role.
 *
 * No class token is read for what it says, and no cursor decides it. Where it
 * counts is the caller's: a table cell, or a repeated item (see
 * {@link heldByItem}).
 * @param el - the element to classify.
 * @param isVisible - injected visibility.
 * @param computedStyle - injected computed style.
 * @returns whether the element draws an icon.
 */
export declare function isIconShape(el: Element, isVisible: (el: Element) => boolean, computedStyle: ComputedStyleOf): boolean;
/** Every element the page shows as a dialog, an alert included. */
export declare const DIALOG_SELECTOR = "dialog, [role~=\"dialog\"], [role~=\"alertdialog\"]";
/**
 * Collapse every run of whitespace to one space and trim the ends.
 * @param value - raw text from the page.
 * @returns the collapsed text.
 */
export declare function collapse(value: string): string;
/**
 * True when text puts nothing on the screen: it is empty, or it holds nothing
 * but whitespace and the format code points a browser draws no character for.
 * A control whose contents draw nothing reports what the page wrote for it
 * instead, rather than a pair of quotes around an invisible character.
 * @param text - the collapsed text.
 * @returns whether the text draws nothing.
 */
export declare function drawsNothing(text: string): boolean;
/**
 * Cut one text run to the length a snapshot prints.
 * @param text - the collapsed text.
 * @returns the text, ending in an ellipsis when it was too long.
 */
export declare function clip(text: string): string;
/**
 * Cut one text run to a length a caller sets, for the places that print less
 * than a whole run: a sample cell, a header cell, the name of a click target.
 * @param text - the collapsed text.
 * @param limit - the longest result, the ellipsis included.
 * @returns the text, ending in an ellipsis when it was too long.
 */
export declare function clipTo(text: string, limit: number): string;
/**
 * True for an element whose text flows into the run around it.
 * @param el - the element to classify.
 * @returns whether text either side of the element is one run.
 */
export declare function isInline(el: Element): boolean;
/**
 * The children a walk descends into: an open shadow root replaces the light
 * children it renders in place of.
 * @param el - the element being descended into.
 * @returns the node whose children the walk reads.
 */
export declare function childHost(el: Element): ParentNode;
/**
 * What one selector matches inside a subtree, as an array. Callers read the
 * result as a sequence of the page — the first heading of a section, the first
 * dialog it has open — which is what the DOM answers a selector in: tree order,
 * over one tree, and this is that answer in a form the callers can iterate more
 * than once.
 * @param root - the subtree to search.
 * @param selector - the selector to match.
 * @returns the matching elements, first in the document first.
 */
export declare function queryInOrder(root: ParentNode, selector: string): Element[];
/**
 * True for a control holding a password, whose value never leaves the page.
 *
 * The type is not the only way a page says so: a box with its own show/hide
 * toggle is a `text` box while the password is showing, and what it holds is
 * declared in `autocomplete` instead — `current-password` or `new-password`.
 * Both are read, because what the rule protects is the credential, not the
 * attribute.
 *
 * `autocomplete` is read on every control HTML gives an autofill field to, not
 * on `input` alone: a `textarea` declaring a password holds one, and holds it
 * in a text node rather than an attribute, which is where the reads that print
 * an element's own text would otherwise find it.
 * @param el - the element to classify.
 * @returns whether the element holds a password.
 */
export declare function isPassword(el: Element): boolean;
/**
 * The element's role. A password box has none of its own, and the model still
 * needs to see the field, so it reads as the text box it is.
 *
 * A role the page wrote is only a role when ARIA defines it: a misspelled or
 * framework-private word tells the reader nothing, and printing it would put
 * text the page controls where the model reads the kind of a row. Such an
 * element reads by its structure instead. What HTML itself gives an element is
 * not filtered — that role comes from the tag, not from the page.
 *
 * A page may write several roles and mean the first one a reader understands,
 * which is how a document written against a newer vocabulary falls back to an
 * older one, so the tokens are read in order and the first defined role wins.
 * The comparison is case-sensitive, as ARIA defines these names. Every selector
 * this package matches a role with reads the attribute the same way — one
 * token of several, `[role~="x"]` — so a page that falls back is answered the
 * same wherever it is asked about.
 *
 * A page that marks an element as decoration and still labels it, or draws it
 * with something the user can operate, has written two things that contradict
 * each other; ARIA resolves that in favour of what the element offers, for
 * `presentation` and its synonym `none` alike, and so does this.
 * @param el - the element to classify.
 * @returns the role name, or null for an element with no role ARIA knows.
 */
export declare function roleOf(el: Element): string | null;
/**
 * The role `dom-accessibility-api` reads: the first word of the attribute
 * alone, cut on spaces. The name it computes and the presentational conflict it
 * resolves are answers about that role, so a walk that read another one cannot
 * take those answers unchanged.
 * @param el - the element to read.
 * @returns the word the library takes as the role, empty when the page wrote none.
 */
export declare function libraryRole(el: Element): string;
/**
 * True for an element whose content a browser never renders: a drawing, a media
 * element, a bar. A path is not a paragraph, the title a drawing carries is a
 * tooltip the page never shows, and the words inside a `progress` are there for
 * an engine that cannot draw one.
 * @param el - the element to classify.
 * @returns whether the walk stops at the element rather than reading into it.
 */
export declare function isOpaque(el: Element): boolean;
/**
 * True for an element written inside one of those, which is no row of the page
 * however it is marked up: a link drawn as a slice of a chart is a part of the
 * picture, and the words a chart holds label the picture rather than naming
 * anything around it.
 * @param el - the element to classify.
 * @returns whether something the page never renders encloses the element.
 */
export declare function insideOpaque(el: Element): boolean;
/**
 * True for a role that names something the model can read or act on, rather
 * than how the page is assembled.
 * @param role - the element's role.
 * @returns whether the role earns a row of its own.
 */
export declare function isNameable(role: string): boolean;
/**
 * The element's accessible name, and for a box the page named nowhere else,
 * the word written inside it.
 *
 * The placeholder is a fallback and never an override: a real name — a label,
 * `aria-label`, a title — is what the page said the control is, and this is
 * what is left when it said none. It is not the neighbouring-text rule the
 * reader deliberately does not have: the word is written on the control
 * itself, in the attribute whose whole purpose is to show it there, and it is
 * what a user reads in that box. A control with neither is left nameless,
 * which is what keeps `content_act` from being pointed at it at all.
 * @param el - the element to name.
 * @returns the collapsed name, empty when the element has none.
 */
export declare function nameOf(el: Element): string;
/**
 * The first heading inside an element, in document order, for a region whose
 * title is written rather than labelled.
 * @param el - the element to look inside.
 * @param isVisible - injected visibility.
 * @returns the heading's text, empty when there is none.
 */
export declare function headingText(el: Element, isVisible: (el: Element) => boolean): string;
/**
 * A container's name: what it is labelled, or failing that what it is titled.
 * @param el - the container element.
 * @param isVisible - injected visibility.
 * @returns the name, empty when the container has none.
 */
export declare function containerName(el: Element, isVisible: (el: Element) => boolean): string;
/**
 * True for an element that carries no content of its own, as opposed to one
 * the page merely hides: what is inside it is source, not page.
 * @param el - the element to classify.
 * @returns whether the element's subtree is not content.
 */
export declare function isNonContent(el: Element): boolean;
/**
 * True for an element the reader never sees, along with everything inside it.
 * @param el - the element to classify.
 * @param isVisible - injected visibility.
 * @returns whether the walk skips the element and its subtree.
 */
export declare function isSkipped(el: Element, isVisible: (el: Element) => boolean): boolean;
/**
 * True for an element hidden by something around it as well as by itself. The
 * injected visibility already answers for the styling, which reaches an element
 * from every ancestor over it; the two attributes are read again over the
 * ancestors because `aria-hidden` changes no style at all, so a wrapper
 * carrying it hides what is inside however the page draws it.
 *
 * The walk itself never needs this — it stops at the wrapper and never reaches
 * what is inside — and the searches that look at one element without walking to
 * it do.
 * @param el - the element to classify.
 * @param isVisible - injected visibility.
 * @returns whether the element is drawn nowhere the reader looks.
 */
export declare function isHiddenAround(el: Element, isVisible: (el: Element) => boolean): boolean;
/**
 * The visible text of an element as one run.
 * @param el - the element to read.
 * @param isVisible - injected visibility.
 * @param stopAt - subtrees whose text belongs to something else.
 * @returns the collapsed text, empty when the element shows none.
 */
export declare function visibleText(el: Element, isVisible: (el: Element) => boolean, stopAt?: (child: Element) => boolean): string;
/**
 * The value a field currently holds.
 * @param el - the field element.
 * @returns the value, or undefined for an element that holds none.
 */
export declare function fieldValue(el: Element): string | undefined;
/**
 * What a bar reports: the text the page wrote for it, the number behind that
 * text, or the value a native bar carries. A bar carrying none of the three
 * draws whatever it means somewhere else, and reports nothing here.
 * @param el - the bar element.
 * @returns the value, or undefined for a bar that reports none.
 */
export declare function quantityValue(el: Element): string | undefined;
/**
 * Whether a checkbox, radio, or switch is currently on. A box the browser keeps
 * the state of is read from the browser; anything else the page draws as one
 * has the state it wrote, and no state at all until it writes one. ARIA
 * requires the attribute on these roles, so a page that leaves it out has not
 * said the control is off — it has said nothing, and a reader told "off" would
 * click to turn on what is already on.
 *
 * A box the page reports as half checked has no state of the two either: it is
 * the box at the head of a table with some of its rows picked, and a reader
 * told it is off clicks it and picks every row on the page.
 *
 * The attribute is read the way HTML reads an enumerated one, ignoring case and
 * surrounding space: a page that wrote `TRUE` said the box is on.
 * @param el - the element to read.
 * @returns its checked state, or undefined when the page has declared none.
 */
export declare function isChecked(el: Element): boolean | undefined;
/**
 * Whether the page has disabled the element.
 * @param el - the element to read.
 * @returns its disabled state.
 */
export declare function isDisabled(el: Element): boolean;
/**
 * Whether the page takes what a field holds and refuses to let the reader type
 * over it. A page draws a picker as a box it fills itself, so a reader told
 * nothing would type into a field that answers no key.
 * @param el - the element to read.
 * @returns its read-only state.
 */
export declare function isReadonly(el: Element): boolean;
/**
 * The clickability test, in one home: the seat injects it into every read it
 * runs and `collect` falls back to it. A page that gives a role-less element a
 * pointer cursor is telling the reader it can be clicked.
 * @param el - the element to classify.
 * @returns whether the element looks clickable.
 */
export declare function looksClickable(el: Element): boolean;
/**
 * The document inside a frame, when this page may read it.
 * @param frame - the frame element.
 * @returns the frame's document, or undefined for a frame of another origin.
 */
export declare function frameDocument(frame: Element): Document | undefined;
/**
 * Every document this page may read, the root first and each same-origin frame
 * after it.
 * @param root - the root document.
 * @returns the readable documents, in document order.
 */
export declare function readableDocuments(root: Document): Document[];
//# sourceMappingURL=dom.d.ts.map