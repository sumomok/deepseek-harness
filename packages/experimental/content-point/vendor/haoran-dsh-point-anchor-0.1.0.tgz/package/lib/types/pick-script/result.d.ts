/**
 * What the pick script resolves to, and the strict read the Beiming shell and
 * the FDE plugin hold it to before using it: the script runs in the page's
 * main world, where the page can rewrite anything, so its result is untrusted
 * data until this read accepts it.
 * @module @haoran/dsh-point-anchor/pick-script/result
 */
import type { Anchor, NameWarning, Parsed, Shown, What } from '../index.ts';
/** The `Symbol.for` key of the one slot the pick script leaves on the page's window while a pick runs. */
export declare const PICK_SLOT = "dsh.point.pick";
/** The two formats one side works in. */
export interface PickFormats {
    /** Its describe format. */
    readonly describe: number;
    /** Its anchor format. */
    readonly anchor: number;
}
/**
 * Every reason a pick ends without an anchor: the describer's refusals, plus
 * `cancelled` (Escape, a cancel script, or a newer pick), `no-reader` (the
 * console carries no point-at-it marker, so nothing there would ever produce
 * this key line), and `format-mismatch` (the marker lists no anchor format the
 * script writes, or cannot be read).
 */
export declare const PICK_REASONS: readonly ["cancelled", "no-reader", "format-mismatch", "outside-content", "unsupported-component", "popup", "kit-too-old", "not-ready", "unknown-point", "unknown-model", "unreadable-frame", "no-column", "nameless", "too-large", "nav-unidentified", "failed"];
/** One reason a pick ends without an anchor. */
export type PickReason = typeof PICK_REASONS[number];
/**
 * One pick's result, structured-cloneable plain data.
 *
 * - `ok: true`: the anchor, what it is, and its display text, with the formats
 *   the script wrote them in, and `warnings` when the anchor drew any — for
 *   the name it keeps, or for the controls around a control in a cell or an
 *   item (see `NAME_WARNINGS`); a draft keeps them beside the anchor, and
 *   neither reaches the key line.
 * - `ok: false`: why, with the script's formats (`here`) and, for a
 *   `format-mismatch`, the formats the console's marker lists (`page`).
 */
export type PickResult = {
    readonly ok: true;
    readonly formats: PickFormats;
    readonly anchor: Anchor;
    readonly what: What;
    readonly shown: Shown;
    readonly warnings?: readonly NameWarning[];
} | {
    readonly ok: false;
    readonly reason: PickReason;
    readonly here: PickFormats;
    readonly page?: {
        readonly describe: number;
        readonly anchors: readonly number[];
    };
    readonly detail?: string;
};
/**
 * Read a pick result the page handed back. An anchor is accepted only in a
 * format this build reads (`ANCHOR_FORMATS_READ`), held to every rule of that
 * format, and with a `what` that describes it; display text is held to the
 * cleaned-label rule; warnings are held to `parseNameWarnings`, so a name with
 * a digit states `name-digits`; a refusal names one of {@link PICK_REASONS}.
 * @param value - what the script's promise resolved to.
 * @returns the result, or the first field that refused it.
 */
export declare function parsePickResult(value: unknown): Parsed<PickResult>;
/**
 * Clean a refusal's detail for a pick result.
 * @param detail - the raw detail.
 * @returns the cleaned detail, or undefined when nothing is left.
 */
export declare function pickDetail(detail: string | undefined): string | undefined;
//# sourceMappingURL=result.d.ts.map