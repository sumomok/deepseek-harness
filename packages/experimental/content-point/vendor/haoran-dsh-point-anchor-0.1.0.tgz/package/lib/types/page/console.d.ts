/**
 * The reads of the console's own DOM: which content-column entry is in front,
 * which sidebar entry names it, and which content-frame iframe an element of a
 * frame document sits in.
 *
 * Elements of frame documents belong to another realm, so nothing here uses
 * `instanceof`; node types and attributes decide.
 * @module @haoran/dsh-point-anchor/page/console
 */
/** The content column's selected entry. */
export interface SelectedEntry {
    /** The entry kind: `page`, `component`, or another column kind. */
    readonly kind: string;
    /** The entry id. */
    readonly entryId: string;
    /** The switcher's title for it, cleaned; empty when it shows none. */
    readonly title: string;
}
/**
 * Split a `<kind> <id>` key at its first space.
 * @param key - the key.
 * @returns the two halves, or undefined when the key has no space or an empty half.
 */
export declare function splitKey(key: string | null): {
    readonly kind: string;
    readonly id: string;
} | undefined;
/**
 * Clean display text read from the page.
 * @param text - the raw text.
 * @returns the cleaned text, or undefined when nothing is left.
 */
export declare function shownText(text: string | null | undefined): string | undefined;
/**
 * The content column's selected entry in one console document.
 * @param doc - the console document.
 * @returns the entry, or undefined when the switcher selects none.
 */
export declare function selectedEntry(doc: Document): SelectedEntry | undefined;
/**
 * The title of the sidebar entry with one catalog kind and id, compared
 * attribute by attribute rather than through a selector built from the id.
 * @param doc - the console document.
 * @param kind - `page` or `view`.
 * @param id - the entry id.
 * @returns the cleaned title, or undefined when no sidebar button carries that kind and id.
 */
export declare function navTitle(doc: Document, kind: string, id: string): string | undefined;
/**
 * The sidebar catalog kind that lists entries of one content-column kind:
 * content-frame pages are `page` on both sides, and a component-surface view
 * opens as a `component` entry under the view's id.
 * @param entryKind - the content-column kind.
 * @returns the sidebar kind, or undefined for a kind the sidebar does not list.
 */
export declare function navKindOf(entryKind: string): 'page' | 'view' | undefined;
/**
 * The display text for the content-column entry with one kind and id: its
 * switcher title when it is the selected entry, and the sidebar title naming it.
 * @param doc - the console document.
 * @param kind - the entry kind.
 * @param entryId - the entry id.
 * @returns the page and nav display values, each absent when unknown.
 */
export declare function entryShown(doc: Document, kind: string, entryId: string): {
    readonly page?: string;
    readonly nav?: string;
};
/**
 * The content-frame iframe an element of a frame document sits in, however
 * deep the frames nest inside it.
 * @param el - the element.
 * @returns the iframe, or undefined for an element of a document no content frame holds.
 */
export declare function contentFrameOf(el: Element): Element | undefined;
/**
 * The element above one in the composed tree, across a shadow root to its
 * host and across a frame document to its iframe, stopping at `root`'s top.
 * @param el - the element.
 * @param root - the document whose own top ends the climb.
 * @returns the element above, or undefined at the top.
 */
export declare function composedParent(el: Element, root: Document): Element | undefined;
//# sourceMappingURL=console.d.ts.map