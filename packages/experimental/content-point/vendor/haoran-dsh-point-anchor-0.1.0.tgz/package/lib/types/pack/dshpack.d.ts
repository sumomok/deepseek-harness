/**
 * The `.dshpack` writer: delivery-archive format 1 as the console's skill-pack
 * writes and reads it in deepseek-harness a9e2680281
 * (`packages/experimental/skill-pack/src/archive.ts` and `delivery.ts`). For
 * the same packs it writes the bytes `buildPackArchive` writes under the same
 * fflate version, and every pack name and path it writes passes
 * `validatePacks`. It does not hold an archive to a console's read limits or
 * require a set id and version: `checkExport` holds the entry count with the
 * manifest and each file's size to those limits and requires a non-empty set
 * id and version before writing, and `exportDshpack` holds the written
 * archive's own size to them. A name a file system refuses for a reason
 * `validatePacks` does not check still fails the console's write.
 *
 * - The archive is a ZIP holding `pack-delivery.json` first and then every file
 *   at `packs/<pack>/<path>`, in UTF-16 code-unit order of `<pack>/<path>`.
 * - The manifest is `JSON.stringify({ format: 1, set: { id, version }, files:
 *   [{ path, sha256 }] }, undefined, 2)` plus one line break, digests in
 *   lowercase hexadecimal.
 * - Every entry is written at DEFLATE level 6 under the local-time
 *   modification time `1980-01-01T12:00:00`, which encodes to the same DOS
 *   fields in every timezone.
 * - A pack name is one directory name; a file path stays inside its pack and
 *   ends in `.md .yml .yaml .png .jpg .jpeg .gif .webp`. A pack name and each
 *   path segment hold no lone UTF-16 surrogate and take at most 255 bytes of
 *   UTF-8. Folded by {@link collisionKey}, no two pack names are equal, no two
 *   paths of one pack are equal, and no path of a pack is a directory of
 *   another. A backslash is refused in both on every platform, where
 *   skill-pack refuses it in a pack name on Windows only, so the result never
 *   depends on the host.
 *
 * An archive is a whole set: a console's delivery directory holds exactly one,
 * and installing it retires every pack it does not carry. The input is
 * therefore every skill of the deployment, never the ones that changed.
 * @module @haoran/dsh-point-anchor/pack/dshpack
 */
/** The manifest format this writes, the only one skill-pack reads. */
export declare const DSHPACK_FORMAT = 1;
/** The archive entry carrying the manifest. */
export declare const DSHPACK_MANIFEST = "pack-delivery.json";
/** The file-name suffix a console's delivery directory recognizes. */
export declare const DSHPACK_EXTENSION = ".dshpack";
/** File extensions a pack may carry, lowercase with the dot. */
export declare const PACK_FILE_EXTENSIONS: ReadonlySet<string>;
/** The sizes and count a console reads an archive under. */
export interface DshpackLimits {
    /** Most entries, the manifest among them. */
    readonly maxFiles: number;
    /** Largest single file, in bytes. */
    readonly maxFileBytes: number;
    /** Largest archive, in bytes. */
    readonly maxArchiveBytes: number;
}
/** skill-pack's default read limits: 512 entries, 4 MiB per file, 32 MiB per archive. */
export declare const DSHPACK_DEFAULT_LIMITS: Readonly<{
    maxFiles: 512;
    maxFileBytes: 4194304;
    maxArchiveBytes: 33554432;
}>;
/** The set identity an archive's manifest carries: the site, and the export's version. */
export interface DshpackSet {
    /** The set's id; the FDE plugin writes the site id. */
    readonly id: string;
    /** The set's version; the FDE plugin writes the export's version. */
    readonly version: string;
}
/** One pack an archive carries. */
export interface DshpackPack {
    /** The pack's directory name. */
    readonly name: string;
    /** Its files, pack-relative. */
    readonly files: readonly {
        readonly path: string;
        readonly content: string | Uint8Array;
    }[];
}
/** The refusals the writer shares with skill-pack, by skill-pack's names. */
export type DshpackRefusal = 'path-escape' | 'duplicate-entry' | 'code-file';
/** A pack the writer refuses, named by the entry that refused it. */
export declare class DshpackError extends Error {
    readonly code: DshpackRefusal;
    readonly entry: string;
    /**
     * @param code - skill-pack's name for the refusal.
     * @param entry - the pack or `<pack>/<path>` refused.
     * @param detail - why.
     */
    constructor(code: DshpackRefusal, entry: string, detail: string);
}
/**
 * The form skill-pack compares two pack names, or two paths of one pack, in:
 * Unicode NFC, lower case, upper case, lower case again, and NFC again. Two
 * names with equal forms are refused as one name. The pass through upper case
 * makes one name of pairs lower case keeps apart, such as `ß` and `ss`, and
 * `σ` and `ς`. The fold is wider than any one file system's: it also makes
 * one name of a few pairs file systems keep apart, such as `ı` and `I`, and
 * refuses them, because refusing a pair costs less than writing two names
 * into one directory.
 * @param name - a pack name or a path.
 * @returns the folded form, which keeps every `/` of a path.
 */
export declare function collisionKey(name: string): string;
/**
 * Why a pack name is refused, if it is: it is not one directory name, holds a
 * lone UTF-16 surrogate, or takes more than 255 bytes of UTF-8.
 * @param name - the pack name.
 * @returns the reason, or undefined for a valid name.
 */
export declare function packNameProblem(name: string): string | undefined;
/**
 * Why a pack-relative path is refused, if it is: it leaves its pack, a segment
 * holds a lone UTF-16 surrogate or takes more than 255 bytes of UTF-8
 * (`path-escape`), or it ends in an extension a pack may not carry
 * (`code-file`), checked in that order.
 * @param path - the path.
 * @returns the refusal and its reason, or undefined for a valid path.
 */
export declare function packPathProblem(path: string): {
    readonly code: DshpackRefusal;
    readonly reason: string;
} | undefined;
/** How a path collides with a path of its pack seen before it, both folded by {@link collisionKey}. */
export interface PathCollision {
    /** `same` when the two are one path, `file-and-directory` when one is a directory of the other. */
    readonly kind: 'same' | 'file-and-directory';
    /** The path seen before it. */
    readonly other: string;
}
/**
 * Follow the paths of one pack in order, as skill-pack's `validatePacks`
 * compares them.
 * @returns a function that takes the pack's next path and returns how it
 *   collides with a path before it, or undefined, adding the path to those
 *   it compares later paths with only when it collides with none.
 */
export declare function pathCollisions(): (path: string) => PathCollision | undefined;
/**
 * Write a set of packs into one `.dshpack` archive.
 * @param packs - every pack of the deployment.
 * @param set - the identity the manifest carries.
 * @returns the archive's bytes.
 * @throws {DshpackError} when a pack name, a path, or an extension is one a pack may not carry, two pack names or two
 *   paths of one pack are one once folded by {@link collisionKey}, or a path of a pack is so folded a directory of another.
 */
export declare function writeDshpack(packs: readonly DshpackPack[], set: DshpackSet): Promise<Uint8Array>;
//# sourceMappingURL=dshpack.d.ts.map