/**
 * `@haoran/dsh-point-anchor/pack`: the two exits of an FDE export, written from
 * one skill directory.
 *
 * - The file exit: {@link exportDshpack} checks, then writes one `.dshpack`
 *   archive holding every skill of the site, for a console's delivery
 *   directory.
 * - The organization exit: {@link exportDelivery} checks, then builds the
 *   `POST /v1/delivery/skill-packs` request body, whose files are the same
 *   bytes.
 *
 * Both take the list of kept names the FDE confirmed — `listKeptNames` gives
 * the list to show — and refuse an export it does not match.
 *
 * Runs in Node and in browsers; it imports nothing but this package's neutral
 * entry and the inlined `fflate`.
 * @module @haoran/dsh-point-anchor/pack
 */
import type { DeliveryMeta, ExportViolation } from './check.ts';
import type { ConfirmedName } from './names.ts';
import type { DshpackLimits, DshpackSet } from './dshpack.ts';
import type { ExportSkill, SkillInvocation } from './skill.ts';
export { checkExport, DELIVERY_LIMITS, dshpackLimits, FIXED_RESERVED_NAMES, hasErrors, SKILL_NAME, } from './check.ts';
export type { DeliveryMeta, ExportCheckOptions, ExportRule, ExportTarget, ExportViolation } from './check.ts';
export { DSHPACK_DEFAULT_LIMITS, DSHPACK_EXTENSION, DSHPACK_FORMAT, DSHPACK_MANIFEST, DshpackError, PACK_FILE_EXTENSIONS, packNameProblem, packPathProblem, writeDshpack, } from './dshpack.ts';
export type { DshpackLimits, DshpackPack, DshpackRefusal, DshpackSet } from './dshpack.ts';
export { checkConfirmedNames, listKeptNames } from './names.ts';
export type { ConfirmedName, KeptName } from './names.ts';
export { ANCHOR_READING_INSTRUCTIONS, ANCHORS_TITLE, compareCodeUnits, DATA_PAGE_PART, DEFAULT_INVOCATION, renderAnchorsMd, renderSkillMd, requiredParts, SKILL_FILE, skillFiles, } from './skill.ts';
export type { AnchorEntry, ExportSkill, SkillFile, SkillInvocation, ViewFile } from './skill.ts';
/** The outcome of one export: what to hand over, or every finding that stopped it. */
export type ExportOutcome<T> = {
    readonly ok: true;
    readonly value: T;
    readonly warnings: readonly ExportViolation[];
} | {
    readonly ok: false;
    readonly violations: readonly ExportViolation[];
};
/**
 * Check every skill of a site and write them into one `.dshpack` archive.
 * The archive replaces the whole set on the console that installs it, so
 * `skills` is the site's every skill.
 * @param skills - every skill of the site.
 * @param set - the manifest identity: the site id and the export's version.
 * @param options - the target console's reserved skill names and read limits, and every kept name the FDE confirmed.
 * @returns the archive's bytes and the warnings, or every finding when one is an error.
 */
export declare function exportDshpack(skills: readonly ExportSkill[], set: DshpackSet, options: {
    readonly reservedNames: readonly string[];
    readonly limits?: Partial<DshpackLimits>;
    readonly confirmedNames: readonly ConfirmedName[];
}): Promise<ExportOutcome<Uint8Array>>;
/** One file of a delivery request: skill-relative, `/`-separated, as UTF-8 text. */
export interface DeliveryFile {
    /** The path. */
    readonly path: string;
    /** Always `utf8`: every file an FDE export writes is text. */
    readonly encoding: 'utf8';
    /** The text. */
    readonly content: string;
}
/** One skill of a delivery request. */
export interface DeliverySkill {
    /** The skill name. */
    readonly name: string;
    /** The description. */
    readonly description: string;
    /** When to use it. */
    readonly whenToUse?: string;
    /** How it may be invoked. */
    readonly invocation: SkillInvocation;
    /** The component parts it needs; the same list as `metadata.requires.parts`. */
    readonly requires?: readonly string[];
    /** Its files. */
    readonly files: readonly DeliveryFile[];
}
/** The `POST /v1/delivery/skill-packs` request body. */
export interface DeliveryRequest {
    /** The pack to add a version to. */
    readonly packId?: string;
    /** The version this delivery creates. */
    readonly version: string;
    /** The pack's title. */
    readonly title: string;
    /** A note for the reviewer. */
    readonly note?: string;
    /** The skills. */
    readonly skills: readonly DeliverySkill[];
}
/**
 * Build the organization request body from the same files the archive carries.
 * It checks nothing; {@link exportDelivery} checks first.
 * @param skills - the skills.
 * @param meta - the request's own fields.
 * @returns the body, fields in a fixed order.
 */
export declare function toDeliveryRequest(skills: readonly ExportSkill[], meta: DeliveryMeta): DeliveryRequest;
/**
 * Check every skill for the organization exit and build its request body.
 * @param skills - the skills of the delivery.
 * @param meta - the request's own fields.
 * @param options - the backend's reserved skill names, and every kept name the FDE confirmed.
 * @returns the body and the warnings, or every finding when one is an error.
 */
export declare function exportDelivery(skills: readonly ExportSkill[], meta: DeliveryMeta, options: {
    readonly reservedNames: readonly string[];
    readonly confirmedNames: readonly ConfirmedName[];
}): ExportOutcome<DeliveryRequest>;
//# sourceMappingURL=index.d.ts.map