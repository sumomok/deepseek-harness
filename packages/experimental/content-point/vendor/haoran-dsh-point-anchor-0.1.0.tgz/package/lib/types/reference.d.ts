/**
 * A description as `PromptReference.data`: built field by field in one fixed
 * order, held to the console's byte bound, and read back strictly from a
 * session log.
 *
 * `data` is durable — the console records it verbatim on the accepted user
 * message — so the read refuses anything this build would not have written: an
 * unknown key, a `what` that does not describe the anchor, a row on anything
 * but a DataPage cell, row, or row operation, a format number it does not read.
 * @module @haoran/dsh-point-anchor/reference
 */
import type { LabelWords } from './label.ts';
import type { Anchor, Parsed, PointData, PointDescription, PointReference, Shown, What } from './types.ts';
/** Longest display value, in code points. */
export declare const SHOWN_CODE_POINTS = 64;
/**
 * Whether a `What` describes an anchor: the same kind, and for a DataPage the
 * same region and part, for a frame the same role, for a picture the same tag.
 * @param what - the description's kind.
 * @param anchor - the anchor.
 * @returns the answer.
 */
export declare function describesAnchor(what: What, anchor: Anchor): boolean;
/**
 * Turn a description into a prompt reference that fits the console's bounds.
 * When `JSON.stringify(data)` is over `POINT_LIMITS.dataBytes` in UTF-8, the
 * row loses columns from its end, counted in `rowOmitted`; when that is not
 * enough, the anchor is dropped for `unanchored: 'too-large'`. The result is
 * the same for the same description.
 * @param point - the description, as `/page`'s `describeElement` made it for a reference.
 * @param source - the owner name the reference is filed under, `[A-Za-z0-9_.-]{1,64}`.
 * @param words - the words for the label; describe format 1's when omitted.
 * @returns the reference, or undefined when even the smallest form is over the bound.
 * @throws {RangeError} when `source` is not an owner name.
 */
export declare function toPromptReference(point: PointDescription, source: string, words?: Partial<LabelWords>): PointReference | undefined;
/**
 * Read a `What` from untrusted data.
 * @param value - the candidate.
 * @returns the value, or the refusal.
 */
export declare function parseWhat(value: unknown): Parsed<What>;
/**
 * Read a `Shown` from untrusted data: each value already cleaned the way
 * `sanitizeLabel` cleans it, non-empty, and at most 64 code points.
 * @param value - the candidate.
 * @returns the value, or the refusal.
 */
export declare function parseShown(value: unknown): Parsed<Shown>;
/** A `parsePointData` refusal, which names the format numbers when they are what refused it. */
export type PointDataParsed = {
    readonly ok: true;
    readonly value: PointData;
} | {
    readonly ok: false;
    readonly field: string;
    readonly reason: string;
    readonly stated?: number;
    readonly reads?: readonly number[];
};
/**
 * Read a logged `PromptReference.data` back into a description.
 *
 * `v` must be one of `DESCRIBE_FORMATS_READ` and `anchorFormat` one of
 * `ANCHOR_FORMATS_READ`; a refusal over either names the stated number and the
 * list read, which `renderUnreadablePoint` writes for the model. Everything
 * else is held to what this build writes: the fixed keys, an anchor
 * `parseAnchor` accepts and `what` describes, a row of at most 20
 * property-named string cells of at most 40 code units, a positive integer
 * `rowOmitted`, and either of the last two only on a DataPage cell, row, or row
 * operation.
 * @param value - the logged `data`.
 * @returns the description, or the first field that refused it.
 */
export declare function parsePointData(value: unknown): PointDataParsed;
/**
 * The description fields every producer in this package stamps: the formats this build writes.
 * @returns `{ v, anchorFormat }`.
 */
export declare function currentFormats(): {
    readonly v: number;
    readonly anchorFormat: number;
};
//# sourceMappingURL=reference.d.ts.map