/**
 * Anchor format 1: the fields of each anchor kind, the key line they render
 * to, and the strict reads that take an anchor back from untrusted data — a
 * page's pick result, a draft on disk, a line of `anchors.md`.
 *
 * The key line is the anchor's whole identity. Two places match exactly when
 * their key lines are equal byte for byte, so the line is built from the
 * structural fields alone, in one fixed order per kind, and never by iterating
 * an object:
 *
 * ```
 * key   = kind *(" " field)
 * kind  = "data-page" / "frame" / "picture" / "nav"
 * field = name "=" value               ; only the fields that are present
 * value = bare / json-string
 * ```
 *
 * - `data-page`: `model region part button column operation field`
 * - `frame`: `page column role name mark nth in`
 * - `picture`: `page tag mark nth in`, `nth` always present
 * - `nav`: `nav id`
 *
 * A value made only of ASCII letters, digits and `_ . : -` is written as it
 * stands; any other value is `JSON.stringify(value)` with every C1 control,
 * DEL, format character, U+2028, U+2029 and backtick replaced in that output by
 * its six-character `\uXXXX` escape (lowercase hexadecimal). `nth` is a
 * positive integer in decimal without leading zeros. The line carries no
 * format number: a skill states it once in `metadata.pack.anchorFormat`.
 *
 * {@link parseAnchorKey} accepts only the line {@link anchorKey} writes for the
 * anchor it reads — a bare-capable value in quotes, a raw separator inside a
 * string, or fields out of order are refused — so a line and its anchor
 * convert both ways without loss.
 * @module @haoran/dsh-point-anchor/anchor
 */
import type { Anchor, DataPageFieldRegion, DataPagePart, DataPageRegion, DataPageToolbarButton, Parsed, PictureTag } from './types.ts';
/** A property name as kit and the console's component catalog accept one: at most 64 characters. */
export declare const PROPERTY_NAME: RegExp;
/** Every DataPage region an anchor may name. */
export declare const DATA_PAGE_REGIONS: readonly DataPageRegion[];
/** Every DataPage part an anchor may name. */
export declare const DATA_PAGE_PARTS: readonly DataPagePart[];
/** The toolbar buttons kit 0.4.6 recognizes. */
export declare const DATA_PAGE_TOOLBAR_BUTTONS: readonly DataPageToolbarButton[];
/** The regions whose `field` part names a form item or an info-card attribute. */
export declare const DATA_PAGE_FIELD_REGIONS: readonly DataPageFieldRegion[];
/** The drawings a picture anchor names. */
export declare const PICTURE_TAGS: readonly PictureTag[];
/**
 * The roles of a table cell itself, rather than of a control inside one. A
 * frame anchor with one of them names its column and nothing else: what the
 * cell holds is row data.
 */
export declare const CELL_ROLES: ReadonlySet<string>;
/**
 * The roles a frame anchor may carry a name for: the interactive controls a
 * page names in its own words, and the fields named by their label. Every
 * other place — a cell, a heading, an image, a repeated item, a status, a
 * region, a click target the page gives no role, whose name is all the text it
 * shows — is named by its structure, and its anchor never carries a name.
 */
export declare const NAMED_ROLES: ReadonlySet<string>;
/**
 * The roles a control in a table cell or a repeated item keeps its name for,
 * and so the roles a frame anchor with a `column` may carry a name for: a
 * button's, a link's and a menu item's name says what it does to the record,
 * and an operation only some rows offer needs a key line of its own. A link's
 * text is as often a record's title; the name warnings and the FDE's
 * confirmation of every kept name catch that.
 */
export declare const ITEM_NAMED_ROLES: ReadonlySet<string>;
/**
 * The roles of an interactive control, whose mark keeps the type its class
 * says: an icon-only 「通过」 and 「删除」 are often told apart by nothing else.
 * An icon a cell or an item draws is one of the commands of its row.
 */
export declare const INTERACTIVE_ROLES: ReadonlySet<string>;
/**
 * Whether the mark of a place of one role keeps a class token. A page writes
 * a record's id, a date, a mount counter, and what the page or the pointer is
 * doing into class tokens, and a mark holding one changes with the record or
 * the moment, so no mark keeps a token that holds a decimal digit; starts
 * `is-`, `has-`, `status-` or `state-`; or has a word (split at runs of `-`
 * and `_`) in `active current selected checked hover focus focused disabled
 * expanded collapsed open opened closed striped highlight highlighted
 * loading`. A token saying a type — one of `success warning danger error
 * primary info` as the whole token or as the modifier after `--` that ends it
 * — is kept in the mark of an interactive control (one of
 * {@link INTERACTIVE_ROLES}), where it tells one command from another, and
 * dropped from every other mark, where it says the state of a record. A token
 * that only holds a type word among others is no type token, and is kept
 * everywhere: `el-icon-warning`, `btn-success`, `label-danger`,
 * `warning-text`, `success-row`. Examples dropped everywhere:
 * `order-20261001`, `status-approved`, Element UI's `is-fullscreen`,
 * `current-row`, `el-table__row--striped`, an option's `selected` and
 * `hover`, a page number's `active`, Vue Router's `router-link-active`; kept on
 * a button and dropped from a tag: `el-button--success`, `el-tag--success`,
 * `success`. Letter case does not matter. The one exception is the sprite
 * symbol id the page reader adds after the class tokens of an `svg` whose
 * first `use` points at a symbol: in the mark of an icon (`role=icon`) or of a
 * picture of tag `svg`, that token keeps a digit (`icon-xinzeng1`), and every
 * other rule holds it. The page reader writes every mark through this, and the
 * export checks hold every mark to it, reading the last token of an icon's or
 * an `svg` picture's mark as that symbol.
 * @param token - one mark token.
 * @param role - the role of the place the mark names: a frame anchor's role, or a picture's tag.
 * @param symbol - whether the token is the sprite symbol id ending the mark.
 * @returns whether the mark keeps it.
 */
export declare function keptMarkToken(token: string, role: string, symbol?: boolean): boolean;
/**
 * Render an anchor's key line. The Beiming shell, the FDE plugin and the
 * console host all call this in Node on the same structural fields, so equal
 * anchors give byte-identical lines everywhere.
 * @param anchor - the anchor, as {@link parseAnchor} accepts it.
 * @returns the key line.
 */
export declare function anchorKey(anchor: Anchor): string;
/**
 * Read an anchor from untrusted data — a pick result, a stored draft, a parsed
 * key line — holding it to every rule of its format: no field the kind does not
 * define, every required field present (a picture's `nth` among them), every
 * value within its charset and length, a name only for one of
 * {@link NAMED_ROLES}, only for one of {@link ITEM_NAMED_ROLES} beside a
 * `column`, and never beside a mark, a cell carrying its column and neither a
 * mark nor an `nth`, and a key line within `POINT_LIMITS.anchorKeyBytes`. The
 * anchor returned is a fresh object with its fields in key-line order.
 * @param value - the candidate.
 * @param format - the anchor format the value states it was written in; this build's own format when omitted.
 * @returns the anchor, or the first field that refused it and why.
 */
export declare function parseAnchor(value: unknown, format?: number): Parsed<Anchor>;
/**
 * Read a key line back into its anchor. Only the canonical line is accepted:
 * the one {@link anchorKey} writes for the anchor read, which fixes the field
 * order, which values are bare, and how a quoted value is escaped.
 * @param line - one key line, without its surrounding code span.
 * @returns the anchor, or why the line is not one.
 */
export declare function parseAnchorKey(line: string): Parsed<Anchor>;
//# sourceMappingURL=anchor.d.ts.map