/**
 * The warnings a picked anchor carries for the name its key line keeps and for
 * the controls around it, and the strict read a pick result and a draft hold
 * them to. A warning is a type and nothing else: what the page showed when the
 * anchor was picked never leaves the page.
 * @module @haoran/dsh-point-anchor/warning
 */
import type { Anchor, Parsed } from './types.ts';
/**
 * Every warning, in the one order a list of them is written in:
 *
 * - `name-in-data`: the name and a text the page showed where it draws
 *   records when the anchor was picked — a table cell, a repeated item, a
 *   heading, a description list's value — hold one another, as a menu item
 *   「删除张三」 holds the 「张三」 of a list. A text every sibling row or
 *   item shows alike, such as each row's 「编辑」, is the page's structure and
 *   not a record's; a name kept in a cell or an item carries the warning
 *   unless every sibling shows it. Only the pick can tell.
 * - `name-digits`: the name holds a decimal digit, as a count, a date, a phone
 *   number or an id does.
 * - `mixed-cell-controls`: the anchor names a link of a table body cell,
 *   and when it was picked the cells of that column in the body rows the page
 *   showed included both a cell holding one link alone and a cell holding two
 *   controls or more; or it names a link of a repeated item, and the items
 *   the page showed under the item's parent — an item has no columns, so its
 *   run of sibling items stands for one, each item read whole — included both.
 *   A link alone keeps no name and a link beside other controls keeps its
 *   name, so the same operation has a different key line in each kind of row,
 *   and the FDE picks it on both. The anchor may keep no name.
 */
export declare const NAME_WARNINGS: readonly ["name-in-data", "name-digits", "mixed-cell-controls"];
/** One warning. */
export type NameWarning = typeof NAME_WARNINGS[number];
/**
 * Whether a text holds a decimal digit of any script.
 * @param text - the text.
 * @returns the answer.
 */
export declare function holdsDigit(text: string): boolean;
/**
 * Read the warnings of one anchor from untrusted data: a list of one or more
 * distinct warnings in {@link NAME_WARNINGS} order, `name-in-data` and
 * `name-digits` only on an anchor whose key line keeps a name, `name-digits`
 * exactly when that name holds a decimal digit, and `mixed-cell-controls` only
 * on a frame anchor of role `link`. An absent list reads as no
 * warnings, and is refused for a name with a digit.
 * @param value - the candidate, `undefined` when the field is absent.
 * @param anchor - the anchor the warnings are about, already read.
 * @param field - the name a refusal reports.
 * @returns the warnings, empty when there are none, or the refusal.
 */
export declare function parseNameWarnings(value: unknown, anchor: Anchor, field: string): Parsed<readonly NameWarning[]>;
//# sourceMappingURL=warning.d.ts.map