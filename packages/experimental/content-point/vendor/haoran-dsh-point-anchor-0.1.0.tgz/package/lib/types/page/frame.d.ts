/**
 * Naming a place on an original-system page the way the console's page reader
 * names it, so an anchor picked in Beiming and a point the console's user makes
 * name the same element with the same words.
 *
 * The names come from the reader's own walk, copied unchanged into
 * `content-frame/`: {@link indexFrame} runs that walk once over a frame
 * document and keeps every row it prints, and {@link locateFrameTarget} climbs
 * from the element under the pointer to the first of those rows — the row a
 * listing prints for it. Position decides whether an element prints a row, and
 * the walk is what knows position, so the climb never guesses it. The climb
 * also stops, before the row around them, at the places the walk reads
 * through but an anchor names: a repeated item (a list item, a row outside a
 * table the walk reads as one, a feed article) and a status, an alert or a
 * figure.
 *
 * What names a place comes from the page's structure and never from its
 * data, so the same element has the same key line however many rows the page
 * shows and whichever record it has open; no rule compares one row's names
 * with another's. A place is in a repeated item when an ancestor is one — a
 * `<tr>`, or an element whose role is `listitem`, `row`, `treeitem` or
 * `option`, or an `article` in a `feed` — and is in a table cell when the
 * walk reads the table around it as one.
 *
 * - A control outside a cell and an item keeps its accessible name when its
 *   role is one of `NAMED_ROLES`: a button, a link, a menu item, a tab, a tick
 *   box, a radio, a switch, a slider, a field named by its label. Without a
 *   name it carries its mark. Element UI's `el-link` drawn as an `<a>` without
 *   an href, which the walk reads as a click target, is a link.
 * - In a cell or an item, a button, a link or a menu item keeps its name, and
 *   carries `nth`, its position among the cell's or item's controls of its
 *   role that carry the same name (or, nameless, the same mark), when two or
 *   more do. A link's name there is as often a record's title, which the name
 *   warnings and the FDE's confirmation of every kept name catch. Every other
 *   control there carries no name.
 * - A link alone in its cell or item — the one control `cellControls` finds
 *   there, counted as {@link holderControls} counts — keeps no name and
 *   carries its mark and no `nth`, since a column of values drawn as links (a
 *   theme, a parent, empty in some rows) would carry the record's value. A
 *   button or a menu item keeps its name however many controls stand beside
 *   it, and carries its mark only without one.
 * - An icon — a leaf the walk reads as one of a cell's or an item's
 *   controls because it draws a picture and has no role, whatever cursor is
 *   over it — is `role=icon`, an `svg` icon included, which is never a
 *   picture.
 * - A control whose name the browser may read from a field — a text box, a
 *   select, a number field, a slider or a bar, an `<input type="password">`
 *   only when the first word of its `role` is one of those, and an element
 *   the page makes editable (in a document in design mode, or under the
 *   nearest `contenteditable` at or above it other than `false`) — keeps no
 *   name anywhere, since the name carries the field's value: a field the
 *   control holds, for a role named from its content (「数量 5」), a field a
 *   label of it, or the `label` drawn before it that names it, holds besides
 *   the control (「其他 张三的备注」), or a field that an element its
 *   `aria-labelledby` names is or holds (「查询 李四」).
 *   An element holds the elements inside it — for a `<slot>`, what is
 *   assigned to it, or its own children when nothing is assigned — the
 *   labels of it and of every element it holds, and every element it or one
 *   it holds names in `aria-owns` or `aria-labelledby`, with what each of
 *   those holds.
 * - A place that keeps no name — a heading, an image, a status, an alert, a
 *   figure, a click target the page gives no role, an icon, a control in a
 *   cell or an item — carries its mark and its position among the places of
 *   its role and mark in its cell, else its nearest item, else the nearest
 *   container the walk prints around it (a region, or one of the three that
 *   `in` passes over), counted in document order from 1; a drawing is counted
 *   among the drawings of its tag and mark. A link alone in its cell or item
 *   carries its mark and no position. In a cell, a control inside a list item
 *   or a nested table's row there is counted in that item, so no position is
 *   counted across rows or items.
 * - A repeated item itself and a region carry their mark and no position,
 *   since an item's position among the items is data; a region is every
 *   container but the three that are controls as well, a tree node, a menu
 *   item and a click target holding items, and `in` is the type of the
 *   nearest region, passing over those three.
 * - A tree node the walk prints as one row — collapsed, or a leaf — names a
 *   control inside it as the node showing its children does, where the walk
 *   prints the control's own row, and a drawing inside it outside its controls
 *   as a picture, as the node showing its children does; so does a click
 *   target in a list holding no control, for a drawing that is no icon. Its
 *   controls are those `cellControls` counts, so a menu item, a tab or a
 *   slider in such a node is the node itself. Inside a node the walk names,
 *   it prints no row for a click target or an icon, and neither is one of the
 *   node's controls there: a click target the page gives no role is read
 *   through for the controls inside it, since Element UI draws a pointer
 *   cursor over `el-tree-node__content`, the line a node shows, and an Element
 *   UI `el-link` without an href there is the node's link in every state.
 *
 * Every mark is the mark the console reader prints on the place's row — the
 * class tokens a place is named by, and after them, for an `svg` whose first
 * `use` points at a sprite symbol, the symbol id — less every token
 * `keptMarkToken` drops for the place's role: one holding a decimal digit,
 * but the symbol id ending an icon's or an `svg` picture's mark, starting
 * `is-`, `has-`, `status-` or `state-`, or saying a state in a word
 * (`user-dialog-1024`, `status-approved`, Element UI's `is-fullscreen`,
 * `current-row`, an option's `selected`), and, outside an interactive control
 * or an icon, one saying a type as a whole token or a `--` modifier
 * (`el-tag--success`); a button's `el-button--success` stays, and so does
 * `el-icon-warning` or `btn-danger` on every place.
 *
 * Tables are the one place the walk prints a shape rather than rows. A cell is
 * named by its column's header text: from the header cell carrying the same
 * Element UI column token (`el-table_<n>_column_<m>`) inside the same
 * `.el-table` — Element UI draws a table's header and body as two `<table>`s,
 * and a fixed column once more in each fixed side, marking every copy but the
 * one it shows `is-hidden` — or, in a table drawn as one, from the header
 * row's cell covering exactly the columns the cell covers, laid out by HTML's
 * table model so that what another row spans moves no cell of this one. The
 * token pairs cells and never reaches an anchor: it changes on every mount.
 * Only a header row the page declares heads columns: the first row of a
 * `<thead>`, or a first row whose every cell says it heads a column
 * (`scope="col"`, `scope="colgroup"`, `role="columnheader"`), and neither when
 * it shows one cell, which is a title: nothing above the rows that hold data
 * tells a table one column wide from a record's title over a wider table. A
 * first row of plain `<th>`s is as likely a record's title or a key-value
 * table's labels as a header, so in a table without a declared header row no
 * cell has a column. A header cell in a body row, such as a record's name
 * drawn as `<th scope="row">`, is named by its column like any other body
 * cell. A row that is neither the header row nor a data row — a title, a
 * `<tfoot>` row, a `<thead>` row below the first, Element UI's summary row —
 * is in no column. The header row's controls are named as any row's are.
 * @module @haoran/dsh-point-anchor/page/frame
 */
import type { Walk } from './content-frame/collect.ts';
import type { ComputedStyleOf } from './content-frame/dom.ts';
import type { ContainerItem, ContainerType, ElementItem, TableItem } from './content-frame/model.ts';
import type { PictureTag } from '../index.ts';
/** The three injections a frame read runs under; the console reader's own when omitted. */
export interface FrameEnv {
    /** Whether an element is visible. */
    readonly isVisible?: (el: Element) => boolean;
    /** Whether a role-less element looks clickable. */
    readonly isClickable?: (el: Element) => boolean;
    /** The computed style of an element or of its `::before` or `::after`, which says whether a leaf draws a picture. */
    readonly computedStyle?: ComputedStyleOf;
}
/** One frame document's rows, as the reader's walk prints them. */
export interface FrameIndex {
    /** The document the walk started from. */
    readonly root: Document;
    /** Every element and region row, by element. */
    readonly rows: ReadonlyMap<Element, ElementItem | ContainerItem>;
    /** Every table, by element. */
    readonly tables: ReadonlyMap<Element, TableItem>;
    /** Every `label` a field is named by, to the field. */
    readonly labels: ReadonlyMap<Element, Element>;
    /** Every field named by a `label`, to the label: the same pairs as `labels`. */
    readonly fieldLabels: ReadonlyMap<Element, Element>;
    /** The injections the walk ran under. */
    readonly walk: Walk;
}
/**
 * Run the reader's walk once over a frame document and keep its rows.
 * @param root - the content-frame iframe's document.
 * @param env - the injections.
 * @returns the index; empty for a document without a body.
 */
export declare function indexFrame(root: Document, env?: FrameEnv): FrameIndex;
/**
 * What one place on a frame page is, as the reader names it. `name` is always
 * the walk's own name for the place; `named` says whether its anchor keeps it,
 * `mark` is the mark its anchor carries (empty where it keeps the name, or
 * where no token is left), and `nth` the position its anchor carries (see the
 * module documentation). `container` is the type of the nearest region around
 * it.
 */
export type FrameFace = {
    /** A control, heading, or other element row. */
    readonly kind: 'element';
    readonly el: Element;
    readonly role: string;
    readonly name: string;
    readonly named: boolean;
    readonly mark: string;
    readonly nth: number | undefined;
    readonly container: ContainerType | undefined;
} | {
    /**
     * A container row; `role` is its container type. `region` is true for
     * every type but a tree node, a menu item and a click target holding
     * items, and a region's anchor carries its mark alone.
     */
    readonly kind: 'container';
    readonly el: Element;
    readonly role: ContainerType;
    readonly name: string;
    readonly named: boolean;
    readonly mark: string;
    readonly nth: number | undefined;
    readonly region: boolean;
    readonly container: ContainerType | undefined;
} | {
    /** A place the walk prints no row for: a repeated item, a status, an alert or a figure. */
    readonly kind: 'structure';
    readonly el: Element;
    readonly role: string;
    readonly mark: string;
    readonly nth: number | undefined;
    readonly container: ContainerType | undefined;
} | {
    /** A table as a whole, a region: `name` is the walk's, which its anchor leaves out, and `mark` its class tokens. */
    readonly kind: 'table';
    readonly el: Element;
    readonly name: string;
    readonly mark: string;
    readonly container: ContainerType | undefined;
} | {
    /** One cell of a table; `header` for a cell heading its column. */
    readonly kind: 'cell';
    readonly el: Element;
    readonly role: string;
    readonly header: boolean;
    readonly column: string | undefined;
    readonly container: ContainerType | undefined;
} | {
    /** A control inside a cell. */
    readonly kind: 'cell-control';
    readonly el: Element;
    readonly role: string;
    readonly name: string;
    readonly named: boolean;
    readonly mark: string;
    readonly nth: number | undefined;
    readonly column: string | undefined;
    readonly container: ContainerType | undefined;
} | {
    /** A drawing, named by its tag, its mark and its position among the drawings of its tag and mark. */
    readonly kind: 'picture';
    readonly el: Element;
    readonly tag: PictureTag;
    readonly mark: string;
    readonly nth: number;
    readonly container: ContainerType | undefined;
} | {
    /** No row encloses the element. */
    readonly kind: 'none';
    readonly el: Element;
};
/**
 * Whether the place a picked link is in gives its operation two key lines:
 * the link is one of the controls of a table body cell, and the cells of its
 * column in the body rows the page shows include both a cell holding one link
 * alone and a cell holding two controls or more — or it is one of the
 * controls of a repeated item, and the items the page shows beside it include
 * both an item holding one link alone and one holding two controls or more.
 * A control in a list item or a nested table row inside a cell is read as in
 * that item. A link alone keeps no name and a link beside other controls keeps
 * its name, so the same operation has a key line in each kind of row; every
 * other control keeps one key line in both.
 * @param el - the picked control, the element its description covers.
 * @param index - the frame document's rows.
 * @returns the answer; false for a place that is no such link.
 */
export declare function mixesHeldControls(el: Element, index: FrameIndex): boolean;
/**
 * The face of the place under the pointer: the first row the reader prints
 * for it, climbing from the element through shadow roots and frames up to
 * `index.root`, or a repeated item, a status, an alert or a figure the climb
 * passes before that row. A `label` the reader prints as a field's name
 * resolves to that field. A drawing is a picture unless a table holds it or the
 * first row around it is a control's; the one row the walk prints for a tree
 * node or a click target in a list, and the container it opens for a tree node
 * it names, count as a control's only where one of the item's controls holds
 * the drawing.
 * @param deepest - the element under the pointer.
 * @param index - the frame document's rows.
 * @param env - the injections the index was built under.
 * @returns the face.
 */
export declare function locateFrameTarget(deepest: Element, index: FrameIndex, env?: FrameEnv): FrameFace;
/**
 * The document a frame read starts from for an element: the content-frame
 * iframe's document when the element is in one, else the topmost document
 * this page may read above the element.
 * @param el - the element.
 * @param contentFrame - the content-frame iframe holding it, when known.
 * @returns the document.
 */
export declare function frameRootOf(el: Element, contentFrame?: Element | undefined): Document;
/**
 * Name one element the way the pick script and the point-at-it plugin name it,
 * for a caller that holds no index.
 * @param el - the element under the pointer.
 * @param env - the injections, and the document to walk from; the element's frame root when omitted.
 * @returns the face.
 */
export declare function frameFace(el: Element, env?: FrameEnv & {
    readonly root?: Document;
}): FrameFace;
//# sourceMappingURL=frame.d.ts.map