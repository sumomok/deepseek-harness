/**
 * `@haoran/dsh-point-anchor/page`: the browser half. It describes the place
 * under the pointer in the console's content column, draws the picker over the
 * console, and writes the marker the pick script checks. It imports nothing
 * from the page — no kit, no Vue, no Element UI, no React — and sends nothing
 * anywhere.
 *
 * It also exports the copy of the console reader's naming it runs on
 * (`contentFrameCopy`), so the product can hold the copy to the original
 * element by element.
 * @module @haoran/dsh-point-anchor/page
 */
import { collect, itemName } from './content-frame/collect.ts';
import { computedStyleOf, looksClickable, rowMark } from './content-frame/dom.ts';
import { isVisible } from './content-frame/visibility.ts';
export { DOM_CONTRACT } from './contract.ts';
export { contentFrameOf, entryShown, navTitle, selectedEntry } from './console.ts';
export type { SelectedEntry } from './console.ts';
export { askDataPage, dataPageAnchor, dataPageTarget, MODIFY_OPERATION_LABEL, readKitPoint } from './data-page.ts';
export type { DataPageAnswer, KitPoint } from './data-page.ts';
export { describeElement, resolvePointTarget } from './describe.ts';
export type { DescribeOptions, DescribePurpose, DescribeResult } from './describe.ts';
export { frameFace, frameRootOf, indexFrame, locateFrameTarget } from './frame.ts';
export type { FrameEnv, FrameFace, FrameIndex } from './frame.ts';
export { pageMarkerValue, readPageMarker, writePageMarker } from './marker.ts';
export type { PageMarker } from './marker.ts';
export { createPicker, PICK_GUARD_LIMIT_MS, PICK_SWALLOWED_EVENTS, PICK_TAIL_GUARD_MS } from './picker.ts';
export type { Picker, PickerOptions, PickOutcome } from './picker.ts';
export { DATA_TEXT_MIN_CODE_POINTS, nameWarnings } from './warnings.ts';
export type { CellControl, ContainerItem, ContainerType, ElementItem, Item, SnapshotOptions, TableItem } from './content-frame/model.ts';
/**
 * The copy of the console reader's naming this package runs on, as copied from
 * deepseek-harness at {@link contentFrameCopy.revision}: the whole walk
 * (`collect(root, options, scope)`), the one name a listing prints
 * (`itemName(el, options, root)`), the mark of a nameless row, and the three
 * injections the reader runs under.
 */
export declare const contentFrameCopy: Readonly<{
    /** The deepseek-harness commit the copy was taken at. */
    revision: "6822829a2f";
    collect: typeof collect;
    itemName: typeof itemName;
    rowMark: typeof rowMark;
    isVisible: typeof isVisible;
    looksClickable: typeof looksClickable;
    computedStyleOf: typeof computedStyleOf;
}>;
//# sourceMappingURL=index.d.ts.map