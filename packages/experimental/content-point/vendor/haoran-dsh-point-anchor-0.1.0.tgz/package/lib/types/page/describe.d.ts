/**
 * One description of the place under the pointer, whichever kind of place it
 * is: a DataPage in the content column's component seat, an original-system
 * page in a content-frame iframe, a drawing on such a page, or a sidebar
 * navigation entry.
 *
 * Anything else in the content column is refused rather than described some
 * other way — a place with two possible anchors is worse than one with none —
 * so content-frame naming never stands in for a component, and a DataPage
 * popup is refused as one.
 * @module @haoran/dsh-point-anchor/page/describe
 */
import type { DescribeRefusal, PointDescription } from '../index.ts';
import type { FrameEnv, FrameIndex } from './frame.ts';
/** What a description is for: an anchor (the FDE's pick, never a row) or a reference (the console user's point, with its row). */
export type DescribePurpose = 'anchor' | 'reference';
/** How {@link describeElement} runs. */
export interface DescribeOptions extends FrameEnv {
    /** What the description is for. */
    readonly purpose: DescribePurpose;
    /** Where to take a frame document's index from; a fresh walk when omitted. */
    readonly frameIndex?: (root: Document) => FrameIndex;
}
/** The outcome of one description. `highlight` is the element the place covers, for drawing a box. */
export type DescribeResult = {
    readonly ok: true;
    readonly point: PointDescription;
    readonly highlight: Element;
} | {
    readonly ok: false;
    readonly reason: DescribeRefusal;
    readonly detail?: string;
    readonly highlight?: Element;
};
/**
 * Describe the place under the pointer.
 *
 * For `anchor`, a place without an anchor — a cell whose column cannot be
 * told, a nameless control, an anchor over the key-line bound — is refused
 * with that reason, and the point carries no row. For `reference`, such a
 * place is described with `unanchored` set, and a DataPage cell, row, or row
 * operation carries its row.
 *
 * The iframe page's names come from the browser's accessible-name computation
 * over the live layout: the same element gives the same name in the same
 * engine under the same viewport, media queries, fonts and zoom, and the
 * Beiming shell's Chromium is the engine anchors are picked in. DataPage
 * anchors depend on none of that.
 * @param target - the element under the pointer, normally the first entry of the event's `composedPath()`.
 * @param options - the purpose, the injections, and the index source.
 * @returns the description and the element it covers, or the refusal.
 */
export declare function describeElement(target: Element, options: DescribeOptions): DescribeResult;
/**
 * The element a description of the place under the pointer covers: the row
 * the console's reader prints for it, the DataPage part kit names, or the
 * sidebar button.
 * @param deepest - the element under the pointer.
 * @param options - the injections; a reference description is what decides.
 * @returns the covered element, or `deepest` when the place is refused without one.
 */
export declare function resolvePointTarget(deepest: Element, options?: FrameEnv & {
    readonly frameIndex?: (root: Document) => FrameIndex;
}): Element;
//# sourceMappingURL=describe.d.ts.map