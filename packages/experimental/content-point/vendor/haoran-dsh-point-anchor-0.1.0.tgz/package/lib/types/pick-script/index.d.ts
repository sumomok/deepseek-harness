/**
 * `@haoran/dsh-point-anchor/pick-script`: what the Beiming shell's main
 * process needs to run a pick — the fixed script, its digest, the cancel
 * script, and the strict read of the result — and nothing that touches a DOM.
 *
 * The shell injects only {@link PICK_SCRIPT}, never a caller's script: a page
 * view logged in to a customer's system will run whatever it is given under
 * the FDE's account. Evaluate it once in the main world of the view's main
 * frame (`executeJavaScript`), race the promise against navigation, the view's
 * destruction and a timeout, and pass the value through `parsePickResult`
 * before it reaches the FDE plugin. Report `POINT_ANCHOR_VERSION` and
 * {@link PICK_SCRIPT_FORMATS} in the handshake with the FDE plugin.
 *
 * `PICK_SCRIPT` exists only in the built `lib/pick-script.js`; importing this
 * module from source throws.
 * @module @haoran/dsh-point-anchor/pick-script
 */
import type { PickFormats } from './result.ts';
export { parsePickResult, PICK_REASONS, PICK_SLOT } from './result.ts';
export type { PickFormats, PickReason, PickResult } from './result.ts';
export { POINT_ANCHOR_VERSION } from '../index.ts';
/**
 * The pick script: a self-contained IIFE whose value is a promise of a
 * structured-cloneable `PickResult`.
 */
export declare const PICK_SCRIPT: string;
/** The SHA-256 of {@link PICK_SCRIPT}'s UTF-8 bytes, lowercase hexadecimal. */
export declare const PICK_SCRIPT_SHA256: string;
/** An expression that ends the pick running on the page, if any, as cancelled; its value is `null`. */
export declare const PICK_CANCEL_SCRIPT: string;
/** The formats {@link PICK_SCRIPT} works in. */
export declare const PICK_SCRIPT_FORMATS: PickFormats;
//# sourceMappingURL=index.d.ts.map