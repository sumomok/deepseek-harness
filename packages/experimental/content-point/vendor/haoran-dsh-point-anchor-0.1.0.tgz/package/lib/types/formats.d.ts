/**
 * The format numbers this package writes and reads, the bounds it shares with
 * the console's prompt references, and the rules that keep two builds that
 * state the same number agreeing.
 *
 * Two numbers, each owning its own surface:
 *
 * - {@link DESCRIBE_FORMAT} owns a `PointDescription` (`PromptReference.data`)
 *   and the model text rendered from one.
 * - {@link ANCHOR_FORMAT} owns the anchor fields, the key line they render to,
 *   the `anchors.md` layout, and the fixed `SKILL.md` body.
 *
 * For both: a number, once a tarball carrying it has been released, names one
 * rule set forever, and a change to what an existing value renders to takes
 * the next number. The two read lists keep an earlier number on different
 * conditions, because they are read for different things:
 *
 * - {@link ANCHOR_FORMATS_READ} keeps anchor format N while every place N can
 *   anchor is still described by this build as the same key line N gave it.
 *   A later format may add kinds, and add optional fields only on places N
 *   cannot anchor; filling a new field on a place N anchors, or changing how a
 *   field is written, removes N from the list, which is a breaking change (see
 *   {@link ANCHOR_FORMATS_READ}). skill-pack activates a pack, and the pick
 *   script picks, on this list, and a key line from a skill pack matches the
 *   console's only under this rule.
 * - {@link DESCRIBE_FORMATS_READ} keeps describe format N while this build
 *   renders every value of N byte for byte as N did, the model text included,
 *   because what reads it replays a `PromptReference.data` from a session log.
 * @module @haoran/dsh-point-anchor/formats
 */
/** This package's own version, which the Beiming shell reports in its handshake with the FDE plugin. */
export declare const POINT_ANCHOR_VERSION = "0.1.0";
/** The describe format this build writes. */
export declare const DESCRIBE_FORMAT = 1;
/** The describe formats whose every value this build renders as that format did, under the rule in the module documentation. */
export declare const DESCRIBE_FORMATS_READ: readonly number[];
/** The anchor format this build writes. */
export declare const ANCHOR_FORMAT = 1;
/**
 * The anchor formats whose every anchorable place this build describes as the
 * same key line, under the rule in the module documentation.
 *
 * Per fde-plugin.md §4 the list only grows: a number is added and never
 * changed. skill-pack activates a delivered pack only when the anchor format
 * its skills state is on this list, so taking a number off it deactivates
 * every pack already delivered in that format. That is a breaking change: the
 * main session decides it, and an upgrade guide records it before it ships.
 */
export declare const ANCHOR_FORMATS_READ: readonly number[];
/**
 * Where a skill's `SKILL.md` frontmatter states its anchor format, under
 * `metadata`: `metadata.pack.anchorFormat`, an integer beside `viewFormat`.
 * `renderSkillMd` writes both keys from it.
 */
export declare const ANCHOR_FORMAT_METADATA_PATH: readonly ['pack', 'anchorFormat'];
/** The file in a skill directory that holds the anchors and their explanations. */
export declare const ANCHORS_FILE = "anchors.md";
/**
 * The bounds a description is held to. The first three are the console's
 * prompt-reference bounds (`MAX_PROMPT_REFERENCE_DATA_BYTES`,
 * `MAX_PROMPT_REFERENCE_LABEL_CHARS`, `MAX_PROMPT_REFERENCES` in the fork's
 * `dsh-attachment`), restated because this repository builds against a release
 * without them; no test holds the two copies equal. `anchorKeyBytes` bounds
 * one key line's UTF-8 encoding.
 */
export declare const POINT_LIMITS: Readonly<{
    dataBytes: 8192;
    labelCodePoints: 64;
    referencesPerPrompt: 16;
    anchorKeyBytes: 8192;
}>;
//# sourceMappingURL=formats.d.ts.map