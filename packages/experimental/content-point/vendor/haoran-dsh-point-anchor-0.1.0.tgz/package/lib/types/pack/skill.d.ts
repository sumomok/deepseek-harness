/**
 * One exported skill's directory: `SKILL.md`, `anchors.md`, and the view files
 * it carries. {@link skillFiles} is the one source both exits are written
 * from, so the `.dshpack` archive and the organization request carry the same
 * bytes, and `metadata.requires.parts` and the request's `requires` come from
 * the same {@link requiredParts}.
 * @module @haoran/dsh-point-anchor/pack/skill
 */
import type { Anchor, NameWarning, Shown, What } from '../index.ts';
/** The skill-file name skill-pack reads a skill's manifest and body from. */
export declare const SKILL_FILE = "SKILL.md";
/** The component part a DataPage anchor needs on the console that reads it. */
export declare const DATA_PAGE_PART = "toy.data-page";
/**
 * The body of every exported `SKILL.md`: how to read `anchors.md`, and nothing
 * about the site. It is part of anchor format 1 and carries no version number.
 */
export declare const ANCHOR_READING_INSTRUCTIONS = "\u7528\u6237\u5728\u5185\u5BB9\u680F\u91CC\u6307\u7740\u67D0\u4E00\u5904\u65F6\uFF0C\u5BF9\u8BDD\u91CC\u4F1A\u6709\u4E00\u884C\u300C\u951A\u70B9\uFF1A`\u2026`\u300D\u3002\u6253\u5F00\u672C\u6280\u80FD\u76EE\u5F55\u91CC\u7684 anchors.md\uFF0C\u627E\u951A\u70B9\u90A3\u4E00\u884C\u4E0E\u5B83\u9010\u5B57\u76F8\u540C\u7684\u4E00\u8282\uFF0C\u6309\u90A3\u4E00\u8282\u7684\u8BB2\u89E3\u56DE\u7B54\uFF1B\u6CA1\u6709\u9010\u5B57\u76F8\u540C\u7684\u4E00\u8282\u65F6\uFF0C\u4E0D\u5957\u7528\u522B\u7684\u8282\u3002";
/** The heading `anchors.md` opens with. */
export declare const ANCHORS_TITLE = "# \u9875\u9762\u4E0A\u5404\u5904\u7684\u8BB2\u89E3";
/** One section of `anchors.md`: a picked place and the FDE's explanation of it. */
export interface AnchorEntry {
    /** The place's identity. */
    readonly anchor: Anchor;
    /** What kind of place it is, for the section heading. */
    readonly what: What;
    /** The display text the pick recorded. */
    readonly shown: Shown;
    /** The FDE's explanation: what the place is, when to use it, the site's own rules. */
    readonly explanation: string;
    /**
     * The warnings the pick gave the anchor — for the name it keeps, and for
     * the controls around a control in a cell or an item — as `parsePickResult`
     * read them; absent for none. They are shown at export and never written
     * into a skill.
     */
    readonly warnings?: readonly NameWarning[];
}
/** A view file a skill already has, written into the skill directory unchanged. */
export interface ViewFile {
    /** The skill-relative path, `/`-separated, ending in `.yml` or `.yaml`. */
    readonly path: string;
    /** The file's text. */
    readonly content: string;
}
/** Whether the model and the user may invoke a skill, as the organization request states it. */
export interface SkillInvocation {
    /** The model may load the skill. */
    readonly modelInvocable: boolean;
    /** The user may invoke the skill by name. */
    readonly userInvocable: boolean;
}
/** Everything one exported skill is written from. */
export interface ExportSkill {
    /** The skill name, which is also its directory name. */
    readonly name: string;
    /** The skill's description. */
    readonly description: string;
    /** When the model should load it. */
    readonly whenToUse?: string;
    /** `metadata.pack.version`: the skill's own exact semantic version, which skill-pack requires. */
    readonly version: string;
    /** `metadata.pack.platform`: a range over the console platform version. */
    readonly platform?: string;
    /** How the skill may be invoked; both true when omitted. */
    readonly invocation?: SkillInvocation;
    /** The sections of `anchors.md`, in the FDE's order. */
    readonly entries: readonly AnchorEntry[];
    /** View files the skill carries; `metadata.pack.viewFormat` is 1 whenever there is one. */
    readonly views?: readonly ViewFile[];
    /** Component parts the skill needs besides the ones its anchors imply. */
    readonly requiresParts?: readonly string[];
}
/** One file of a skill directory. */
export interface SkillFile {
    /** The skill-relative path. */
    readonly path: string;
    /** The file's text, which is written as UTF-8. */
    readonly content: string;
}
/** The invocation a skill states when it states none. */
export declare const DEFAULT_INVOCATION: SkillInvocation;
/**
 * Compare two strings by UTF-16 code unit, as skill-pack orders names.
 * @param left - the string that sorts first when the result is negative.
 * @param right - the string that sorts first when the result is positive.
 * @returns a negative number, a positive number, or zero.
 */
export declare function compareCodeUnits(left: string, right: string): number;
/**
 * The component parts a skill requires: `toy.data-page` when any anchor names
 * a DataPage, plus the ones the skill lists, without repeats, in code-unit
 * order.
 * @param skill - the skill.
 * @returns the parts, empty when none is needed.
 */
export declare function requiredParts(skill: ExportSkill): readonly string[];
/**
 * Write one skill's `SKILL.md`: the frontmatter fields in one fixed order with
 * every string as a JSON string literal (which YAML reads as a double-quoted
 * scalar), and the fixed reading instructions as the body.
 *
 * ```yaml
 * ---
 * name: "site-layers"
 * description: "…"
 * metadata:
 *   pack:
 *     version: "1.0.0"
 *     anchorFormat: 1
 *   requires:
 *     parts: ["toy.data-page"]
 * ---
 * ```
 *
 * `whenToUse`, `pack.platform`, `pack.viewFormat`, `requires` and `views` are
 * written only when they have a value. The `pack` key and the anchor format's
 * key are the two keys of `ANCHOR_FORMAT_METADATA_PATH`.
 * @param skill - the skill.
 * @returns the file's text, ending in one line break.
 */
export declare function renderSkillMd(skill: ExportSkill): string;
/**
 * Write `anchors.md`: one section per entry, in the given order, headed by the
 * place's label, then its key line in a code span, its display line, and the
 * explanation as a quotation.
 *
 * ```markdown
 * # 页面上各处的讲解
 *
 * ## 列「图层名称」
 * 锚点：`data-page model=layerInfo region=table part=header column=layerName`
 * 显示：侧栏「图层管理」 · 数据页「图层管理」 · 列「图层名称」
 *
 * > 讲解……
 * ```
 *
 * No author and no time is written: two exports of the same entries are the
 * same bytes, and no FDE's name reaches the customer's organization.
 * @param entries - the sections.
 * @returns the file's text, ending in one line break.
 */
export declare function renderAnchorsMd(entries: readonly AnchorEntry[]): string;
/**
 * Every file of one skill directory: `SKILL.md`, `anchors.md`, then its views
 * in code-unit order.
 * @param skill - the skill.
 * @returns the files.
 */
export declare function skillFiles(skill: ExportSkill): readonly SkillFile[];
//# sourceMappingURL=skill.d.ts.map