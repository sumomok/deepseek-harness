/**
 * The data this package passes between the page, the hosts, and the files it
 * writes: anchors, the description of one pointed-at place, and the
 * `PromptReference.data` object that description travels as. Types only.
 *
 * Every string field here is plain data the page produced; nothing carries an
 * element, a row index, a DOM position, or HTML.
 * @module @haoran/dsh-point-anchor/types
 */
/** A region of a DataPage as kit 0.4.6 names it, plus the two kit adds for the page itself. */
export type DataPageRegion = 'query' | 'toolbar' | 'table' | 'operate' | 'pagination' | 'infoCard' | 'addForm' | 'modifyForm' | 'noAuth' | 'page';
/** The part of a region a DataPage point names. */
export type DataPagePart = 'area' | 'button' | 'header' | 'cell' | 'row' | 'rowOperation' | 'field';
/** The toolbar buttons kit 0.4.6 recognizes. */
export type DataPageToolbarButton = 'add' | 'exp' | 'gridexp' | 'search' | 'clear';
/** The regions whose `field` part names a form item or an info-card attribute. */
export type DataPageFieldRegion = 'query' | 'addForm' | 'modifyForm' | 'infoCard';
/**
 * A place on a DataPage: the model's English name and the structural fields of
 * kit's `DataPagePoint`. Display names never take part — a customer who renames
 * a column keeps every anchor written against its property name.
 *
 * `operation` is `row:modify` for kit's own modify icon and `custom:<name>` for
 * a custom operation, `<name>` being its `customOperations` name.
 */
export type DataPageAnchor = {
    readonly kind: 'data-page';
    readonly model: string;
    readonly region: DataPageRegion;
    readonly part: 'area';
} | {
    readonly kind: 'data-page';
    readonly model: string;
    readonly region: 'toolbar';
    readonly part: 'button';
    readonly button: DataPageToolbarButton;
} | {
    readonly kind: 'data-page';
    readonly model: string;
    readonly region: 'table';
    readonly part: 'header' | 'cell';
    readonly column: string;
} | {
    readonly kind: 'data-page';
    readonly model: string;
    readonly region: 'table';
    readonly part: 'row';
} | {
    readonly kind: 'data-page';
    readonly model: string;
    readonly region: 'table';
    readonly part: 'rowOperation';
    readonly operation: string;
} | {
    readonly kind: 'data-page';
    readonly model: string;
    readonly region: DataPageFieldRegion;
    readonly part: 'field';
    readonly field: string;
};
/**
 * A place on an original-system page shown in a content-frame iframe, named
 * by the page's structure the way the console's page reader names it, never by
 * the records the page shows: the same element has the same anchor however
 * many rows the page has loaded and whichever record it has open.
 *
 * - `page` is the content-frame page id.
 * - `column` is the header text of the column a table cell or a control inside
 *   one sits in.
 * - `role` is the place's ARIA role, `clickable` for a click target the page
 *   gives no role, `icon` for an icon the reader reads as one of a table
 *   cell's or a repeated item's controls, or the reader's container type for
 *   a region.
 * - `name` is the reader's accessible name, kept only for a role in
 *   `NAMED_ROLES`: an interactive control outside a table cell and a repeated
 *   item, or a button, a link or a menu item inside one (`ITEM_NAMED_ROLES`,
 *   the only roles that keep a name beside a `column`), but a link alone in
 *   its cell or item — the one control there — which keeps none, since a
 *   column of values drawn as links would carry the record. A control whose
 *   name the browser may read from a field — one it holds, one a label of it
 *   holds, or one that an element its `aria-labelledby` names is or holds —
 *   carries none. A cell, a heading, an image, a status, an alert, a
 *   figure, a click target the page gives no role, an icon, a repeated item
 *   itself (a list item, a row, a tree node, an option, a feed article), a
 *   region, and every other control in a cell or an item carry no name.
 * - `mark` is the tokens of the mark the reader prints on the place's row —
 *   its class tokens, and for an `svg` pointing at a sprite symbol the symbol
 *   id after them — less every one `keptMarkToken` drops for its role,
 *   present wherever the anchor carries no name and a token is left, and
 *   never beside a name.
 * - `nth` is a 1-based position in document order among the places of its
 *   role carrying the same kept name or, without one, the same mark, counted
 *   inside the place's table cell (inside the list item or nested-table row in
 *   that cell holding it, when one does), else inside its nearest repeated
 *   item, else inside the nearest container the reader prints around it, and
 *   never across rows or items. A place that keeps no name carries it, but a
 *   link alone in its cell or item; a button or menu item in a cell or an item
 *   carries it only beside a sibling of its role carrying the same name, or
 *   the same mark when it has no name; any other interactive control outside
 *   cells and items carries none. A repeated item itself and a region carry
 *   none either: their position depends on the data.
 * - `in` is the type of the nearest region around it, a tree node, a menu
 *   item and a click target holding items passed over, never that region's
 *   name.
 */
export interface FrameAnchor {
    /** Discriminant. */
    readonly kind: 'frame';
    /** The content-frame page id. */
    readonly page: string;
    /** The column header text, for a table cell or a control inside one. */
    readonly column?: string;
    /** The role, `clickable`, `icon`, or a container type. */
    readonly role: string;
    /** The reader's accessible name, for a role in `NAMED_ROLES` only. */
    readonly name?: string;
    /** The row mark's tokens `keptMarkToken` keeps for the role, only where the anchor carries no name. */
    readonly mark?: string;
    /** The place's position among its siblings of its role and kept name or mark in its cell, item or region. */
    readonly nth?: number;
    /** The type of the nearest region around the row. */
    readonly in?: string;
}
/** The drawings a picture anchor names. */
export type PictureTag = 'canvas' | 'svg' | 'object' | 'video';
/**
 * A drawing on an original-system page: one picture, named by its tag, its
 * class tokens as a frame anchor's `mark` keeps them, its 1-based position
 * among the drawings of its tag and mark in its nearest repeated item or else
 * its region, and the type of that region. What the page wrote on the drawing
 * — a chart labelled 「张三的销售额」 — is never carried.
 */
export interface PictureAnchor {
    /** Discriminant. */
    readonly kind: 'picture';
    /** The content-frame page id. */
    readonly page: string;
    /** The drawing's tag. */
    readonly tag: PictureTag;
    /** The row mark's tokens `keptMarkToken` keeps for the tag. */
    readonly mark?: string;
    /** The drawing's position among the drawings of its tag and mark in its item or region. */
    readonly nth: number;
    /** The type of the nearest region around it. */
    readonly in?: string;
}
/** One sidebar navigation entry: a content-frame page (`page`) or a component-surface view (`view`). */
export interface NavAnchor {
    /** Discriminant. */
    readonly kind: 'nav';
    /** Which catalog the entry comes from. */
    readonly nav: 'page' | 'view';
    /** The entry id in that catalog. */
    readonly id: string;
}
/** Every anchor of format 1. */
export type Anchor = DataPageAnchor | FrameAnchor | PictureAnchor | NavAnchor;
/**
 * What kind of place a description is about, which selects the words its label
 * is written in. It is present whether or not the place has an anchor.
 */
export type What = {
    readonly kind: 'data-page';
    readonly region: DataPageRegion;
    readonly part: DataPagePart;
} | {
    readonly kind: 'frame';
    readonly role: string;
} | {
    readonly kind: 'picture';
    readonly tag: PictureTag;
} | {
    readonly kind: 'nav';
};
/**
 * Display text around a place, for people and for the line of model text that
 * repeats it. None of it takes part in matching. Each value is cleaned by
 * `sanitizeLabel` to at most 64 code points.
 */
export interface Shown {
    /** The title of the content column's current entry. */
    readonly page?: string;
    /** The sidebar entry's title, when the current entry is one. */
    readonly nav?: string;
    /** What the place itself is called: a column, button, field, or control name. */
    readonly target?: string;
}
/** Why a described place has no anchor. */
export type Unanchored = 'no-column' | 'nameless' | 'too-large';
/**
 * One pointed-at place, as the page describes it and as `PromptReference.data`
 * carries it. Exactly one of `anchor` and `unanchored` is present.
 *
 * `row` is the DataPage row a cell, row, or row operation belongs to, keyed by
 * property name in the page's own column order; it is present only when the
 * description was made for a reference, never for an anchor.
 */
export interface PointDescription {
    /** The describe format this object is written in. */
    readonly v: number;
    /** The anchor format `anchor` is written in. */
    readonly anchorFormat: number;
    /** What kind of place this is. */
    readonly what: What;
    /** The place's identity. */
    readonly anchor?: Anchor;
    /** Why the place has no identity. */
    readonly unanchored?: Unanchored;
    /** Display text around the place. */
    readonly shown: Shown;
    /** The DataPage row, for a reference. */
    readonly row?: Readonly<Record<string, string>>;
    /** How many trailing columns were left out of `row` to keep `data` within its byte bound. */
    readonly rowOmitted?: number;
}
/** The `data` of one `PromptReference`: a description as JSON. */
export type PointData = PointDescription;
/** The three fields of a `PromptReference`, spelled out here because the plugin repository builds against a release without them. */
export interface PointReference {
    /** Owner name, `[A-Za-z0-9_.-]{1,64}`. */
    readonly source: string;
    /** The attachment-row label: 1–64 code points, no control, format, or unpaired surrogate characters. */
    readonly label: string;
    /** The description. */
    readonly data: PointData;
}
/** One parse that either produced a value or names why not. */
export type Parsed<T> = {
    readonly ok: true;
    readonly value: T;
} | {
    readonly ok: false;
    readonly field: string;
    readonly reason: string;
};
//# sourceMappingURL=types.d.ts.map