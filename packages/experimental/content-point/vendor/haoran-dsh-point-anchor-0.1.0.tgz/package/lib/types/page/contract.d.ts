/**
 * Every attribute, class, and component name this package reads from the
 * console's DOM, in one place, so the product can pin each of them to the
 * component that writes it.
 * @module @haoran/dsh-point-anchor/page/contract
 */
/**
 * The console DOM this package reads.
 *
 * - `surfaceEntryAttr` / `surfaceSelectedAttr`: the content column's switcher
 *   button for each entry, valued `<kind> <entryId>`, and the mark on the
 *   selected one (content-column `ContentSurface`).
 * - `surfaceSeatAttr`: the seat of one entry kind (`page`, `component`, …).
 * - `frameAttr` / `frameIdAttr` / `frameActiveAttr`: a content-frame iframe,
 *   its id `<sessionId> <pageId>`, and the mark on the one shown
 *   (content-frame `ContentFrame`).
 * - `navKindAttr` / `navEntryAttr`: a sidebar navigation button's catalog kind
 *   and its entry id (server-sidebar `NavGroup`; the entry id is written by a
 *   product change this package depends on).
 * - `dataPageClass` / `dataPageName`: a DataPage's root class and component
 *   name (toy-crud-kit 0.4.6).
 * - `kitBoxAttr`: the box toy-crud-kit moves a DataPage's popups into.
 * - `markerAttr`: the `documentElement` attribute the point-at-it plugin writes
 *   with the formats it reads.
 * - `pageKind` / `componentKind`: the two entry kinds that have a describer.
 */
export declare const DOM_CONTRACT: Readonly<{
    readonly surfaceEntryAttr: "data-content-surface-entry";
    readonly surfaceSelectedAttr: "data-content-surface-selected";
    readonly surfaceSeatAttr: "data-content-surface-seat";
    readonly frameAttr: "data-content-frame";
    readonly frameIdAttr: "data-content-frame-id";
    readonly frameActiveAttr: "data-content-active";
    readonly navKindAttr: "data-server-sidebar-nav-kind";
    readonly navEntryAttr: "data-server-sidebar-nav-entry";
    readonly dataPageClass: "toy-data-page";
    readonly dataPageName: "ToyDataPage";
    readonly kitBoxAttr: "data-toy-crud-box";
    readonly markerAttr: "data-dsh-point";
    readonly pageKind: "page";
    readonly componentKind: "component";
}>;
//# sourceMappingURL=contract.d.ts.map