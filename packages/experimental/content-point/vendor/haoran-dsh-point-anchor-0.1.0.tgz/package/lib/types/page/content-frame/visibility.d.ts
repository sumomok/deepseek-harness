/**
 * The visibility the console's reader injects into every read it runs.
 *
 * Copied from deepseek-harness `packages/experimental/content-frame/src/client/access/executor.ts`
 * (`viewOf`, `MaybeCheckable`, `visibleByStyle`, `isVisible`) at 6822829a2f,
 * Copyright (c) 2026 DeepSeek, MIT License (see THIRD-PARTY-LICENSES.txt).
 * Only this header, the module tag, and the error message's package name differ
 * from the source.
 * @module @haoran/dsh-point-anchor/page/content-frame/visibility
 */
/**
 * Injected visibility: the browser's own answer where there is one.
 *
 * `checkVisibility` also covers `content-visibility` and collapsed subtrees,
 * which the style walk cannot see; the walk stands in under a DOM
 * implementation that does not provide it.
 * @param el - the element to test.
 * @returns whether the element is visible.
 */
export declare function isVisible(el: Element): boolean;
//# sourceMappingURL=visibility.d.ts.map