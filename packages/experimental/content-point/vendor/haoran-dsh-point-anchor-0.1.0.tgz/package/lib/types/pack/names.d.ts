/**
 * The names an export's key lines keep, which the FDE confirms one by one
 * before either exit writes anything: the describer keeps an interactive
 * control's accessible name, a button's, a link's and a menu item's in a cell
 * or an item included — a link alone in its cell or item keeps none — and
 * only the FDE can tell a page's word (「保存」, 「审核」) from a record's
 * (「删除张三」, a name column's button 「张三」).
 * {@link listKeptNames} lists them with the warnings the picks gave, those
 * with a warning first, and {@link checkConfirmedNames} refuses an export
 * whose confirmed list is not exactly that list.
 * @module @haoran/dsh-point-anchor/pack/names
 */
import type { NameWarning } from '../index.ts';
import type { ExportViolation } from './check.ts';
import type { ExportSkill } from './skill.ts';
/** One name a key line keeps, as the FDE is shown it. */
export interface KeptName {
    /** The skill whose `anchors.md` holds the key line. */
    readonly skill: string;
    /** The key line. */
    readonly key: string;
    /** The name it keeps. */
    readonly name: string;
    /** The warnings of the pick that made it, with `name-digits` for a name holding a digit; empty for none. */
    readonly warnings: readonly NameWarning[];
}
/** One name the FDE confirmed: the skill, the key line and the name of a {@link KeptName}. */
export type ConfirmedName = Pick<KeptName, 'skill' | 'key' | 'name'>;
/**
 * Every name the key lines of an export keep: one per entry whose frame
 * anchor carries a `name`, the entries with a warning first and each group in
 * skill order and then entry order. Column texts and marks are not names, and
 * an entry keeping no name is not listed whatever warnings it carries;
 * `checkExport` reports those.
 * @param skills - every skill of the export.
 * @returns the names, empty when no key line keeps one.
 */
export declare function listKeptNames(skills: readonly ExportSkill[]): readonly KeptName[];
/**
 * Check the list the FDE confirmed against the names the export keeps: every
 * kept name must be confirmed once, and nothing else. Order does not matter.
 * @param skills - every skill of the export.
 * @param confirmed - the names the FDE confirmed.
 * @returns one `unconfirmed-names` error per name kept and not confirmed,
 *   confirmed and not kept, or confirmed twice; empty when the lists agree.
 */
export declare function checkConfirmedNames(skills: readonly ExportSkill[], confirmed: readonly ConfirmedName[]): readonly ExportViolation[];
//# sourceMappingURL=names.d.ts.map