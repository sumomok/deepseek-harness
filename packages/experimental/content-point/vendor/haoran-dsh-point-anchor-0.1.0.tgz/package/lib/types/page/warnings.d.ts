/**
 * The warnings a pick gives its anchor, read off the page at the moment of
 * the pick: `name-in-data` when the name it keeps and a text the page shows
 * where records are drawn overlap, `name-digits` when that name holds a
 * decimal digit, and `mixed-cell-controls` when it names a link in a cell or
 * an item whose column or run of items holds both a link alone and two
 * controls or more (see `mixesHeldControls`). The text read stays in this
 * function; only the warning types leave it.
 *
 * A data text is a run of text in a table cell outside a `<thead>`, a repeated
 * item (a list item, a row, an option, a tree node, a feed article), a heading
 * or a description list's value (`<dd>`), together with the whole of each such
 * place's data runs: on a detail page a heading and a description's value hold
 * the record. The text of a button or a link there counts, the picked
 * control's own included — a page draws a record's value as a button as often
 * as as text, as Element UI's `el-button type="text"` name columns do.
 *
 * A run is structure rather than data when the nearest repeated item around
 * it — a table row, whose siblings are the rows of its table body, a list
 * item, an option, a tree node, a feed article — has at least one sibling
 * item the page shows (the visible items under its parent, itself among them,
 * number at least two), and every one of those items, itself included, shows
 * a run of exactly that text somewhere inside it: 「编辑」 and 「删除」 on every
 * row are the page's words, while 「审核」 on the pending rows alone, or each
 * row's own 「张三」, is data. With no such sibling the structure cannot be
 * told, and every run is data. So a name kept in a cell or an item warns
 * unless every sibling shows it, and so does a name elsewhere that some rows'
 * buttons show and others' do not (a toolbar's 「删除」 beside rows offering
 * 「删除」 only some of the time). Text the page hides and text inside a
 * drawing are left out. The name and a data text overlap when either holds the
 * other, whitespace left out of both, the shorter at least
 * {@link DATA_TEXT_MIN_CODE_POINTS} long.
 * @module @haoran/dsh-point-anchor/page/warnings
 */
import type { Anchor, NameWarning } from '../index.ts';
import type { FrameEnv, FrameIndex } from './frame.ts';
/**
 * The shortest text, in code points with whitespace left out, the comparison
 * reads: a data text the name may hold, and a name a data text may hold. A
 * single character — 「删」, 「张」, 「是」, 「1」 — is part of ordinary words
 * and would warn of almost every name; two characters is the length of the
 * shortest common record value, a two-character Chinese name such as 「张三」.
 */
export declare const DATA_TEXT_MIN_CODE_POINTS = 2;
/**
 * The warnings one picked anchor carries, in {@link NAME_WARNINGS} order.
 * @param anchor - the anchor the pick produced.
 * @param picked - the element the place covers.
 * @param env - the injections the pick runs under; the browser's when omitted.
 * @param index - the rows of the frame document the pick described the place from; a fresh walk under `env` when omitted.
 * @returns the warnings, empty for an anchor of no other kind than a frame's.
 */
export declare function nameWarnings(anchor: Anchor, picked: Element, env?: FrameEnv, index?: FrameIndex): readonly NameWarning[];
//# sourceMappingURL=warnings.d.ts.map