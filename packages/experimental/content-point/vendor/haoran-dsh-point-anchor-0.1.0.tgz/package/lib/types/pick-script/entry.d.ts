/**
 * The pick script's own code, which the build bundles with everything it
 * imports into one self-contained IIFE string, `PICK_SCRIPT`. The Beiming
 * shell evaluates that string once in the main world of the view's main frame
 * — the content column's frames are same-origin and read through it — and the
 * evaluation's value is the promise {@link run} returns.
 *
 * It sends nothing, stores nothing, and posts no message. It leaves one slot
 * on the window, under `Symbol.for('dsh.point.pick')`, holding the running
 * pick's `cancel`; a second evaluation cancels the first through it, and the
 * slot is removed when the pick ends. No row value reaches the result: the
 * pick describes for an anchor, and of the page's text it reads for warnings
 * only the warning types reach it.
 * @module @haoran/dsh-point-anchor/pick-script/entry
 */
import type { PickResult } from './result.ts';
/**
 * Run one pick on the current page.
 * @returns the pick's result; a refusal when the console carries no readable
 *   point-at-it marker or its marker lists no anchor format this script writes.
 */
export declare function run(): Promise<PickResult>;
//# sourceMappingURL=entry.d.ts.map